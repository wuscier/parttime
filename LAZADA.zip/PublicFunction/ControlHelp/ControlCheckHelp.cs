﻿using PublicFunction.AlertHelp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PublicFunction.ControlHelp
{
    public class ControlCheckHelp
    {
        /// <summary>
        /// 判断非空
        /// </summary>
        /// <param name="txt"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        public bool CheckControlIsEmpty(TextBox txt,PasswordBox pwd)
        {
            if (txt.Text.Trim() == string.Empty)
            {
                //MyMessageBox.ShowEmptyPrompt(txt.Tag);
                txt.Focus();
                return false;
            }
            if (pwd.Password.Trim()==string.Empty)
            {
                //MyMessageBox.ShowEmptyPrompt(pwd.Password);
                pwd.Focus();
                return false;
            }
            return true;
        }
        /// <summary>
        /// 判断TextBox控件是否为空
        /// </summary>
        /// <param name="txt"></param>
        /// <returns></returns>
        public bool CheckTextBox(TextBox txt)
        {
            if (txt.Text.Trim() == string.Empty)
            {
                txt.BorderBrush = Brushes.Red;
                return false;
            }
            return true;
        }
        /// <summary>
        /// 检查目录
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public bool CheckDirectory(string filename)
        {
            if (System.IO.Directory.Exists(filename.Trim()))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// 查找文件
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public bool CheckFile(string filename)
        {
            if (File.Exists(filename.Trim()))
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// 判断长度
        /// </summary>
        /// <param name="txtLoginName"></param>
        /// <returns></returns>
        public bool CheckLength(TextBox txtLoginName,int Minlength,int Maxlength)
        {
            if (txtLoginName.Text.Length< Minlength || txtLoginName.Text.Length> Maxlength)
            {
                txtLoginName.Focus();
                return false;
            }
            return true;
        }

        public bool CheckPwdLength(PasswordBox pwd, int minlength, int maxlength)
        {
            if (pwd.Password.Length<minlength||pwd.Password.Length>maxlength)
            {
                pwd.Focus();
                return false;
            }
            return true;
        }
        
    }
}
