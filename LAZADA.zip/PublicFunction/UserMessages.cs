﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PublicFunction
{
   public class UserMessages
    {
        public string LoginName { get; set; }//用户名

        public string Pwd { get; set; }//密码

        public string Author { get; set; }//站点

        public string Hardiskid { get; set; }//磁盘序列号

        public string Ip { get; set; }//ip

        public string Version { get; set; }//版本号
    }
}
