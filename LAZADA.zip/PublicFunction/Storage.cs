﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction
{
    /// <summary>
    /// 数据存储
    /// </summary>
   public class Storage
    {
        #region 初始化
        private static Dictionary<object, object> StorageData;
        /// <summary>
        /// 初始化
        /// </summary>
        public static void Initialize()
        {
            StorageData = new Dictionary<object, object>();
        }
        #endregion


        /// <summary>
        /// 保存数据
        /// </summary>
        public static void SaveData<T>(object key, T data)
        {
            if (StorageData.ContainsKey(key))
            {
                //存在这个Key所以更新数据
                StorageData[key] = data;
            }
            else
            {
                StorageData.Add(key, data);
            }
            //return true;
        }

        /// <summary>
        /// 查找数据
        /// </summary>
        public static T GetData<T>(string name)
        {
            if (StorageData.ContainsKey(name))
            {
                if (StorageData[name] is T data)
                {
                    return data;
                }
            }
            return default;
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        public static bool DelData<T>(string name)
        {
            return StorageData.Remove(name);
        }

        /// <summary>
        /// 销毁
        /// </summary>
        public static void Destroy()
        {
            StorageData.Clear();
        }
    }
}
