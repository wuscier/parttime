﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PublicFunction.SaveHelp
{
    public class SQLiteHelp
    {
        /// <summary>
        /// SQLite链接对象
        /// </summary>
        private SQLiteConnection conn;
        private SQLiteCommand cmd;

        /// <summary>
        /// 创建查询命令
        /// </summary>
        /// <param name="commandText">查询语句</param>
        /// <param name="commandParameters">参数数组</param>
        private void CreateCommand(string commandText, SQLiteParameter[] commandParameters)
        {
            cmd = new SQLiteCommand(commandText, conn);
            if (commandParameters != null)
            {
                cmd.Parameters.AddRange(commandParameters);
            }
        }

        /// <summary>
        /// 增删改方法
        /// </summary>
        /// <param name="commandText">查询语句</param>
        /// <param name="paramList">参数数组</param>
        /// <returns></returns>
        public int ExecuteNonQuery(string commandText, SQLiteParameter[] paramList = null)
        {
            try
            {
                int result = 0;
                using (conn = new SQLiteConnection(Constants.SQLiteConnStr))
                {
                    conn.Open();
                    CreateCommand(commandText, paramList);
                    result = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    conn.Close();
                    return result;
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return 0;
            }
        }

        #region ExecuteScalar(commandText,paramList)
        /// <summary>
        /// 执行ExecuteScalar
        /// </summary>
        /// <param name="commandText">语句s</param>
        /// <param name="paramList">参数</param>
        /// <returns></returns>
        public static object ExecuteScalar(string commandText, params object[] paramList)
        {
            SQLiteConnection cn = new SQLiteConnection(Constants.SQLiteConnStr);
            SQLiteCommand cmd = cn.CreateCommand();
            cmd.CommandText = commandText;
            AttachParameters(cmd, commandText, paramList);
            if (cn.State == ConnectionState.Closed)
                cn.Open();
            object result = cmd.ExecuteScalar();
            cmd.Dispose();
            cn.Close();
            return result;
        }
        #endregion
        #region AttachParameters(SQLiteCommand,commandText,object[] paramList)
        /// <summary>
        /// 增加参数到命令（自动判断类型）
        /// </summary>
        /// <param name="commandText">命令语句</param>
        /// <param name="paramList">object参数列表</param>
        /// <returns>返回SQLiteParameterCollection参数列表</returns>
        /// <remarks>Status experimental. Regex appears to be handling most issues. Note that parameter object array must be in same ///order as parameter names appear in SQL statement.</remarks>
        private static SQLiteParameterCollection AttachParameters(SQLiteCommand cmd, string commandText, params object[] paramList)
        {
            if (paramList == null || paramList.Length == 0) return null;

            SQLiteParameterCollection coll = cmd.Parameters;
            string parmString = commandText.Substring(commandText.IndexOf("@"));
            // pre-process the string so always at least 1 space after a comma.
            parmString = parmString.Replace(",", " ,");
            // get the named parameters into a match collection
            string pattern = @"(@)\S*(.*?)\b";
            Regex ex = new Regex(pattern, RegexOptions.IgnoreCase);
            MatchCollection mc = ex.Matches(parmString);
            string[] paramNames = new string[mc.Count];
            int i = 0;
            foreach (Match m in mc)
            {
                paramNames[i] = m.Value;
                i++;
            }

            // now let's type the parameters
            int j = 0;
            Type t = null;
            foreach (object o in paramList)
            {
                t = o.GetType();

                SQLiteParameter parm = new SQLiteParameter();
                switch (t.ToString())
                {

                    case ("DBNull"):
                    case ("Char"):
                    case ("SByte"):
                    case ("UInt16"):
                    case ("UInt32"):
                    case ("UInt64"):
                        throw new SystemException("Invalid data type");


                    case ("System.String"):
                        parm.DbType = DbType.String;
                        parm.ParameterName = paramNames[j];
                        parm.Value = (string)paramList[j];
                        coll.Add(parm);
                        break;

                    case ("System.Byte[]"):
                        parm.DbType = DbType.Binary;
                        parm.ParameterName = paramNames[j];
                        parm.Value = (byte[])paramList[j];
                        coll.Add(parm);
                        break;

                    case ("System.Int32"):
                        parm.DbType = DbType.Int32;
                        parm.ParameterName = paramNames[j];
                        parm.Value = (int)paramList[j];
                        coll.Add(parm);
                        break;

                    case ("System.Boolean"):
                        parm.DbType = DbType.Boolean;
                        parm.ParameterName = paramNames[j];
                        parm.Value = (bool)paramList[j];
                        coll.Add(parm);
                        break;

                    case ("System.DateTime"):
                        parm.DbType = DbType.DateTime;
                        parm.ParameterName = paramNames[j];
                        parm.Value = Convert.ToDateTime(paramList[j]);
                        coll.Add(parm);
                        break;

                    case ("System.Double"):
                        parm.DbType = DbType.Double;
                        parm.ParameterName = paramNames[j];
                        parm.Value = Convert.ToDouble(paramList[j]);
                        coll.Add(parm);
                        break;

                    case ("System.Decimal"):
                        parm.DbType = DbType.Decimal;
                        parm.ParameterName = paramNames[j];
                        parm.Value = Convert.ToDecimal(paramList[j]);
                        break;

                    case ("System.Guid"):
                        parm.DbType = DbType.Guid;
                        parm.ParameterName = paramNames[j];
                        parm.Value = (System.Guid)(paramList[j]);
                        break;

                    case ("System.Object"):

                        parm.DbType = DbType.Object;
                        parm.ParameterName = paramNames[j];
                        parm.Value = paramList[j];
                        coll.Add(parm);
                        break;

                    default:
                        throw new SystemException("Value is of unknown data type");

                } // end switch

                j++;
            }
            return coll;
        }
        #endregion

        #region CreateCommand(commandText,SQLiteParameter[])
        /// <summary>
        /// 创建命令
        /// </summary>
        /// <param name="connection">连接</param>
        /// <param name="commandText">语句</param>
        /// <param name="commandParameters">语句参数.</param>
        /// <returns>SQLite Command</returns>
        public static SQLiteCommand CreateCommands(string commandText, params SQLiteParameter[] commandParameters)
        {
            SQLiteConnection cn = new SQLiteConnection(Constants.SQLiteConnStr);
            SQLiteCommand cmd = new SQLiteCommand(commandText, cn);
            if (commandParameters.Length > 0)
            {
                foreach (SQLiteParameter parm in commandParameters)
                    cmd.Parameters.Add(parm);
            }
            return cmd;
        }
        #endregion

        #region ExecuteNonQuery(IDbCommand)
        /// <summary>
        /// 执行ExecuteNonQuery方法
        /// </summary>
        /// <param name="cmd">创建好的命令.</param>
        /// <returns></returns>
        public static int ExecuteNonQuery(IDbCommand cmd)
        {
            if (cmd.Connection.State == ConnectionState.Closed)
                cmd.Connection.Open();
            int result = cmd.ExecuteNonQuery();
            cmd.Connection.Close();
            cmd.Dispose();
            return result;
        }
        #endregion

        /// <summary>
        /// 查询首行首列
        /// </summary>
        /// <typeparam name="T">泛型参数</typeparam>
        /// <param name="commandText">查询语句</param>
        /// <param name="paramList">参数数组</param>
        /// <returns></returns>
        public T ExecuteScalar<T>(string commandText, SQLiteParameter[] paramList = null)
        {
            try
            {
                using (conn = new SQLiteConnection(Constants.SQLiteConnStr))
                {
                    conn.Open();
                    CreateCommand(commandText, paramList);
                    var result = (T)cmd.ExecuteScalar();
                    cmd.Dispose();
                    conn.Close();
                    return result;
                }

            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return default;
            }
        }

        /// <summary>
        /// 获取集合列表
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText"></param>
        /// <param name="paramList"></param>
        /// <returns></returns>
        public List<T> GetList<T>(string commandText, SQLiteParameter[] paramList = null) where T : class, new()
        {
            var name = "";
            try
            {
                using (conn = new SQLiteConnection(Constants.SQLiteConnStr))
                {
                    conn.Open();
                    CreateCommand(commandText, paramList);
                    var reader = cmd.ExecuteReader();
                    var list = new List<T>();
                    PropertyInfo[] properties = typeof(T).GetProperties();
                    while (reader.Read())
                    {
                        T t = new T();
                        foreach (var p in properties)
                        {
                            try
                            {
                                name = p.Name;
                                var value = reader[p.Name];
                                if (value == DBNull.Value)
                                {
                                    value = p.GetType().IsValueType ? Activator.CreateInstance(p.GetType()) : null;
                                }
                                p.SetValue(t, value);
                            }
                            catch(Exception ex)
                            { }
                        }
                        list.Add(t);
                    }
                    reader.Close();
                    cmd.Dispose();
                    conn.Close();
                    return list;
                }

            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return new List<T>();
            }
        }

        /// <summary>
        /// 获取string集合列表
        /// </summary>
        /// <param name="commandText"></param>
        /// <param name="paramList"></param>
        /// <returns></returns>
        public List<string[]> GetList(string commandText, SQLiteParameter[] paramList = null)
        {
            try
            {
                var list = new List<string[]>();
                using (conn = new SQLiteConnection(Constants.SQLiteConnStr))
                {
                    conn.Open();
                    CreateCommand(commandText, paramList);
                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        var str = new string[3];
                        str[0] = reader[0].ToString();
                        str[1] = reader[1].ToString();
                        str[2] = reader[2].ToString();
                        list.Add(str);
                    }
                    reader.Close();
                    cmd.Dispose();
                    conn.Close();
                }

                return list;
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return new List<string[]>();
            }
        }

        public  DataSet ExecuteDataSet(string commandText)
        {
            DataSet ds = new DataSet();
            try
            {
                var list = new List<string[]>();
                using (conn = new SQLiteConnection(Constants.SQLiteConnStr))
                {
                    conn.Open();
                    CreateCommand(commandText, null);
                    SQLiteDataAdapter da = new SQLiteDataAdapter(cmd);
                    da.Fill(ds);
                    da.Dispose();
                    cmd.Dispose();
                    conn.Close();
                }

                return ds;
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return null;
            }
        }


    }
}
