﻿using PublicFunction.AlertHelp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.SaveHelp
{
    public class IOHelp
    {
        public string CheckDirectory(string path)
        {
            if (!System.IO.Directory.Exists(path))
            {
                return "当前图片保存路径无效";
            }
            return "";
        }

        /// <summary>
        /// 写入ACT文件
        /// </summary>
        /// <param name="path"></param>
        /// <param name="content"></param>
        public void SaveActFile(string path, string content)
        {
            try
            {
                FileStream fst3 = new FileStream(path, FileMode.OpenOrCreate);
                StreamWriter sw3 = new StreamWriter(fst3, System.Text.Encoding.Default);
                //清空后再写
                fst3.Seek(0, SeekOrigin.Begin);
                fst3.SetLength(0); //清空txt文件

                sw3.WriteLine(content);
                sw3.Flush();
                sw3.Close();
                fst3.Close();
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine("写入act文件报错：" + ex.Message);
            }
        }

        /// <summary>
        /// 根据路径读取ACT文件
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public string ReadActFile(string path)
        {
            string rs = "";
            try
            {
                //读一个文本
                FileStream fsfyc = new FileStream(path, FileMode.OpenOrCreate);
                //读文本
                StreamReader swtfyc = new StreamReader(fsfyc, System.Text.Encoding.Default);
                rs = swtfyc.ReadToEnd().Trim();
                swtfyc.Close();
                fsfyc.Close();
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine("读取act文件报错：" + ex.Message);
            }
            return rs;
        }
    }
}
