﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace PublicFunction
{
    /// <summary>
    /// 公共方法
    /// </summary>
    public class PublicFunctions
    {
        /// <summary>
        /// 随机验证码生成函数
        /// </summary>
        /// <returns></returns>
        public static string CreateRandomCode()
        {
            string allChar = "0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z";
            string[] allCharArray = allChar.Split(',');
            string randomNum = "";
            int temp = -1;
            Random rand = new Random();
            for (int i = 0; i < 4; i++)
            {
                if (temp != -1)
                {
                    rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
                }
                int t = rand.Next(62);//不要数字的去掉，然后这里做相应修改
                randomNum += allCharArray[t];
            }
            return randomNum;
        }


        /// <summary>
        /// 单词首字母大字并保留单个空格,用个符号分隔的返回时用该符号拼起来
        /// </summary>
        /// <param name="_str"></param>
        /// <param name="_splitor"></param>
        /// <returns></returns>
        public static string upFirstCharWithSpaceWithSplitor(string _str, char _splitor,bool size=true)
        {
            if (_str.Trim() == "") return "";

            _str = _str.Trim();

            string[] words = _str.Split(new char[] { _splitor }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                words[i] = size? upFirstCharWithSpace(words[i]): words[i];

            }

            return string.Join(" " + _splitor.ToString() + " ", words.Distinct().ToArray());
        }

        public static string upFirstCharWithSpace(string _str)
        {
            if (_str.Trim() == "") return " ";
            string[] words = _str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > 1)
                {
                    words[i] = words[i].Substring(0, 1).ToUpper() + words[i].Substring(1).ToLower();
                }
                else
                {

                    words[i] = words[i].ToUpper();
                }
            }

            return string.Join(" ", words);
        }
        //取第一块硬盘编号   
        public static String GetHardDiskID()
        {
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia");
                String strHardDiskID = null;
                foreach (ManagementObject mo in searcher.Get())
                {
                    strHardDiskID = mo["SerialNumber"].ToString().Trim();
                    break;
                }
                return strHardDiskID;
            }
            catch
            {
                return GetMACSerialNumber();
            }
        }//end  



        /// 获取网卡序列号
        public static string GetMACSerialNumber()
        {
            try
            {

                string SerialNumberStr = "";

                ManagementClass mana = new ManagementClass("Win32_NetworkAdapterConfiguration");

                ManagementObjectCollection Moc = mana.GetInstances();

                foreach (ManagementObject mo in Moc)
                {

                    if (Convert.ToBoolean(mo["IPEnabled"]))
                    {
                        SerialNumberStr = mo["MacAddress"].ToString();///网卡序列号
                        break;
                    }
                    //mo.Properties["MacAddress"].Value.ToString(); 

                }

                return SerialNumberStr;
            }
            catch
            {
                return "unknow";
            }
        }

        /// <summary>
        /// 首字母大写去空格
        /// </summary>
        /// <param name="a"></param>
        /// <returns></returns>
        public static string ATjWj6oy0m(string a)
        {
            bool flag = a.Trim() == "";
            string result;
            if (flag)
            {
                result = "";
            }
            else
            {
                string[] array = a.Split(new char[]
                {
                    ' '
                }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < array.Length; i++)
                {
                    bool flag2 = array[i].Length > 1;
                    if (flag2)
                    {
                        array[i] = array[i].Substring(0, 1).ToUpper() + array[i].Substring(1).ToLower();
                    }
                    else
                    {
                        array[i] = array[i].ToUpper();
                    }
                }
                result = string.Join("", array);
            }
            return result;
        }

        /// <summary>
        /// 控件绕中心旋转动画
        /// </summary>
        /// <param name="element">控件名</param>
        /// <param name="anglefrom">开始角度</param>
        /// <param name="angleto">结束角度</param>
        /// <param name="power">过渡强度1为不用过渡</param>
        /// <param name="time">持续时间，例如3秒： TimeSpan(0,0,3) </param>
        public  void AngleEasingAnimationShow(UIElement element, double anglefrom, double angleto, int power, TimeSpan time)
        {
            RotateTransform angle = new RotateTransform();  //旋转
            element.RenderTransform = angle;
            //定义圆心位置
            element.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
            //定义过渡动画,power为过度的强度
            EasingFunctionBase easeFunction = new PowerEase()
            {
                EasingMode = EasingMode.EaseInOut,
                Power = power
            };

            DoubleAnimation angleAnimation = new DoubleAnimation()
            {
                From = anglefrom,                                   //起始值
                To = angleto,                                     //结束值
                FillBehavior = FillBehavior.HoldEnd,
                Duration = time,                                 //动画播放时间
            };
            angle.BeginAnimation(RotateTransform.AngleProperty, angleAnimation);
        }
    }
}
