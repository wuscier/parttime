﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace PublicFunction.SiteImgRequestHelp
{
  public  class SiteImgModeConvert
    {
        /// <summary>
        /// 设置站点名称
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static string SetSiteName(SiteImgMode name)
        {
            switch (name)
            {
                case SiteImgMode.MYImg:
                    return "马来西亚";
                case SiteImgMode.PHImg:
                    return "菲律宾";
                case SiteImgMode.THImg:
                    return "泰国";
                case SiteImgMode.SgImg:
                    return "新加坡";
                case SiteImgMode.IDImg:
                    return "印度尼西亚";
                case SiteImgMode.VNImg:
                    return "越南";
                case SiteImgMode.CrbImg:
                    return "六合一";
                default:
                    return "未选择站点";
            }
        }

        /// <summary>
        /// 设置站点图片
        /// </summary>
        /// <param name="img"></param>
        /// <returns></returns>
        public static BitmapImage SetSiteImg(SiteImgMode img)
        {
            switch (img)
            {
                case SiteImgMode.MYImg:
                    return new BitmapImage(new Uri("Images/MYIMG.png", UriKind.RelativeOrAbsolute));
                case SiteImgMode.PHImg:
                    return new BitmapImage(new Uri("Images/PHIMG.png", UriKind.RelativeOrAbsolute));
                case SiteImgMode.THImg:
                    return new BitmapImage(new Uri("Images/THIMG.png", UriKind.RelativeOrAbsolute));
                case SiteImgMode.SgImg:
                    return new BitmapImage(new Uri("Images/SGIMG.png", UriKind.RelativeOrAbsolute));
                case SiteImgMode.IDImg:
                    return new BitmapImage(new Uri("Images/IDIMG.png", UriKind.RelativeOrAbsolute));
                case SiteImgMode.VNImg:
                    return new BitmapImage(new Uri("Images/VNIMG.png", UriKind.RelativeOrAbsolute));
                case SiteImgMode.CrbImg:
                    return new BitmapImage(new Uri("Images/CrossBorder.png", UriKind.RelativeOrAbsolute));
                default:
                    return new BitmapImage(new Uri("Images/main2.ico", UriKind.RelativeOrAbsolute));
            }
        }

        public enum SiteImgMode
        {
            /// <summary>
            /// 马来站点
            /// </summary>
            MYImg,
            /// <summary>
            /// 菲律宾站点
            /// </summary>
            PHImg,
            /// <summary>
            /// 泰国站点
            /// </summary>
            THImg,
            /// <summary>
            /// 新加坡
            /// </summary>
            SgImg,
            /// <summary>
            /// 印尼站点
            /// </summary>
            IDImg,
            /// <summary>
            /// 越南站点
            /// </summary>
            VNImg,
            /// <summary>
            /// 六合一
            /// </summary>
            CrbImg,
            /// <summary>
            /// 默认
            /// </summary>
            DefaultImg
        }
    }
}
