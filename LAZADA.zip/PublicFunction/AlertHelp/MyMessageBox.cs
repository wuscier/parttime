﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace PublicFunction.AlertHelp
{
    /// <summary>
    /// 自定义用户提示框实体类
    /// </summary>
    public class MyMessageBox
    {
        /// <summary>
        /// 提示不能控件不能为空
        /// </summary>
        public static void ShowEmptyPrompt(object controlName)
        {
            MessageBox.Show(controlName + Constants.ControlEmptyPrompt, Constants.MessageBoxShowInfoTitle, MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public static bool ConfirmDoSomething(string content)
        {
            if (MessageBoxResult.OK == MessageBox.Show(content, "提示", MessageBoxButton.OKCancel))
                return true;
            return false;
        }


        /// <summary>
        /// 消息提示框
        /// </summary>
        /// <param name="str">需要提示的话</param>
        public static void ShowInfo(string str)
        {
            MessageBox.Show(str, Constants.MessageBoxShowInfoTitle, MessageBoxButton.OK, MessageBoxImage.Information);
        }
        /// <summary>
        /// 长度提示
        /// </summary>
        /// <param name="name"></param>
        public static void ShowLengthPrompt(object name)
        {
            MessageBox.Show(name + Constants.Length, Constants.MessageBoxShowInfoTitle, MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
