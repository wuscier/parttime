﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.AlertHelp
{
    public class MySoundPlay
    {
        public static void PlayMusic()
        {
            SoundPlayer player = new SoundPlayer();
            player.SoundLocation = AppDomain.CurrentDomain.BaseDirectory + "sysdata\\dofinish.wav";
            player.Load();
            player.Play();
        }
        public static void PlayPushMusic()
        {
            SoundPlayer player = new SoundPlayer();
            player.SoundLocation = AppDomain.CurrentDomain.BaseDirectory + "AK8N.wav";
            player.Load();
            player.Play();
        }
    }
}
