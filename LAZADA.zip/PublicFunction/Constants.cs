﻿using LAZADA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;

namespace PublicFunction
{
    public static class Constants
    {
        public static string LoginAccount="";
        public static string LoginPwd = "";
        /// <summary>
        /// 蜂鸟服务器地址
        /// </summary>
        public static string HB_ClientGatewayUrl = "http://client-api.fengniaobox.com";//正式环境
        //public static string HB_ClientGatewayUrl = "http://client-api-staging.fengniaoerp.com";//测试环境
    
        public static string VERSIONNUMBER = "V1.0.1";
        /// <summary>
        /// 判断主窗体是否打开
        /// </summary>
        public static bool MainWindowIsOpening = false;
        /// <summary>
        /// 服务条款URL
        /// </summary>
        public static string SERVERTERMS_URL = "http://39.106.31.58:8010/";
        /// <summary>
        /// 注册URL
        /// </summary>
        public static string REGISTER_URL = "http://rj.91lazada.com/";
        /// <summary>
        /// 磁盘序列号
        /// </summary>
        public static string HARD_DISKID = "RW18B15187B7112";//磁盘
        /// <summary>
        /// 阿里自增ID
        /// </summary>
        public static string ALFYID = "0";
        /// <summary>
        /// 阿里加密ID
        /// </summary>
        public static string ACCESSKEYID = "";
        /// <summary>
        /// 阿里秘钥
        /// </summary>
        public static string ACCESSKEYSECRET = "";

        public static string ALIAPPID_BASE64Str = "QWxpQWNjZXNzS2V5SUQ=";

        public static string ALIAPPSECRET_BASE64Str = "QWxpQWNjZXNzS2V5U2VjcmV0";
        /// <summary>
        /// 获取登录链接数据加密
        /// </summary>
        public static string GETLINK_LOGIN_ENCRYPT = "EyNjE1LjIxNzc3MDEuMC4wLnlZUXFDZX0mbT";
        /// <summary>
        /// 个人信息接口连接
        /// </summary>
        public static string GETPROFILEURL = HB_ClientGatewayUrl + "/user/getProfile";
        /// <summary>
        /// 海王用户TOKEN查询接口
        /// </summary>
        public static string GETHWPROFILEURL = HB_ClientGatewayUrl + "/user/system";

        /// <summary>
        /// Tocken时间
        /// </summary>
        public static DateTime dataTocken = new DateTime();
        public static string VEDIOURI =AppDomain.CurrentDomain.BaseDirectory+ "ProductTutorial.mp4";

        #region act文件名称
        public static string ACTFILE_HISTORY = "sysdata\\historycategory.act";
        public static string ACTFILE_MACHEDCOLOR = "sysdata\\machedcolor.act";
        public static string ACTFILE_WISHCOLOR = "sysdata\\wishcolors.act";
        #endregion

        #region 系统默认部分参数
        public static string DEFAULTWEIGHT = "590";
        public static string DEFAULTIMAGESAVEPATH = System.IO.Path.GetPathRoot(AppDomain.CurrentDomain.BaseDirectory) + "\\sycimages";
        #endregion

        #region Lazada平台请求参数
        public static string LAZADA_GETAPIURL = "http://api.lazada.com.my/rest";
        public static string LAZADA_APPKEY = "100755";
        public static string LAZADA_APPSECRET = "";
        public static string LAZADA_ACCESSTOKEN = "";//50000200d1285Doxuweh4J2c1b04a49djxC0PCaCbvCNtXeIGOIYjtUjkqRKzj
        public static string OnlineLAZADA_ACCESSTOKEN = "";
        public static string OnlineLAZADA_ACCOUNT = "";
        public static string LAZADA_REFERSHTOKEN = "";
        public static string LAZADA_ACCESSTOKENMY = "";//马来
        public static string LAZADA_ACCESSTOKENSG = "50000900a19M1u7jnoyRSbhYgWDprCv1ba957eexleDiT4tw0kjiJLyEXMcfFA";//新加坡
        public static string LAZADA_ACCESSTOKENID = "";//印尼
        public static string LAZADA_ACCESSTOKENVN = "";//越南
        public static string LAZADA_ACCESSTOKENTH = "500009000101xzZx6ocFSM11e46b93mQ7KkvxPtih6H1GiyeywgbbFseRLMfyf";//泰国
        public static string LAZADA_ACCESSTOKENPH = "";//菲律宾
        public static string LAZADA_ACCESSTOKENCRB = "";//六合一
        public static string LAZADA_API_SG = "http://api.lazada.sg/rest";
        public static string LAZADA_API_TH = "http://api.lazada.co.th/rest";
        public static string LAZADA_API_MY = "http://api.lazada.com.my/rest";
        public static string LAZADA_API_VN = "http://api.lazada.vn/rest";
        public static string LAZADA_API_PH = "http://api.lazada.com.ph/rest";
        public static string LAZADA_API_ID = "http://api.lazada.co.id/rest";
        public static string LAZADA_CreateProduct = "/product/create";
        public static string LAZADA_UpdateProduct = "/product/update";
        public static string LAZADA_UpdatePriceQuantity = "/product/price_quantity/update";
        public static string LAZADA_GetProducts = "/products/get";
        public static string LAZADA_GetProductItem = "/product/item/get";
        public static string LAZADA_GetCategoryTree = "/category/tree/get";
        /// <summary>
        /// 获取lazada密钥
        /// </summary>
        public static void GETLAZADA_APPSECRET()
        {
            HttpClient client = new HttpClient();
            //specify to use TLS 1.2 as default connection
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            string url = HB_ClientGatewayUrl + "/system/config/TEFaQURBX0FQUFNFQ1JFVA==";
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + GlobalUserClass.Access_Token);
            var val = new HttpRequestMessage(HttpMethod.Get, url);
            HttpResponseMessage response = client.SendAsync(val).Result;
            var result = response.Content.ReadAsStringAsync().Result;
            Constants.LAZADA_APPSECRET = EncryptionWay.base64Decode(result);
        }
        public static string GetAppIdOrSecret(string key)
        {
            HttpClient client = new HttpClient();
            //specify to use TLS 1.2 as default connection
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            string url = HB_ClientGatewayUrl + $"/system/config/{key}";
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + GlobalUserClass.Access_Token);
            var val = new HttpRequestMessage(HttpMethod.Get, url);
            HttpResponseMessage response = client.SendAsync(val).Result;
            var result = response.Content.ReadAsStringAsync().Result;
            var str = EncryptionWay.base64Decode(result);
            return str;
        }
        #endregion

        #region 发布店铺集合
        public static int iChooseStore = 0;
        public static Dictionary<string,string> ReleaseStore = null;//发布店铺 
        #endregion

        #region 1688授权相关
        /// <summary>
        /// 1688 采集请求ID
        /// </summary>
        public static string ALIBABA_ID = "5723483";
        /// <summary>
        /// 1688 采集请求加密KEY
        /// </summary>
        public static string ALIBABA_KEY = "";
        /// <summary>
        /// 1688 采集接口主地址
        /// </summary>
        public static string ALIBABA_OPEN_URL = "http://gw.open.1688.com/openapi/";
        /// <summary>
        /// 1688采集（商品加入店铺接口地址）
        /// </summary>
        public static string ALIBABA_OPENAPI_PUSHED = "param2/1/com.alibaba.product.push/alibaba.cross.syncProductListPushed/";
        /// <summary>
        /// 1688采集（采集商品接口地址）
        /// </summary>
        public static string ALIBABA_OPENAPI_GETPRODUCT = "param2/1/com.alibaba.product/alibaba.cross.productInfo/";
        /// <summary>
        /// 1688access_token
        /// </summary>
        public static string Ali1688_ACCESSTOKEN = "";
        /// <summary>
        /// 1688refresh_token
        /// </summary>
        public static string Ali1688_REFRESHTOKEN = "";
        /// <summary>
        /// 1688授权ID
        /// </summary>
        public static string Ali1688_ID = "";
        /// <summary>
        /// 1688refresh_token换取access_token的url
        /// </summary>
        public static string Ali1688_REFRESH_ACCESSTOKEN_URL = "http://gw.open.1688.com/openapi/param2/1/system.oauth2/getToken/5723483";

        /// <summary>
        /// 获取1688KEY
        /// </summary>
        public static void GETALIBABA_KEY()
        {
            HttpClient client = new HttpClient();
            //specify to use TLS 1.2 as default connection
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            string url = HB_ClientGatewayUrl + "/system/config/QUxJQkFCQV9LRVk=";
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + GlobalUserClass.Access_Token);
            var val = new HttpRequestMessage(HttpMethod.Get, url);
            HttpResponseMessage response = client.SendAsync(val).Result;
            var result = response.Content.ReadAsStringAsync().Result;
            ALIBABA_KEY = EncryptionWay.base64Decode(result);
        }
        #endregion

        #region 授权接口
        public static string Update_Author_URL = Constants.HB_ClientGatewayUrl + "/AuthorizedShop/UpdateTokenInfo?";
        #endregion

        #region MessageBox 标题
        public static string MessageBoxShowInfoTitle = "系统提示";
        #endregion

        #region 系统提示语句
        public static string ControlEmptyPrompt = "不能为空";
        #endregion

        #region 用户额度 地址和加密字符串
        /// <summary>
        /// 用户额度的接口地址
        /// </summary>
        public static string REMAINAMOUNT_SERVERURL = "http://39.106.31.58:8010/sycWebService.asmx/ClientGetBalance";
        /// <summary>
        /// 用户额度 ARG3加密KEY
        /// </summary>
        public static string REMAINAMOUNT_ARG3KEY = "EyNjE1LjIxNzc3MDEuMC4wLnlZUXFDZX0mbT";
        /// <summary>
        /// 用户额度 ARG2加密KEY
        /// </summary>
        public static string REMAINAMOUNT_ARG2KEY = "BvcnQsY3R5cGUlM2FpbmR1c3RyeXxjX2JpZD0yMDEyMjJfMS0yMDE";

        /// <summary>
        /// 用户额度Response KEY
        /// </summary>
        public static string REMAINAMOUNT_RESPONSEKEY = "ZhdGVGaWx0ZXI9ZmFsc2UmbW9iaWxlT2ZVyPWZhbHNlJn";


        /// <summary>
        /// 减少用户额度的接口地址
        /// </summary>
        public static string REDUCEAMOUNT_SERVERURL = "http://39.106.31.58:8010/sycWebService.asmx/ClientReduceBalance";

        /// <summary>
        /// 减少用户额度Response KEY
        /// </summary>
        public static string REDUCEAMOUNT_RESPONSEKEY = "ByaXZhdGVGaWx0ZXI9ZmFsc2UmbW9iaWxlT2ZVyPWZhbHNlJn";
        #endregion

        #region 长度
        public static string Length = "长度不符";
        #endregion

        #region 获取链接 地址和加密KEY
        /// <summary>
        /// 获取链接的接口地址
        /// </summary>
        public static string GETLINK_SERVERURL = "http://39.106.31.58/sycWebService.asmx/LinkAction";
        /// <summary>
        /// 获取链接的数据加密KEY
        /// </summary>
        public static string GETLINK_ARG3KEY = "YWvXCJ9JmLSZPhiemhhbmdjaGF";
        /// <summary>
        /// 获取链接的时间加密KEY
        /// </summary>
        public static string GETLINK_ARG2KEY = "FvXCJ9JmYWhiemhhbmaGI9LSZP";
        /// <summary>
        /// 登录链接
        /// </summary>
        public static string GETLINK_LOGINURL = "http://39.106.31.58:8010/sycWebService.asmx/BukClientLoginVision";
        /// <summary>
        /// 请求认证服务登录url
        /// </summary>
        public static string GETLINK_LOGINURLNew = HB_ClientGatewayUrl + "/connect/token";

        public static string My1688redirectUrl = "http://uac.fengniaobox.com:8001/Home/?";

        //public static string My1688redirectUrl = "http://localhost:5001/Home/?";
        //"http://localhost:5000/?";

        public static string MyStoreredirectUrl = "http://uac.fengniaobox.com:5000/?";
        //"http://localhost:5050?";
        #endregion

        #region  SQLite 保存路径
        public static string SQLiteConnStr = "Data Source=" + AppDomain.CurrentDomain.BaseDirectory + "data\\LazadaData.db;Pooling=true;FailIfMissing=false";
        #endregion

        #region 平台类型判断的正则表达式
        public static string REGEX_FROMTYPE_1688 = "1688.com/offer/(?<offerID>\\d{6,}).html";
        public static string REGEX_FROMTYPE_SMT = "aliexpress.com/item/(.*?)/(?<offerID>\\d{6,}).htm";
        public static string REGEX_FROMTYPE_TaoBao = "taobao.com/item.htm.id=(?<offerID>\\d{6,})";
        public static string REGEX_FROMTYPE_JD = "jd.com/(?<offerID>\\d{6,}).html";
        public static string REGEX_FROMTYPE_TianMao = "tmall.com/item.htm.id=(?<offerID>\\d{6,})";
        public static string REGEX_FROMTYPE_YMX = "amazon.com/dp/(?<offerID>\\w{6,})";
        public static string REGEX_FROMTYPE_LAZADAMY = "www.lazada.com.my";
        public static string REGEX_FROMTYPE_LAZADASG = "www.lazada.sg";
        public static string REGEX_FROMTYPE_LAZADAPH = "www.lazada.com.ph";
        public static string REGEX_FROMTYPE_LAZADAID = "www.lazada.co.id";
        public static string REGEX_FROMTYPE_LAZADAVN = "www.lazada.vn";
        public static string REGEX_FROMTYPE_LAZADATH = "www.lazada.co.th";
        public static string REGEX_FROMTYPE_SHOPEETW = "xiapi.xiapibuy.com";
        public static string REGEX_FROMTYPE_SHOPEEMY = "shopee.com.my";
        public static string REGEX_FROMTYPE_SHOPEESG = "shopee.sg";
        public static string REGEX_FROMTYPE_SHOPEETH = "shopee.co.th";
        public static string REGEX_FROMTYPE_SHOPEEVN = "shopee.vn";
        public static string REGEX_FROMTYPE_SHOPEEID = "shopee.co.id";
        public static string REGEX_FROMTYPE_SHOPEEPH = "shopee.ph";
        public static string REGEX_FROMTYPE_17HY = "17zwd.com/item(.*?)GID=(?<offerID>\\d{6,})";
        public static string REGEX_FROMTYPE_PDD = "yangkeduo.com/goods.html.goods_id=(?<offerID>\\d{6,})";
        public static string REGEX_FROMTYPE_SKW = "www.vvic.com/item/(?<offerID>\\w{6,})";

        public static string REGEX_FROMTYPE_SXW = "sooxie.com/(?<offerID>\\d{6,}).aspx";
        public static string REGEX_FROMTYPE_BNN = "bao66.cn/p/(?<offerID>\\w{6,}).html";
        public static string REGEX_FROMTYPE_3E3E = "3e3e.cn/product/(?<offerID>\\w{6,}).html";
        public static string REGEX_FROMTYPE_QCW = "17qcc.com/item/(?<offerID>\\d{6,}).html";
        public static string REGEX_FROMTYPE_GTW = "go2.cn/product/(?<offerID>\\w{6,}).html";
        public static string REGEX_FROMTYPE_HQHP = "chinabrands.cn/item";
//http://z.go2.cn/product/oakskoo.html?pos=st.1498911.1
//http://www.chinabrands.cn/item/4612688-p.html
//www.17qcc.com/item/261975.html
//http://www.3e3e.cn/product/oikqimg.html?form=search
//http://www.bao66.cn/p/ebbmmfi.html
//http://qql.sooxie.com/688600.aspx
        #endregion

        #region 其他数据采集的参数
        public static string OTHERCOLLECT_APPID = "";
        public static string OTHERCOLLECT_URI = "http://api.wangduoyun.com/?";
        /// <summary>
        /// 获取其他数据采集APPID
        /// </summary>
        public static void GETOTHERCOLLECT_APPID()
        {
            HttpClient client = new HttpClient();
            //specify to use TLS 1.2 as default connection
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            string url = HB_ClientGatewayUrl + "/system/config/T1RIRVJDT0xMRUNUX0FQUElE";
            client.DefaultRequestHeaders.Add("Authorization", "Bearer " + GlobalUserClass.Access_Token);
            var val = new HttpRequestMessage(HttpMethod.Get, url);
            HttpResponseMessage response = client.SendAsync(val).Result;
            var result = response.Content.ReadAsStringAsync().Result;
            OTHERCOLLECT_APPID = EncryptionWay.base64Decode(result);
        }
        #endregion

        #region 蜂鸟接口相关

        /// <summary>
        /// 上传产品记录
        /// </summary>
        public static string HB_API_SPUCREATE = "/SpuRecord/Create";
        /// <summary>
        /// 获取产品详情
        /// </summary>
        public static string HB_API_SPUGET = "/SpuRecord/Get";
        /// <summary>
        /// 获取产品分页列表
        /// </summary>
        public static string HB_API_SPUPAGED = "/SpuRecord/Paged";
        /// <summary>
        /// 获取用户积分
        /// </summary>
        public static string HB_API_GETPOINTS = "/User/GetPoints";
        /// <summary>
        /// 获取新增采集链接
        /// </summary>
        public static string HB_API_GETNEWLINKS = "/LinkCollector/GetNewLinks";
        /// <summary>
        /// 保存手动新增
        /// </summary>
        public static string HB_API_CREATE = "/LinkCollector/Create";
        /// <summary>
        /// 查询历史采集
        /// </summary>
        public static string HB_API_COLLECTHISTORY = "/LinkCollector/Paged";
        #endregion

        #region 海王项目相关

        /// <summary>
        /// 海王APPKEY
        /// </summary>
        public static string HAIWANG_APPKEY = "27765741";
        /// <summary>
        /// 海王APP秘钥
        /// </summary>
        public static string HAIWANG_APPSECRET = "bb53554372b8c13c517671624ea9ceaa";
        /// <summary>
        /// 海王API接口地址
        /// </summary>
        public static string HAIWANG_APIURL = "https://eco.taobao.com/router/rest";
        /// <summary>
        /// 海王API服务的基础地址
        /// </summary>
        public static string HAIWANG_FUN_BASE_URL = "http://www.alifanyi.com";
        /// <summary>
        /// 海王店铺商品诊断服务的页面地址
        /// </summary>
        public static string HAIWANG_FUN_DIAGNOSE_URL = "/ai/diagnosis.html";
        /// <summary>
        /// 海王机翻个性化定制服务的页面地址
        /// </summary>
        public static string HAIWANG_FUN_PERSONAL_URL = "/ai/index.html";
        /// <summary>
        /// 海王标题改写服务的页面地址
        /// </summary>
        public static string HAIWANG_FUN_TITLE_URL = "/rewrite/";//index.html?taskId=
        /// <summary>
        /// 海王图片翻译服务的页面地址
        /// </summary>
        public static string HAIWANG_FUN_PIC_URL = "/picture/";//index.html?taskId=
        /// <summary>
        /// 海王授权页面地址
        /// </summary>
        public static string HAIWANG_FUN_AUTHORIZED_URL = "/userCenter/agreement.html";
        /// <summary>
        /// 海王功能页面跳转URL
        /// </summary>
        public static string HAIWANG_SERVICE_REDIRECT_URL = "http://www.alifanyi.com/dologin?type=@type&token=@token&redirect=@redirect";
        /// <summary>
        /// 海王授权取消链接
        /// </summary>
        public static string HAIWANG_DELETEROLE_URL = "/api/account/deletePack";
        /// <summary>
        /// 海王EXCEL模板下载地址
        /// </summary>
        public static string HAIWANG_EXCEL_DOWNLOAD_URL = "http://files.alicdn.com/tpsservice/d8f9bffbe40331b80e73eb074b8c0cf5.xlsx";
        #endregion

    }
}
