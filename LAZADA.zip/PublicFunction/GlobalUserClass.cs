﻿using Lazop.Api;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.RequestModel;
using PublicFunction.Entity.ResponseModel;
using PublicFunction.SaveHelp;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;

namespace LAZADA
{
    public class GlobalUserClass
    {
        public static string PublishingSite = "MY";
        public static string LoginName = "";//账号名
        public static string LoginPwdMD5 = "";//加密密码
        public static string serverEndTime = string.Empty;
        public static string serverNowTime = string.Empty;
        public GlobalUserClass()
        {

        }
        public long GetAlibabaAuthorTableId()
        {
            long Id = 0;
            using (HttpClient httpClient = new HttpClient())
            {
                //specify to use TLS 1.2 as default connection
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + GlobalUserClass.Access_Token);
                string myauthapi = Constants.HB_ClientGatewayUrl + "/AuthorizedShop/GetAll";
                var pro = new HttpRequestMessage(HttpMethod.Get, myauthapi);
                HttpResponseMessage response = httpClient.SendAsync(pro).Result;

                var msg = response.Content.ReadAsStringAsync().Result;
                var data = (JObject)JsonConvert.DeserializeObject(msg);
                foreach (var item in data["result"])
                {
                    if ((int)item["siteType"] == 3)
                    {
                        Id = int.Parse(item["id"].ToString());
                    }
                }
            }
            return Id;

        }
        /// <summary>
        /// 刷新、获取1688accesstoken
        /// </summary>
        /// <param name="siteId"></param>
        public void RefreshSiteToken(int siteId)
        {
            string accesstoken = Access_Token;
            string authorMsg = GetSiteProfile(accesstoken);
            JObject result = (JObject)JsonConvert.DeserializeObject(authorMsg);
            JArray arryresult = (JArray)result["result"];
            foreach (var item in arryresult)
            {
                if ((int)item["siteType"] == (int)WebSiteType.Ali1688)
                {
                    if ((int)item["region"] == siteId)
                    {
                        //Constants.Ali1688_ACCESSTOKEN = Convert.ToString(item["accessToken"]);
                        Constants.Ali1688_REFRESHTOKEN = Convert.ToString(item["refreshToken"]);
                        return;
                    }
                }

            }
        }
        /// <summary>
        /// 获取用户站点授权信息所有
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public static string GetSiteProfile(string token)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                //specify to use TLS 1.2 as default connection
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
                string myauthapi = Constants.HB_ClientGatewayUrl + "/AuthorizedShop/GetAll";
                var pro = new HttpRequestMessage(HttpMethod.Get, myauthapi);
                HttpResponseMessage response = httpClient.SendAsync(pro).Result;

                GlobalUserClass.StatusCode = Convert.ToInt32(response.StatusCode);
                ServiceBulletins(StatusCode);

                var msg = response.Content.ReadAsStringAsync().Result;
                return msg;
            }
        }
        /// <summary>
        /// 用户个人信息
        /// </summary>
        /// <param name="loginResultMsg"></param>
        public string SetMsg(string loginResultMsg)
        {
            JObject result = new JObject();
            result = (JObject)JsonConvert.DeserializeObject(loginResultMsg);
            try
            {
                #region 海王用的用户ID
                GlobalUserClass.GetHaiWangModel().UserID = Convert.ToString(result["result"]["id"]);
                #endregion
                #region 账号
                Result.account = Convert.ToString(result["result"]["account"]);
                #endregion
                #region 昵称
                Result.nickName = Convert.ToString(result["result"]["nickName"]);
                #endregion
                #region 真实姓名
                if (Convert.ToString(result["result"]["realName"]) == "")
                {
                    Result.realName = Result.nickName;
                }
                else
                {
                    Result.realName = Convert.ToString(result["result"]["realName"]);
                }
                #endregion
                #region 邮箱
                if (Convert.ToString(result["result"]["email"]) == string.Empty)
                {
                    Result.email = "";
                }
                else
                {
                    Result.email = Convert.ToString(result["result"]["email"]);
                }
                #endregion
                #region 手机
                Result.phone = Convert.ToString(result["result"]["phone"]);
                #endregion
                #region 用户类型
                Result.userType = Convert.ToInt32(result["result"]["userType"]);
                #endregion
                #region 用户ID
                Result.id = Convert.ToInt32(result["result"]["id"]);
                #endregion
                #region 启用/禁用
                //bool enable = Convert.ToBoolean(result["result"]["enable"].ToString());
                #endregion
                #region 创建时间
                Result.creationTime = (DateTime)result["result"]["creationTime"];
                #endregion
                #region 开通地区信息

                //获取用户授权信息
                JObject authresult = new JObject();
                authresult = (JObject)JsonConvert.DeserializeObject(GlobalUserClass.GetAuthorMSG());

                List<int> listReg = new List<int>();
                Dictionary<int, DateTime> siteTimePairs = new Dictionary<int, DateTime>();
                //取值保存到程序
                List<int> listShops = new List<int>();
                Dictionary<int, object> authorMSG = new Dictionary<int, object>();
                JArray arrayShops = (JArray)authresult["result"];
                string strSQL = "; ";
                string strDel = " delete from Store where user='" + GlobalUserClass.uname + "'";
                if (arrayShops.Count > 0)
                {
                    try
                    {
                        foreach (var item in authresult["result"])
                        {
                            #region 获取平台类型
                            JToken site = item["siteType"];
                            GlobalUserClass.AuthedShopsItem.siteType = (int)site;
                            #endregion
                            #region region
                            GlobalUserClass.AuthedShopsItem.regions = (int)item["region"];
                            #endregion

                            #region 用户id
                            GlobalUserClass.AuthedShopsItem.UserId = (long)item["userId"];
                            #endregion

                            #region 访问令牌
                            GlobalUserClass.AuthedShopsItem.AccessToken = item["accessToken"].ToString();
                            #endregion

                            #region 有效期
                            GlobalUserClass.AuthedShopsItem.ExpiresIn = (int)item["expiresIn"];
                            #endregion

                            #region 刷新令牌
                            GlobalUserClass.AuthedShopsItem.RefreshToken = item["refreshToken"].ToString();
                            #endregion

                            #region 刷新令牌超时时间
                            GlobalUserClass.AuthedShopsItem.RefreshTokenTimeOut = (DateTime?)item["refreshTokenTimeOut"];
                            #endregion

                            #region shopId
                            GlobalUserClass.AuthedShopsItem.ShopId = Convert.ToInt64("0"+item["shopId"].ToString());
                            #endregion

                            #region lastModificationTime
                            try
                            {
                                if (item["lastModificationTime"] == null)
                                {
                                    GlobalUserClass.AuthedShopsItem.LastModificationTime = DateTime.Now;
                                }
                                else
                                {
                                    GlobalUserClass.AuthedShopsItem.LastModificationTime = (DateTime?)item["lastModificationTime"];
                                }
                            }
                            catch (Exception ex)
                            {

                                new LogOutput.LogTo().WriteLine(ex.Message);
                            }


                            #endregion

                            #region creationTime
                            if (item["creationTime"] != null)
                            {
                                GlobalUserClass.AuthedShopsItem.CreationTime = (DateTime?)item["creationTime"];
                            }
                            else
                            {
                                GlobalUserClass.AuthedShopsItem.CreationTime = DateTime.Now;
                            }
                            #endregion
                            #region id
                            GlobalUserClass.AuthedShopsItem.Id = (int)item["id"];
                            #endregion
                            var list = new List<KeyValuePair<string, object>>()
                            {
                            new KeyValuePair<string, object>("userId", GlobalUserClass.AuthedShopsItem.UserId),
                            new KeyValuePair<string, object>("siteType", GlobalUserClass.AuthedShopsItem.siteType),
                            new KeyValuePair<string, object>("region", GlobalUserClass.AuthedShopsItem.regions),
                            new KeyValuePair<string, object>("accessToken", GlobalUserClass.AuthedShopsItem.AccessToken),
                            new KeyValuePair<string, object>("expiresIn", GlobalUserClass.AuthedShopsItem.ExpiresIn),
                            new KeyValuePair<string, object>("refreshToken", GlobalUserClass.AuthedShopsItem.RefreshToken),
                            new KeyValuePair<string, object>("refreshTokenTimeOut", GlobalUserClass.AuthedShopsItem.RefreshTokenTimeOut),
                            new KeyValuePair<string, object>("shopId", GlobalUserClass.AuthedShopsItem.ShopId),
                            new KeyValuePair<string, object>("account", GlobalUserClass.AuthedShopsItem.Account),
                            new KeyValuePair<string, object>("accountId", GlobalUserClass.AuthedShopsItem.AccountId),
                            new KeyValuePair<string, object>("creationTime", GlobalUserClass.AuthedShopsItem.CreationTime),
                            new KeyValuePair<string, object>("lastModificationTime", GlobalUserClass.AuthedShopsItem.LastModificationTime),
                            new KeyValuePair<string, object>("id", GlobalUserClass.AuthedShopsItem.Id)
                            };
                            authorMSG.Add(GlobalUserClass.AuthedShopsItem.Id, list);
                            AuthorMSG = authorMSG;

                            try
                            {
                                //获取平台类型
                                OpenedRegionsItem.siteType = (int)site;
                                if (OpenedRegionsItem.siteType == 1)
                                {
                                    int arrReg = (int)item["region"];
                                    listReg.Add(arrReg);
                                    OpenedRegionsItem.regions = listReg;
                                    #region 过期时间
                                    OpenedRegionsItem.expirationTime = (DateTime)item["expirationTime"];
                                    if (!siteTimePairs.ContainsKey(arrReg)) siteTimePairs.Add(arrReg, OpenedRegionsItem.expirationTime);
                                    #endregion
                                    List<Store> lStore = GetStoreList(" and account<>'' and id='" + item["id"] + "' ");
                                    strSQL += "Insert into Store(id,IsDefault,Name,account,authTime,expirationTime,user,region,accessToken) Values(" + item["id"] + "," + (lStore.Count > 0 ? (lStore[0].IsDefault == "true" ? "1" : "0") : "1") + ",'" + (item["shopName"].ToString() == "" ? item["account"].ToString() : item["shopName"].ToString()) + "','"
                                        + item["account"].ToString() + "','" + item["authTime"].ToString().Split('T')[0].Replace("/", "-").Replace("-1-", "-01-").Replace("-2-", "-02-").Replace("-3-", "-03-").Replace("-4-", "-04-").Replace("-5-", "-05-").Replace("-6-", "-06-").Replace("-7-", "-07-").Replace("-8-", "-08-").Replace("-9-", "-09-").Replace("-1 ", "-01 ").Replace("-2 ", "-02 ").Replace("-3 ", "-03 ").Replace("-4 ", "-04 ").Replace("-5 ", "-05 ").Replace("-6 ", "-06 ").Replace("-7 ", "-07 ").Replace("-8 ", "-08 ").Replace("-9 ", "-09 ") + "','"
                                        + item["expirationTime"].ToString().Split('T')[0].Replace("/", "-").Replace("-1-", "-01-").Replace("-2-", "-02-").Replace("-3-", "-03-").Replace("-4-", "-04-").Replace("-5-", "-05-").Replace("-6-", "-06-").Replace("-7-", "-07-").Replace("-8-", "-08-").Replace("-9-", "-09-").Replace("-1 ", "-01 ").Replace("-2 ", "-02 ").Replace("-3 ", "-03 ").Replace("-4 ", "-04 ").Replace("-5 ", "-05 ").Replace("-6 ", "-06 ").Replace("-7-", "-07 ").Replace("-8 ", "-08 ").Replace("-9 ", "-09 ") + "','" + GlobalUserClass.uname + "',"
                                        + arrReg + ",'" + item["accessToken"].ToString() + "'); ";

                                }

                            }
                            catch (Exception ex)
                            {
                                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                            }
                        }

                        SiteExpriateTime = siteTimePairs;
                    }
                    catch (Exception ex)
                    {

                        new LogOutput.LogTo().WriteErrorLine(ex.Message);
                    }
                }
                if(strSQL != "; ")
                {
                    new SQLiteHelp().ExecuteNonQuery(strDel + strSQL);
                }
                #endregion
            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteErrorLine(ex.Message);
            }
            return result.ToString();

        }
        public List<Store> GetStoreList(string strFilter = "")
        {
            string sql = "SELECT id,case IsDefault when '1' then 'true' else 'false' end as IsDefault,Name,account,authTime,expirationTime,user,region,accessToken,case account  when '' then '未授权'  else '已授权' end as State,case account  when '' then '添加授权'  else '重新授权' end as Operation FROM Store where 1=1 " + strFilter;
            return new SQLiteHelp().GetList<Store>(sql);
        }
        /// <summary>
        /// 获取lazada的access_token
        /// </summary>
        /// <param name="SiteId"></param>
        public void GETLAZADATOKEN(int SiteId)
        {
            //获取授权信息
            string msg = GetAuthorMSG();
            //取值
            JObject data = (JObject)JsonConvert.DeserializeObject(msg);
            foreach (var item in data["result"])
            {
                if ((int)item["siteType"] == (int)WebSiteType.Lazada)
                {
                    if ((int)item["region"] == SiteId)
                    {
                        if (item["accessToken"] != null)
                        {
                            Constants.LAZADA_ACCESSTOKEN = Convert.ToString(item["accessToken"]);
                            Constants.LAZADA_REFERSHTOKEN = Convert.ToString(item["refreshToken"]);
                            return;
                        }
                    }
                    else
                    {
                        Constants.LAZADA_ACCESSTOKEN = "";
                        Constants.LAZADA_REFERSHTOKEN = "";
                    }
                }
            }
        }
        /// <summary>
        /// 获取服务器时间
        /// </summary>
        /// <param name="access_token"></param>
        /// <returns></returns>
        public static string GetTime(string access_token)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                //specify to use TLS 1.2 as default connection
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + access_token);
                string myauthapi = Constants.HB_ClientGatewayUrl + "/system/time";
                var pro = new HttpRequestMessage(HttpMethod.Get, myauthapi);
                HttpResponseMessage response = httpClient.SendAsync(pro).Result;

                GlobalUserClass.StatusCode = Convert.ToInt32(response.StatusCode);
                ServiceBulletins(StatusCode);

                var msg = response.Content.ReadAsStringAsync().Result;
                return msg;
            }
        }

        /// <summary>
        /// 获取用户所有授权信息
        /// </summary>
        /// <returns></returns>
        public static string GetAuthorMSG()
        {
            //string r = Token().ToString();
            //JObject loginresult = new JObject();
            //loginresult = (JObject)JsonConvert.DeserializeObject(r);
            //GlobalUserClass.Access_Token = Convert.ToString(loginresult["access_token"]);
            HttpClient httpClient = new HttpClient();
            //specify to use TLS 1.2 as default connection
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            string allauthorurl = Constants.HB_ClientGatewayUrl + "/AuthorizedShop/GetAll";
            var val = new HttpRequestMessage(HttpMethod.Get, allauthorurl);
            httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + GlobalUserClass.Access_Token);
            var response = httpClient.SendAsync(val).Result;

            GlobalUserClass.StatusCode = Convert.ToInt32(response.StatusCode);
            ServiceBulletins(StatusCode);

            var msg = response.Content.ReadAsStringAsync().Result;
            JValue data = (JValue)JsonConvert.DeserializeObject(msg).ToString();
            return data.ToString();
        }

        public static string Token()
        {
            try
            {
                var list = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("client_id","fengniao-client"),
                        new KeyValuePair<string, string>("username",uname),
                        new KeyValuePair<string, string>("password",uepwd),
                        new KeyValuePair<string, string>("grant_type","password")
                    };
                using (HttpClient httpClient = new HttpClient())
                {
                    //specify to use TLS 1.2 as default connection
                    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    httpClient.Timeout = TimeSpan.FromSeconds(5);
                    var result = new HttpRequestMessage(HttpMethod.Post, Constants.GETLINK_LOGINURLNew) { Content = new FormUrlEncodedContent(list) };
                    HttpResponseMessage response = httpClient.SendAsync(result).Result;
                    var str = response.Content.ReadAsStringAsync().Result;
                    new LogOutput.LogTo().WriteLine(str);
                    var jsondata = (JObject)JsonConvert.DeserializeObject(str);
                    //获取状态码
                    GlobalUserClass.StatusCode = Convert.ToInt32(response.StatusCode);
                    if (jsondata["error_description"] != null)
                    {
                        GlobalUserClass.Error_Description = jsondata["error_description"].ToString();
                    }
                    else
                    {
                        GlobalUserClass.Error_Description = null;
                    }
                    return jsondata.ToString();
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
        }
        /// <summary>
        /// 登录时获取1688access_token
        /// </summary>
        public void RefreshAli1688Token()
        {
            if (Constants.dataTocken == new DateTime() || Constants.dataTocken.AddMinutes(400) < System.DateTime.Now || Constants.Ali1688_ACCESSTOKEN == "")
            {
                //获取授权所有信息
                string msg = GetAuthorMSG();

                //取值
                JObject data = (JObject)JsonConvert.DeserializeObject(msg);
                foreach (var item in data["result"])
                {
                    if ((int)item["siteType"] == (int)WebSiteType.Ali1688)
                    {
                        Constants.Ali1688_ID= Convert.ToString(item["id"]);
                        Constants.Ali1688_REFRESHTOKEN = Convert.ToString(item["refreshToken"]);
                        Constants.Ali1688_ACCESSTOKEN = Convert.ToString(item["accessToken"]);
                        break;
                    }
                }
                //Constants.GETALIBABA_KEY();
                if (Constants.Ali1688_REFRESHTOKEN != "" || Constants.Ali1688_REFRESHTOKEN != string.Empty)
                {
                    var list_ref_prm = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("grant_type","refresh_token"),
                        new KeyValuePair<string, string>("client_id",Constants.ALIBABA_ID),
                        new KeyValuePair<string, string>("client_secret",Constants.ALIBABA_KEY),
                        new KeyValuePair<string, string>("refresh_token",Constants.Ali1688_REFRESHTOKEN)
                    };
                    HttpClient httpClient = new HttpClient();
                    string myapiurl = "https://gw.open.1688.com/openapi/param2/1/system.oauth2/getToken/5723483";
                    var val = new HttpRequestMessage(HttpMethod.Post, myapiurl) { Content = new FormUrlEncodedContent(list_ref_prm) };
                    HttpResponseMessage res_Ref = httpClient.SendAsync(val).Result;


                    var str = res_Ref.Content.ReadAsStringAsync().Result;
                    var jsondata = (JObject)JsonConvert.DeserializeObject(str);
                    Constants.Ali1688_ACCESSTOKEN = Convert.ToString(jsondata["access_token"]);
                    Constants.dataTocken = System.DateTime.Now;

                    using (HttpClient httpClient_sav = new HttpClient())
                    {
                        string urlref_sav = "http://client-api.fengniaobox.com/AuthorizedShop/UpdateTokenInfo";

                        string Data = JsonConvert.SerializeObject(new
                        {
                            id=Convert.ToInt64(Constants.Ali1688_ID),
                            siteType = 3,
                            region = 8,
                            accessToken = Constants.Ali1688_ACCESSTOKEN,
                            expiresIn = 36000,
                            refreshToken = Constants.Ali1688_REFRESHTOKEN,
                            //refreshTokenTimeOut = refresh_token_timeout,
                        });
                        new LogOutput.LogTo().WriteLine("数据:" + Data);
                        httpClient_sav.BaseAddress = new Uri(urlref_sav);
                        httpClient_sav.DefaultRequestHeaders.Add("Authorization", "Bearer " + Access_Token);
                        var content = new StringContent(Data, Encoding.UTF8, "application/json");
                        var valref_sav = httpClient_sav.PutAsync(urlref_sav, content).Result;
                        var str_ref_sav = valref_sav.Content.ReadAsStringAsync().Result;
                        var jsondatabb = (JObject)JsonConvert.DeserializeObject(str_ref_sav);
                    };

                }
            }
            new LogOutput.LogTo().WriteLine(Constants.Ali1688_ACCESSTOKEN);
        }
        /// <summary>
        /// 定时刷新并保存1688token
        /// </summary>
        public void Ref_Sav_AliToken()
        {
            //string r = Token().ToString();
            //JObject loginresult = new JObject();
            //loginresult = (JObject)JsonConvert.DeserializeObject(r);
            //GlobalUserClass.Access_Token = Convert.ToString(loginresult["access_token"]);
            string msg = GetAuthorMSG();

            //取值
            JObject data = (JObject)JsonConvert.DeserializeObject(msg);
            foreach (var item in data["result"])
            {
                if ((int)item["siteType"] == (int)WebSiteType.Ali1688)
                {
                    Constants.Ali1688_ID = Convert.ToString(item["id"]);
                    Constants.Ali1688_REFRESHTOKEN = Convert.ToString(item["refreshToken"]);
                    Constants.Ali1688_ACCESSTOKEN = Convert.ToString(item["accessToken"]);
                    break;
                }
            }
            //Constants.GETALIBABA_KEY();
            if (Constants.Ali1688_REFRESHTOKEN != "" || Constants.Ali1688_REFRESHTOKEN != string.Empty)
            {
                var list_ref_prm = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("grant_type","refresh_token"),
                        new KeyValuePair<string, string>("client_id",Constants.ALIBABA_ID),
                        new KeyValuePair<string, string>("client_secret",Constants.ALIBABA_KEY),
                        new KeyValuePair<string, string>("refresh_token",Constants.Ali1688_REFRESHTOKEN)
                    };
                HttpClient httpClient = new HttpClient();
                string myapiurl = "http://gw.open.1688.com/openapi/param2/1/system.oauth2/getToken/5723483";
                var val = new HttpRequestMessage(HttpMethod.Post, myapiurl) { Content = new FormUrlEncodedContent(list_ref_prm) };
                HttpResponseMessage res_Ref = httpClient.SendAsync(val).Result;


                var str = res_Ref.Content.ReadAsStringAsync().Result;
                var jsondata = (JObject)JsonConvert.DeserializeObject(str);
                Constants.Ali1688_ACCESSTOKEN = Convert.ToString(jsondata["access_token"]);
                //Constants.Ali1688_REFRESHTOKEN = Convert.ToString(jsondata["refresh_token"]);
                //var refresh_token_timeout = DateTime.ParseExact(Convert.ToString(jsondata["refresh_token_timeout"]), "yyyyMMddHHmmssfffzzz", CultureInfo.InvariantCulture);

                using (HttpClient httpClient_sav = new HttpClient())
                {
                    //specify to use TLS 1.2 as default connection
                    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    string urlref_sav = Constants.HB_ClientGatewayUrl + "/AuthorizedShop/UpdateTokenInfo";

                    string Data = JsonConvert.SerializeObject(new
                    {
                        id = Convert.ToInt64(Constants.Ali1688_ID),
                        siteType = 3,
                        region = 8,
                        accessToken = Constants.Ali1688_ACCESSTOKEN,
                        expiresIn = 36000,
                        refreshToken = Constants.Ali1688_REFRESHTOKEN,
                        //refreshTokenTimeOut = refresh_token_timeout,
                    });
                    new LogOutput.LogTo().WriteLine("数据:" + Data);
                    httpClient_sav.BaseAddress = new Uri(urlref_sav);
                    httpClient_sav.DefaultRequestHeaders.Add("Authorization", "Bearer " + Access_Token);
                    var content = new StringContent(Data, Encoding.UTF8, "application/json");
                    var valref_sav = httpClient_sav.PutAsync(urlref_sav, content).Result;
                    var str_ref_sav = valref_sav.Content.ReadAsStringAsync().Result;
                    var jsondatabb = (JObject)JsonConvert.DeserializeObject(str_ref_sav);
                };
                #region 刷新ref_token
                //var list_sav_prm = new List<KeyValuePair<string, string>>()
                //{
                //    new KeyValuePair<string, string>("client_id",Constants.ALIBABA_ID),
                //    new KeyValuePair<string, string>("client_secret",Constants.ALIBABA_KEY),
                //    new KeyValuePair<string, string>("refresh_token",Constants.Ali1688_REFRESHTOKEN),
                //    new KeyValuePair<string, string>("access_token",Constants.Ali1688_ACCESSTOKEN)
                //};
                //HttpClient httpClient_sav = new HttpClient();
                //string url_sav = "http://gw.open.1688.com/openapi/param2/1/system.oauth2/postponeToken/5723483";
                //var val_sav = new HttpRequestMessage(HttpMethod.Post, url_sav) { Content = new FormUrlEncodedContent(list_sav_prm) };
                //HttpResponseMessage res_sav = httpClient.SendAsync(val_sav).Result;
                //var sav= res_sav.Content.ReadAsStringAsync().Result;
                //var jsondata_sav_prm = (JObject)JsonConvert.DeserializeObject(sav);

                //Constants.Ali1688_ACCESSTOKEN = Convert.ToString(jsondata_sav_prm["access_token"]);
                //Constants.Ali1688_REFRESHTOKEN = Convert.ToString(jsondata_sav_prm["refresh_token"]);
                //var time_sav_prm= DateTime.ParseExact(Convert.ToString(jsondata_sav_prm["refresh_token_timeout"]), "yyyyMMddHHmmssfffzzz", CultureInfo.InvariantCulture);
                //var expires_in_prm = Convert.ToString(jsondata_sav_prm["expires_in"]);
                #endregion



            }
        }

       
        public  void Ref_lazadaToken(int siteid)
        {
            string lazadamsg = GetSiteProfile(Access_Token);
            JObject result = (JObject)JsonConvert.DeserializeObject(lazadamsg);
            JArray arryresult = (JArray)result["result"];
            foreach (var item in arryresult)
            {
                string refersh_token_send = "";
                if ((int)item["siteType"] == 1)
                {
                    if ((int)item["region"] == siteid)
                    {
                        try
                        {
                            DateTime lasttime;
                            if (item["lastModificationTime"].ToString() == string.Empty)
                            {
                                lasttime = DateTime.Now;
                            }
                            else
                            {
                                lasttime = Convert.ToDateTime(item["lastModificationTime"]);
                            }
                            DateTime cretetime = Convert.ToDateTime(item["creationTime"]);
                            DateTime time = DateTime.Now;
                            if (lasttime == null)
                            {
                                TimeSpan times = time - cretetime;
                                if (times.Days >= 25)
                                {
                                    refersh_token_send = Convert.ToString(item["refreshToken"]);
                                    Ref_my(arryresult, refersh_token_send, (int)item["region"]);
                                    return;
                                }
                                return;
                            }
                            else
                            {
                                TimeSpan times = time - lasttime;
                                if (times.Days >= 25)
                                {
                                    refersh_token_send = Convert.ToString(item["refreshToken"]);
                                    Ref_my(arryresult, refersh_token_send, (int)item["region"]);
                                    return;
                                }
                                return;
                            }
                            
                        }
                        catch (Exception ex)
                        {

                            throw;
                        }
                    }
                }
            }
        }
        public void Ref_my(JArray arryresult, string refersh_token_send, int id)
        {
            LazopClient client = new LazopClient("http://auth.lazada.com/rest", "100755", "rXuiMSNUeXDuH6X4dsnbXpe6xZeEWg9p");
            LazopRequest request = new LazopRequest("/auth/token/refresh");
            request.AddApiParameter("refresh_token", refersh_token_send);
            LazopResponse response = client.Execute(request);
            var jsondata = (JObject)JsonConvert.DeserializeObject(response.Body);
            string accesstoken = Convert.ToString(jsondata["access_token"]);
            string refreshtoken = Convert.ToString(jsondata["refresh_token"]);
            //string refresh_expires_in = Convert.ToString(jsondata["refresh_expires_in"]);
            string expires_in = Convert.ToString(jsondata["expires_in"]);
            //string Account = Convert.ToString(jsondata["account"]);
            //var RefreshTokenTimeOut = DateTime.ParseExact(Convert.ToString(creationTime), "yyyyMMddHHmmssfffzzz", CultureInfo.InvariantCulture);

            if (id == SiteId)
            {
                Save_token(accesstoken, expires_in, refreshtoken, SiteId);
                return;
            }
        }
        public void Save_token(string accesstoken, string expires_in, string refreshtoken, int siteid)
        {
            //保存token
            using (HttpClient httpClient_sav = new HttpClient())
            {
                //specify to use TLS 1.2 as default connection
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                string urlref_sav = Constants.HB_ClientGatewayUrl + "/AuthorizedShop/UpdateTokenInfo";
                string Data = JsonConvert.SerializeObject(new
                {
                    id = Convert.ToInt64(Constants.Ali1688_ID),
                    siteType = 1,
                    region = siteid,
                    accessToken = accesstoken,
                    expiresIn = expires_in,
                    refreshToken = refreshtoken,
                });
                httpClient_sav.BaseAddress = new Uri(urlref_sav);
                httpClient_sav.DefaultRequestHeaders.Add("Authorization", "Bearer " + Access_Token);
                var content = new StringContent(Data, Encoding.UTF8, "application/json");
                var valref_sav = httpClient_sav.PutAsync(urlref_sav, content).Result;
                var str_ref_sav = valref_sav.Content.ReadAsStringAsync().Result;
                var date = (JObject)JsonConvert.DeserializeObject(str_ref_sav);
            };
        }
        /// <summary>
        /// 502服务器维护
        /// </summary>
        public static void ServiceBulletins(int StatussCode)
        {
            if (StatussCode == 502)
            {
                MessageBox.Show("系统正在维护，请稍后再试");
                Thread.Sleep(2000);
                Environment.Exit(0);
            }
        }
        public static Dictionary<int, object> AuthorMSG { get; set; }
        /// <summary>
        /// 使用期限（已到期）
        /// </summary>
        public static bool EndTimeOver()
        {
            DateTime tend;
            DateTime tnow;
            bool bte = DateTime.TryParse(serverEndTime, out tend);
            bool btn = DateTime.TryParse(serverNowTime, out tnow);
            if (bte == false)
            {
                return true;
            }
            else
            {

                try
                {
                    tend = Convert.ToDateTime(serverEndTime);
                    bte = true;
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.InnerException.Message);
                }
                return false;
            }

        }
        public static bool IsNoImg { get; set; }
        /// <summary>
        /// 用户站点到期时间集合
        /// </summary>
        public static Dictionary<int, DateTime> SiteExpriateTime { get; set; }
        /// <summary>
        /// 开通地区
        /// </summary>
        public class OpenedRegionsItem
        {
            /// <summary>
            /// 平台类型
            /// </summary>
            public static int siteType { get; set; }
            /// <summary>
            /// 地区集合
            /// </summary>
            public static List<int> regions { get; set; }
            /// <summary>
            /// 过期时间
            /// </summary>
            public static DateTime expirationTime { get; set; }
        }
        /// <summary>
        /// 授权给蜂鸟的软件版本和地区
        /// </summary>
        public class AuthedShopsItem
        {
            public static string Account { get; set; }

            public static string AccountId { get; set; }

            public virtual Result User { get; set; }

            public static long UserId { get; set; }

            public static string AccessToken { get; set; }

            public static int ExpiresIn { get; set; }

            public static string RefreshToken { get; set; }

            public static DateTime? RefreshTokenTimeOut { get; set; }

            public static long? ShopId { get; set; }

            public static DateTime? CreationTime { get; set; }

            public static DateTime? LastModificationTime { get; set; }
            /// <summary>
            /// 平台类型
            /// </summary>
            public static int siteType { get; set; }
            /// <summary>
            /// 地区集合
            /// </summary>
            public static int regions { get; set; }
            /// <summary>
            /// id
            /// </summary>
            public static int Id { get; set; }
        }
        /// <summary>
        /// 个人信息实体
        /// </summary>
        public class Result
        {
            /// <summary>
            /// 账户
            /// </summary>
            public static string account { get; set; }
            /// <summary>
            /// 昵称
            /// </summary>
            public static string nickName { get; set; }
            /// <summary>
            /// 真实名称
            /// </summary>
            public static string realName { get; set; }
            /// <summary>
            /// 邮箱
            /// </summary>
            public static string email { get; set; }
            /// <summary>
            /// 手机
            /// </summary>
            public static string phone { get; set; }
            /// <summary>
            /// 用户类型
            /// </summary>
            public static int userType { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public static string enable { get; set; }
            /// <summary>
            /// 创建时间
            /// </summary>
            public static DateTime creationTime { get; set; }
            /// <summary>
            /// 开通地区
            /// </summary>
            public List<OpenedRegionsItem> opendSites { get; set; }
            /// <summary>
            /// 授权给蜂鸟的软件版本和地区
            /// </summary>
            public static List<AuthedShopsItem> authedShops { get; set; }
            /// <summary>
            /// 用户id
            /// </summary>
            public static int id { get; set; }
        }

        public class Root
        {
            /// <summary>
            /// 
            /// </summary>
            public Result result { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string targetUrl { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string success { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string error { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string unAuthorizedRequest { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public string __abp { get; set; }
        }
        /// <summary>
        /// 1688采集回调地址
        /// </summary>
        public static string redirectUrl { get; set; }
        /// <summary>
        /// lazada卖家授权回调地址
        /// </summary>
        public static string MyStoreAuthrect_Url { get; set; }
        /// <summary>
        /// 个人信息
        /// </summary>
        public static string Msg { get; set; }
        /// <summary>
        /// 使用期限（未到期）
        /// </summary>
        /// <returns></returns>
        public static bool StartTimeBegin()
        {
            DateTime tend;
            DateTime tnow;
            bool bte = DateTime.TryParse(serverEndTime, out tend);
            bool btn = DateTime.TryParse(serverNowTime, out tnow);
            if (bte && bte && DateTime.Compare(tend, tnow) >= 0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 版本号
        /// </summary>
        public string sysClientVersion { get; set; }

        /// <summary>
        /// 积分
        /// </summary>
        public static int Balance { get; set; }

        /// <summary>
        /// 服务类别
        /// </summary>
        public static int ServerTypes { get; set; }

        /// <summary>
        /// 用户类型
        /// </summary>
        public static string UserTypes { get; set; }

        /// <summary>
        /// 授权
        /// </summary>
        public static bool Author { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public static string uname { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        public static string uepwd { get; set; }

        /// <summary>
        /// 站点集合
        /// </summary>
        public List<string> SiteList { get; set; }
        /// <summary>
        /// 站点名称
        /// </summary>
        public static string SiteName { get; set; }
        /// <summary>
        /// 站点编号
        /// </summary>
        public static int SiteId { get; set; }
        /// <summary>
        /// 卖家店铺授权token
        /// </summary>
        public static string StoreAccess_Token { get; set; }
        /// <summary>
        /// 店铺授权信息
        /// </summary>
        public static string StoreAuthorMSG { get; set; }
        /// <summary>
        /// 登录信息
        /// </summary>
        public static string LoginMsg { get; set; }
        /// <summary>
        /// 登录Access_token
        /// </summary>
        public static string Access_Token { get; set; }
        /// <summary>
        /// 刷新token
        /// </summary>
        public static string Refresh_token { get; set; }
        /// <summary>
        /// 登录请求状态码
        /// </summary>
        public static int StatusCode { get; set; }
        /// <summary>
        /// 登录错误提示
        /// </summary>
        public static string Error_Description { get; set; }
        /// <summary>
        /// 1688采集授权结果
        /// </summary>
        public static int AilbabaStaCode { get; set; }

        /// <summary>
        /// 是否切换站点标识
        /// </summary>
        public static bool IsChangeSite { get; set; }
        /// <summary>
        /// 地区
        /// </summary>
        public enum Region
        {
            /// <summary>
            /// 新加坡
            /// </summary>
            Singapore = 1,
            /// <summary>
            /// 泰国
            /// </summary>
            Thailand = 2,
            /// <summary>
            /// 马来西亚
            /// </summary>
            Malaysia = 3,
            /// <summary>
            /// 越南
            /// </summary>
            Vietnam = 4,
            /// <summary>
            /// 菲律宾
            /// </summary>
            Philippines = 5,
            /// <summary>
            /// 印度尼西亚
            /// </summary>
            Indonesia = 6,
            /// <summary>
            /// 台湾
            /// </summary>
            TaiWan = 7,
            /// <summary>
            /// 中国
            /// </summary>
            China = 8,
            /// <summary>
            /// 六合一
            /// </summary>
            CrossBorder = 9
        }

        /// <summary>
        /// 平台类型
        /// </summary>
        public enum WebSiteType
        {
            Lazada = 1,
            Shopee = 2,
            Ali1688 = 3
        }

        private static HaiWangRoleModel haiwangModel;

        public static HaiWangRoleModel GetHaiWangModel()
        {
            if (haiwangModel == null)
                haiwangModel = new HaiWangRoleModel();
            return haiwangModel;

        }

    }

    public class HaiWangRoleModel
    {
        private bool isAuthorized = false;

        private string userID = "";

        private string token = "";
        public bool IsAuthorized { get => isAuthorized; set => isAuthorized = value; }
        public string UserID { get => userID; set => userID = value; }
        public string Token { get => token; set => token = value; }

        public string CreateURL(string apiName)
        {
            return Constants.HAIWANG_SERVICE_REDIRECT_URL.Replace("@type", "fengniao").Replace("@token", GlobalUserClass.GetHaiWangModel().Token).Replace("@redirect", apiName + "?from=fengniao");
        }

        public string CreateURLByTaskID(string apiName, long taskid)
        {
            return Constants.HAIWANG_SERVICE_REDIRECT_URL.Replace("@type", "fengniao").Replace("@token", GlobalUserClass.GetHaiWangModel().Token).Replace("@redirect", apiName + taskid + ".html?from=fengniao");
        }
    }
}
