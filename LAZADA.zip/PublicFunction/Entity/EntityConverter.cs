﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity
{
    /// <summary>
    /// 实体内字段转义辅助类
    /// </summary>
    public class EntityConverter
    {
    }
}
