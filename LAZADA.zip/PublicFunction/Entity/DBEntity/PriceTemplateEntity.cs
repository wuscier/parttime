﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.DBEntity
{
    public class PriceTemplateEntity
    {
        #region 私有变量
        private Int64 _jnumber;
        private Int64 _SiteID;
        private string _jname;
        private string _jprfix;
        private string _jkuchen;
        private string _jpkghight;
        private string _jpkgwidth;
        private string _jpkglength;
        private string _jyunfeigs;
        private string _jjiagegs;
        private string _jliyunbi;
        private string _jMSRPtype;
        private string _jMSRPjiajashou;
        private string _jMSRPjiajabi;

        /// <summary>
        /// 20190619 追加 汇率
        /// </summary>
        private string _jrate;

        /// <summary>
        /// 20190619 追加 国内运费
        /// </summary>
        private string _jhometran;

        #endregion

        #region 属性
        /// <summary>
        /// 计价模板ID
        /// </summary>
        public Int64 Jnumber { get => _jnumber; set => _jnumber = value; }
        /// <summary>
        /// 站点ID
        /// </summary>
        public Int64 SiteID { get => _SiteID; set => _SiteID = value; }
        /// <summary>
        /// 计价模板的名称
        /// </summary>
        public string Jname { get => _jname; set => _jname = value; }
        /// <summary>
        /// SKU前缀
        /// </summary>
        public string Jprfix { get => _jprfix; set => _jprfix = value; }
        /// <summary>
        /// 产品默认库存数量
        /// </summary>
        public string Jkuchen { get => _jkuchen; set => _jkuchen = value; }
        /// <summary>
        /// 产品默认高度
        /// </summary>
        public string Jpkghight { get => _jpkghight; set => _jpkghight = value; }
        /// <summary>
        /// 产品默认宽度
        /// </summary>
        public string Jpkgwidth { get => _jpkgwidth; set => _jpkgwidth = value; }
        /// <summary>
        /// 产品默认长度
        /// </summary>
        public string Jpkglength { get => _jpkglength; set => _jpkglength = value; }
        /// <summary>
        /// 运费公式
        /// </summary>
        public string Jyunfeigs { get => _jyunfeigs; set => _jyunfeigs = value; }
        /// <summary>
        /// 计价公式
        /// </summary>
        public string Jjiagegs { get => _jjiagegs; set => _jjiagegs = value; }
        /// <summary>
        /// 利润率
        /// </summary>
        public string Jliyunbi { get => _jliyunbi; set => _jliyunbi = value; }
        /// <summary>
        /// 折扣价计算方式（1.原价*？；2.原价+？
        /// </summary>
        public string JMSRPtype { get => _jMSRPtype; set => _jMSRPtype = value; }
        /// <summary>
        /// 原价加的值
        /// </summary>
        public string JMSRPjiajashou { get => _jMSRPjiajashou; set => _jMSRPjiajashou = value; }
        /// <summary>
        /// 原价乘的值
        /// </summary>
        public string JMSRPjiajabi { get => _jMSRPjiajabi; set => _jMSRPjiajabi = value; }
        /// <summary>
        /// 汇率
        /// </summary>
        public string Jrate { get => _jrate; set => _jrate = value; }
        /// <summary>
        /// 国内运费
        /// </summary>
        public string Jhometran { get => _jhometran; set => _jhometran = value; }
        #endregion
    }
}
