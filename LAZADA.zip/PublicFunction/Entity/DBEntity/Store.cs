﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.DBEntity
{
    public class Store
    {
        public Int64 id { get; set; }                //授权ID
        public string IsDefault { get; set; }         //是否默认发布
        public string Name { get; set; }           //备注名称
        public string account { get; set; }        //账号
        public string authTime { get; set; }       //授权时间
        public string expirationTime { get; set; } //店铺到期时间
        public string user { get; set; }           //用户名
        public Int64 region { get; set; }            //站点
        public string accessToken { get; set; }    //发布token
        public string Operation { get; set; }      //操作
        public string State { get; set; }          //状态
    }
}
