﻿using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.DBEntity
{
    public class OnlineProduct : BaseViewModel
    {
        #region 私有变量
        private Int64 _SiteID;
        private Int64 _number;
        private string _lazadaisparent;
        private string _lazadaparentid;
        private string _lazadazhusku;
        private string _lazadafujiaskucount;
        private string _pimgurl;
        private string _poriglink;
        private string _pfromtype;
        private string _ppid;
        private string _porigprice;
        private string _pnewprice;
        private string _pchenbenjia;
        private string _pprofit;
        private string _pweight;
        private string _pshipfee;
        private string _poldshipfee;
        private string _plowestprice;
        private string _porigtitle;
        private string _pnewtitle;
        private string _pnewtitleX;
        private string _pdescription;
        private string _porigattribute;
        private string _puid;
        private string _pnewimgsurl;
        private string _pupedimg;
        private string _porigimgsurl;
        private string _plocalimgpath;
        private string _pcolors;
        private string _psizes;
        private string _pfanyidcolors;
        private string _pcolormatch;
        private string _punfanyiimgs;
        private string _pbrand;
        private string _pUPC;
        private string _pZUPC;
        private string _pusername;
        private string _padddate;
        private string _peditdate;
        private string _pcancsv;
        private string _lazadapublishresult;
        private string _lazadapublishdate;
        private string _pstate;
        private string _plinkcreatedate;
        private string _pallsoldcount;
        private string _pjisangongshi;
        private string _pkuchen;
        private string _PackageLength;
        private string _PackageHight;
        private string _PackageWidth;
        private string _pstatetype;
        private string _prelalink;
        private string _pidprefix;
        private string _lazadacategoryid;
        private string _lazadacategoryidpath;
        private string _lazadacategorynamepath;
        private string _lazadahighlight;
        private string _lazadadescription;
        private string _lazadaprice;
        private string _lazadapromprice;
        private string _lazadapromstart;
        private string _lazadapromend;
        private string _lazadawarrantytype;
        private string _lazadawarrantyperiod;
        private string _lazadawarrantypolicy;
        private string _lazadatax;
        private string _lazadaskyz;
        private string _lazadaskuy;
        private string _lazadaskux;
        private string _lazadasizes;
        private string _lazadaattributs;
        private string _lazadapackageweight;
        private string _lazadapackageincluding;
        private string _lazadaskuimages;
        private string _PublishingSites;
        private string _sgSalesPrice;
        private string _sgRetailPrice;
        private string _mySalesPrice;
        private string _myRetailPrice;
        private string _idSalesPrice;
        private string _idRetailPrice;
        private string _phSalesPrice;
        private string _phRetailPrice;
        private string _thSalesPrice;
        private string _thRetailPrice;
        private string _vnSalesPrice;
        private string _vnRetailPrice;
        private Boolean _AutoAllocateStock;
        private string _video;
        private Int64 _SKUNumber;
        private string _SPUEditError;
        private string _DetailsEditError;
        private string _UploadImgError;
        private bool _isChecked = false;
        private string _porigReservelink;

        /// <summary>
        /// 20190509 增加子SKU
        /// </summary>
        private string _ChildSku;
        /// <summary>
        /// 20190514 增加服务端ID，用于后续UPDATE或者其他操作
        /// </summary>
        private string _ServerID;
        /// <summary>
        /// 20190517 增加类目书完整英语结构，用于后续查找更换类目使用
        /// </summary>
        private string _lazadaCategoryTreePath;
        /// <summary>
        /// 20190605 用于保存SPU界面生成SKU明细，以JOSN字符串保存
        /// </summary>
        private string _SKUDetail;
        #endregion

        #region 属性
        /// <summary>
        /// 备用链接
        /// </summary>
        public string porigReservelink
        {
            get => _porigReservelink;
            set
            {
                if (_porigReservelink != value)
                {
                    _porigReservelink = value;
                    base.RaisePropertyChanged("_porigReservelink");
                }
            }
        }


        /// <summary>
        /// 站点ID
        /// </summary>
        public Int64 SiteID
        {
            get => _SiteID;
            set
            {
                if (_SiteID != value)
                {
                    _SiteID = value;
                    base.RaisePropertyChanged("SiteID");
                }
            }
        }

        /// <summary>
        /// 对应站点下的SKU数量（编号）
        /// 手动自增
        /// </summary>
        public Int64 Number
        {
            get => _number;
            set
            {
                if (_number != value)
                {
                    _number = value;
                    base.RaisePropertyChanged("Number");
                }
            }
        }

        /// <summary>
        /// 是否是父级数据（1.是，0.不是）
        /// 用于SKU附加
        /// </summary>
        public string Lazadaisparent
        {
            get => _lazadaisparent;
            set
            {
                if (_lazadaisparent != value)
                {
                    _lazadaisparent = value;
                    base.RaisePropertyChanged("Lazadaisparent");
                }
            }
        }

        /// <summary>
        /// 当前站点的源SKU编号
        /// </summary>
        public string Lazadaparentid
        {
            get => _lazadaparentid;
            set
            {
                if (_lazadaparentid != value)
                {
                    _lazadaparentid = value;
                    base.RaisePropertyChanged("Lazadaparentid");
                }
            }
        }

        /// <summary>
        /// 主SKU（保留，后期不用可清除）
        /// </summary>
        public string Lazadazhusku { get => _lazadazhusku; set => _lazadazhusku = value; }

        /// <summary>
        /// 附加SKU数量
        /// </summary>
        public string Lazadafujiaskucount
        {
            get
            {
                if (_lazadafujiaskucount == null || _lazadafujiaskucount == string.Empty)
                {
                    _lazadafujiaskucount = "0";
                }
                return _lazadafujiaskucount;
            }
            set
            {
                if (_lazadafujiaskucount != value)
                {
                    _lazadafujiaskucount = value;
                    base.RaisePropertyChanged("Lazadafujiaskucount");
                }
            }
        }

        /// <summary>
        /// 主图片路径
        /// 一般为网络图片
        /// </summary>
        public string Pimgurl
        {
            get => _pimgurl;
            set
            {
                if (_pimgurl != value)
                {
                    _pimgurl = value;
                    base.RaisePropertyChanged("Pimgurl");
                }
            }
        }

        /// <summary>
        /// 货源链接
        /// </summary>
        public string Poriglink
        {
            get => _poriglink;
            set
            {
                if (_poriglink != value)
                {
                    _poriglink = value;
                    base.RaisePropertyChanged("Poriglink");
                }
            }
        }

        /// <summary>
        /// 货源类型
        /// </summary>
        public string Pfromtype
        {
            get => _pfromtype;
            set
            {
                if (_pfromtype != value)
                {
                    _pfromtype = value;
                    base.RaisePropertyChanged("Pfromtype");
                }
            }
        }

        /// <summary>
        /// 商品链接地址上的商品ID
        /// 可能用于SKU是否重复的检查
        /// </summary>
        public string Ppid
        {
            get => _ppid;
            set
            {
                if (_ppid != value)
                {
                    _ppid = value;
                    base.RaisePropertyChanged("Ppid");
                }
            }
        }

        /// <summary>
        /// 商品RMB价格
        /// </summary>
        public string Porigprice
        {
            get => _porigprice;
            set
            {
                if (_porigprice != value)
                {
                    _porigprice = value;
                    base.RaisePropertyChanged("Porigprice");
                }
            }
        }

        /// <summary>
        /// 新价格（程序内注释掉了，保留，后期不用可清除）
        /// </summary>
        public string Pnewprice { get => _pnewprice; set => _pnewprice = value; }

        /// <summary>
        /// SKU成本价（外币价）
        /// </summary>
        public string Pchenbenjia
        {
            get => _pchenbenjia;
            set
            {
                if (_pchenbenjia != value)
                {
                    _pchenbenjia = value;
                    base.RaisePropertyChanged("Pchenbenjia");
                }
            }
        }

        /// <summary>
        /// 预估利润
        /// </summary>
        public string Pprofit
        {
            get => _pprofit;
            set
            {
                if (_pprofit != value)
                {
                    _pprofit = value;
                    base.RaisePropertyChanged("Pprofit");
                }
            }
        }

        /// <summary>
        /// 净重
        /// </summary>
        public string Pweight
        {
            get => _pweight;
            set
            {
                if (_pweight != value)
                {
                    _pweight = value;
                    base.RaisePropertyChanged("Pweight");
                }
            }
        }
        /// <summary>
        /// 运费(程序内注释掉了，保留，后期不用可清除）
        /// </summary>
        public string Pshipfee { get => _pshipfee; set => _pshipfee = value; }

        /// <summary>
        /// 运费
        /// </summary>
        public string Poldshipfee
        {
            get => _poldshipfee;
            set
            {
                if (_poldshipfee != value)
                {
                    _poldshipfee = value;
                    base.RaisePropertyChanged("Poldshipfee");
                }
            }
        }

        /// <summary>
        /// 最低售价
        /// </summary>
        public string Plowestprice
        {
            get => _plowestprice;
            set
            {
                if (_plowestprice != value)
                {
                    _plowestprice = value;
                    base.RaisePropertyChanged("Plowestprice");
                }
            }
        }

        /// <summary>
        /// 源标题
        /// </summary>
        public string Porigtitle
        {
            get => _porigtitle;
            set
            {
                if (_porigtitle != value)
                {
                    _porigtitle = value;
                    base.RaisePropertyChanged("Porigtitle");
                }
            }
        }

        /// <summary>
        /// 翻译前标题
        /// </summary>
        public string Pnewtitle
        {
            get => _pnewtitle;
            set
            {
                if (_pnewtitle != value)
                {
                    _pnewtitle = value;
                    base.RaisePropertyChanged("Pnewtitle");
                }
            }
        }

        /// <summary>
        /// 翻译后标题
        /// </summary>
        public string PnewtitleX
        {
            get => _pnewtitleX;
            set
            {
                if (_pnewtitleX != value)
                {
                    _pnewtitleX = value;
                    base.RaisePropertyChanged("PnewtitleX");
                }
            }
        }

        /// <summary>
        /// 源产品附加说明
        /// </summary>
        public string Pdescription
        {
            get => _pdescription;
            set
            {
                if (_pdescription != value)
                {
                    _pdescription = value;
                    base.RaisePropertyChanged("Pdescription");
                }
            }
        }

        /// <summary>
        /// 源产品属性
        /// </summary>
        public string Porigattribute
        {
            get => _porigattribute;
            set
            {
                if (_porigattribute != value)
                {
                    _porigattribute = value;
                    base.RaisePropertyChanged("Porigattribute");
                }
            }
        }

        /// <summary>
        /// (功能不清，保留，后期不用可清除）
        /// </summary>
        public string Puid { get => _puid; set => _puid = value; }

        /// <summary>
        /// 选择的图片链接 以,分割
        /// 采集完为空，
        /// 编辑后保存本地路径，
        /// 上传后保存服务器返回的路径
        /// </summary>
        public string Pnewimgsurl
        {
            get => _pnewimgsurl;
            set
            {
                if (_pnewimgsurl != value)
                {
                    _pnewimgsurl = value;
                    base.RaisePropertyChanged("Pnewimgsurl");
                }
            }
        }

        /// <summary>
        /// 源图片下载进度
        /// 开始下载         0/总数
        /// 下载中    已下载数/总数
        /// 下载完成      总数/总数
        /// </summary>
        public string Pupedimg
        {
            get => _pupedimg;
            set
            {
                if (_pupedimg != value)
                {
                    _pupedimg = value;
                    base.RaisePropertyChanged("Pupedimg");
                }
            }
        }

        /// <summary>
        /// 网络图片链接 以,分割
        /// </summary>
        public string Porigimgsurl
        {
            get => _porigimgsurl;
            set
            {
                if (_porigimgsurl != value)
                {
                    _porigimgsurl = value;
                    base.RaisePropertyChanged("Porigimgsurl");
                }
            }
        }

        /// <summary>
        /// 图片本地保存路径 
        /// </summary>
        public string Plocalimgpath
        {
            get => _plocalimgpath;
            set
            {
                if (_plocalimgpath != value)
                {
                    _plocalimgpath = value;
                    base.RaisePropertyChanged("Plocalimgpath");
                }
            }
        }

        /// <summary>
        /// 颜色 以,分割
        /// </summary>
        public string Pcolors
        {
            get => _pcolors;
            set
            {
                if (_pcolors != value)
                {
                    _pcolors = value;
                    base.RaisePropertyChanged("Pcolors");
                }
            }
        }

        /// <summary>
        /// 尺码 以,分割
        /// </summary>
        public string Psizes
        {
            get => _psizes;
            set
            {
                if (_psizes != value)
                {
                    _psizes = value;
                    base.RaisePropertyChanged("Psizes");
                }
            }
        }

        /// <summary>
        /// 图片上传进度
        /// </summary>
        public string Pfanyidcolors { get => _pfanyidcolors; set => _pfanyidcolors = value; }

        /// <summary>
        /// 颜色尺码组合出的规格
        /// </summary>
        public string Pcolormatch { get => _pcolormatch; set => _pcolormatch = value; }

        /// <summary>
        /// 下载的图片详细链接集合
        /// </summary>
        public string Punfanyiimgs { get => _punfanyiimgs; set => _punfanyiimgs = value; }

        /// <summary>
        /// 品牌（保留，后期不用可清除）
        /// </summary>
        public string Pbrand { get => _pbrand; set => _pbrand = value; }

        /// <summary>
        /// 是否导出（1.已导出）
        /// </summary>
        public string PUPC { get => _pUPC; set => _pUPC = value; }

        /// <summary>
        /// ppid等信息加密字符串（用意不清）
        /// </summary>
        public string PZUPC { get => _pZUPC; set => _pZUPC = value; }

        /// <summary>
        /// 用户名称
        /// </summary>
        public string Pusername
        {
            get => _pusername;
            set
            {
                if (_pusername != value)
                {
                    _pusername = value;
                    base.RaisePropertyChanged("Pusername");
                }
            }
        }

        /// <summary>
        /// 添加日期 yyyy/MM/dd HH:mm:ss
        /// </summary>
        public string Padddate
        {
            get => _padddate;
            set
            {
                if (_padddate != value)
                {
                    _padddate = value;
                    base.RaisePropertyChanged("Padddate");
                }
            }
        }

        /// <summary>
        /// 修改日期 yyyy/MM/dd HH:mm:ss
        /// </summary>
        public string Peditdate
        {
            get => _peditdate;
            set
            {
                if (_peditdate != value)
                {
                    _peditdate = value;
                    base.RaisePropertyChanged("Peditdate");
                }
            }
        }

        /// <summary>
        /// 发布提示
        /// 成功，就提示发布成功
        /// 失败，就提示失败的原因
        /// </summary>
        public string Pcancsv
        {
            get => _pcancsv;
            set
            {
                if (_pcancsv != value)
                {
                    _pcancsv = value;
                    base.RaisePropertyChanged("Pcancsv");
                }
            }
        }

        /// <summary>
        /// (功能不清，保留，后期不用可清除）
        /// </summary>
        public string Lazadapublishresult { get => _lazadapublishresult; set => _lazadapublishresult = value; }

        /// <summary>
        /// (功能不清，保留，后期不用可清除）
        /// </summary>
        public string Lazadapublishdate { get => _lazadapublishdate; set => _lazadapublishdate = value; }

        /// <summary>
        /// 采集提示
        /// 未采集 >> 图片未采集 >> 采集完成
        /// </summary>
        public string Pstate
        {
            get => _pstate;
            set
            {
                if (_pstate != value)
                {
                    _pstate = value;
                    base.RaisePropertyChanged("Pstate");
                }
            }
        }

        /// <summary>
        /// 源链接创建时间(意义不清，保留，后期不用可清除）
        /// </summary>
        public string Plinkcreatedate { get => _plinkcreatedate; set => _plinkcreatedate = value; }

        /// <summary>
        /// 累计销量/收藏
        /// </summary>
        public string Pallsoldcount
        {
            get => _pallsoldcount;
            set
            {
                if (_pallsoldcount != value)
                {
                    _pallsoldcount = value;
                    base.RaisePropertyChanged("Pallsoldcount");
                }
            }
        }

        /// <summary>
        /// 选择的计价模板名称
        /// </summary>
        public string Pjisangongshi
        {
            get => _pjisangongshi;
            set
            {
                if (_pjisangongshi != value)
                {
                    _pjisangongshi = value;
                    base.RaisePropertyChanged("Pjisangongshi");
                }
            }
        }

        /// <summary>
        /// 库存
        /// </summary>
        public string Pkuchen
        {
            get => _pkuchen;
            set
            {
                if (_pkuchen != value)
                {
                    _pkuchen = value;
                    base.RaisePropertyChanged("Pkuchen");
                }
            }
        }

        /// <summary>
        /// 包裹长
        /// </summary>
        public string PackageLength
        {
            get => _PackageLength;
            set
            {
                if (_PackageLength != value)
                {
                    _PackageLength = value;
                    base.RaisePropertyChanged("PackageLength");
                }
            }
        }

        /// <summary>
        /// 包裹高
        /// </summary>
        public string PackageHight
        {
            get => _PackageHight;
            set
            {
                if (_PackageHight != value)
                {
                    _PackageHight = value;
                    base.RaisePropertyChanged("PackageHight");
                }
            }
        }

        /// <summary>
        /// 包裹宽
        /// </summary>
        public string PackageWidth
        {
            get => _PackageWidth;
            set
            {
                if (_PackageWidth != value)
                {
                    _PackageWidth = value;
                    base.RaisePropertyChanged("_PackageWidth");
                }
            }
        }


        /// <summary>
        /// 状态（原数值定义：0、10.待编辑，1.发布成功，2.发布失败，3、12、13.表格导入，6、7.同步过来，-3.回收站）
        /// 新定义状态 0:待编辑,1:发布成功,2：发布失败 -3：删除的
        /// </summary>
        public string Pstatetype
        {
            get => _pstatetype;
            set
            {
                if (_pstatetype != value)
                {
                    _pstatetype = value;
                    base.RaisePropertyChanged("Pstatetype");
                }
            }
        }

        /// <summary>
        /// (功能不清，保留，后期不用可清除）
        /// </summary>
        public string Prelalink { get => _prelalink; set => _prelalink = value; }

        /// <summary>
        /// SKU前缀
        /// </summary>
        public string Pidprefix
        {
            get => _pidprefix;
            set
            {
                if (_pidprefix != value)
                {
                    _pidprefix = value;
                    base.RaisePropertyChanged("Pidprefix");
                }
            }
        }

        /// <summary>
        /// 类别ID
        /// </summary>
        public string Lazadacategoryid
        {
            get => _lazadacategoryid;
            set
            {
                if (_lazadacategoryid != value)
                {
                    _lazadacategoryid = value;
                    base.RaisePropertyChanged("Lazadacategoryid");
                }
            }
        }

        /// <summary>
        /// 类别ID节点路径（保留，后期不用可清除）
        /// </summary>
        public string Lazadacategoryidpath { get => _lazadacategoryidpath; set => _lazadacategoryidpath = value; }

        /// <summary>
        /// 类别名称路径 用>>符号来分割
        /// </summary>
        public string Lazadacategorynamepath
        {
            get => _lazadacategorynamepath;
            set
            {
                if (_lazadacategorynamepath != value)
                {
                    _lazadacategorynamepath = value;
                    base.RaisePropertyChanged("Lazadacategorynamepath");
                }
            }
        }

        /// <summary>
        /// 卖点
        /// </summary>
        public string Lazadahighlight
        {
            get => _lazadahighlight;
            set
            {
                if (_lazadahighlight != value)
                {
                    _lazadahighlight = value;
                    base.RaisePropertyChanged("Lazadahighlight");
                }
            }
        }

        /// <summary>
        /// 描述
        /// </summary>
        public string Lazadadescription
        {
            get => _lazadadescription;
            set
            {
                if (_lazadadescription != value)
                {
                    _lazadadescription = value;
                    base.RaisePropertyChanged("Lazadadescription");
                }
            }
        }

        /// <summary>
        /// 原价
        /// </summary>
        public string Lazadaprice
        {
            get => _lazadaprice;
            set
            {
                if (_lazadaprice != value)
                {
                    _lazadaprice = value;
                    base.RaisePropertyChanged("Lazadaprice");
                }
            }
        }

        /// <summary>
        /// 促销价
        /// </summary>
        public string Lazadapromprice
        {
            get => _lazadapromprice;
            set
            {
                if (_lazadapromprice != value)
                {
                    _lazadapromprice = value;
                    base.RaisePropertyChanged("Lazadapromprice");
                }
            }
        }

        /// <summary>
        /// 促销开始时间 yyyy/MM/dd HH:mm:ss
        /// </summary>
        public string Lazadapromstart
        {
            get => _lazadapromstart;
            set
            {
                if (_lazadapromstart != value)
                {
                    _lazadapromstart = value;
                    base.RaisePropertyChanged("Lazadapromstart");
                }
            }
        }

        /// <summary>
        /// 促销结束时间  yyyy/MM/dd HH:mm:ss
        /// </summary>
        public string Lazadapromend
        {
            get => _lazadapromend;
            set
            {
                if (_lazadapromend != value)
                {
                    _lazadapromend = value;
                    base.RaisePropertyChanged("Lazadapromend");
                }
            }
        }

        /// <summary>
        /// 保修类型
        /// </summary>
        public string Lazadawarrantytype { get => _lazadawarrantytype; set => _lazadawarrantytype = value; }

        /// <summary>
        /// 保修期
        /// </summary>
        public string Lazadawarrantyperiod { get => _lazadawarrantyperiod; set => _lazadawarrantyperiod = value; }

        /// <summary>
        /// 保修策略
        /// </summary>
        public string Lazadawarrantypolicy { get => _lazadawarrantypolicy; set => _lazadawarrantypolicy = value; }

        /// <summary>
        /// 税种
        /// </summary>
        public string Lazadatax { get => _lazadatax; set => _lazadatax = value; }

        /// <summary>
        /// (功能不清，保留，后期不用可清除）
        /// </summary>
        public string Lazadaskyz { get => _lazadaskyz; set => _lazadaskyz = value; }

        /// <summary>
        /// 附加SKU时分配的类型
        /// </summary>
        public string Lazadaskuy
        {
            get => _lazadaskuy;
            set
            {
                if (_lazadaskuy != value)
                {
                    _lazadaskuy = value;
                    base.RaisePropertyChanged("Lazadaskuy");
                }
            }
        }

        /// <summary>
        /// 颜色尺码等变体属性名，值
        /// 用JSON字符串保存
        /// name：属性名称
        /// Value：属性值，属性值用,分割
        /// [{"name":"color_family","value":"Yellow , Black"},{"name":"size","value":"EU:35 , EU:36 , EU:37 , EU:38 , EU:39 , EU:40 , EU:41"}]
        /// </summary>
        public string Lazadaskux
        {
            get => _lazadaskux;
            set
            {
                if (_lazadaskux != value)
                {
                    _lazadaskux = value;
                    base.RaisePropertyChanged("Lazadaskux");
                }
            }
        }

        /// <summary>
        /// (功能不清，保留，后期不用可清除）
        /// </summary>
        public string Lazadasizes { get => _lazadasizes; set => _lazadasizes = value; }

        /// <summary>
        /// 根据类目选择后，需要填写的相关属性
        /// 用JSON字符串保存
        /// name：属性名称
        /// Value：属性值
        /// [{"name":"brand","value":"OEM"},{"name":"model","value":"自行车"},{"name":"pattern","value":"Abstract"},{"name":"towel_fabric","value":"100% cotton"}]
        /// </summary>
        public string Lazadaattributs
        {
            get => _lazadaattributs;
            set
            {
                if (_lazadaattributs != value)
                {
                    _lazadaattributs = value;
                    base.RaisePropertyChanged("Lazadaattributs");
                }
            }
        }

        /// <summary>
        /// 包裹重
        /// </summary>
        public string Lazadapackageweight
        {
            get => _lazadapackageweight;
            set
            {
                if (_lazadapackageweight != value)
                {
                    _lazadapackageweight = value;
                    base.RaisePropertyChanged("Lazadapackageweight");
                }
            }
        }

        /// <summary>
        /// 产品规格 （1 x headphones）
        /// </summary>
        public string Lazadapackageincluding
        {
            get => _lazadapackageincluding;
            set
            {
                if (_lazadapackageincluding != value)
                {
                    _lazadapackageincluding = value;
                    base.RaisePropertyChanged("Lazadapackageincluding");
                }
            }
        }

        /// <summary>
        /// 颜色等类对应的图片链接
        /// JSON字符串
        /// SKU ：属性字符串（name：属性名称，Value：属性值）
        /// leftimages: 图片路径集合 
        /// rightimages：图片路径集合
        /// </summary>
        public string Lazadaskuimages
        {
            get => _lazadaskuimages;
            set
            {
                if (_lazadaskuimages != value)
                {
                    _lazadaskuimages = value;
                    base.RaisePropertyChanged("Lazadaskuimages");
                }
            }
        }

        /// <summary>
        /// (功能不清，保留，后期不用可清除）
        /// </summary>
        public string PublishingSites { get => _PublishingSites; set => _PublishingSites = value; }

        /// <summary>
        /// 新加坡销售价格
        /// </summary>
        public string SgSalesPrice
        {
            get => _sgSalesPrice;
            set
            {
                if (_sgSalesPrice != value)
                {
                    _sgSalesPrice = value;
                    base.RaisePropertyChanged("SgSalesPrice");
                }
            }
        }

        /// <summary>
        /// 新加坡零售价格
        /// </summary>
        public string SgRetailPrice
        {
            get => _sgRetailPrice;
            set
            {
                if (_sgRetailPrice != value)
                {
                    _sgRetailPrice = value;
                    base.RaisePropertyChanged("SgRetailPrice");
                }
            }
        }

        /// <summary>
        /// 马来销售价格
        /// </summary>
        public string MySalesPrice
        {
            get => _mySalesPrice;
            set
            {
                if (_mySalesPrice != value)
                {
                    _mySalesPrice = value;
                    base.RaisePropertyChanged("MySalesPrice");
                }
            }
        }

        /// <summary>
        /// 马来零售价格
        /// </summary>
        public string MyRetailPrice
        {
            get => _myRetailPrice;
            set
            {
                if (_myRetailPrice != value)
                {
                    _myRetailPrice = value;
                    base.RaisePropertyChanged("MyRetailPrice");
                }
            }
        }

        /// <summary>
        /// 印尼销售价格
        /// </summary>
        public string IdSalesPrice
        {
            get => _idSalesPrice;
            set
            {
                if (_idSalesPrice != value)
                {
                    _idSalesPrice = value;
                    base.RaisePropertyChanged("IdSalesPrice");
                }
            }
        }

        /// <summary>
        /// 印尼零售价格
        /// </summary>
        public string IdRetailPrice
        {
            get => _idRetailPrice;
            set
            {
                if (_idRetailPrice != value)
                {
                    _idRetailPrice = value;
                    base.RaisePropertyChanged("IdRetailPrice");
                }
            }
        }

        /// <summary>
        /// 菲律宾销售价格
        /// </summary>
        public string PhSalesPrice
        {
            get => _phSalesPrice;
            set
            {
                if (_phSalesPrice != value)
                {
                    _phSalesPrice = value;
                    base.RaisePropertyChanged("PhSalesPrice");
                }
            }
        }

        /// <summary>
        /// 菲律宾零售价格
        /// </summary>
        public string PhRetailPrice
        {
            get => _phRetailPrice;
            set
            {
                if (_phRetailPrice != value)
                {
                    _phRetailPrice = value;
                    base.RaisePropertyChanged("PhRetailPrice");
                }
            }
        }

        /// <summary>
        /// 泰国销售价格
        /// </summary>
        public string ThSalesPrice
        {
            get => _thSalesPrice;
            set
            {
                if (_thSalesPrice != value)
                {
                    _thSalesPrice = value;
                    base.RaisePropertyChanged("ThSalesPrice");
                }
            }
        }

        /// <summary>
        /// 泰国零售价格
        /// </summary>
        public string ThRetailPrice
        {
            get => _thRetailPrice;
            set
            {
                if (_thRetailPrice != value)
                {
                    _thRetailPrice = value;
                    base.RaisePropertyChanged("ThRetailPrice");
                }
            }
        }

        /// <summary>
        /// 越南销售价格
        /// </summary>
        public string VnSalesPrice
        {
            get => _vnSalesPrice;
            set
            {
                if (_vnSalesPrice != value)
                {
                    _vnSalesPrice = value;
                    base.RaisePropertyChanged("VnSalesPrice");
                }
            }
        }

        /// <summary>
        /// 越南零售价格
        /// </summary>
        public string VnRetailPrice
        {
            get => _vnRetailPrice;
            set
            {
                if (_vnRetailPrice != value)
                {
                    _vnRetailPrice = value;
                    base.RaisePropertyChanged("VnRetailPrice");
                }
            }
        }

        /// <summary>
        /// 是否平均分配库存
        /// </summary>
        public Boolean AutoAllocateStock { get => _AutoAllocateStock; set => _AutoAllocateStock = value; }

        /// <summary>
        /// 视频连接
        /// </summary>
        public string Video
        {
            get => _video;
            set
            {
                if (_video != value)
                {
                    _video = value;
                    base.RaisePropertyChanged("Video");
                }
            }
        }

        /// <summary>
        /// SKU编号 （后缀名后面的数字）
        /// </summary>
        public Int64 SKUNumber
        {
            get => _SKUNumber;
            set
            {
                if (_SKUNumber != value)
                {
                    _SKUNumber = value;
                    base.RaisePropertyChanged("SKUNumber");
                }
            }
        }

        /// <summary>
        /// SPU编辑异常
        /// 没有编辑前，保存未编辑
        /// 编辑后，有错，保存错误
        /// 编辑后，没错，保存空字符串
        /// </summary>
        public string SPUEditError
        {
            get => _SPUEditError;
            set
            {
                if (_SPUEditError != value)
                {
                    _SPUEditError = value;
                    base.RaisePropertyChanged("SPUEditError");
                    base.RaisePropertyChanged("GlobalError");
                }
            }
        }

        /// <summary>
        /// 详情编辑异常
        /// 没有编辑前，保存未编辑
        /// 编辑后，有错，保存错误
        /// 编辑后，没错，保存空字符串
        /// </summary>
        public string DetailsEditError
        {
            get => _DetailsEditError;
            set
            {
                if (_DetailsEditError != value)
                {
                    _DetailsEditError = value;
                    base.RaisePropertyChanged("DetailsEditError");
                    base.RaisePropertyChanged("GlobalError");
                }
            }
        }

        /// <summary>
        /// 上传图片异常
        /// 没有编辑前，保存未编辑
        /// 编辑后，有错，保存错误
        /// 编辑后，没错，保存空字符串
        /// </summary>
        public string UploadImgError
        {
            get => _UploadImgError;
            set
            {
                if (_UploadImgError != value)
                {
                    _UploadImgError = value;
                    base.RaisePropertyChanged("UploadImgError");
                    base.RaisePropertyChanged("GlobalError");
                }
            }
        }

        /// <summary>
        /// 子SKU
        /// 发布成功后更新该字段
        /// 保存发布到后台的子SKU，以,分割
        /// </summary>
        public string ChildSku { get => _ChildSku; set => _ChildSku = value; }

        public string GlobalError
        {
            get => _SPUEditError + "\n" + _DetailsEditError + "\n" + _UploadImgError;
        }
        public string ServerID { get => _ServerID; set => _ServerID = value; }

        public bool IsChecked
        {
            get => _isChecked;
            set
            {
                if (_isChecked != value)
                {
                    _isChecked = value;
                    base.RaisePropertyChanged("IsChecked");
                }
            }
        }

        public string LazadaCategoryTreePath { get => _lazadaCategoryTreePath; set => _lazadaCategoryTreePath = value; }

        public string SKUDetail { get => _SKUDetail; set => _SKUDetail = value; }

        #endregion
    }
}
