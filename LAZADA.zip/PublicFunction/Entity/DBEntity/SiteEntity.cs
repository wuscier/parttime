﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.DBEntity
{
    public class SiteEntity
    {
        public long ID { get; set; }
        public string EnName { get; set; }
        public string ZhName { get; set; }
    }
}
