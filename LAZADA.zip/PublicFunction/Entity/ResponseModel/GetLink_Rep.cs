﻿using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.ResponseModel
{
    /// <summary>
    /// 获取链接请求
    /// </summary>
    public class GetLink_Rep : HttpResponseBaseModel
    {
        /// <summary>
        /// 操作状态
        /// </summary>
        public string raction { get; set; }
        /// <summary>
        /// 新链接条数
        /// </summary>
        public int count { get; set; }
        /// <summary>
        /// 链接集合
        /// </summary>
        public List<string> links { get; set; }
        /// <summary>
        /// 总条数
        /// </summary>
        public int endpos { get; set; }
        /// <summary>
        /// 动作名称
        /// getAllCount,getAllLink,setHaveDown,getNewCount,getNewLink
        /// </summary>
        public string oaction { get; set; }
    }
}
