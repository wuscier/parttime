﻿using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.ResponseModel
{
    public class UserLogin_Rep : HttpResponseBaseModel
    {
        /// <summary>
        /// 保存登录请求认证Token
        /// </summary>
        public string access_token { get; set; }
        /// <summary>
        /// Token有效期
        /// </summary>
        public int expires_in { get; set; }
        /// <summary>
        /// Token类型
        /// </summary>
        public string token_type { get; set; }
        /// <summary>
        /// 更新Token
        /// </summary>
        public string refresh_token { get; set; }
    }
}
