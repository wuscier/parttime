﻿using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.ResponseModel
{
    public class RemainAmount_Rep : HttpResponseBaseModel
    {
        public  string rcode { get; set; }
        public  string msg { get; set; }
    }
}
