﻿using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.BaseEntity
{
    /// <summary>
    /// HttpRequest基类
    /// 用于请求的实体基类
    /// </summary>
    public class HttpRequestBaseModel
    {
    }
}
