﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.BaseEntity
{
    /// <summary>
    /// HttpResponse基类
    /// 用于转换请求返回数据的实体
    /// </summary>
    public class HttpResponseBaseModel
    {
       
    }
}
