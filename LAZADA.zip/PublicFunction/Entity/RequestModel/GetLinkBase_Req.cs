﻿using LAZADA;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.RequestModel
{
    /// <summary>
    /// 获取链接请求实体
    /// </summary>
    public class GetLinkBase_Req : HttpRequestBaseModel
    {
        /// <summary>
        /// 获取链接基础构造函数
        /// </summary>
        /// <param name="action">
        /// 动作名称
        /// getAllCount,getAllLink,setHaveDown,getNewCount,getNewLink
        /// </param>
        /// <param name="startp">条数</param>
        public GetLinkBase_Req(string action, string startp)
        {
            arg1 = DateTime.Now.GetDateTimeFormats('r')[0].ToString();
            arg2 = EncryptionWay.Encrypt(arg1, HttpClientModeConverter.GetArg2KeyByMode(HttpClientMode.GetLink));
            JObject jsondata = new JObject();
            jsondata["action"] = action;
            jsondata["startp"] = startp;
            jsondata["uname"] = GlobalUserClass.uname;
            arg3 = EncryptionWay.Encrypt(JsonConvert.SerializeObject(jsondata), HttpClientModeConverter.GetArg3KeyByMode(HttpClientMode.GetLink));
        }


        public string arg1 { get; set; }
        public string arg2 { get; set; }
        public string arg3 { get; set; }
    }
}
