﻿using PublicFunction.Entity.BaseEntity;
using PublicFunction.WebRequestHelper;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using LAZADA;

namespace PublicFunction.Entity.RequestModel
{
    /// <summary>
    /// 剩余额度请求实体类
    /// </summary>
    public class RemainAmount_Req : HttpRequestBaseModel
    {
        public RemainAmount_Req()
        {
            arg1 = DateTime.Now.GetDateTimeFormats('r')[0].ToString() + GlobalUserClass.uname;
            arg2 = EncryptionWay.Encrypt(arg1, HttpClientModeConverter.GetArg2KeyByMode(HttpClientMode.GetRemainAmount));
            JObject jsondata = new JObject();
            jsondata["uname"] = GlobalUserClass.uname;
            jsondata["uepwd"] = GlobalUserClass.uepwd;
            arg3 = EncryptionWay.Encrypt(JsonConvert.SerializeObject(jsondata), HttpClientModeConverter.GetArg3KeyByMode(HttpClientMode.GetRemainAmount));
        }

        public string arg1 { get; set; }
        public string arg2 { get; set; }
        public string arg3 { get; set; }
    }
}
