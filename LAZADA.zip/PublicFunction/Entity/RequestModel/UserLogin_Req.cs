﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.ResponseModel;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.RequestModel
{
    /// <summary>
    /// 登录请求实体类
    /// </summary>
    public class UserLogin_Req : HttpRequestBaseModel
    {

        /// <summary>
        /// 通过构造函数，初始化对象
        /// </summary>
        public UserLogin_Req(string userName, string userPwd)
        {
           
        }
       

    }
}
