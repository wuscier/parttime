﻿using LAZADA;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.RequestModel
{
    public class ReduceAmount_Req : HttpRequestBaseModel
    {
        public ReduceAmount_Req()
        {
            arg1 = DateTime.Now.GetDateTimeFormats('r')[0].ToString() + GlobalUserClass.uname;
            arg2 = EncryptionWay.Encrypt(arg1, HttpClientModeConverter.GetArg2KeyByMode(HttpClientMode.ReduceAmount));
            JObject jsondata = new JObject();
            jsondata["uname"] = GlobalUserClass.uname;
            jsondata["uepwd"] = GlobalUserClass.uepwd;
            jsondata["reducecount"] = "1";
            arg3 = EncryptionWay.Encrypt(JsonConvert.SerializeObject(jsondata), HttpClientModeConverter.GetArg3KeyByMode(HttpClientMode.ReduceAmount));
        }

        public string arg1 { get; set; }
        public string arg2 { get; set; }
        public string arg3 { get; set; }
    }
}
