﻿using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.ViewModel
{
    public class MainWinViewModel : BaseViewModel
    {
        #region 私有变量
        /// <summary>
        /// 当前任务名称
        /// </summary>
        private string ibulkType = "";
        /// <summary>
        /// 是否在执行任务
        /// </summary>
        private bool isRunTask = false;
        /// <summary>
        /// 当前任务的进度值
        /// </summary>
        private double ipbvalue = 0;
        /// <summary>
        /// 当前任务的进度说明
        /// </summary>
        private string ibulkstate = "";
        /// <summary>
        /// 当前任务的错误数量
        /// </summary>
        private int ibulkErrowCount = 0;
        /// <summary>
        /// 需要执行的任务数量
        /// </summary>
        private int taskCount = 0;
        /// <summary>
        /// 已经在执行的任务数量
        /// </summary>
        private int taskRunCount = 0;
        /// <summary>
        /// 进度条一次增加的数值
        /// </summary>
        private double taskAdd = 0;
        #endregion
        #region 属性
        /// <summary>
        /// 当前任务名称
        /// </summary>
        public string IbulkType
        {
            get => ibulkType;
            set
            {
                if (ibulkType != value)
                {
                    ibulkType = value;
                    base.RaisePropertyChanged("IbulkType");
                }
            }
        }
        /// <summary>
        /// 是否在执行任务
        /// </summary>
        public bool IsRunTask
        {
            get
            {
                if (TaskCount != 0 && TaskRunCount != 0)
                {
                    return !(TaskCount == TaskRunCount);
                }
                return isRunTask;
            }
            set
            {
                if (isRunTask != value)
                {
                    isRunTask = value;
                    base.RaisePropertyChanged("IsRunTask");
                }
            }
        }
        /// <summary>
        /// 当前任务的进度值
        /// </summary>
        public double Ipbvalue
        {
            get => ipbvalue;
            set
            {
                if (ipbvalue != value)
                {
                    ipbvalue = value;
                    base.RaisePropertyChanged("Ipbvalue");
                }
            }
        }

        /// <summary>
        /// 当前任务的进度说明
        /// </summary>
        public string Ibulkstate
        {
            get => taskRunCount + "/" + taskCount;
        }

        /// <summary>
        /// 当前任务的错误数量
        /// </summary>
        public int IbulkErrowCount
        {
            get => ibulkErrowCount;
            set
            {
                if (ibulkErrowCount != value)
                {
                    ibulkErrowCount = value;
                    base.RaisePropertyChanged("IbulkErrowCount");
                    base.RaisePropertyChanged("IsRunTask");
                }
            }
        }


        /// <summary>
        /// 需要执行的任务数量
        /// </summary>
        public int TaskCount
        {
            get => taskCount;
            set
            {
                if (taskCount != value)
                {
                    taskCount = value;
                    base.RaisePropertyChanged("TaskCount");
                    base.RaisePropertyChanged("TaskAdd");
                    base.RaisePropertyChanged("Ibulkstate");
                    base.RaisePropertyChanged("IsRunTask");
                }
            }
        }

        /// <summary>
        /// 已经在执行的任务数量
        /// </summary>
        public int TaskRunCount
        {
            get => taskRunCount;
            set
            {
                if (taskRunCount != value)
                {
                    taskRunCount = value;
                    base.RaisePropertyChanged("TaskRunCount");
                    base.RaisePropertyChanged("Ibulkstate");
                    base.RaisePropertyChanged("IsRunTask");
                }
            }
        }

        /// <summary>
        /// 进度条一次增加的数值
        /// </summary>
        public int TaskAdd
        {
            get => taskCount == 0 ? 0 : Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(100) / taskCount));
        }
        #endregion

        public void InitModel(string nowTitle, int count)
        {
            IsRunTask = true;
            IbulkType = nowTitle;
            Ipbvalue = 0;
            IbulkErrowCount = 0;
            TaskCount = count;
            TaskRunCount = 0;
        }
    }
}
