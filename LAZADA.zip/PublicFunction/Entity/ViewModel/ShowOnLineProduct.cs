﻿using LAZADA;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.ViewModel
{
    public class ShowOnLineProduct : BaseViewModel
    {
        #region 私有属性


        public string Url { get; set; }
        /// <summary>
        /// 产品编号
        /// </summary>
        private string _itemid;
        /// <summary>
        /// SKU标题
        /// </summary>
        private string _title;
        /// <summary>
        /// 主SKU
        /// </summary>
        private string _mainSku;
        /// <summary>
        /// SKU主图（以第一个子SKU为准）
        /// </summary>
        private string _img;
        /// <summary>
        /// SKU创建时间（以第一个子SKU为准）
        /// </summary>
        private DateTime _createTime;
        /// <summary>
        /// SKU最后更新时间（以第一个子SKU为准）
        /// </summary>
        private DateTime _updateTime;
        /// <summary>
        /// SKU变体属性 相同属性以‘,’分割,不同属性换行/n
        /// </summary>
        private List<string> _skuaAttrs;
        /// <summary>
        /// 所有子SKU
        /// </summary>
        private AsyncObservableCollection<ChildSKU> _SKUS;
        /// <summary>
        /// 是否更新
        /// </summary>
        private bool _isUpdate;
        /// <summary>
        /// 是否选中
        /// </summary>
        private bool _isChecked;
        /// <summary>
        /// 加载的SKU JSON字符串后期用于上传
        /// </summary>
        private string jsonStr;

        /// <summary>
        /// 站点ID
        /// </summary>
        private int _siteid;
        /// <summary>
        /// 所有的子SKU,以“,”分割
        /// </summary>
        private string _sellersku;

        /// <summary>
        /// 类别ID
        /// </summary>
        private string _categoryid;

        private DateTime _localTime;

        /// <summary>
        /// 标题评分
        /// </summary>
        private string _titleScore;

        /// <summary>
        /// 旧标题
        /// </summary>
        private string _oldTitle;

        /// <summary>
        /// 店铺名称
        /// </summary>
        private string _storeName;
        
        /// <summary>
        /// 评分细则
        /// </summary>
        private string _scoreDetail;
        #endregion

        #region 变量

        public string Itemid
        {
            get => _itemid;
            set
            {
                if (_itemid != value)
                {
                    _itemid = value;
                    base.RaisePropertyChanged("Itemid");
                }
            }
        }

        public string ScoreDetail
        {
            get => _scoreDetail;
            set
            {
                if (_scoreDetail != value)
                {
                    _scoreDetail = value;
                    base.RaisePropertyChanged("ScoreDetail");
                }
            }
        }

        public string Categoryid
        {
            get => _categoryid;
            set
            {
                if (_categoryid != value)
                {
                    _categoryid = value;
                    base.RaisePropertyChanged("Categoryid");
                }
            }
        }

        public string Title
        {
            get => _title;
            set
            {
                if (_title != value)
                {
                    _title = value;
                    base.RaisePropertyChanged("Title");
                }
            }
        }
        public string MainSku
        {
            get => _mainSku;
            set
            {
                if (_mainSku != value)
                {
                    _mainSku = value;
                    base.RaisePropertyChanged("MainSku");
                }
            }
        }
        public string Img
        {
            get => _img;
            set
            {
                if (_img != value)
                {
                    _img = value;
                    base.RaisePropertyChanged("Img");
                }
            }
        }
        public DateTime CreateTime
        {
            get => _createTime;
            set
            {
                if (_createTime != value)
                {
                    _createTime = value;
                    base.RaisePropertyChanged("CreateTime");
                }
            }
        }
        public DateTime UpdateTime
        {
            get => _updateTime;
            set
            {
                if (_updateTime != value)
                {
                    _updateTime = value;
                    base.RaisePropertyChanged("UpdateTime");
                }
            }
        }
        public List<string> SkuaAttrs
        {
            get => _skuaAttrs;
            set
            {
                if (_skuaAttrs != value)
                {
                    _skuaAttrs = value;
                    base.RaisePropertyChanged("SkuaAttrs");
                }
            }
        }
        public AsyncObservableCollection<ChildSKU> SKUS
        {
            get => _SKUS;
            set
            {
                if (_SKUS != value)
                {
                    _SKUS = value;
                    base.RaisePropertyChanged("SKUS");
                }
            }
        }
        public bool IsUpdate
        {
            get => _isUpdate;
            set
            {
                if (_isUpdate != value)
                {
                    _isUpdate = value;
                    base.RaisePropertyChanged("IsUpdate");
                }
            }
        }

        public string JsonStr
        {
            get => jsonStr;
            set
            {
                if (jsonStr != value)
                {
                    jsonStr = value;
                    base.RaisePropertyChanged("JsonStr");
                }
            }
        }

        public bool IsChecked
        {
            get => _isChecked;
            set
            {
                if (_isChecked != value)
                {
                    _isChecked = value;
                    base.RaisePropertyChanged("IsChecked");
                }
            }
        }

        public int Siteid
        {
            get => _siteid;
            set
            {
                if (_siteid != value)
                {
                    _siteid = value;
                    base.RaisePropertyChanged("Siteid");
                }
            }
        }
        public string Sellersku
        {
            get => _sellersku;
            set
            {
                if (_sellersku != value)
                {
                    _sellersku = value;
                    base.RaisePropertyChanged("Sellersku");
                }
            }
        }
        public DateTime LocalTime
        {
            get => _localTime;
            set
            {
                if (_localTime != value)
                {
                    _localTime = value;
                    base.RaisePropertyChanged("LocalTime");
                }
            }
        }
        public string TitleScore
        {
            get => _titleScore;
            set
            {
                if (_titleScore != value)
                {
                    _titleScore = value;
                    base.RaisePropertyChanged("TitleScore");
                }
            }
        }
        public string OldTitle
        {
            get => _oldTitle;
            set
            {
                if (_oldTitle != value)
                {
                    _oldTitle = value;
                    base.RaisePropertyChanged("OldTitle");
                }
            }
        }
        public string StoreName
        {
            get => _storeName;
            set
            {
                if (_storeName != value)
                {
                    _storeName = value;
                    base.RaisePropertyChanged("StoreName");
                }
            }
        }
        #endregion
    }

    public class ChildSKU : BaseViewModel
    {
        private bool isChecked;
        /// <summary>
        /// 子Sku
        /// </summary>
        private string _sellerSku;
        /// <summary>
        /// 促销开始时间
        /// </summary>
        private string _special_to_time;
        /// <summary>
        /// 促销结束时间
        /// </summary>
        private string _special_from_time;
        /// <summary>
        /// 价格
        /// </summary>
        private string _price;
        /// <summary>
        /// 促销价格
        /// </summary>
        private string _special_price;
        /// <summary>
        /// 库存
        /// </summary>
        private string _quantity;

        public string SellerSku
        {
            get => _sellerSku;
            set
            {
                if (_sellerSku != value)
                {
                    _sellerSku = value;
                    base.RaisePropertyChanged("SellerSku");
                }
            }
        }
        public string Special_to_time
        {
            get => _special_to_time;
            set
            {
                if (_special_to_time != value)
                {
                    _special_to_time = value;
                    base.RaisePropertyChanged("Special_to_time");
                }
            }
        }
        public string Special_from_time
        {
            get => _special_from_time;
            set
            {
                if (_special_from_time != value)
                {
                    _special_from_time = value;
                    base.RaisePropertyChanged("Special_from_time");
                }
            }
        }
        public string Price
        {
            get => _price;
            set
            {
                if (_price != value)
                {
                    _price = value;
                    base.RaisePropertyChanged("Price");
                }
            }
        }
        public string Special_price
        {
            get => _special_price;
            set
            {
                if (_special_price != value)
                {
                    _special_price = value;
                    base.RaisePropertyChanged("Special_price");
                }
            }
        }
        public string Quantity
        {
            get => _quantity;
            set
            {
                if (_quantity != value)
                {
                    _quantity = value;
                    base.RaisePropertyChanged("Quantity");
                }
            }
        }

        public bool IsChecked
        {
            get => isChecked;
            set
            {
                if (isChecked != value)
                {
                    isChecked = value;
                    base.RaisePropertyChanged("IsChecked");
                }
            }
        }
    }

    public enum OnlineProductType
    {
        all,//all,
        live,//live,
        inactive,//inactive,
        deleted,//deleted,
        imagemissing,//image-missing,
        pending,//pending,
        rejected,//rejected,
        soldout,//sold-out
        Mandatory//Mandatory
    }
}
