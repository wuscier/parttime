﻿using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.ViewModel
{
    public class SimpleProduct : BaseViewModel
    {
        private string _title;
        private string _from;
        private string _price;
        private string _weight;
        private string _linkUrl;
        private string _mainSku;
        private string _mainPicture;
        private string _id;
        private bool isChecked = false;
        private bool isExists;
        private string creationTime;

        /// <summary>
        /// 标题
        /// </summary>
        public string Title
        {
            get => _title;
            set
            {
                if (_title != value)
                {
                    _title = value;
                    base.RaisePropertyChanged("Title");
                }
            }
        }
        /// <summary>
        /// 平台
        /// </summary>
        public string From
        {
            get => _from;
            set
            {
                if (_from != value)
                {
                    _from = value;
                    base.RaisePropertyChanged("From");
                }
            }
        }
        /// <summary>
        /// 原价RMB
        /// </summary>
        public string Price
        {
            get => _price;
            set
            {
                if (_price != value)
                {
                    _price = value;
                    base.RaisePropertyChanged("Price");
                }
            }
        }
        /// <summary>
        /// 净重
        /// </summary>
        public string Weight
        {
            get => _weight;
            set
            {
                if (_weight != value)
                {
                    _weight = value;
                    base.RaisePropertyChanged("Weight");
                }
            }
        }
        /// <summary>
        /// 货源链接
        /// </summary>
        public string LinkUrl
        {
            get => _linkUrl;
            set
            {
                if (_linkUrl != value)
                {
                    _linkUrl = value;
                    base.RaisePropertyChanged("LinkUrl");
                }
            }
        }
        /// <summary>
        /// 主SKU名称
        /// </summary>
        public string MainSku
        {
            get => _mainSku;
            set
            {
                if (_mainSku != value)
                {
                    _mainSku = value;
                    base.RaisePropertyChanged("MainSku");
                }
            }
        }

        /// <summary>
        /// 主图链接
        /// </summary>
        public string MainPicture
        {
            get => _mainPicture;
            set
            {
                if (_mainPicture != value)
                {
                    _mainPicture = value;
                    base.RaisePropertyChanged("MainPicture");
                }
            }
        }

        /// <summary>
        /// 是否被选中
        /// </summary>
        public bool IsChecked
        {
            get => isChecked;
            set
            {
                if (isChecked != value)
                {
                    isChecked = value;
                    base.RaisePropertyChanged("IsChecked");
                }
            }
        }

        /// <summary>
        /// 产品ID
        /// </summary>
        public string Id { get => _id; set => _id = value; }
        public bool IsExists { get => isExists; set => isExists = value; }
        public string CreationTime {
            get => creationTime;
            set
            {
                if (creationTime != value)
                {
                    creationTime = value;
                    base.RaisePropertyChanged("CreationTime");
                }
            }
        }
    }
}
