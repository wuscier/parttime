﻿using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.Entity.ViewModel
{
    public class NewTaskViewModel : BaseViewModel
    {
        private string msg = "";
        private string barContent = "0/0";
        private double barValue = 0;
        private int counts;

        public string BarContent
        {
            get => barContent;
            set
            {
                if (barContent != value)
                {
                    barContent = value;
                    base.RaisePropertyChanged("BarContent");
                }
            }
        }
        public double BarValue
        {
            get => barValue;
            set
            {
                if (barValue != value)
                {
                    barValue = value;
                    base.RaisePropertyChanged("BarValue");
                }
            }
        }

        public string Msg
        {
            get => msg;
            set
            {
                if (msg != value)
                {
                    msg = value;
                    base.RaisePropertyChanged("Msg");
                }
            }
        }

        public int Counts
        {
            get => counts;
            set
            {
                if (counts != value)
                {
                    counts = value;
                    base.RaisePropertyChanged("Counts");
                }
            }
        }
    }
}
