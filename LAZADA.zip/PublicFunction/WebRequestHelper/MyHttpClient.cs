﻿using LAZADA;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.AlertHelp;
using PublicFunction.Entity;
using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PublicFunction.WebRequestHelper
{
    public class MyHttpClient
    {
        /// <summary>
        /// 私有的访问网络对象
        /// </summary>
        //private static HttpClient httpClient = null;


        public string GetResponse(string resquestUri)
        {
            string result = "";
            using (HttpClient client = new HttpClient())
            {
                var response = client.GetAsync(resquestUri).Result;
                result = response.Content.ReadAsStringAsync().Result;
                return result;
            }
        }

        /// <summary>
        /// 通过Post方法返回请求的实体对象 
        /// 同步 对应keep_alive=true 
        /// </summary>
        /// <typeparam name="T">返回数据的实体对象</typeparam>
        /// <param name="mode">请求数据的方式(详见枚举说明)</param>
        /// <param name="requestModel">请求数据的实体类</param>
        /// <returns></returns>
        public T PostEntity<T>(HttpClientMode mode, HttpRequestBaseModel requestModel) where T : HttpResponseBaseModel, new()
        {
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.Timeout = TimeSpan.FromSeconds(5);
                    HttpResponseMessage response = httpClient.PostAsJsonAsync(HttpClientModeConverter.CreateHttpClientURL(mode), requestModel).Result;
                    var result = response.Content.ReadAsStringAsync().Result;
                    var jsondata = (JObject)JsonConvert.DeserializeObject(result);
                    return JsonConvert.DeserializeObject<T>(jsondata["d"].ToString());
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return default(T);
            }
        }

        /// <summary>
        /// 通过Post方法返回请求的实体对象
        /// 异步 对应keep_alive=false
        /// </summary>
        /// <typeparam name="T">返回数据的实体对象</typeparam>
        /// <param name="mode">请求数据的方式(详见枚举说明)</param>
        /// <param name="requestModel">请求数据的实体类</param>
        /// <returns></returns>
        public async Task<T> PostEntityAsync<T>(HttpClientMode mode, HttpRequestBaseModel requestModel) where T : HttpResponseBaseModel, new()
        {
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.Timeout = TimeSpan.FromSeconds(5);
                    HttpResponseMessage response = await httpClient.PostAsJsonAsync(HttpClientModeConverter.CreateHttpClientURL(mode), requestModel);
                    var result = await response.Content.ReadAsStringAsync();
                    var jsondata = (JObject)JsonConvert.DeserializeObject(result);
                    return JsonConvert.DeserializeObject<T>(jsondata["d"].ToString());
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return default(T);
            }
        }

        /// <summary>
        /// 通过Post方法返回请求的实体对象
        /// 异步 对应keep_alive=false
        /// </summary>
        /// <typeparam name="T">返回数据的实体对象</typeparam>
        /// <param name="mode">请求数据的方式(详见枚举说明)</param>
        /// <param name="requestModel">请求数据的实体类</param>
        /// <returns></returns>
        public JObject PostEntityAsync(HttpClientMode mode, HttpRequestBaseModel requestModel)
        {
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.Timeout = TimeSpan.FromSeconds(5);
                    HttpResponseMessage httpResponse = httpClient.PostAsJsonAsync(HttpClientModeConverter.CreateHttpClientURL(mode), requestModel).Result;
                    var str = httpResponse.Content.ReadAsStringAsync().Result;
                    var d = (JObject)JsonConvert.DeserializeObject(str);
                    return (JObject)JsonConvert.DeserializeObject(d["d"].ToString());
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return new JObject();
            }
        }


        /// <summary>
        /// 异步发送请求
        /// </summary>
        /// <typeparam name="T">转换成的实体类</typeparam>
        /// <param name="method">请求方式</param>
        /// <param name="url">请求地址</param>
        /// <param name="content">Http实体正文和内容标头</param>
        /// <returns></returns>
        public async Task<string> SendResponseAsync(HttpMethod method, string url, HttpContent content = null)
        {
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.Timeout = TimeSpan.FromSeconds(5);
                    var httpRequest = new HttpRequestMessage(method, url);
                    if (content != null)
                    {
                        httpRequest.Content = content;
                    }
                    HttpResponseMessage response = await httpClient.SendAsync(httpRequest);
                    var result = await response.Content.ReadAsStringAsync();
                    return result;
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return "";
            }
        }



        /// <summary>
        /// POST请求
        /// x-www-form-urlencoded方式的POST请求
        /// 目前用于
        /// 1.请求认证服务登录
        /// 2.刷新TOKEN
        /// </summary>
        /// <param name="url">请求地址</param>
        /// <param name="pairs">请求参数</param>
        /// <returns></returns>
        public JObject AsyncPostWithFormEncoded(string url, List<KeyValuePair<string, string>> pairs)
        {
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.Timeout = TimeSpan.FromSeconds(5);
                    HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, url)
                    {
                        Content = new FormUrlEncodedContent(pairs)
                    };
                    HttpResponseMessage httpResponse = httpClient.SendAsync(requestMessage).Result;
                    return httpResponse.Content.ReadAsAsync<JObject>().Result;

                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine("AsyncPostWithFormEncoded 请求错误：" + ex.Message);
                return default;
            }
        }


        /// <summary>
        /// Get请求
        /// 目前用于
        /// 1.获取个人信息
        /// 2.获取已授权的站点的TOKEN
        /// 3.获取用户所有授权
        /// 4.获取产品详情
        /// </summary>
        /// <param name="url">api地址</param>
        /// <param name="pairs">API地址后面的参数键值对</param>
        /// <returns></returns>
        public JObject GetWithToken(string url, List<KeyValuePair<string, string>> pairs = null, string otherToken = "")
        {
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    var token = (otherToken == "" ? GlobalUserClass.Access_Token : otherToken);
                    httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + (otherToken == "" ? GlobalUserClass.Access_Token : otherToken));
                    if (pairs != null)
                    {
                        url += "?";
                        foreach (var item in pairs)
                        {
                            url += item.Key + "=" + item.Value + "&";
                        }
                        url = url.Substring(0, url.Length - 1);
                    }
                    var myurl = url;
                    HttpResponseMessage httpResponse = httpClient.GetAsync(url).Result;
                    return httpResponse.Content.ReadAsAsync<JObject>().Result;

                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine("AsyncGetWithToken 请求错误：" + ex.Message);
                return default;
            }
        }

        /// <summary>
        /// POST请求
        /// 目前用于
        /// 1.上传产品记录
        /// 2.获取产品分页列表
        /// </summary>
        /// <param name="url"></param>
        /// <param name="jObject"></param>
        /// <returns></returns>
        public JObject PostDataWithToken(string url, JObject jObject, string otherToken = "")
        {
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + (otherToken == "" ? GlobalUserClass.Access_Token : otherToken));
                    HttpResponseMessage httpResponse = httpClient.PostAsJsonAsync(url, jObject).Result;
                    return httpResponse.Content.ReadAsAsync<JObject>().Result;
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine("AsyncPostDataWithToken 请求错误：" + ex.Message);
                return default;
            }
        }

        /// <summary>
        /// PUT请求
        /// 目前用于
        /// 1.更新店铺名称
        /// </summary>
        /// <param name="url"></param>
        /// <param name="jObject"></param>
        /// <returns></returns>
        public JObject PutDataWithToken(string url, JObject jObject, string otherToken = "")
        {
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + (otherToken == "" ? GlobalUserClass.Access_Token : otherToken));
                    HttpResponseMessage httpResponse = httpClient.PutAsJsonAsync(url, jObject).Result;
                    return httpResponse.Content.ReadAsAsync<JObject>().Result;
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine("AsyncPostDataWithToken 请求错误：" + ex.Message);
                return default;
            }
        }
    }


}
