﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.WebRequestHelper
{
    public class WebClientWithOutTime : WebClient
    {
        protected override WebRequest GetWebRequest(Uri address)
        {

            HttpWebRequest request = (HttpWebRequest)base.GetWebRequest(address);
            request.Timeout = 10000;//设置超时为0.5分钟
            request.ReadWriteTimeout = 20000;
            return request;
        }
    }

    public class aimg
    {
        public string imgUrl;
        public string imgName;
        public int imgId;

        public aimg(string _imgUrl, string _imgName, int _imgId)
        {
            this.imgUrl = _imgUrl;
            this.imgName = _imgName;
            this.imgId = _imgId;

        }
    }

}
