﻿using LAZADA;
using Lazop.Api;
using Lazop.Api.Util;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.ConfigHelp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.WebRequestHelper
{
    /// <summary>
    /// Lazada平台数据请求类
    /// </summary>
    public class LazadaRequestClient
    {
        /// <summary>
        /// Lazada请求数据
        /// </summary>
        /// <param name="apiName">求情的接口地址 如"/brands/get"</param>
        /// <param name="httpMethod">求情的方式 如"GET"</param>
        /// <param name="paramDic">请求的参数键值对</param>
        /// <returns></returns>
        public JObject GetResponse(string apiName, string httpMethod, Dictionary<string, string> paramDic = null)
        {
            //Constants.GETLAZADA_APPSECRET();
            ILazopClient client = new LazopClient(new SiteChangeHelp().GetPushLazadaUrl(), Constants.LAZADA_APPKEY, Constants.LAZADA_APPSECRET);
            LazopRequest request = new LazopRequest();
            request.SetApiName(apiName);
            request.SetHttpMethod(httpMethod);
            if (paramDic != null)
            {
                foreach (var item in paramDic)
                {
                    request.AddApiParameter(item.Key, item.Value);
                }
            }
            LazopResponse response = client.Execute(request);
            //isError = response == null ? true : response.IsError();
            return response.Body == string.Empty ? null : (JObject)JsonConvert.DeserializeObject(response.Body);
        }

        /// <summary>
        /// Lazada请求数据
        /// </summary>
        /// <param name="apiName">求情的接口地址 如"/brands/get"</param>
        /// <param name="httpMethod">求情的方式 如"GET"</param>
        /// <param name="paramDic">请求的参数键值对</param>
        /// <returns></returns>
        public JObject GetResponseToken(string apiName, string httpMethod, Dictionary<string, string> paramDic = null)
        {
            //Constants.GETLAZADA_APPSECRET();
            ILazopClient client = new LazopClient(new SiteChangeHelp().GetPushLazadaUrl(), Constants.LAZADA_APPKEY ,  Constants.LAZADA_APPSECRET);
            LazopRequest request = new LazopRequest();
            request.SetApiName(apiName);
            request.SetHttpMethod(httpMethod);
            if (paramDic != null)
            {
                foreach (var item in paramDic)
                {
                    request.AddApiParameter(item.Key, item.Value);
                }
            }
            var token = Constants.OnlineLAZADA_ACCESSTOKEN;
            if (token == "")
            {
                new GlobalUserClass().GETLAZADATOKEN(GlobalUserClass.SiteId);
                token = Constants.LAZADA_ACCESSTOKEN;
            }
            LazopResponse response = client.Execute(request, token);
            //isError = response == null ? true : response.IsError();
            return response.Body == string.Empty ? null : (JObject)JsonConvert.DeserializeObject(response.Body);
        }

        /// <summary>
        /// Lazada请求数据
        /// </summary>
        /// <param name="apiName"></param>
        /// <param name="isError"></param>
        /// <param name="paramDic"></param>
        /// <returns></returns>
        public JObject GetResponseToken(string apiName, out bool isError, Dictionary<string, string> paramDic = null)
        {
            //Constants.GETLAZADA_APPSECRET();
            JObject obj = new JObject();
            isError = true;
            foreach (var str in Constants.ReleaseStore)
            {
                ILazopClient client = new LazopClient(new SiteChangeHelp().GetPushLazadaUrl(), Constants.LAZADA_APPKEY, Constants.LAZADA_APPSECRET);
                LazopRequest request = new LazopRequest();
                request.SetApiName(apiName);
                if (paramDic != null)
                {
                    foreach (var item in paramDic)
                    {
                        request.AddApiParameter(item.Key, item.Value);
                    }
                }

                //var toekn = Constants.LAZADA_ACCESSTOKEN;
                LazopResponse response = client.Execute(request, str.Value.Split(',')[1]);
                if (response != null && !response.IsError())
                    isError = false;
                obj.Add(str.Key+","+str.Value.Split(',')[0], response.Body == string.Empty ? null : (JObject)JsonConvert.DeserializeObject(response.Body));
            }
            return obj;
        }
        /// <summary>
        /// Lazada请求数据
        /// </summary>
        /// <param name="apiName"></param>
        /// <param name="isError"></param>
        /// <param name="paramDic"></param>
        /// <returns></returns>
        public JObject UpdateGetResponseToken(string apiName, out bool isError, Dictionary<string, string> paramDic = null)
        {
            //Constants.GETLAZADA_APPSECRET();

            ILazopClient client = new LazopClient(new SiteChangeHelp().GetPushLazadaUrl(), Constants.LAZADA_APPKEY, Constants.LAZADA_APPSECRET);
            LazopRequest request = new LazopRequest();
            request.SetApiName(apiName);
            if (paramDic != null)
            {
                foreach (var item in paramDic)
                {
                    request.AddApiParameter(item.Key, item.Value);
                }
            }

            //var toekn = Constants.LAZADA_ACCESSTOKEN;
            LazopResponse response = client.Execute(request, Constants.OnlineLAZADA_ACCESSTOKEN);
            isError = response == null ? true : response.IsError();
            return response.Body == string.Empty ? null : (JObject)JsonConvert.DeserializeObject(response.Body);

        }

        public JObject UploadImage(string path)
        {
            //Constants.GETLAZADA_APPSECRET();
            ILazopClient client = new LazopClient(new SiteChangeHelp().GetPushLazadaUrl(), Constants.LAZADA_APPKEY, Constants.LAZADA_APPSECRET);
            LazopRequest request = new LazopRequest();
            request.SetApiName("/image/upload");
            request.AddFileParameter("image", new FileItem(path));
            LazopResponse response = client.Execute(request, Constants.LAZADA_ACCESSTOKEN);
            return response.Body == string.Empty ? null : (JObject)JsonConvert.DeserializeObject(response.Body);
        }

        public JObject imageMigrate(string path)
        {
            ILazopClient client = new LazopClient(new SiteChangeHelp().GetPushLazadaUrl(), Constants.LAZADA_APPKEY, Constants.LAZADA_APPSECRET);
            LazopRequest request = new LazopRequest();
            request.SetApiName("/image/migrate");
            request.AddApiParameter("payload", "<?xml version=\"1.0\" encoding=\"UTF-8\" ?> <Request>     <Image>         <Url>" + path + "</Url>     </Image> </Request>");
            LazopResponse response = client.Execute(request, Constants.LAZADA_ACCESSTOKEN);
            return response.Body == string.Empty ? null : (JObject)JsonConvert.DeserializeObject(response.Body);
        }

        public JObject RemoveProduct(string SellerSkuList)
        {
            ILazopClient client = new LazopClient(new SiteChangeHelp().GetPushLazadaUrl(), Constants.LAZADA_APPKEY, Constants.LAZADA_APPSECRET);
            LazopRequest request = new LazopRequest();
            request.SetApiName("/product/remove");
            request.AddApiParameter("seller_sku_list", SellerSkuList);
            LazopResponse response = client.Execute(request, Constants.OnlineLAZADA_ACCESSTOKEN);
            return response.Body == string.Empty ? null : (JObject)JsonConvert.DeserializeObject(response.Body);
        }
    }
}
