﻿using LAZADA;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.WebRequestHelper
{
    public class HttpClientModeConverter
    {
        /// <summary>
        /// 根据请求方式，获取请求链接
        /// </summary>
        /// <param name="mode">请求方式</param>
        /// <returns></returns>
        public static string CreateHttpClientURL(HttpClientMode mode)
        {
            switch (mode)
            {
                case HttpClientMode.GetLink:
                    return Constants.GETLINK_SERVERURL;
                case HttpClientMode.GetLogin:
                    return Constants.GETLINK_LOGINURL;
                case HttpClientMode.GetRemainAmount:
                    return Constants.REMAINAMOUNT_SERVERURL;
                case HttpClientMode.ReduceAmount:
                    return Constants.REDUCEAMOUNT_SERVERURL;
                default:
                    return "";
            }
        }

        /// <summary>
        /// 根据请求方式，获取请求数据加密KEY
        /// </summary>
        /// <param name="mode">请求方式</param>
        /// <returns></returns>
        public static string GetArg3KeyByMode(HttpClientMode mode)
        {
            switch (mode)
            {
                case HttpClientMode.GetLink:
                    return Constants.GETLINK_ARG3KEY;
                case HttpClientMode.GetLogin:
                    return Constants.GETLINK_LOGIN_ENCRYPT;
                case HttpClientMode.GetRemainAmount:
                case HttpClientMode.ReduceAmount:
                    return Constants.REMAINAMOUNT_ARG3KEY;
                default:
                    return "";
            }
        }

        /// <summary>
        /// 根据请求方式，获取请求时间加密KEY
        /// </summary>
        /// <param name="mode">请求方式</param>
        /// <returns></returns>
        public static string GetArg2KeyByMode(HttpClientMode mode)
        {
            switch (mode)
            {
                case HttpClientMode.GetLink:
                    return Constants.GETLINK_ARG2KEY;
                case HttpClientMode.GetRemainAmount:
                case HttpClientMode.ReduceAmount:
                    return Constants.REMAINAMOUNT_ARG2KEY;
                default:
                    return "";
            }
        }
    }

    public enum HttpClientMode
    {
        /// <summary>
        /// 获取采集连接
        /// </summary>
        GetLink,
        /// <summary>
        /// 上传LAZADA
        /// </summary>
        Lazada,
        /// <summary>
        /// 登录客户端
        /// </summary>
        GetLogin,
        /// <summary>
        /// 同步登录信息
        /// </summary>
        GetMsg,
        /// <summary>
        /// 获取剩余可用额度
        /// </summary>
        GetRemainAmount,
        /// <summary>
        /// 减少可用额度
        /// </summary>
        ReduceAmount,
        /// <summary>
        /// 获取登录access_token
        /// </summary>
        GetAccessToken,
    }
}
