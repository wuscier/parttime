﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace PublicFunction.WebRequestHelper
{
    public class MyWebClient : WebClient
    {
        public MyWebClient() { }

        protected override WebRequest GetWebRequest(Uri uri)
        {
            HttpWebRequest httpWebRequest = (HttpWebRequest)base.GetWebRequest(uri);
            httpWebRequest.Timeout = 10000;
            httpWebRequest.ReadWriteTimeout = 20000;
            return httpWebRequest;
        }
    }
}
