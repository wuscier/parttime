﻿using LAZADA;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Top.Api;
using Top.Api.Request;
using Top.Api.Response;

namespace PublicFunction.WebRequestHelper
{
    public class HaiWangRequestClient
    {

        SiteChangeHelp sch = new SiteChangeHelp();
        //获取海王用户权限包
        public JObject GetServicepackResponse()
        {
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingServicepackRequest req = new AlibabaSeakingServicepackRequest();
                req.IdentifyType = "fengniao";
                var id = GlobalUserClass.GetHaiWangModel().UserID;
                req.Identifier = id;
                AlibabaSeakingServicepackResponse rsp = client.Execute(req);
                var jsondata = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(rsp));
                return jsondata;
            }
            catch
            {
                return null;
            }
        }
        //机器翻译
        public AlibabaSeakingTranslateResponse GetTranslateResponse(string source, string sourceLang, string targetLang, string fieldType = "title")
        {
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingTranslateRequest req = new AlibabaSeakingTranslateRequest();
                req.Identifier = GlobalUserClass.GetHaiWangModel().UserID;
                req.TargetLang = targetLang;
                req.SourceLang = sourceLang;
                req.SourceText = source;
                req.SourceFormat = "text";
                req.IdentifierType = "fengniao";
                req.FieldType = fieldType;
                AlibabaSeakingTranslateResponse rsp = client.Execute(req);
                //var jsondata = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(rsp));
                return rsp;
            }
            catch
            {
                return null;
            }
        }

        public string GetTranslateZhToSiteDefaultResponse(string source)
        {
            var response = GetTranslateResponse(source, "zh", sch.GetToLanguage());
            if (response == null) return "";
            if (response.IsError) return "";
            return response.Result;
        }

        public string GetTranslateSiteDefaultToZhResponse(string source)
        {
            var response = GetTranslateResponse(source, sch.GetToLanguage(), "zh");
            if (response == null) return "";
            if (response.IsError) return "";
            return response.Result;
        }
        //图片翻译并返回结果
        public string PostSeakingImagetranslate( string image, string sourceLang)
        {
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingImagetranslateRequest req = new AlibabaSeakingImagetranslateRequest();
                req.Identifier = GlobalUserClass.GetHaiWangModel().UserID;
                req.TargetLang = sch.GetToLanguage();
                req.SourceLang = sourceLang;
                req.IdentifierType = "fengniao";
                req.Url = image;
                AlibabaSeakingImagetranslateRequest.ExtraDomain obj1 = new AlibabaSeakingImagetranslateRequest.ExtraDomain();
                obj1.SubIdentifyType = "lazada"; 
                obj1.SubIdentifier = "1000";
                req.Extra_ = obj1;
                //req.Token = GlobalUserClass.GetHaiWangModel().Token;
                AlibabaSeakingImagetranslateResponse rsp = client.Execute(req);
                return rsp.IsError==true?null:rsp.Result;
            }
            catch
            {
                return null;
            }
        }
        //提交图片翻译任务
        public long PostImagesToTranslate(long productId, List<string> images, string sourceLang)
        {
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingImagetranslateSubmitRequest req = new AlibabaSeakingImagetranslateSubmitRequest();
                req.TokenFrom = "fengniao";
                List<AlibabaSeakingImagetranslateSubmitRequest.ImageTranslateDetailDtoDomain> list2 = new List<AlibabaSeakingImagetranslateSubmitRequest.ImageTranslateDetailDtoDomain>();
                int index = 1;
                foreach (var item in images)
                {
                    AlibabaSeakingImagetranslateSubmitRequest.ImageTranslateDetailDtoDomain obj3 = new AlibabaSeakingImagetranslateSubmitRequest.ImageTranslateDetailDtoDomain();
                    list2.Add(obj3);
                    obj3.TargetLang = sch.GetToLanguage();
                    obj3.SourceLang = sourceLang;
                    obj3.ImageUrl = item;
                    obj3.ProductId = productId;
                    obj3.Platform = "lazada";
                    obj3.Idx = index;
                    index++;
                }
                req.ImageTranslateDetailList_ = list2;
                //req.Token = @"eyJhbGciOiJSUzI1NiIsImtpZCI6ImFiNzIwYzRhNGI4MjAzYzBhMWI5YWNiNzA2MDI5MThmIiwidHlwIjoiSldUIn0.eyJuYmYiOjE1NjU3NDUyNzMsImV4cCI6MTU5NzI4MTI3MywiaXNzIjoiaHR0cDovL2lkZW50aXR5c2VydmljZS1ob3N0IiwiYXVkIjpbImh0dHA6Ly9pZGVudGl0eXNlcnZpY2UtaG9zdC9yZXNvdXJjZXMiLCJvcGVuLXVzZXItYXBpIl0sImNsaWVudF9pZCI6ImFsaXl1biIsInN1YiI6IjEiLCJhdXRoX3RpbWUiOjE1NjU3NDUyNzMsImlkcCI6ImxvY2FsIiwibmFtZSI6InRvaGtpbnpodSIsInJvbGUiOiJVc2VyIiwic2NvcGUiOlsib3Blbi11c2VyLWFwaSIsIm9mZmxpbmVfYWNjZXNzIl0sImFtciI6WyJwd2QiXX0.BcSohtr6OfP_WpnQn-ztvCJ4iKTs9A_LqFRD29nCIeTgPf8HT4SEoxus97oeMbqAEkE92ELxB0i7HqAPwQVTOzSKNDNzZkB9GjVXQJSLLIiKRmcgISjckYHSoqPNxJXBN6e3xTRKHPu1uaKokaWq3Xs_QRsDHCRoZLFhq8hWra_BH9ov2NpcrM9l7otV1-5aPl3fjuHP4vwtmmVOi74yZdxmFABEk2b8_U7nCER_DLrjUvYaonTG1yxZveIFPxBLxEWtKA63DbBx_0U8cj-NJ9bZMu3xILie7JoxFRZH_ymjVbTDyfiD8sscA76VLZuB-swap1qt7_Pl1ghNVECuWw";
                req.Token = GlobalUserClass.GetHaiWangModel().Token;
                AlibabaSeakingImagetranslateSubmitResponse rsp = client.Execute(req);
                //var jsondata = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(rsp));
                return rsp.TaskId;
            }
            catch
            {
                return -1;
            }
        }
        //获取图片翻译任务结果
        public List<string> GetTranslateImages(long taskid)
        {
            List<string> list = new List<string>();
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingImagetranslateResultRequest req = new AlibabaSeakingImagetranslateResultRequest();
                req.TokenFrom = "fengniao";
                req.TaskId = taskid;
                //req.Token = @"eyJhbGciOiJSUzI1NiIsImtpZCI6ImFiNzIwYzRhNGI4MjAzYzBhMWI5YWNiNzA2MDI5MThmIiwidHlwIjoiSldUIn0.eyJuYmYiOjE1NjU3NDUyNzMsImV4cCI6MTU5NzI4MTI3MywiaXNzIjoiaHR0cDovL2lkZW50aXR5c2VydmljZS1ob3N0IiwiYXVkIjpbImh0dHA6Ly9pZGVudGl0eXNlcnZpY2UtaG9zdC9yZXNvdXJjZXMiLCJvcGVuLXVzZXItYXBpIl0sImNsaWVudF9pZCI6ImFsaXl1biIsInN1YiI6IjEiLCJhdXRoX3RpbWUiOjE1NjU3NDUyNzMsImlkcCI6ImxvY2FsIiwibmFtZSI6InRvaGtpbnpodSIsInJvbGUiOiJVc2VyIiwic2NvcGUiOlsib3Blbi11c2VyLWFwaSIsIm9mZmxpbmVfYWNjZXNzIl0sImFtciI6WyJwd2QiXX0.BcSohtr6OfP_WpnQn-ztvCJ4iKTs9A_LqFRD29nCIeTgPf8HT4SEoxus97oeMbqAEkE92ELxB0i7HqAPwQVTOzSKNDNzZkB9GjVXQJSLLIiKRmcgISjckYHSoqPNxJXBN6e3xTRKHPu1uaKokaWq3Xs_QRsDHCRoZLFhq8hWra_BH9ov2NpcrM9l7otV1-5aPl3fjuHP4vwtmmVOi74yZdxmFABEk2b8_U7nCER_DLrjUvYaonTG1yxZveIFPxBLxEWtKA63DbBx_0U8cj-NJ9bZMu3xILie7JoxFRZH_ymjVbTDyfiD8sscA76VLZuB-swap1qt7_Pl1ghNVECuWw";
                req.Token = GlobalUserClass.GetHaiWangModel().Token;
                AlibabaSeakingImagetranslateResultResponse rsp = client.Execute(req);
                //var jsondata = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(rsp));
                foreach (var item in rsp.Result.TaskResultDetailList)
                {
                    if (item.Status == "finished")
                        list.Add(item.Result);
                }
                return list;
            }
            catch
            {
                return list;
            }
        }
        //提交标题改写任务 
        public long PostTitleToTranslate(long productId, List<string> titles, List<long> categoryids, List<string> categorynames, List<string> images, string sourceLang)
        {
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingTitlerewriteSubmitRequest req = new AlibabaSeakingTitlerewriteSubmitRequest();
                req.TokenFrom = "fengniao";
                List<AlibabaSeakingTitlerewriteSubmitRequest.TitleRewriteDetailDtoDomain> list2 = new List<AlibabaSeakingTitlerewriteSubmitRequest.TitleRewriteDetailDtoDomain>();
                int index = 1;
                foreach (var item in titles)
                {
                    AlibabaSeakingTitlerewriteSubmitRequest.TitleRewriteDetailDtoDomain obj3 = new AlibabaSeakingTitlerewriteSubmitRequest.TitleRewriteDetailDtoDomain();
                    list2.Add(obj3);
                    obj3.TargetLang = sch.GetToLanguage();
                    obj3.SourceLang = sourceLang;
                    obj3.CategoryId = categoryids[index - 1];
                    obj3.CategoryName = categorynames[index - 1];
                    obj3.Title = item;
                    obj3.ProductId = productId;
                    obj3.Platform = "lazada";
                    obj3.ImageUrl = images[index - 1];
                    obj3.Idx = index;
                    index++;
                }
                req.TitleRewriteDetailList_ = list2;
                //req.Token = @"eyJhbGciOiJSUzI1NiIsImtpZCI6ImFiNzIwYzRhNGI4MjAzYzBhMWI5YWNiNzA2MDI5MThmIiwidHlwIjoiSldUIn0.eyJuYmYiOjE1NjU3NDUyNzMsImV4cCI6MTU5NzI4MTI3MywiaXNzIjoiaHR0cDovL2lkZW50aXR5c2VydmljZS1ob3N0IiwiYXVkIjpbImh0dHA6Ly9pZGVudGl0eXNlcnZpY2UtaG9zdC9yZXNvdXJjZXMiLCJvcGVuLXVzZXItYXBpIl0sImNsaWVudF9pZCI6ImFsaXl1biIsInN1YiI6IjEiLCJhdXRoX3RpbWUiOjE1NjU3NDUyNzMsImlkcCI6ImxvY2FsIiwibmFtZSI6InRvaGtpbnpodSIsInJvbGUiOiJVc2VyIiwic2NvcGUiOlsib3Blbi11c2VyLWFwaSIsIm9mZmxpbmVfYWNjZXNzIl0sImFtciI6WyJwd2QiXX0.BcSohtr6OfP_WpnQn-ztvCJ4iKTs9A_LqFRD29nCIeTgPf8HT4SEoxus97oeMbqAEkE92ELxB0i7HqAPwQVTOzSKNDNzZkB9GjVXQJSLLIiKRmcgISjckYHSoqPNxJXBN6e3xTRKHPu1uaKokaWq3Xs_QRsDHCRoZLFhq8hWra_BH9ov2NpcrM9l7otV1-5aPl3fjuHP4vwtmmVOi74yZdxmFABEk2b8_U7nCER_DLrjUvYaonTG1yxZveIFPxBLxEWtKA63DbBx_0U8cj-NJ9bZMu3xILie7JoxFRZH_ymjVbTDyfiD8sscA76VLZuB-swap1qt7_Pl1ghNVECuWw";
                req.Token = GlobalUserClass.GetHaiWangModel().Token;
                AlibabaSeakingTitlerewriteSubmitResponse rsp = client.Execute(req);
                //var jsondata = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(rsp));
                return rsp.TaskId;
            }
            catch
            {
                return -1;
            }
        }
        //获取标题改写任务结果
        public List<string> GetTranslateTitle(long taskid)
        {
            List<string> list = new List<string>();
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingTitlerewriteResultRequest req = new AlibabaSeakingTitlerewriteResultRequest();
                req.TokenFrom = "fengniao";
                req.TaskId = taskid;
                //req.Token = @"eyJhbGciOiJSUzI1NiIsImtpZCI6ImFiNzIwYzRhNGI4MjAzYzBhMWI5YWNiNzA2MDI5MThmIiwidHlwIjoiSldUIn0.eyJuYmYiOjE1NjU3NDUyNzMsImV4cCI6MTU5NzI4MTI3MywiaXNzIjoiaHR0cDovL2lkZW50aXR5c2VydmljZS1ob3N0IiwiYXVkIjpbImh0dHA6Ly9pZGVudGl0eXNlcnZpY2UtaG9zdC9yZXNvdXJjZXMiLCJvcGVuLXVzZXItYXBpIl0sImNsaWVudF9pZCI6ImFsaXl1biIsInN1YiI6IjEiLCJhdXRoX3RpbWUiOjE1NjU3NDUyNzMsImlkcCI6ImxvY2FsIiwibmFtZSI6InRvaGtpbnpodSIsInJvbGUiOiJVc2VyIiwic2NvcGUiOlsib3Blbi11c2VyLWFwaSIsIm9mZmxpbmVfYWNjZXNzIl0sImFtciI6WyJwd2QiXX0.BcSohtr6OfP_WpnQn-ztvCJ4iKTs9A_LqFRD29nCIeTgPf8HT4SEoxus97oeMbqAEkE92ELxB0i7HqAPwQVTOzSKNDNzZkB9GjVXQJSLLIiKRmcgISjckYHSoqPNxJXBN6e3xTRKHPu1uaKokaWq3Xs_QRsDHCRoZLFhq8hWra_BH9ov2NpcrM9l7otV1-5aPl3fjuHP4vwtmmVOi74yZdxmFABEk2b8_U7nCER_DLrjUvYaonTG1yxZveIFPxBLxEWtKA63DbBx_0U8cj-NJ9bZMu3xILie7JoxFRZH_ymjVbTDyfiD8sscA76VLZuB-swap1qt7_Pl1ghNVECuWw";
                req.Token = GlobalUserClass.GetHaiWangModel().Token;
                AlibabaSeakingTitlerewriteResultResponse rsp = client.Execute(req);
                //var jsondata = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(rsp));
                foreach (var item in rsp.Result.TaskResultDetailList)
                {
                    if (item.Status == "finished")
                        list.Add(item.Result);
                }
                return list;
            }
            catch
            {
                return list;
            }
        }
        //上报人工任务关联商品id
        public bool ProductTaskReport(long lazadaid, long taskid, string taskType)
        {
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingTaskReportRequest req = new AlibabaSeakingTaskReportRequest();
                List<AlibabaSeakingTaskReportRequest.TaskDetailReportDtoDomain> list2 = new List<AlibabaSeakingTaskReportRequest.TaskDetailReportDtoDomain>();
                AlibabaSeakingTaskReportRequest.TaskDetailReportDtoDomain obj3 = new AlibabaSeakingTaskReportRequest.TaskDetailReportDtoDomain();
                list2.Add(obj3);
                obj3.Idx = 1L;
                obj3.Platform = "lazada";
                obj3.ProductId = lazadaid;
                obj3.TaskId = taskid;
                req.ReportDetail_ = list2;
                req.TaskType = taskType;
                req.Token = GlobalUserClass.GetHaiWangModel().Token;
                req.TokenFrom = "fengniao";
                AlibabaSeakingTaskReportResponse rsp = client.Execute(req);
                //var jsondata = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(rsp));
                return rsp.Result;
            }
            catch
            {
                return false;
            }
        }

        //翻译授权
        public bool Authmachine(string strName)
        {
            try
            {
                ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
                AlibabaSeakingAuthmachineapiRequest req = new AlibabaSeakingAuthmachineapiRequest();
                req.IdentifyType = "fengniao";
                var id = GlobalUserClass.GetHaiWangModel().UserID;
                req.Identifier = id;
                req.SubIdentifyType = "lazada";
                req.SubIdentifier = strName;
                AlibabaSeakingAuthmachineapiResponse rsp = client.Execute(req);
                return rsp.Result;
            }
            catch
            {
                return false;
            }
        }

        //标题智能优化
        public string Aititlegenerate(Product product,string text,string Language="en")
        {
            ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
            AlibabaSeakingAititlegenerateRequest req = new AlibabaSeakingAititlegenerateRequest();
            req.Identifier = GlobalUserClass.GetHaiWangModel().UserID;
            AlibabaSeakingAititlegenerateRequest.ExtraDomain obj1 = new AlibabaSeakingAititlegenerateRequest.ExtraDomain();
            obj1.SubIdentifyType = "lazada";
            obj1.SubIdentifier = "1000";
            obj1.ProductId = product.LazadaItemid.ToString();
            obj1.Platform = "lazada";
            req.Extra_ = obj1;
            req.Language = Language;
            req.Attributes = product.Lazadaattributs==null?null: product.Lazadaattributs.Replace("{", "").Replace("}", "").Replace("[","{").Replace("]", "}");// "{\"1\": \"VIDONIA\", \"2\": \"Medium Temperature\"}";
            req.IdentifierType = "fengniao";
            req.Title = text;
            req.Platform = "lazada";
            req.CategoryId = Convert.ToInt64(product.Lazadacategoryid)>0 ? Convert.ToInt64(product.Lazadacategoryid):-1;
            AlibabaSeakingAititlegenerateResponse rsp = client.Execute(req);
            return rsp.Body;
        }
        //标题诊断
        public AlibabaSeakingDiagnosistitleResponse Diagnosistitle(Product product, string text, string Language = "en")
        {
            ITopClient client = new DefaultTopClient(Constants.HAIWANG_APIURL, Constants.HAIWANG_APPKEY, Constants.HAIWANG_APPSECRET);
            AlibabaSeakingDiagnosistitleRequest req = new AlibabaSeakingDiagnosistitleRequest();
            req.CategoryId = Convert.ToInt64(product.Lazadacategoryid);
            AlibabaSeakingDiagnosistitleRequest.ExtraDomain obj1 = new AlibabaSeakingDiagnosistitleRequest.ExtraDomain();
            obj1.Platform = "lazada";
            obj1.ProductId = product.LazadaItemid.ToString();
            obj1.SubIdentifier = "1000";
            obj1.SubIdentifyType = "lazada";
            req.Extra_ = obj1;
            req.Identifier = GlobalUserClass.GetHaiWangModel().UserID;
            req.IdentifierType = "fengniao";
            req.Language = Language;
            req.Platform = "lazada";
            req.Title = text;
            AlibabaSeakingDiagnosistitleResponse rsp = client.Execute(req);
            return rsp;
            
        }
    }

}
