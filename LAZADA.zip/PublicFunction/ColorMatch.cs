﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PublicFunction
{
    /// <summary>
    /// 颜色适配类
    /// </summary>
    public class ColorMatch
    {
        private static Dictionary<string, string> _colorDic = null;
        private static string _sysColor = null;
        private static string[] _wishcolors = null;

        /// <summary>
        /// 系统颜色文件的值
        /// </summary>
        public static string SysColor
        {
            get
            {
                if (_sysColor == null)
                {
                    try
                    {
                        _sysColor = new IOHelp().ReadActFile(AppDomain.CurrentDomain.BaseDirectory + Constants.ACTFILE_MACHEDCOLOR);
                    }
                    catch
                    {
                        _sysColor = "";
                    }
                }
                return _sysColor;
            }
            set => _sysColor = value;
        }

        /// <summary>
        /// WISH 平台颜色字符串
        /// </summary>
        public static string[] wishcolors
        {
            get
            {
                if (_wishcolors == null)
                {
                    try
                    {
                        _wishcolors = new IOHelp().ReadActFile(AppDomain.CurrentDomain.BaseDirectory + Constants.ACTFILE_WISHCOLOR).Split(new[] { "\n" }, StringSplitOptions.RemoveEmptyEntries);
                        for (int i = 0; i < _wishcolors.Length; i++)
                        {
                            if (_wishcolors[i].Trim() == "")
                            {
                                _wishcolors[i] = "-X-X-";
                            }
                            else
                            {
                                _wishcolors[i] = _wishcolors[i].Trim();
                            }
                        }
                    }
                    catch
                    {
                        _wishcolors = null;
                    }

                }
                return ColorMatch._wishcolors;


            }
            set { ColorMatch._wishcolors = value; }


        }

        public static Dictionary<string, string> colorDic
        {
            get
            {
                if (_colorDic == null)
                {
                    try
                    {
                        string[] sArray = Regex.Replace(SysColor.Replace("\n", "|").Replace("=", "|"), @"[A-Za-z&\-\s]+", "").Trim().Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                        //  if (sArray.Length < 1) return;
                        Array.Sort(sArray, new CustomComparer());
                        Dictionary<string, string> t_colorDic = new Dictionary<string, string>();
                        t_colorDic.Clear();
                        for (int i = 0; i < sArray.Length; i++)
                        {
                            sArray[i] = sArray[i].Trim();
                            if (String.IsNullOrEmpty(sArray[i])) continue;

                            if (!t_colorDic.ContainsKey(sArray[i]))
                            {
                                string tENcolor = GetENcolor(sArray[i]);
                                if (String.IsNullOrEmpty(tENcolor)) continue;
                                t_colorDic.Add(sArray[i], tENcolor);

                            }


                        }

                        ColorMatch._colorDic = t_colorDic;
                    }
                    catch
                    {
                        // _syscolor = "";
                        ColorMatch._colorDic = null;
                    }

                }
                return ColorMatch._colorDic;


            }
            set { _colorDic = value; }
        }

        /// <summary>
        /// 颜色匹配
        /// 没怎么看懂，照抄，后期整理逻辑，重写
        /// </summary>
        /// <param name="_CHcolor"></param>
        /// <param name="_haveFYDcolors"></param>
        /// <returns></returns>
        private static string GetENcolor2(string _CHcolor, List<string> _haveFYDcolors)
        {
            string tsrt = _CHcolor.Trim();
            string retSrt = "";
            retSrt = GetWISHcolor(tsrt);
            if (retSrt.Length > 0 && !_haveFYDcolors.Contains(retSrt))
            {
                return retSrt;

            }
            else
            {
                retSrt = "";
            }

            if (SysColor == "") return "";

            string[] machedcolors = SysColor.Split(new[] { "\n" }, StringSplitOptions.RemoveEmptyEntries); //文本里的

            for (int imc = 0; imc < machedcolors.Length; imc++)
            {
                machedcolors[imc] = machedcolors[imc].Trim();
                if (machedcolors[imc] == "") continue;
                string[] sArray = machedcolors[imc].Split(new char[2] { '=', '|' }, StringSplitOptions.RemoveEmptyEntries);
                if (sArray.Length < 2) continue;

                if (sArray.Contains(tsrt) && !_haveFYDcolors.Contains(sArray[0])) //文本里的
                {
                    retSrt = sArray[0];
                    break;
                }
            }
            return retSrt;

        }

        /// <summary>
        /// 匹配WISH平台的颜色值
        /// </summary>
        /// <param name="_CHcolor"></param>
        /// <returns></returns>
        private static string GetWISHcolor(string _CHcolor)
        {
            if (SysColor == null) return "";
            _CHcolor = _CHcolor.Trim();
            if (_CHcolor == "") return "";
            _CHcolor = UpFirstcharWithBlank(_CHcolor);
            if (wishcolors.Contains(_CHcolor)) return _CHcolor;
            return "";

        }

        /// <summary>
        /// 单词首字母大字并去空格
        /// </summary>
        /// <param name="_str"></param>
        /// <returns></returns>
        private static string UpFirstcharWithBlank(string _str)
        {

            _str = _str.Trim();
            if (_str == "") return "";
            if (_str.Length > 1)
            {

                // RegexOptions options = RegexOptions.None;
                //  Regex regex = new Regex(@"[ ]{2,}", options);
                //  _str = regex.Replace(_str, @" ");
                _str = Regex.Replace(_str, "\\s+", " ");

                return (_str.Substring(0, 1).ToUpper() + _str.Substring(1).ToLower());

            }
            else
            {
                return _str.ToUpper();
            }

        }

        /// <summary>
        /// 将颜色匹配成英语
        /// </summary>
        /// <param name="_CHcolor">需要匹配的颜色</param>
        /// <param name="_haveFYDcolors">已经匹配的颜色列表</param>
        /// <returns></returns>
        public static string GetENcolor3(string _CHcolor, List<string> _haveFYDcolors)
        {

            if (_haveFYDcolors == null)
                _haveFYDcolors = new List<string>();

            string tsrt = _CHcolor.Trim();
            string retSrt = "";
            retSrt = GetWISHcolor(tsrt);
            if (retSrt.Length > 0 && !_haveFYDcolors.Contains(retSrt))
            {
                return retSrt;

            }
            else
            {
                retSrt = "";
            }

            if (SysColor == "" || colorDic == null) return "";

            try
            {
                if (colorDic.Count < 1) return "";

                foreach (KeyValuePair<string, string> kvp in colorDic)
                {
                    tsrt = tsrt.Replace(kvp.Key, "|" + kvp.Value + "|");
                }
                //for (int i = 0; i < colorDic.Count; i++)
                //{
                //    tsrt = tsrt.Replace(colorDic.Keys[i], "|" + kvp.Value + "|");

                //}


                string[] preColors = tsrt.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                if (preColors.Length == 1)
                {


                    return GetENcolor2(preColors[0], _haveFYDcolors);

                }
                else
                {

                    List<string> alist = new List<string>();
                    for (int k = 0; k < preColors.Length; k++)
                    {
                        string useColor = GetWISHcolor(preColors[k]);
                        if (String.IsNullOrEmpty(useColor)) continue;
                        alist.Add(useColor);


                    }

                    if (alist.Count > 2)
                    {
                        retSrt = alist[0] + " & " + alist[1];
                    }
                    else
                    {

                        retSrt = String.Join(" & ", alist.ToArray());
                    }

                    if (_haveFYDcolors.Contains(retSrt))
                    {
                        return "";
                    }
                    else
                    {
                        return retSrt;
                    }

                }
            }
            catch
            {
                return "";
            }

        }


        /// <summary>
        /// 颜色匹配
        /// 没怎么看懂，照抄，后期整理逻辑，重写
        /// </summary>
        /// <param name="_CHcolor"></param>
        /// <returns></returns>
        public static string GetENcolor(string _CHcolor)
        {
            string tsrt = _CHcolor.Trim();
            string retSrt = "";
            retSrt = GetWISHcolor(tsrt);
            if (retSrt.Length > 0) return retSrt;

            if (SysColor == "") return "";

            string[] machedcolors = SysColor.Split(new[] { "\n" }, StringSplitOptions.RemoveEmptyEntries); //文本里的

            for (int imc = 0; imc < machedcolors.Length; imc++)
            {
                machedcolors[imc] = machedcolors[imc].Trim();
                if (machedcolors[imc] == "") continue;
                string[] sArray = machedcolors[imc].Split(new char[2] { '=', '|' }, StringSplitOptions.RemoveEmptyEntries);
                if (sArray.Length < 2) continue;

                if (sArray.Contains(tsrt)) //文本里的
                {
                    retSrt = sArray[0];
                    break;
                }

            }/////////////

            return retSrt;

        }

        /// <summary>
        /// 返回是否是WISH平台的颜色
        /// </summary>
        /// <param name="_str"></param>
        /// <returns></returns>
        public static bool IsWishColor(string _str)
        {
            if (_str.Trim() == "") return false;

            string[] leftColors2 = _str.Trim().Split(new[] { "&" }, StringSplitOptions.RemoveEmptyEntries);
            if (leftColors2.Length > 0)
            {
                for (int j = 0; j < leftColors2.Length; j++)
                {
                    if (!ColorMatch.wishcolors.Contains(leftColors2[j].Trim()))
                        return false;
                }

            }
            else
            {
                return false;
            }

            return true;
        }

        public static string ColorsUpFirstchar2(string _str)
        {
            if (_str.Trim() == "") return "";
            string retStr = "";
            string[] leftColors = _str.Trim().Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);

            if (leftColors.Length > 0)
            {
                for (int i = 0; i < leftColors.Length; i++)
                {
                    //  retStr += upFirstcharWithBlank(leftColors[i]) + ",";

                    string[] leftColors2 = leftColors[i].Trim().Split(new[] { "&" }, StringSplitOptions.RemoveEmptyEntries);
                    if (leftColors2.Length > 0)
                    {
                        for (int j = 0; j < leftColors2.Length; j++)
                        {
                            leftColors2[j] = UpFirstcharWithBlank(leftColors2[j]);
                        }
                        leftColors[i] = String.Join(" & ", leftColors2);
                    }
                    else
                    {
                        leftColors[i] = "";
                    }
                }

                retStr = String.Join(" , ", leftColors);
            }
            else
            {
                return "";

            }

            return retStr;
        }

        /// <summary>
        /// 颜色替换
        /// </summary>
        /// <param name="encolor"></param>
        /// <param name="match"></param>
        /// <returns></returns>
        public static string GetCHcolor(string encolor, string match)
        {
            if (match == null || match == string.Empty) return "";
            JArray jsonArr = (JArray)(JsonConvert.DeserializeObject(match));

            for (int i = 0; i < jsonArr.Count; i++)
            {
                if (jsonArr[i]["encolor"].ToString() == encolor.Trim())
                    return jsonArr[i]["chcolor"].ToString();
            }
            return "";
        }


        public static bool isAllWishColor(string[] _colors)
        {
            if (_colors == null) return false;
            if (_colors.Length < 1) return true;

            foreach (string str in _colors)
            {
                if (str.Trim() != "" && !ColorMatch.IsWishColor(str.Trim()))
                {
                    return false;
                }
            }

            return true;
        }
    }

    public class CustomComparer : System.Collections.IComparer
    {
        public int Compare(object x, object y)
        {
            string s1 = (string)x;
            string s2 = (string)y;
            if (s1.Length > s2.Length) return -1;
            if (s1.Length < s2.Length) return 1;
            return 0;
        }
    }
}
