﻿using LAZADA;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using static LAZADA.GlobalUserClass;

namespace Logic.Author
{
    public class GetUserAuthorMSG
    {
        /// <summary>
        /// 获取用户所有授权信息(需改)
        /// </summary>
        public GetUserAuthorMSG()
        {
            //获取用户授权信息
            JObject authresult = new JObject();
            authresult = (JObject)JsonConvert.DeserializeObject(GlobalUserClass.GetAuthorMSG());

            //取值保存到程序
            List<int> listShops = new List<int>();
            Dictionary<int, object> authorMSG = new Dictionary<int, object>();
            JArray arrayShops = (JArray)authresult["result"];
            if (arrayShops.Count > 0)
            {
                try
                {
                    foreach (var item in authresult["result"])
                    {
                        #region 获取平台类型
                        JToken site = item["siteType"];
                        GlobalUserClass.AuthedShopsItem.siteType = (int)site;
                        #endregion
                        #region region
                        GlobalUserClass.AuthedShopsItem.regions = (int)item["region"];
                        #endregion

                        #region 用户id
                        GlobalUserClass.AuthedShopsItem.UserId = (long)item["userId"];
                        #endregion

                        #region 访问令牌
                        GlobalUserClass.AuthedShopsItem.AccessToken = item["accessToken"].ToString();
                        #endregion

                        #region 有效期
                        GlobalUserClass.AuthedShopsItem.ExpiresIn = (int)item["expiresIn"];
                        #endregion

                        #region 刷新令牌
                        GlobalUserClass.AuthedShopsItem.RefreshToken = item["refreshToken"].ToString();
                        #endregion

                        #region 刷新令牌超时时间
                        GlobalUserClass.AuthedShopsItem.RefreshTokenTimeOut = (DateTime?)item["refreshTokenTimeOut"];
                        #endregion

                        #region shopId
                        GlobalUserClass.AuthedShopsItem.ShopId = Convert.ToInt64((long)item["shopId"]);
                        #endregion

                        #region lastModificationTime
                        try
                        {
                            if (item["lastModificationTime"] == null)
                            {
                                GlobalUserClass.AuthedShopsItem.LastModificationTime = DateTime.Now;
                            }
                            else
                            {
                                GlobalUserClass.AuthedShopsItem.LastModificationTime = (DateTime?)item["lastModificationTime"];
                            }
                        }
                        catch (Exception ex)
                        {

                            new LogOutput.LogTo().WriteLine(ex.Message);
                        }


                        #endregion

                        #region creationTime
                        if (item["creationTime"] != null)
                        {
                            GlobalUserClass.AuthedShopsItem.CreationTime = (DateTime?)item["creationTime"];
                        }
                        else
                        {
                            GlobalUserClass.AuthedShopsItem.CreationTime = DateTime.Now;
                        }
                        #endregion
                        #region id
                        GlobalUserClass.AuthedShopsItem.Id = (int)item["id"];
                        #endregion
                        var list = new List<KeyValuePair<string, object>>()
                        {
                            new KeyValuePair<string, object>("userId", GlobalUserClass.AuthedShopsItem.UserId),
                            new KeyValuePair<string, object>("siteType", GlobalUserClass.AuthedShopsItem.siteType),
                            new KeyValuePair<string, object>("region", GlobalUserClass.AuthedShopsItem.regions),
                            new KeyValuePair<string, object>("accessToken", GlobalUserClass.AuthedShopsItem.AccessToken),
                            new KeyValuePair<string, object>("expiresIn", GlobalUserClass.AuthedShopsItem.ExpiresIn),
                            new KeyValuePair<string, object>("refreshToken", GlobalUserClass.AuthedShopsItem.RefreshToken),
                            new KeyValuePair<string, object>("refreshTokenTimeOut", GlobalUserClass.AuthedShopsItem.RefreshTokenTimeOut),
                            new KeyValuePair<string, object>("shopId", GlobalUserClass.AuthedShopsItem.ShopId),
                            new KeyValuePair<string, object>("account", GlobalUserClass.AuthedShopsItem.Account),
                            new KeyValuePair<string, object>("accountId", GlobalUserClass.AuthedShopsItem.AccountId),
                            new KeyValuePair<string, object>("creationTime", GlobalUserClass.AuthedShopsItem.CreationTime),
                            new KeyValuePair<string, object>("lastModificationTime", GlobalUserClass.AuthedShopsItem.LastModificationTime),
                            new KeyValuePair<string, object>("id", GlobalUserClass.AuthedShopsItem.Id)
                        };
                        authorMSG.Add(GlobalUserClass.AuthedShopsItem.Id, list);
                        AuthorMSG = authorMSG;
                    }

                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
            }

        }
    }
}
