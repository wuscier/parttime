﻿using LAZADA;
using Logic.Author;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using static LAZADA.GlobalUserClass;

namespace PublicFunction.Author
{
    public class My1688Collect
    {
        public My1688Collect()
        {

        }
        /// <summary>
        /// 1688采集授权链接
        /// </summary>
        public static string GET_1688COLLECT_URL = $"https://auth.1688.com/oauth/authorize?client_id=5723483&site=1688&redirect_uri= { WebUtility.UrlEncode(GlobalUserClass.redirectUrl)}";
        /// <summary>
        /// 获取1688采集授权链接
        /// </summary>
        /// <returns></returns>
        public static string GetCollectUrl()
        {
            string red = "https://auth.1688.com/oauth/authorize?client_id=5723483&site=1688&redirect_uri="+WebUtility.UrlEncode(GlobalUserClass.redirectUrl);
            GET_1688COLLECT_URL = red;
            return GET_1688COLLECT_URL;
        }
        /// <summary>
        /// 1688授权——refreshToken换取accessToken
        /// </summary>
        /// <returns></returns>
        public string Ali1688_Refresh_AccessToken()
        {
            var list = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("client_id",Constants.ALIBABA_ID),
                        new KeyValuePair<string, string>("client_secret",Constants.ALIBABA_KEY),
                        new KeyValuePair<string, string>("refresh_token",Constants.Ali1688_REFRESHTOKEN),
                        new KeyValuePair<string, string>("grant_type","refresh_token")
                    };
            using (HttpClient httpClient = new HttpClient())
            {
                //specify to use TLS 1.2 as default connection
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                var result = new HttpRequestMessage(HttpMethod.Post, Constants.Ali1688_REFRESH_ACCESSTOKEN_URL) { Content = new FormUrlEncodedContent(list) };
                HttpResponseMessage response = httpClient.SendAsync(result).Result;
                var str = response.Content.ReadAsStringAsync().Result;
                var jsondata = (JObject)JsonConvert.DeserializeObject(str);
                return jsondata.ToString();
            }
        }
    }
}
