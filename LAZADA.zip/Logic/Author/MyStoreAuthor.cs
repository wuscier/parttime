﻿using LAZADA;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Logic.Author
{
   public class MyStoreAuthor
    {

        public static string GET_StoreAuthor_Url = "https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri= "+ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url)+"&client_id=100755";
        /// <summary>
        /// lazada卖家授权链接
        /// </summary>
        /// <param name="str"></param>
        public static string GetStoreUrl()
        {
            //GET_StoreAuthor_Url = "https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&client_id=100755&redirect_uri= " + WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url);
            return GET_StoreAuthor_Url;
        }
       
    }
}
