﻿using LAZADA;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using static LAZADA.GlobalUserClass;

namespace Logic.Author
{
    public class SiteAuthor
    {
        /// <summary>
        /// 选择或切换站点时是否开通了此站点
        /// </summary>
        /// <returns></returns>
        public bool SiteAuthors(Region region)
        {
            #region 判断是否开通了此站点

            JObject jObject = new JObject();
            //保存枚举的值
            int val = (int)region;
            //是否开通此站点
            if (OpenedRegionsItem.regions.Contains(val) || OpenedRegionsItem.regions.Contains((int)Region.CrossBorder))
            {
                return true;
            }
            else
            {
                return false;
            }
            #endregion
        }

        /// <summary>
        /// 站点是否到期
        /// </summary>
        public bool Expriation(int siteId)
        {
            string dt = GlobalUserClass.GetTime(Access_Token);
            DateTime now = Convert.ToDateTime(dt.Replace("\"", string.Empty));
            Dictionary<int, DateTime> keyValuePairs = new Dictionary<int, DateTime>();
            keyValuePairs = SiteExpriateTime;
            if (OpenedRegionsItem.siteType == (int)WebSiteType.Lazada)
            {
                foreach (var item in keyValuePairs)
                {
                    if (item.Key == (int)Region.CrossBorder&& DateTime.Compare(now, item.Value) < 0)
                    {
                        return false;
                    }
                }
                foreach (var item in keyValuePairs)
                {
                    
                    if (siteId == item.Key)
                    {
                        
                        if (DateTime.Compare(now, item.Value) > 0)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }

                    }
                }
                return true;
            }
            return false;
        }

    }
}
