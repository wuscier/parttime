﻿using LAZADA;
using Logic.PriceTemplate;
using PublicFunction.ConfigHelp;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    public class SystemConfigCore
    {
        /// <summary>
        /// 判断是否要更新
        /// </summary>
        /// <returns></returns>
        public bool CheckNeedToUpdate()
        {
            string sql = "SELECT COUNT(*) from SystemConfiguration where Name='FreightVision'";
            var count = new SQLiteHelp().ExecuteScalar<Int64>(sql);
            if (count == 0)
            {
                return true;
            }
            sql = "SELECT Value from SystemConfiguration where Name='FreightVision'";
            var rs = new SQLiteHelp().ExecuteScalar<string>(sql);
            if (rs != "3")
            {
                sql = "Update SystemConfiguration set VALUE='TRUE' where Name='ISNOTICEDME'";
                new SQLiteHelp().ExecuteNonQuery(sql);
                return true;
            }
            return false;
        }

        /// <summary>
        /// 更新国际运费版本
        /// </summary>
        private void UpdateVision()
        {
            string sql = "SELECT COUNT(*) from SystemConfiguration where Name='FreightVision'";
            var count = new SQLiteHelp().ExecuteScalar<Int64>(sql);
            if (count == 0)
                sql = "INSERT INTO SystemConfiguration VALUES('FreightVision','3')";
            else
                sql = "UPDATE SystemConfiguration SET VALUE='3' WHERE Name='FreightVision'";
            new SQLiteHelp().ExecuteNonQuery(sql);
        }

        /// <summary>
        /// 设置不需要提醒
        /// </summary>
        public void SetNoNoticedMe()
        {
            string sql = "SELECT COUNT(*) from SystemConfiguration where Name='ISNOTICEDME'";
            var count = new SQLiteHelp().ExecuteScalar<Int64>(sql);
            if (count == 0)
                sql = "INSERT INTO SystemConfiguration VALUES('ISNOTICEDME','FALSE')";
            else
                sql = "UPDATE SystemConfiguration SET VALUE='FALSE' where Name='ISNOTICEDME'";
            new SQLiteHelp().ExecuteNonQuery(sql);
        }

        /// <summary>
        /// 设置是否开启默认发布站点
        /// </summary>
        public int SetOpenChooseStore()
        {
            string sql0 = "SELECT Count(*) FROM sqlite_master WHERE type='table' and name ='Store'";
            if (Convert.ToInt32(SQLiteHelp.ExecuteScalar(sql0)) == 0)
            {
                string createsql = "CREATE TABLE 'Store' (  'id' INTEGER NOT NULL,  'IsDefault' integer,  'Name' TEXT,  'account' TEXT,  'authTime' TEXT,  'expirationTime' datatime,  'user' text,  'region' integer,  'accessToken' TEXT,  PRIMARY KEY('id')); ";
                SQLiteHelp.ExecuteNonQuery(SQLiteHelp.CreateCommands(createsql));
            }
            string sql = "SELECT COUNT(*) from SystemConfiguration where Name='OpenChooseStore'";
            var count = new SQLiteHelp().ExecuteScalar<Int64>(sql);
            if (count == 0)
            {
                sql = "INSERT INTO SystemConfiguration VALUES('OpenChooseStore','1')";
                new SQLiteHelp().ExecuteNonQuery(sql);
                return 1;
            }
            else
            {
                sql = "SELECT Value from SystemConfiguration where Name='OpenChooseStore'";
                return Convert.ToInt32(new SQLiteHelp().ExecuteScalar<string>(sql));
            }
        }

        /// <summary>
        /// 设置阿里翻译授权弹窗
        /// </summary>
        public int SetAliAuthorization()
        {
            string sql = "SELECT COUNT(*) from SystemConfiguration where Name='AliAuthorization" + GlobalUserClass.GetHaiWangModel().UserID + "'";
            var count = new SQLiteHelp().ExecuteScalar<Int64>(sql);
            if (count == 0)
            {
                sql = "INSERT INTO SystemConfiguration VALUES('AliAuthorization" + GlobalUserClass.GetHaiWangModel().UserID + "','1')";
                new SQLiteHelp().ExecuteNonQuery(sql);
                return 1;
            }
            else
            {
                sql = "SELECT Value from SystemConfiguration where Name='AliAuthorization" + GlobalUserClass.GetHaiWangModel().UserID + "'";
                return Convert.ToInt32(new SQLiteHelp().ExecuteScalar<string>(sql));
            }
        }

        /// <summary>
        /// 设置需要提醒
        /// </summary>
        public void SetNeedNoticedMe()
        {
            string sql = "SELECT COUNT(*) from SystemConfiguration where Name='ISNOTICEDME'";
            var count = new SQLiteHelp().ExecuteScalar<Int64>(sql);
            if (count == 0)
                sql = "INSERT INTO SystemConfiguration VALUES('ISNOTICEDME','TRUE')";
            else
                sql = "UPDATE SystemConfiguration SET VALUE='TRUE' where Name='ISNOTICEDME'";
            new SQLiteHelp().ExecuteNonQuery(sql);
        }

        /// <summary>
        /// 判断是否需要展示本窗体
        /// </summary>
        /// <returns></returns>
        public bool IsNeedToShow()
        {
            string sql = "SELECT COUNT(*) from SystemConfiguration where Name='ISNOTICEDME'";
            var count = new SQLiteHelp().ExecuteScalar<Int64>(sql);
            if (count == 0)//需要展示
                return true;
            sql = "SELECT Value from SystemConfiguration where Name='ISNOTICEDME'";
            var rs = new SQLiteHelp().ExecuteScalar<string>(sql);
            if (rs == "TRUE")//需要展示
                return true;
            return false;
        }

        /// <summary>
        /// 更新运费公式
        /// </summary>
        /// <returns></returns>
        public bool UpdateAllFreight()
        {
            try
            {
                var list = new PriceTemplateCore().GetAllPriceTemplateList();
                var sch = new SiteChangeHelp();
                var sh = new SQLiteHelp();
                string sql = "";
                foreach (var item in list)
                {
                    sql += $"UPDATE PriceFormula SET jyunfeigs='{sch.GetDefaultJyunfeigs(Convert.ToInt32(item.SiteID))}' WHERE jnumber={item.Jnumber};";
                }

                var count = sh.ExecuteNonQuery(sql);
                if (count == list.Count)
                {
                    SetNoNoticedMe();
                    UpdateVision();
                    return true;
                }
                else
                {
                    SetNeedNoticedMe();
                    return false;
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine("更新运费失败：" + ex.Message);
                return false;
            }
        }

        public bool IsShowVedio()
        {
            string sql = "SELECT value FROM SystemConfiguration where Name='NeedShowVedio'";
            var rs = new SQLiteHelp().ExecuteScalar<string>(sql);
            if (rs == string.Empty || rs == null)
            {
                return true;
            }
            return rs == "0";
        }

        public void UpdateIsShowVedio(bool isShow)
        {
            string sql = "SELECT value FROM SystemConfiguration where Name='NeedShowVedio'";
            var rs = new SQLiteHelp().ExecuteScalar<string>(sql);
            if (rs == string.Empty || rs == null)
            {
                sql = $"insert into SystemConfiguration VALUES('NeedShowVedio','{isShow}')";
            }
            else
            {
                sql = $"update SystemConfiguration set value={isShow} where Name='NeedShowVedio'";
            }
            new SQLiteHelp().ExecuteNonQuery(sql);
        }

        //检查表内字段
        public void sqlCheck()
        {
            DataSet dataSet2 = Select("sqlite_master", " and tbl_name = 'OnlineProduct' and type = 'table' and sql like '%StoreName%' ");
            if (dataSet2.Tables[0].Rows.Count == 0)
            {
                string str1 = "ALTER TABLE 'OnlineProduct' ADD 'StoreName' TEXT";
                new SQLiteHelp().ExecuteNonQuery(str1);
                string str2 = "UPDATE OnlineProduct SET StoreName = (SELECT account FROM(SELECT min(id) as id,account,region,user from Store  GROUP BY user , region) where OnlineProduct.UserName=user and OnlineProduct.siteid=region) WHERE OnlineProduct.UserName = (SELECT user FROM(SELECT min(id) as id,account,region,user from Store  GROUP BY user , region) where OnlineProduct.UserName=user and OnlineProduct.siteid=region)  and OnlineProduct.siteid = (SELECT region FROM(SELECT min(id) as id,account,region,user from Store  GROUP BY user , region) where OnlineProduct.UserName=user and OnlineProduct.siteid=region); ";
                new SQLiteHelp().ExecuteNonQuery(str2);
            }
        }
        public DataSet Select(string strName, string strFilter)
        {
            DataSet ds = new DataSet();
            string sql0 = "SELECT * FROM " + strName + " where 1=1 " + strFilter;
            ds = new SQLiteHelp().ExecuteDataSet(sql0);
            return ds;
        }
    }
}
