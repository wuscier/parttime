﻿using PublicFunction.Entity.DBEntity;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    public class SqlAuthorization
    {
        public List<Store> GetStoreList(string strFilter="" )
        {
            string sql = "SELECT id,case IsDefault when '1' then 'true' else 'false' end as IsDefault,Name,account,authTime,expirationTime,user,region,accessToken,case account  when '' then '未授权'  else '已授权' end as State,case account  when '' then '添加授权'  else '重新授权' end as Operation FROM Store where 1=1 " + strFilter;
            return new SQLiteHelp().GetList<Store>(sql);
        }
        
        public void Edit(string sql)
        {
            new SQLiteHelp().ExecuteNonQuery(sql);
        }
    }
}
