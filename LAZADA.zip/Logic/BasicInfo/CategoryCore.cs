﻿using Logic.Platform;
using Logic.SystemSole;
using Logic.Translation;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.DBEntity;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    /// <summary>
    /// 类目操作业务类
    /// </summary>
    public class CategoryCore
    {

        public List<Category> GetCategoryList()
        {
            string sql = "SELECT * FROM Category ";
            return new SQLiteHelp().GetList<Category>(sql);
        }

        public string GetChineseName(string cateName)
        {
            var category = SystemSoleEntity.GetCategoryList().Where(p => p.CateName == cateName).FirstOrDefault();
            if (category != null)
                return category.ChineseName;
            var chineseName = new ALiCore().ChangeEnToZh(cateName);
            AddNew(cateName, chineseName);
            SystemSoleEntity.RefrushCategoryList();
            return chineseName;

        }

        public void AddNew(string CateName, string ChineseName)
        {
            string sql = "INSERT INTO Category(CateName,ChineseName) VALUES(@CateName,@ChineseName)";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@CateName",CateName),
                  new SQLiteParameter("@ChineseName",ChineseName),
            };
            new SQLiteHelp().ExecuteNonQuery(sql, paramList);
        }

        string GetCategoryID(JArray jarray, string[] arr, int index)
        {
            var rs = "";
            var name = arr[index];
            foreach (var item in jarray)
            {
                var itemName = Convert.ToString(item["name"]).Replace(" ", "");
                if (itemName == name)
                {
                    if (item["children"] != null && item["children"].HasValues)
                    {
                        var jarry = (JArray)item["children"];
                        index++;
                        return GetCategoryID(jarry, arr, index);
                    }
                    else
                    {
                        return Convert.ToString(item["category_id"]);
                    }
                }
            }
            return rs;
        }

        public string ChangeSiteCategory(string namePath)
        {
            if (namePath == null || namePath == string.Empty) return "";
            //string text = "Fashion >> Women >> Clothing >> Jackets & Coats >> Blazers & Vests";
            var arr = namePath.Replace(">>", ",").Replace(" ", "").Split(',');
            //var arr = text.Replace(">>", ",").Replace(" ", "").Split(',').ToList();
            var jarray = (JArray)(new LazadaCore().GetCategoryTree())["data"];
            var rs = GetCategoryID(jarray, arr.ToArray(), 0);
            return rs;
        }
    }
}
