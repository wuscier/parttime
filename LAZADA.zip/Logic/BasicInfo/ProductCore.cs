﻿using LAZADA;
using Logic.SystemSole;
using PublicFunction.Entity.DBEntity;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    /// <summary>
    /// 产品操作业务类
    /// </summary>
    public class ProductCore
    {
        /// <summary>
        /// 获取当前站点最后一条的SKU编号
        /// </summary>
        /// <returns></returns>
        public int GetNextProductNumber()
        {
            string sql = "select IFNULL(max(number),0) myNumber from ProductList where SiteID=@SiteID";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
            };
            return Convert.ToInt32(new SQLiteHelp().ExecuteScalar<Int64>(sql, paramList)) + 1;
        }


        /// <summary>
        /// 根据SKU前缀，获取当前站点最后一条SKU后缀编号
        /// </summary>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public int GetNextSKUNumberByIdprefix(string prefix)
        {
            string sql = "select IFNULL(max(SKUNumber),0) mySKUNumber from ProductList where SiteID=@SiteID and pidprefix=@pidprefix";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                  new SQLiteParameter("@pidprefix",prefix),
            };
            return Convert.ToInt32(new SQLiteHelp().ExecuteScalar<Int64>(sql, paramList)) + 1;
        }

        /// <summary>
        /// 查询总条数
        /// </summary>
        /// <param name="queryWhere"></param>
        /// <returns></returns>
        internal Int64 GetProductListCount(string queryWhere = "")
        {
            string sql = $"SELECT COUNT(*) FROM ProductList WHERE SiteID=@SiteID and pusername=@pusername { queryWhere}";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                  new SQLiteParameter("@pusername",GlobalUserClass.uname),
            };
            return new SQLiteHelp().ExecuteScalar<Int64>(sql, paramList);
        }

        /// <summary>
        /// 加载所有的产品
        /// </summary>
        /// <returns></returns>
        internal List<Product> GetProductList(string queryWhere = "")
        {
            string sql = $"SELECT * FROM ProductList WHERE SiteID=@SiteID and pusername=@pusername {queryWhere} order by number desc";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                  new SQLiteParameter("@pusername",GlobalUserClass.uname),
            };
            return new SQLiteHelp().GetList<Product>(sql, paramList);
        }

        /// <summary>
        /// 加载所有的产品
        /// </summary>
        /// <returns></returns>
        internal List<Product> GetProductList(int pagesize, int currentpage, string queryWhere = "")
        {
            string sql = $"SELECT * from ProductList where SiteID=@SiteID and pusername=@pusername {queryWhere} and number not in (SELECT number from ProductList where SiteID=@SiteID and pusername=@pusername {queryWhere} ORDER BY number desc limit {(currentpage - 1) * pagesize}) ORDER BY number desc limit {pagesize}";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                  new SQLiteParameter("@pusername",GlobalUserClass.uname),
            };
            return new SQLiteHelp().GetList<Product>(sql, paramList);
        }

        /// <summary>
        /// 检查当前链接在数据库中是否存在
        /// </summary>
        /// <param name="link"></param>
        /// <returns></returns>
        public bool CheckLinkExists(string link)
        {
            string sql = "SELECT COUNT(*) FROM ProductList WHERE SiteID=@SiteID AND poriglink=@poriglink";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                  new SQLiteParameter("@poriglink",link),
            };
            return new SQLiteHelp().ExecuteScalar<Int64>(sql, paramList) == 0;
        }

        /// <summary>
        /// 向数据库添加一条采集产品
        /// 新增任务时使用
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool AddProduct(Product product)
        {
            string sql = @"INSERT INTO 
ProductList(SiteID,number,lazadaisparent,poriglink,pfromtype,ppid,Pidprefix,Padddate,Pusername,Pstatetype,Plocalimgpath,SKUNumber,pkuchen,PackageLength,PackageHight,PackageWidth,Pjisangongshi,Peditdate) 
values(@SiteID,@Number,@Lazadaisparent,@Poriglink,@Pfromtype,@Ppid,@Pidprefix,@Padddate,@Pusername,@Pstatetype,@Plocalimgpath,@SKUNumber,@Pkuchen,@PackageLength,@PackageHight,@PackageWidth,@Pjisangongshi,@Peditdate)";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Lazadaisparent",product.Lazadaisparent),
                new SQLiteParameter("@Poriglink",product.Poriglink),
                new SQLiteParameter("@Pfromtype",product.Pfromtype),
                new SQLiteParameter("@Ppid",product.Ppid),
                new SQLiteParameter("@Pidprefix",product.Pidprefix),
                new SQLiteParameter("@Padddate",product.Padddate),
                new SQLiteParameter("@Pusername",product.Pusername),
                new SQLiteParameter("@Pstatetype",product.Pstatetype),
                new SQLiteParameter("@Plocalimgpath",product.Plocalimgpath),
                new SQLiteParameter("@SKUNumber",product.SKUNumber),
                new SQLiteParameter("@Pkuchen",product.Pkuchen),
                new SQLiteParameter("@PackageLength",product.PackageLength),
                new SQLiteParameter("@PackageHight",product.PackageHight),
                new SQLiteParameter("@PackageWidth",product.PackageWidth),
                new SQLiteParameter("@Pjisangongshi",product.Pjisangongshi),
                new SQLiteParameter("@Peditdate",product.Peditdate),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 更新采集信息
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateCollectProduct(Product product)
        {
            string sql = @"UPDATE ProductList SET 
                            Pimgurl=@Pimgurl,
                            Pprofit=@Pprofit,
                            Plowestprice=@Plowestprice,
                            Pnewtitle=@Pnewtitle,
                            PnewtitleX=@PnewtitleX,
                            Pweight=@Pweight,
                            Lazadapackageweight=@Lazadapackageweight,
                            Porigprice=@Porigprice,
                            Pallsoldcount=@Pallsoldcount,
                            Plinkcreatedate=@Plinkcreatedate,
                            Peditdate=@Peditdate,
                            Lazadapromprice=@Lazadapromprice,
                            Lazadaprice=@Lazadaprice,
                            Lazadadescription=@Lazadadescription,
                            Psizes =@Psizes,
                            Pcolors = @Pcolors,
                            Pcolormatch = @Pcolormatch,
                            Punfanyiimgs =@Punfanyiimgs,
                            Pfanyidcolors =@Pfanyidcolors,
                            Porigimgsurl =@Porigimgsurl,
                            Pstate = @Pstate,
                            Pdescription=@Pdescription,
                            Lazadahighlight=@Lazadahighlight,
                            Plocalimgpath=@Plocalimgpath,
                            Porigtitle=@Porigtitle,
                            Porigattribute=@Porigattribute,
                            Lazadacategoryid=@Lazadacategoryid,
                            Lazadacategorynamepath=@Lazadacategorynamepath,
                            Pchenbenjia=@Pchenbenjia,
                            Poldshipfee=@Poldshipfee,
                            Plowestprice=@Plowestprice,
                            Video=@Video

                        WHERE SiteID=@SiteID AND Number=@Number";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pimgurl",product.Pimgurl),
                new SQLiteParameter("@Pprofit",product.Pprofit),
                new SQLiteParameter("@Plowestprice",product.Plowestprice),
                new SQLiteParameter("@Pnewtitle",product.Pnewtitle),
                new SQLiteParameter("@PnewtitleX",product.PnewtitleX),
                new SQLiteParameter("@Pweight",product.Pweight),
                new SQLiteParameter("@Lazadapackageweight",product.Lazadapackageweight),
                new SQLiteParameter("@Porigprice",product.Porigprice),
                new SQLiteParameter("@Pallsoldcount",product.Pallsoldcount),
                new SQLiteParameter("@Plinkcreatedate",product.Plinkcreatedate),
                new SQLiteParameter("@Peditdate",product.Peditdate),
                new SQLiteParameter("@Lazadapromprice",product.Lazadapromprice),
                new SQLiteParameter("@Lazadaprice",product.Lazadaprice),
                new SQLiteParameter("@Lazadadescription",product.Lazadadescription),
                new SQLiteParameter("@Psizes",product.Psizes),
                new SQLiteParameter("@Pcolors",product.Pcolors),
                new SQLiteParameter("@Pcolormatch",product.Pcolormatch),
                new SQLiteParameter("@Punfanyiimgs",product.Punfanyiimgs),
                new SQLiteParameter("@Pfanyidcolors",product.Pfanyidcolors),
                new SQLiteParameter("@Porigimgsurl",product.Porigimgsurl),
                new SQLiteParameter("@Pstate",product.Pstate),
                new SQLiteParameter("@Pdescription",product.Pdescription),
                new SQLiteParameter("@Lazadahighlight",product.Lazadahighlight),
                new SQLiteParameter("@Plocalimgpath",product.Plocalimgpath),
                new SQLiteParameter("@Porigtitle",product.Porigtitle),
                new SQLiteParameter("@Porigattribute",product.Porigattribute),
                new SQLiteParameter("@Lazadacategoryid",product.Lazadacategoryid),
                new SQLiteParameter("@Lazadacategorynamepath",product.Lazadacategorynamepath),
                new SQLiteParameter("@Pchenbenjia",product.Pchenbenjia),
                new SQLiteParameter("@Poldshipfee",product.Poldshipfee),
                new SQLiteParameter("@Plowestprice",product.Plowestprice),
                new SQLiteParameter("@Video",product.Video),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 更新图片下载后的信息
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateDownProductImage(Product product)
        {
            string sql = @"UPDATE ProductList SET Pstate = @Pstate,Plocalimgpath=@Plocalimgpath,Peditdate=@Peditdate WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Plocalimgpath",product.Plocalimgpath),
                new SQLiteParameter("@Pstate",product.Pstate),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 上传图片后更新
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateUploadImage(Product product)
        {
            string sql = @"UPDATE ProductList SET 
                                Pimgurl = @Pimgurl,
                                Lazadaskuimages = @Lazadaskuimages,
                                Pnewimgsurl = @Pnewimgsurl,
                                Pupedimg = @Pupedimg,
                                Peditdate = @Peditdate,
                                Pstate=@Pstate
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pimgurl",product.Pimgurl),
                new SQLiteParameter("@Lazadaskuimages",product.Lazadaskuimages),
                new SQLiteParameter("@Pnewimgsurl",product.Pnewimgsurl),
                new SQLiteParameter("@Pupedimg",product.Pupedimg),
                new SQLiteParameter("@Pstate",product.Pstate),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }


        /// <summary>
        /// 更新发布成功的产品
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdatePushProduct(Product product)
        {
            string sql = @"UPDATE ProductList SET 
                                Pcancsv = @Pcancsv,
                                Peditdate = @Peditdate,
                                ChildSku = @ChildSku,
                                ServerID = @ServerID,
                                LazadaItemid = @LazadaItemid,
                                Pstatetype = @Pstatetype
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pcancsv",product.Pcancsv),
                new SQLiteParameter("@ChildSku",product.ChildSku),
                new SQLiteParameter("@ServerID",product.ServerID),
                new SQLiteParameter("@Pstatetype",product.Pstatetype),
                new SQLiteParameter("@LazadaItemid",product.LazadaItemid),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 更新详情编辑
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateDetailsEditor(Product product)
        {
            string sql = @"UPDATE ProductList SET 
                            Pnewtitle = @Pnewtitle,
                            PnewtitleX=@PnewtitleX, 
                            Lazadadescription=@Lazadadescription, 
                            Lazadahighlight=@Lazadahighlight,
                            Pstatetype=@Pstatetype,
                                Peditdate = @Peditdate,
                            DetailsEditError=@DetailsEditError

                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pnewtitle",product.Pnewtitle),
                new SQLiteParameter("@PnewtitleX",product.PnewtitleX),
                new SQLiteParameter("@Lazadadescription",product.Lazadadescription),
                new SQLiteParameter("@Lazadahighlight",product.Lazadahighlight),
                new SQLiteParameter("@DetailsEditError",product.DetailsEditError),
                new SQLiteParameter("@Pstatetype",product.Pstatetype),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 更新SPU编辑
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateSPUEditor(Product product)
        {
            string sql = @"UPDATE ProductList SET 
                            Pkuchen = @Pkuchen,
                            Pprofit = @Pprofit,
                            PackageLength = @PackageLength,
                            PackageWidth = @PackageWidth,
                            PackageHight = @PackageHight,
                            Lazadaprice = @Lazadaprice,
                            Lazadapromprice = @Lazadapromprice,
                            Pjisangongshi = @Pjisangongshi,
                            Pbrand = @Pbrand,
                            AutoAllocateStock = @AutoAllocateStock,
                            Lazadapromstart = @Lazadapromstart,
                            Lazadapromend = @Lazadapromend,
                            Lazadacategorynamepath = @Lazadacategorynamepath,
                            Lazadacategoryid = @Lazadacategoryid,
                            Pcolors = @Pcolors,
                            Psizes = @Psizes,
                            SPUEditError = @SPUEditError,
                            Lazadaskux = @Lazadaskux,
                            Lazadaattributs = @Lazadaattributs,
                            Lazadapackageincluding = @Lazadapackageincluding,
                            Pstatetype = @Pstatetype,
                            Peditdate = @Peditdate,
                            Pweight = @Pweight,
                            Porigprice = @Porigprice,
                            Lazadapackageweight = @Lazadapackageweight,
                            Lazadatax = @Lazadatax,
                            LazadaCategoryTreePath = @LazadaCategoryTreePath,
                            SKUDetail = @SKUDetail


                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pkuchen",product.Pkuchen),
                new SQLiteParameter("@Pprofit",product.Pprofit),
                new SQLiteParameter("@PackageLength",product.PackageLength),
                new SQLiteParameter("@PackageWidth",product.PackageWidth),
                new SQLiteParameter("@PackageHight",product.PackageHight),
                new SQLiteParameter("@Lazadaprice",product.Lazadaprice),
                new SQLiteParameter("@Lazadapromprice",product.Lazadapromprice),
                new SQLiteParameter("@Pjisangongshi",product.Pjisangongshi),
                new SQLiteParameter("@Pbrand",product.Pbrand),
                new SQLiteParameter("@AutoAllocateStock",product.AutoAllocateStock),
                new SQLiteParameter("@Lazadapromstart",product.Lazadapromstart),
                new SQLiteParameter("@Lazadapromend",product.Lazadapromend),
                new SQLiteParameter("@Lazadacategorynamepath",product.Lazadacategorynamepath),
                new SQLiteParameter("@Lazadacategoryid",product.Lazadacategoryid),
                new SQLiteParameter("@Pcolors",product.Pcolors),
                new SQLiteParameter("@Psizes",product.Psizes),
                new SQLiteParameter("@SPUEditError",product.SPUEditError),
                new SQLiteParameter("@Lazadaskux",product.Lazadaskux),
                new SQLiteParameter("@Lazadaattributs",product.Lazadaattributs),
                new SQLiteParameter("@Lazadatax",product.Lazadatax),
                new SQLiteParameter("@Lazadapackageincluding",product.Lazadapackageincluding),
                new SQLiteParameter("@Pstatetype",product.Pstatetype),
                new SQLiteParameter("@Pweight",product.Pweight),
                new SQLiteParameter("@Porigprice",product.Porigprice),
                new SQLiteParameter("@Lazadapackageweight",product.Lazadapackageweight),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
                new SQLiteParameter("@SKUDetail",product.SKUDetail),
                new SQLiteParameter("@LazadaCategoryTreePath",product.LazadaCategoryTreePath),
        };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 更新选择图片
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateImagesEditor(Product product)
        {
            string sql = @"UPDATE ProductList SET 
                            Pupedimg = @Pupedimg,
                            Pstate=@Pstate, 
                            Pnewimgsurl=@Pnewimgsurl, 
                            Lazadaskuimages=@Lazadaskuimages,
                            UploadImgError=@UploadImgError,
                            Peditdate=@Peditdate,
                            Pstatetype=@Pstatetype

                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pupedimg",product.Pupedimg),
                new SQLiteParameter("@Pstate",product.Pstate),
                new SQLiteParameter("@Pnewimgsurl",product.Pnewimgsurl),
                new SQLiteParameter("@Lazadaskuimages",product.Lazadaskuimages),
                new SQLiteParameter("@UploadImgError",product.UploadImgError),
                new SQLiteParameter("@Pstatetype",product.Pstatetype),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        public bool CreateProduct(Product product)
        {
            string sql = @"Insert into ProductList(
                            SiteID,number,Pidprefix,SKUNumber,Pusername,Padddate)
                            VALUES(
                            @SiteID,@number,@Pidprefix,@SKUNumber,@Pusername,@Padddate)";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                new SQLiteParameter("@number",product.Number),
                new SQLiteParameter("@Pidprefix",product.Pidprefix),
                new SQLiteParameter("@SKUNumber",product.SKUNumber),
                new SQLiteParameter("@Pusername",product.Pusername),
                new SQLiteParameter("@Padddate",product.Padddate),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 获取新建产品的SKU前缀
        /// </summary>
        /// <returns></returns>
        public string GetNewPorductPidprefix()
        {
            string sql = @"SELECT IFNULL((select Pidprefix from ProductList where SiteID=@SiteID ORDER BY number desc LIMIT 1),'MSE')";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
            };
            return new SQLiteHelp().ExecuteScalar<string>(sql, paramList);
        }

        /// <summary>
        /// 更新SKU详情
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateSKUEdit(Product product)
        {
            switch (SystemSoleEntity.GetSelectedTab())
            {
                case CurrentSelectedTab.ShowSKU:
                    return true;
                case CurrentSelectedTab.EditSpu:
                    return UpdateSPUEditor(product);
                case CurrentSelectedTab.EditDetail:
                    return UpdateDetailsEditor(product);
                case CurrentSelectedTab.EditImages:
                    return UpdateImagesEditor(product);
            }
            return true;
        }

        /// <summary>
        /// 更改类目
        /// </summary>
        /// <param name="products"></param>
        /// <returns></returns>
        public bool UpdateChoiceCategory(List<Product> products)
        {
            string sql = @"Update ProductList SET 
                            Lazadacategoryid = @Lazadacategoryid,
                            Lazadacategorynamepath=@Lazadacategorynamepath,
                            Lazadaattributs = @Lazadaattributs,
                            Peditdate = @Peditdate,
                            Lazadatax = @Lazadatax
                            WHERE SiteID=" + GlobalUserClass.SiteId + " and Number in(" + string.Join(",", products.Select(p => p.Number).ToArray()) + ")";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",products[0].SiteID),
                new SQLiteParameter("@Lazadacategoryid",products[0].Lazadacategoryid),
                new SQLiteParameter("@Lazadacategorynamepath",products[0].Lazadacategorynamepath),
                new SQLiteParameter("@Lazadaattributs",products[0].Lazadaattributs),
                new SQLiteParameter("@Lazadatax",products[0].Lazadatax),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) > 0;
        }

        /// <summary>
        /// 批量编辑
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateBatchEdit(Product product)
        {
            string sql = @"Update ProductList SET 
                            Pnewtitle = @Pnewtitle,
                            Lazadahighlight=@Lazadahighlight,
                            Lazadadescription = @Lazadadescription,
                            Lazadapackageweight = @Lazadapackageweight,
                            Pjisangongshi = @Pjisangongshi,
                            Pkuchen = @Pkuchen,
                            PackageLength = @PackageLength,
                            PackageWidth = @PackageWidth,
                            PackageHight = @PackageHight,
                            Lazadapromstart = @Lazadapromstart,
                            Lazadapromend = @Lazadapromend,
                            Pprofit = @Pprofit,
                            Peditdate = @Peditdate,
                            Lazadapromprice = @Lazadapromprice,
                            Lazadaprice = @Lazadaprice,
                            Lazadacategoryid = @Lazadacategoryid,
                            Lazadacategorynamepath=@Lazadacategorynamepath,
                            Lazadaattributs = @Lazadaattributs,
                            Lazadatax = @Lazadatax,
                            Lazadapackageincluding=@Lazadapackageincluding
                            WHERE SiteID=" + GlobalUserClass.SiteId + " and Number =@Number";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pnewtitle",product.Pnewtitle),
                new SQLiteParameter("@Lazadahighlight",product.Lazadahighlight),
                new SQLiteParameter("@Lazadadescription",product.Lazadadescription),
                new SQLiteParameter("@Lazadapackageweight",product.Lazadapackageweight),
                new SQLiteParameter("@Pjisangongshi",product.Pjisangongshi),
                new SQLiteParameter("@Pkuchen",product.Pkuchen),
                new SQLiteParameter("@PackageLength",product.PackageLength),
                new SQLiteParameter("@PackageWidth",product.PackageWidth),
                new SQLiteParameter("@PackageHight",product.PackageHight),
                new SQLiteParameter("@Lazadapromstart",product.Lazadapromstart),
                new SQLiteParameter("@Lazadapromend",product.Lazadapromend),
                new SQLiteParameter("@Pprofit",product.Pprofit),
                new SQLiteParameter("@Lazadapromprice",product.Lazadapromprice),
                new SQLiteParameter("@Lazadaprice",product.Lazadaprice),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
                new SQLiteParameter("@Lazadacategoryid",product.Lazadacategoryid),
                new SQLiteParameter("@Lazadacategorynamepath",product.Lazadacategorynamepath),
                new SQLiteParameter("@Lazadaattributs",product.Lazadaattributs),
                new SQLiteParameter("@Lazadatax",product.Lazadatax),
                new SQLiteParameter("@Lazadapackageincluding",product.Lazadapackageincluding)
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) > 0;
        }

        /// <summary>
        /// 更新SPU编辑下的计价模板更换
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateChangePriceTemplate(Product product)
        {
            string sql = @"UPDATE ProductList SET 
                            Pkuchen = @Pkuchen,
                            Pprofit = @Pprofit,
                            PackageLength = @PackageLength,
                            PackageWidth = @PackageWidth,
                            PackageHight = @PackageHight,
                            Lazadaprice = @Lazadaprice,
                            Lazadapromprice = @Lazadapromprice,
                            Peditdate = @Peditdate,
                            Pjisangongshi = @Pjisangongshi

                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pkuchen",product.Pkuchen),
                new SQLiteParameter("@Pprofit",product.Pprofit),
                new SQLiteParameter("@PackageLength",product.PackageLength),
                new SQLiteParameter("@PackageWidth",product.PackageWidth),
                new SQLiteParameter("@PackageHight",product.PackageHight),
                new SQLiteParameter("@Lazadaprice",product.Lazadaprice),
                new SQLiteParameter("@Lazadapromprice",product.Lazadapromprice),
                new SQLiteParameter("@Pjisangongshi",product.Pjisangongshi),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        public bool SaveNewColorSizeToDBprolist(Product product)
        {
            string sql = @"UPDATE ProductList SET 
                                Pcolors = @Pcolors,
                                Peditdate = @Peditdate

                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pcolors",product.Pcolors),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 逻辑删除当前产品
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool DeleteProduct(Product product)
        {
            string sql = @"Update ProductList set 
                                pstatetype='-3', 
                                Peditdate = @Peditdate
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Peditdate",DateTime.Now.ToString()),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }
        /// <summary>
        /// 更新发布结果
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdatePulishResult(Product product)
        {
            string sql = @"Update ProductList set 
                                Pstatetype = @Pstatetype, 
                                Pcancsv = @Pcancsv
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@Pcancsv",product.Pcancsv),
                new SQLiteParameter("@Pstatetype",product.Pstatetype),
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }
        /// <summary>
        /// 复制一行产品，
        /// 并且返回新增这行产品的实体
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public Product CopyProduct(Product product)
        {
            string sql = "";
            PropertyInfo[] properties = typeof(Product).GetProperties();
            List<string> colName = new List<string>();
            List<string> valName = new List<string>();
            List<SQLiteParameter> list = new List<SQLiteParameter>();
            product.Number = GetNextProductNumber();
            product.SKUNumber = GetNextSKUNumberByIdprefix(product.Pidprefix);

            //foreach (var item in properties)
            //{
            //colName.Add(item.Name);
            //valName.Add("@" + item.Name);
            //if (item.Name.ToUpper() == "ISCHECKED" || item.Name == "GlobalError")
            //    continue;
            //if (item.Name.ToUpper() == "NUMBER" )
            //{
            //    SQLiteParameter parameter = new SQLiteParameter("@Number", number_new);
            //    list.Add(parameter);
            //}
            //else if (item.Name.ToUpper() == "SKUNUMBER")
            //{
            //    SQLiteParameter parameter = new SQLiteParameter("@SKUNUMBER", SKUnumber_new);
            //    list.Add(parameter);
            //}
            //else
            //{
            //    SQLiteParameter parameter = new SQLiteParameter("@" + item.Name.ToUpper(), item.GetValue(product));
            //    list.Add(parameter);
            //}
            //}
            //sql = string.Format($"INSERT INTO ProductList({string.Join(",", colName)}) VALUES({string.Join(",", valName)})");
            if (SaveOtherSiteProduct(product))
            {
                return GetProductList(" and NUMBER=" + product.Number).First();
            }
            return null;
        }

        /// <summary>
        /// 更新SKU
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UpdateSKUNumber(Product product)
        {
            string sql = @"Update ProductList set 
                                SKUNumber=@SKUNumber,
                                Pidprefix=@Pidprefix,
                                SKUDetail=@SKUDetail,
                                Peditdate=@Peditdate
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@SKUNumber",product.SKUNumber),
                new SQLiteParameter("@Pidprefix",product.Pidprefix),
                new SQLiteParameter("@Peditdate",product.Peditdate),
                new SQLiteParameter("@SKUDetail",product.SKUDetail),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        /// <summary>
        /// 保存附加SKU
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool SaveParentSku(Product product)
        {
            string sql = @"Update ProductList set 
                                Pnewtitle=@Pnewtitle,
                                PnewtitleX=@PnewtitleX,
                                Lazadaskuy=@Lazadaskuy,
                                Lazadafujiaskucount=@Lazadafujiaskucount,
                                Peditdate=@Peditdate
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Pnewtitle",product.Pnewtitle),
                new SQLiteParameter("@PnewtitleX",product.PnewtitleX),
                new SQLiteParameter("@Lazadaskuy",product.Lazadaskuy),
                new SQLiteParameter("@Lazadafujiaskucount",product.Lazadafujiaskucount),
                new SQLiteParameter("@Peditdate",product.Peditdate),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }


        /// <summary>
        /// 保存同步过来的
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool SaveOtherSiteProduct(Product product)
        {
            string sql = @"Insert into ProductList(
                            SiteID,number,lazadaisparent,lazadaparentid,lazadazhusku,lazadafujiaskucount,pimgurl,poriglink,pfromtype,ppid,porigprice,pnewprice,pchenbenjia,pprofit,pweight,pshipfee,
                            poldshipfee,plowestprice,porigtitle,pnewtitle,pnewtitleX,pdescription,porigattribute,puid,pnewimgsurl,pupedimg,porigimgsurl,plocalimgpath,pcolors,psizes,pfanyidcolors,pcolormatch,
                            punfanyiimgs,pbrand,pUPC,pZUPC,pusername,padddate,peditdate,pcancsv,lazadapublishresult,lazadapublishdate,pstate,plinkcreatedate,pallsoldcount,pjisangongshi,pkuchen,PackageLength,
                            PackageHight,PackageWidth,pstatetype,prelalink,pidprefix,lazadacategoryid,lazadacategoryidpath,lazadacategorynamepath,lazadahighlight,lazadadescription,lazadaprice,lazadapromprice,
                            lazadapromstart,lazadapromend,lazadawarrantytype,lazadawarrantyperiod,lazadawarrantypolicy,lazadatax,lazadaskyz,lazadaskuy,lazadaskux,lazadasizes,lazadaattributs,lazadapackageweight,
                            lazadapackageincluding,lazadaskuimages,PublishingSites,sgSalesPrice,sgRetailPrice,mySalesPrice,myRetailPrice,idSalesPrice,idRetailPrice,phSalesPrice,phRetailPrice,thSalesPrice,thRetailPrice,
                            vnSalesPrice,vnRetailPrice,AutoAllocateStock,video,SKUNumber,SPUEditError,DetailsEditError,UploadImgError,ChildSku,ServerID,LazadaCategoryTreePath,SKUDetail)
                            Values(@SiteID,@number,@lazadaisparent,@lazadaparentid,@lazadazhusku,@lazadafujiaskucount,@pimgurl,@poriglink,@pfromtype,@ppid,@porigprice,@pnewprice,@pchenbenjia,@pprofit,@pweight,@pshipfee,
                            @poldshipfee,@plowestprice,@porigtitle,@pnewtitle,@pnewtitleX,@pdescription,@porigattribute,@puid,@pnewimgsurl,@pupedimg,@porigimgsurl,@plocalimgpath,@pcolors,@psizes,@pfanyidcolors,@pcolormatch,
                            @punfanyiimgs,@pbrand,@pUPC,@pZUPC,@pusername,@padddate,@peditdate,@pcancsv,@lazadapublishresult,@lazadapublishdate,@pstate,@plinkcreatedate,@pallsoldcount,@pjisangongshi,@pkuchen,@PackageLength,
                            @PackageHight,@PackageWidth,@pstatetype,@prelalink,@pidprefix,@lazadacategoryid,@lazadacategoryidpath,@lazadacategorynamepath,@lazadahighlight,@lazadadescription,@lazadaprice,@lazadapromprice,
                            @lazadapromstart,@lazadapromend,@lazadawarrantytype,@lazadawarrantyperiod,@lazadawarrantypolicy,@lazadatax,@lazadaskyz,@lazadaskuy,@lazadaskux,@lazadasizes,@lazadaattributs,@lazadapackageweight,
                            @lazadapackageincluding,@lazadaskuimages,@PublishingSites,@sgSalesPrice,@sgRetailPrice,@mySalesPrice,@myRetailPrice,@idSalesPrice,@idRetailPrice,@phSalesPrice,@phRetailPrice,@thSalesPrice,@thRetailPrice,
                            @vnSalesPrice,@vnRetailPrice,@AutoAllocateStock,@video,@SKUNumber,@SPUEditError,@DetailsEditError,@UploadImgError,@ChildSku,@ServerID,@LazadaCategoryTreePath,@SKUDetail)
                            ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                new SQLiteParameter("@number",product.Number),
                new SQLiteParameter("@lazadaisparent",product.Lazadaisparent),
                new SQLiteParameter("@lazadaparentid",product.Lazadaparentid),
                new SQLiteParameter("@lazadazhusku",product.Lazadazhusku),
                new SQLiteParameter("@lazadafujiaskucount",product.Lazadafujiaskucount),
                new SQLiteParameter("@pimgurl",product.Pimgurl),
                new SQLiteParameter("@poriglink",product.Poriglink),
                new SQLiteParameter("@pfromtype",product.Pfromtype),
                new SQLiteParameter("@ppid",product.Ppid),
                new SQLiteParameter("@porigprice",product.Porigprice),
                new SQLiteParameter("@pnewprice",product.Pnewprice),
                new SQLiteParameter("@pchenbenjia",product.Pchenbenjia),
                new SQLiteParameter("@pprofit",product.Pprofit),
                new SQLiteParameter("@pweight",product.Pweight),
                new SQLiteParameter("@pshipfee",product.Pshipfee),
                new SQLiteParameter("@poldshipfee",product.Poldshipfee),
                new SQLiteParameter("@plowestprice",product.Plowestprice),
                new SQLiteParameter("@porigtitle",product.Porigtitle),
                new SQLiteParameter("@pnewtitle",product.Pnewtitle),
                new SQLiteParameter("@pnewtitleX",product.PnewtitleX),
                new SQLiteParameter("@pdescription",product.Pdescription),
                new SQLiteParameter("@porigattribute",product.Porigattribute),
                new SQLiteParameter("@puid",product.Puid),
                new SQLiteParameter("@pnewimgsurl",product.Pnewimgsurl),
                new SQLiteParameter("@pupedimg",product.Pupedimg),
                new SQLiteParameter("@porigimgsurl",product.Porigimgsurl),
                new SQLiteParameter("@plocalimgpath",product.Plocalimgpath),
                new SQLiteParameter("@pcolors",product.Pcolors),
                new SQLiteParameter("@psizes",product.Psizes),
                new SQLiteParameter("@pfanyidcolors",product.Pfanyidcolors),
                new SQLiteParameter("@pcolormatch",product.Pcolormatch),
                new SQLiteParameter("@punfanyiimgs",product.Punfanyiimgs),
                new SQLiteParameter("@pbrand",product.Pbrand),
                new SQLiteParameter("@pUPC",product.PUPC),
                new SQLiteParameter("@pZUPC",product.PZUPC),
                new SQLiteParameter("@pusername",GlobalUserClass.uname),
                new SQLiteParameter("@padddate",product.Padddate),
                new SQLiteParameter("@peditdate",product.Peditdate),
                new SQLiteParameter("@pcancsv",product.Pcancsv),
                new SQLiteParameter("@lazadapublishresult",product.Lazadapublishresult),
                new SQLiteParameter("@lazadapublishdate",product.Lazadapublishdate),
                new SQLiteParameter("@pstate",product.Pstate),
                new SQLiteParameter("@plinkcreatedate",product.Plinkcreatedate),
                new SQLiteParameter("@pallsoldcount",product.Pallsoldcount),
                new SQLiteParameter("@pjisangongshi",product.Pjisangongshi),
                new SQLiteParameter("@pkuchen",product.Pkuchen),
                new SQLiteParameter("@PackageLength",product.PackageLength),
                new SQLiteParameter("@PackageHight",product.PackageHight),
                new SQLiteParameter("@PackageWidth",product.PackageWidth),
                new SQLiteParameter("@pstatetype",product.Pstatetype),
                new SQLiteParameter("@prelalink",product.Prelalink),
                new SQLiteParameter("@pidprefix",product.Pidprefix),
                new SQLiteParameter("@lazadacategoryid",product.Lazadacategoryid),
                new SQLiteParameter("@lazadacategoryidpath",product.Lazadacategoryidpath),
                new SQLiteParameter("@lazadacategorynamepath",product.Lazadacategorynamepath),
                new SQLiteParameter("@lazadahighlight",product.Lazadahighlight),
                new SQLiteParameter("@lazadadescription",product.Lazadadescription),
                new SQLiteParameter("@lazadaprice",product.Lazadaprice),
                new SQLiteParameter("@lazadapromprice",product.Lazadapromprice),
                new SQLiteParameter("@lazadapromstart",product.Lazadapromstart),
                new SQLiteParameter("@lazadapromend",product.Lazadapromend),
                new SQLiteParameter("@lazadawarrantytype",product.Lazadawarrantytype),
                new SQLiteParameter("@lazadawarrantyperiod",product.Lazadawarrantyperiod),
                new SQLiteParameter("@lazadawarrantypolicy",product.Lazadawarrantypolicy),
                new SQLiteParameter("@lazadatax",product.Lazadatax),
                new SQLiteParameter("@lazadaskyz",product.Lazadaskyz),
                new SQLiteParameter("@lazadaskuy",product.Lazadaskuy),
                new SQLiteParameter("@lazadaskux",product.Lazadaskux),
                new SQLiteParameter("@lazadasizes",product.Lazadasizes),
                new SQLiteParameter("@lazadaattributs",product.Lazadaattributs),
                new SQLiteParameter("@lazadapackageweight",product.Lazadapackageweight),
                new SQLiteParameter("@lazadapackageincluding",product.Lazadapackageincluding),
                new SQLiteParameter("@lazadaskuimages",product.Lazadaskuimages),
                new SQLiteParameter("@PublishingSites",product.PublishingSites),
                new SQLiteParameter("@sgSalesPrice",product.SgSalesPrice),
                new SQLiteParameter("@sgRetailPrice",product.SgRetailPrice),
                new SQLiteParameter("@mySalesPrice",product.MySalesPrice),
                new SQLiteParameter("@myRetailPrice",product.MyRetailPrice),
                new SQLiteParameter("@idSalesPrice",product.IdSalesPrice),
                new SQLiteParameter("@idRetailPrice",product.IdRetailPrice),
                new SQLiteParameter("@phSalesPrice",product.PhSalesPrice),
                new SQLiteParameter("@phRetailPrice",product.PhRetailPrice),
                new SQLiteParameter("@thSalesPrice",product.ThSalesPrice),
                new SQLiteParameter("@thRetailPrice",product.ThRetailPrice),
                new SQLiteParameter("@vnSalesPrice",product.VnSalesPrice),
                new SQLiteParameter("@vnRetailPrice",product.VnRetailPrice),
                new SQLiteParameter("@AutoAllocateStock",product.AutoAllocateStock),
                new SQLiteParameter("@video",product.Video),
                new SQLiteParameter("@SKUNumber",product.SKUNumber),
                new SQLiteParameter("@SPUEditError",product.SPUEditError),
                new SQLiteParameter("@DetailsEditError",product.DetailsEditError),
                new SQLiteParameter("@UploadImgError",product.UploadImgError),
                new SQLiteParameter("@ChildSku",product.ChildSku),
                new SQLiteParameter("@ServerID",product.ServerID),
                new SQLiteParameter("@LazadaCategoryTreePath",product.LazadaCategoryTreePath),
                new SQLiteParameter("@SKUDetail",product.SKUDetail),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }


        /// <summary>
        /// 更新新建产品的图片地址
        /// </summary>
        /// <param name="product"></param>
        public bool UpdatePlocalimgpath(Product product)
        {
            string sql = @"Update ProductList set 
                                Plocalimgpath=@Plocalimgpath
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Plocalimgpath",product.Plocalimgpath),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }

        public void UpdatePorigimgsurl(Product product)
        {
            string sql = @"Update ProductList set 
                                Porigimgsurl=@Porigimgsurl,
                                PicTaskId=@PicTaskId
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@Porigimgsurl",product.Porigimgsurl),
                new SQLiteParameter("@PicTaskId",product.PicTaskId),
            };
            new SQLiteHelp().ExecuteNonQuery(sql, paramList);
        }

        public void UpdateTitleTaskID(Product product)
        {
            string sql = @"Update ProductList set 
                                TitleTaskId=@TitleTaskId
                            WHERE SiteID=@SiteID AND Number=@Number ";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("@SiteID",product.SiteID),
                new SQLiteParameter("@Number",product.Number),
                new SQLiteParameter("@TitleTaskId",product.TitleTaskId),
            };
            new SQLiteHelp().ExecuteNonQuery(sql, paramList);
        }
    }
}
