﻿using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    public class HaiWangUpdateCore
    {
        public bool CheckNeedToUpdate()
        {
            string sql = "select sql from sqlite_master where tbl_name = 'ProductList' and sql like '%titleTaskId%'";
            var rs = new SQLiteHelp().ExecuteScalar<string>(sql);
            if (rs == null || rs == string.Empty)
            {
                sql = @"ALTER TABLE ProductList ADD COLUMN titleTaskId text;
                        ALTER TABLE ProductList ADD COLUMN picTaskId text;
                        ALTER TABLE ProductList ADD COLUMN LazadaItemid varhchar(20);";
                new SQLiteHelp().ExecuteNonQuery(sql);
                sql = "select sql from sqlite_master where tbl_name = 'ProductList' and sql like '%titleTaskId%'";
                rs = new SQLiteHelp().ExecuteScalar<string>(sql);
                if (rs == null || rs == string.Empty)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
