﻿using PublicFunction.AlertHelp;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    /// <summary>
    /// 图片下载类
    /// </summary>
    public class DownImageCore
    {

        public void DownProductImage(Product product)
        {
            product.Pstate = "开始下载图片";
            if (!Directory.Exists(product.Plocalimgpath))
            {
                Directory.CreateDirectory(product.Plocalimgpath);
                Directory.CreateDirectory(product.Plocalimgpath + "\\Trash");
            }
            if (product.Porigimgsurl == null)
            {
                product.Pstate = "下载图片失败";
                return;
            }
            var list = product.Porigimgsurl.Split(',').ToList();
            List<Task> downList = new List<Task>();
            var max = list.Count;
            var remain = max;
            for (int i = 0; i < list.Count; i++)
            {
                remain--;
                Thread.Sleep(100);
                
                var downUrl = "";
                var savePath = "";
                if ((list[i].StartsWith("http") || list[i].StartsWith("https"))&& !list[i].Contains("youtu.be"))
                {
                    product.Pupedimg = String.Format($"[{remain}/{max}]");
                    downUrl = list[i].Substring(0, list[i].IndexOf('?') + 5);
                    savePath = product.Plocalimgpath + "\\" + list[i].Substring(list[i].IndexOf('?') + 5) + ".jpg";
                    Task task = new Task(new Action(() => DownImage(downUrl, savePath)));
                    task.Start();
                    downList.Add(task);
                }
            }
            Task.WaitAll(downList.ToArray());
            product.Pupedimg = "";
            //检查下载图片的信息，然后更新产品信息
            DirectoryInfo info = new DirectoryInfo(product.Plocalimgpath);
            //var downCount = info.GetFiles().Count();
            //if (downCount == list.Count)
            //{
                 //product.Pstate = "全部图片下载OK";
            product.Pstate = "全部图片下载OK";
            //}
            //else if (downCount == 0)
            //{
            //    product.Pstate = "全部图片下载失败";
            //}
            //else
            //{
            //    product.Pstate = $"{list.Count - downCount}张图片下载失败";
            //}
            //product.Pupedimg = "[0/0]";
            //string url = product.Plocalimgpath + "\\" + list[0].Substring(list[0].IndexOf('?') + 5) + ".jpg";
            //if (File.Exists(url))
            //{
            //    product.Pimgurl = url;
            //}
            new ProductCore().UpdateDownProductImage(product);
        }

        private void DownImage(string downUrl, string savePath)
        {
            MyWebClient client = new MyWebClient();
            client.Headers.Add("User-Agent", "Chrome");
            try
            {
                client.DownloadFile(downUrl, savePath);
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
            }
        }
    }
}
