﻿using Aliyun.OSS;
using LAZADA;
using Logic.Platform;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Logic.BasicInfo
{
    /// <summary>
    /// 上传图片操作类
    /// </summary>
    public class UpLoadImageCore
    {
        public void AsyncUploadImageNew(Product product, List<string> originPath, int allcount, int startcount)
        {
            try
            {
                int error = 0;
                int index = 0;
                List<Task> tasks = new List<Task>();
                Dictionary<string, string> dic = new Dictionary<string, string>();
                var lc = new LazadaCore();
                new LogOutput.LogTo().WriteLine("准备上传：" + string.Join(",", originPath));
                foreach (var aimgPath in originPath)
                {
                    index = 0;
                    //tasks.Add(Task.Run(() =>
                    //{
                    //string imgNetName = "" + "SYC" + product.Number.ToString() + DateTime.Now.ToFileTimeUtc().ToString() + Guid.NewGuid().ToString("N") + PublicFunctions.CreateRandomCode() + ".jpg";
                    if (aimgPath != string.Empty)
                    {
                        while (index < 10)
                        {
                            new LogOutput.LogTo().WriteLine("准备上传：" + aimgPath);
                            string path = LazadaUpOneImgDo(product, aimgPath); /*lc.UpLoadImageNew(aimgPath);*/
                            new LogOutput.LogTo().WriteLine("已经上传：" + aimgPath);
                            if (path.StartsWith("http"))
                            {
                                startcount++;
                                product.Pupedimg = String.Format($"[{startcount}/{allcount}]");
                                dic.Add(aimgPath, path);
                                break;
                            }
                            index++;
                            Thread.Sleep(200);
                        }
                        if (index == 10)
                        {
                            error++;
                        }
                    }
                    else
                    {
                        Thread.Sleep(200);
                        startcount++;
                        product.Pupedimg = String.Format($"[{startcount}/{allcount}]");
                    }
                    product.Pstate = String.Format("上传图片[{0}/{1}/{2}]", error, startcount, allcount);
                    product.Pupedimg = String.Format($"[{startcount}/{allcount}]");
                    Thread.Sleep(100);
                    //}));
                }
                //Task.WaitAll(tasks.ToArray());
                if (dic.Count > 0)
                {
                    List<string> imgList = new List<string>();
                    var imgarr = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var item in imgarr)
                    {
                        if (dic.ContainsKey(item))
                        {
                            imgList.Add(dic[item]);
                        }
                        else
                        {
                            imgList.Add(item);
                        }
                    }
                    product.Pnewimgsurl = string.Join(",", imgList.ToArray());
                    JArray msku = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
                    if (msku != null)
                    {
                        foreach (JToken jtn in msku) //不同sku组合
                        {
                            if (jtn["leftimages"] != null && jtn["leftimages"].HasValues)
                            {
                                var jarry = (JArray)jtn["leftimages"];
                                for (int i = 0; i < jarry.Count; i++)
                                {
                                    var item = Convert.ToString(jarry[i]);
                                    if (dic.ContainsKey(item))
                                    {
                                        jarry[i] = dic[item];
                                    }
                                    //if (!product.Pimgurl.StartsWith("http") && item.StartsWith("http"))
                                    //    product.Pimgurl = dic[item];
                                }

                            }
                        }
                    }
                    product.Lazadaskuimages = JsonConvert.SerializeObject(msku);
                }

                if (error > 0)
                    product.Pstate = String.Format("上传图片[{0}/{1}/{2}],{0}张图片上传出错", error, startcount, allcount);
                else
                    product.Pstate = String.Format("OK传图完毕[{0}/{1}/{2}]图片已全上传，无错误", error, startcount, allcount);
            }
            catch (Exception ex)
            {
                product.Pstate = String.Format("图片上传中出现未知错误，重新选择图片后上传");
                product.Pupedimg = String.Format("[{0}/{1}]", startcount, allcount);
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
            }
            //    Task task = new Task(() =>
            //    {
            //        string newpath = LazadaUpOneImgDo(aimgPath, product.Number);
            //        if (!newpath.Trim().StartsWith("http"))
            //        {
            //            Thread.Sleep(4000);

            //            newpath = LazadaUpOneImgDo(aimgPath, product.Number);  //上传 再试一次
            //        }
            //        if (newpath.Trim().StartsWith("http"))
            //        {
            //            lock (upImgPathDicXX)
            //            {
            //                if (upImgPathDicXX.ContainsKey(aimgPath))
            //                {
            //                    upImgPathDicXX[aimgPath] = newpath;
            //                }
            //                else
            //                {
            //                    upImgPathDicXX.Add(aimgPath, newpath);
            //                }
            //            }
            //        }

            //    });
            //    task.Start();
            //    taskList.Add(task);
            //}
            //while (startcount < allcount)
            //{
            //    startcount++;
            //    Thread.Sleep(500);
            //    product.Pupedimg = String.Format($"[{startcount}/{allcount}]");
            //}
            //Task.WaitAll(taskList.ToArray());

            //LazadaReplaceToNetAdress(product, upImgPathDicXX);
        }

        public string LazadaUpOneImgDo(Product product, string _filepath)
        {
            string netimgdir = DateTime.Today.ToString("yyMM/dd");
            string partNetName = "SYC" + product.Number;
            string imgNetName = partNetName + DateTime.Now.ToFileTimeUtc().ToString() + Guid.NewGuid().ToString("N") + PublicFunctions.CreateRandomCode() + ".jpg";
            string retName = "";
            //分配上传函数

            retName = upImgToAliyun(_filepath, netimgdir + "/" + imgNetName, GlobalUserClass.uname);
            if (retName.StartsWith("http"))
            {
                LazadaRequestClient client = new LazadaRequestClient();
                JObject jObject = null;
                for (int i = 0; i < 3; i++)
                {
                    jObject = client.imageMigrate(retName);
                    if (jObject != null && jObject["code"].ToString() == "0")
                    {
                        retName = jObject["data"]["image"]["url"].ToString();
                        break;
                    }
                    else if (i == 2)
                    {
                        retName = _filepath;
                    }
                }
            }
            return retName;

        }

        public string upImgToAliyun(string _imgPath, string _imgNetName, string _uname)
        {
            string endpoint = "oss-cn-shanghai.aliyuncs.com";
            string bucketName = "shopeetp2";
            // 初始化OssClient
            var client = new OssClient("http://" + endpoint, Constants.ACCESSKEYID, Constants.ACCESSKEYSECRET);//MainWindow.someKeys["OSSkey"].ToString(), MainWindow.someKeys["OSSsecret"].ToString());
            try
            {
                // string fileToUpload = _imgPath;
                //  client.PutObject(bucketName, DateTime.Now.ToString("HHmmss") + "TEST.jpg", fileToUpload);

                using (var fs = File.Open(_imgPath, FileMode.Open))
                {
                    var metadata = new ObjectMetadata();
                    metadata.ContentLength = fs.Length;
                    metadata.ContentType = "image/jpeg";
                    metadata.UserMetadata.Add("uname", _uname);

                    // metadata.ExpirationTime = DateTime.Parse("2015-10-12T00:00:00.000Z");
                    client.PutObject(bucketName, _imgNetName, fs, metadata);

                }
                //http://sycimgcnd.oss-cn-shenzhen.aliyuncs.com/143435TEST.jpg
                return "http://" + bucketName + "." + endpoint + "/" + _imgNetName;
                // MessageBox.Show("Put object succeeded");
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Put object failed," + ex.Message);
                return _imgPath;
            }
        }

        public void UpLoadImagesNew(Product product)
        {
            int alreadyUploadCount = 0;
            int allcount = 0;
            int errorCount = 0;
            List<string> uploadList = new List<string>();
            var imgarr = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            try
            {
                if (imgarr.Length == 0)
                {
                    product.Pstate = String.Format("上传图片[{0}/{1}/{2}]", 0, 0, 0);
                    product.Pupedimg = String.Format("[{0}/{1}]", 0, 0);
                    return;
                }
                else
                {
                    product.Pstate = String.Format("准备上传...");
                    product.Pupedimg = String.Format("[{0}/{1}]", 0, 0);
                    Thread.Sleep(100);
                }
                foreach (var item in imgarr)
                {
                    allcount++;
                    if (item.StartsWith("http"))
                    {
                        alreadyUploadCount++;
                    }
                    else
                    {
                        if (File.Exists(item))
                        {
                            if (!uploadList.Contains(item))
                                uploadList.Add(item);
                            else
                                uploadList.Add("");
                        }
                        else
                        {
                            errorCount++;
                        }
                    }
                }
                JArray msku = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
                if (msku != null)
                {
                    foreach (JToken jtn in msku) //不同sku组合
                    {
                        if (jtn["leftimages"] != null && jtn["leftimages"].HasValues)
                        {
                            foreach (string jtx in (JArray)jtn["leftimages"])
                            {
                                allcount++;

                                string jtxp = jtx.Trim();

                                if (jtxp.StartsWith("http"))
                                {
                                    alreadyUploadCount++;
                                }
                                else
                                {
                                    if (File.Exists(jtxp))
                                    {
                                        if (!uploadList.Contains(jtxp))
                                        {
                                            uploadList.Add(jtxp);
                                        }
                                        else
                                            uploadList.Add("");
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }
                                }
                            }
                        }
                    }
                }

                if (uploadList.Count > 0)
                {
                    product.Pstate = String.Format("开始上传[{0}/{1}/{2}]", errorCount, alreadyUploadCount, allcount);
                    product.Pupedimg = String.Format("[{0}/{1}]", alreadyUploadCount, allcount);
                    AsyncUploadImageNew(product, uploadList, allcount, alreadyUploadCount);
                }
                else
                {
                    if (errorCount > 0)
                    {
                        product.Pstate = String.Format("传图出错[{0}/{1}/{2}]有{0}张备选本地图片不存在了", errorCount, alreadyUploadCount, allcount);
                    }
                    else
                    {
                        product.Pstate = String.Format("OK传图完毕[{0}/{1}/{2}]图片已全上传，无错误", errorCount, alreadyUploadCount, allcount);
                    }
                    product.Pupedimg = String.Format("[{0}/{1}]", alreadyUploadCount, allcount);
                }
            }
            catch
            {
                product.Pstate = String.Format("传图出错[{0}/{1}/{2}]图片上传出错，可再次上传", 0, alreadyUploadCount, allcount);
                product.Pupedimg = String.Format("[{0}/{1}]", alreadyUploadCount, allcount);
            }
            new ProductCore().UpdateUploadImage(product);
        }

        public void UpLoadImages(Product product)
        {
            if (product.Lazadaskuimages == null) return;
            var originPathXX = new List<string>();
            var upImgPathDicXX = new Dictionary<string, string>();
            int allimgcount = 0;
            int updimgcount = 0;
            int errowimgcount = 0;

            if (product.Lazadaskuimages == "")
            {
                product.Pstate = String.Format("上传图片[{0}/{1}/{2}]", 0, 0, 0);
                product.Pupedimg = String.Format("[{0}/{1}]", 0, 0);

                return;
            }

            try
            {
                List<string> originPath = new List<string>();
                if (product.Pnewimgsurl.Length > 8)
                {
                    string[] newconimg = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    if (newconimg.Length > 0)
                    {
                        foreach (string imgppp in newconimg)
                        {
                            if (imgppp.Trim().Length > 0)
                            {
                                allimgcount++;

                                string jtxp = imgppp.Trim();

                                if (jtxp.StartsWith("http"))
                                {
                                    updimgcount++;
                                }
                                else
                                {
                                    if (File.Exists(jtxp))
                                    {
                                        if (!originPath.Contains(jtxp))
                                        {
                                            originPath.Add(jtxp);
                                        }
                                    }
                                    else
                                    {
                                        errowimgcount++;
                                    }
                                }
                            }
                        }
                    }
                }
                JArray msku = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);

                foreach (JToken jtn in msku) //不同sku组合
                {
                    if (jtn["leftimages"] != null && jtn["leftimages"].HasValues)
                    {
                        foreach (string jtx in (JArray)jtn["leftimages"])
                        {
                            allimgcount++;

                            string jtxp = jtx.Trim();

                            if (jtxp.StartsWith("http"))
                            {
                                updimgcount++;
                            }
                            else
                            {
                                if (File.Exists(jtxp))
                                {
                                    if (!originPath.Contains(jtxp))
                                    {
                                        originPath.Add(jtxp);

                                    }
                                }
                                else
                                {
                                    errowimgcount++;
                                }
                            }
                        }
                    }
                }

                if (originPath.Count > 0)
                {
                    product.Pstate = String.Format("图片上传中[{0}/{1}/{2}]", errowimgcount, updimgcount, allimgcount);
                    product.Pupedimg = String.Format("[{0}/{1}]", updimgcount, allimgcount);
                    AsyncUploadImage(product, originPath, allimgcount, updimgcount);
                }
                else
                {
                    if (errowimgcount > 0)
                    {
                        product.Pstate = String.Format("传图出错[{0}/{1}/{2}]有{0}张备选本地图片不存在了", errowimgcount, updimgcount, allimgcount);
                    }
                    else
                    {
                        product.Pstate = String.Format("OK传图完毕[{0}/{1}/{2}]图片已全上传，无错误", errowimgcount, updimgcount, allimgcount);
                    }
                    product.Pupedimg = String.Format("[{0}/{1}]", updimgcount, allimgcount);
                }
            }
            catch
            {
                product.Pstate = String.Format("传图出错[{0}/{1}/{2}]图片上传出错，可再次上传", 0, updimgcount, allimgcount);
                product.Pupedimg = String.Format("[{0}/{1}]", updimgcount, allimgcount);
            }
            new ProductCore().UpdateUploadImage(product);

        }

        string UpImgToLazada(string _filepath)
        {
            if (_filepath == null) return "";
            if (!File.Exists(_filepath)) return "";


            JObject jobject = new LazadaCore().GetCategroyWhenUpImg(new Dictionary<string, string> { { "Action", "/image/upload" } }, new Dictionary<string, string> { { "image", _filepath } });
            return jobject == null ? "" : jobject["data"]["image"]["url"].ToString().Replace("https:", "http:");
        }

        string LazadaUpOneImgDo(string _filepath, long proNumber)
        {
            string imgNetName = "" + "SYC" + proNumber.ToString() + DateTime.Now.ToFileTimeUtc().ToString() + Guid.NewGuid().ToString("N") + PublicFunctions.CreateRandomCode() + ".jpg";
            string retName = "";
            retName = UpImgToLazada(_filepath);
            return retName;
        }

        void AsyncUploadImage(Product product, List<string> originPath, int allcount, int startcount)
        {
            Dictionary<string, string> upImgPathDicXX = new Dictionary<string, string>();
            List<Task> taskList = new List<Task>();
            foreach (var aimgPath in originPath)
            {
                startcount++;
                Thread.Sleep(500);
                product.Pupedimg = String.Format($"[{startcount}/{allcount}]");
                Task task = new Task(() =>
                  {
                      string newpath = LazadaUpOneImgDo(aimgPath, product.Number);
                      if (!newpath.Trim().StartsWith("http"))
                      {
                          Thread.Sleep(4000);

                          newpath = LazadaUpOneImgDo(aimgPath, product.Number);  //上传 再试一次
                      }
                      if (newpath.Trim().StartsWith("http"))
                      {
                          lock (upImgPathDicXX)
                          {
                              if (upImgPathDicXX.ContainsKey(aimgPath))
                              {
                                  upImgPathDicXX[aimgPath] = newpath;
                              }
                              else
                              {
                                  upImgPathDicXX.Add(aimgPath, newpath);
                              }
                          }
                      }

                  });
                task.Start();
                taskList.Add(task);
            }
            while (startcount < allcount)
            {
                startcount++;
                Thread.Sleep(500);
                product.Pupedimg = String.Format($"[{startcount}/{allcount}]");
            }
            Task.WaitAll(taskList.ToArray());

            LazadaReplaceToNetAdress(product, upImgPathDicXX);
        }

        private void LazadaReplaceToNetAdress(Product product, Dictionary<string, string> _pathDic)
        {
            if (_pathDic == null) return;
            if (_pathDic.Count < 1) return;
            int allimgcount = 0;
            int updimgcount = 0;
            int errowimgcount = 0;
            try
            {
                if (product.Pnewimgsurl.Length > 8)
                {
                    string[] newconimg2 = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    if (newconimg2.Length > 0)
                    {
                        allimgcount += newconimg2.Length;

                        for (int lx = 0; lx < newconimg2.Length; lx++)
                        {
                            if (_pathDic.ContainsKey(newconimg2[lx].ToString().Trim()))
                            {
                                newconimg2[lx] = _pathDic[newconimg2[lx].ToString().Trim()];  //引用型  可以直接操作到原数据

                            }

                            if (newconimg2[lx].ToString().Trim().StartsWith("http"))
                            {
                                updimgcount++;
                            }
                            else
                            {
                                errowimgcount++;
                            }
                        }


                    }
                    product.Pnewimgsurl = string.Join(",", newconimg2);
                }
                string newZhutuImg = "";
                JArray msku = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
                foreach (JToken jtn in msku) //不同sku组合
                {
                    try
                    {
                        if (jtn["leftimages"] != null && jtn["leftimages"].HasValues && ((JArray)jtn["leftimages"]).Count > 0)
                        {
                            JArray ajry = ((JArray)jtn["leftimages"]);

                            allimgcount += ajry.Count;

                            for (int lx = 0; lx < ajry.Count; lx++)
                            {
                                if (_pathDic.ContainsKey(ajry[lx].ToString().Trim()))
                                {
                                    ajry[lx] = _pathDic[ajry[lx].ToString().Trim()];  //引用型  可以直接操作到原数据
                                }

                                if (ajry[lx].ToString().Trim().StartsWith("http"))
                                {
                                    updimgcount++;
                                }
                                else
                                {
                                    errowimgcount++;
                                }

                                if (newZhutuImg.Length < 5) newZhutuImg = ajry[0].ToString();
                            }


                        }

                    }
                    catch
                    {
                        product.Pstate = String.Format("图片上传中出现未知错误，重新选择图片后上传");
                        product.Pupedimg = String.Format("[{0}/{1}]", updimgcount, allimgcount);
                        return;
                    }

                }
                if (errowimgcount > 0)
                {
                    //if (haveUpZoushou >= needUpZoushou)
                    //{
                    //    product.Pstate = String.Format("传图完毕有错[{0}/{1}/{2}]图片上传操作已完成，但有错误，有{0}张备选图上传失败，可重试上传", errowimgcount, updimgcount, allimgcount);

                    //}
                    //else
                    //{
                    //    product.Pupedimg = String.Format("图片上传中[{0}/{1}/{2}]", 0, updimgcount, allimgcount);

                    //}
                }
                else
                {
                    product.Pstate = String.Format("OK传图完毕[{0}/{1}/{2}]图片已全上传，无错误", errowimgcount, updimgcount, allimgcount);
                }
                product.Pupedimg = String.Format("[{0}/{1}]", updimgcount, allimgcount);

                //回写
                if (newZhutuImg.Length > 5)
                    product.Pimgurl = newZhutuImg;
                product.Lazadaskuimages = JsonConvert.SerializeObject(msku);

            }
            catch (Exception ex)
            {
                product.Pstate = String.Format("图片上传中出现未知错误，重新选择图片后上传");
                product.Pupedimg = String.Format("[{0}/{1}]", updimgcount, allimgcount);
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
            }
        }
    }
}
