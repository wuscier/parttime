﻿using LAZADA;
using Logic.SystemSole;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    public class OnlineProductFunctionUpadteCore
    {
        /// <summary>
        /// 新建在线产品功能的数据库表
        /// </summary>
        /// <returns></returns>
        public bool CreateTableOnlineProduct()
        {
            string sql = "create table if not exists OnlineProduct(UserName varchar,siteid integer,itemid varchar,jsonStr text,title varchar,mainSku varchar,sellersku varchar,url varchar,createTime datetime,localTime datetime,updateTime datetime,primary key (UserName,siteid,itemid));";
            if (!FindTableOnlineProduct())
            {
                new SQLiteHelp().ExecuteNonQuery(sql);
                if (!FindTableOnlineProduct())
                    return false;
            }
            return true;
        }

        /// <summary>
        /// 查询在线产品的数据库表是否存在
        /// </summary>
        /// <returns></returns>
        private bool FindTableOnlineProduct()
        {
            string sql = "select count(*) from sqlite_master where type='table' and name='OnlineProduct'";
            var rs = new SQLiteHelp().ExecuteScalar<Int64>(sql);
            return rs > 0;
        }

        public bool SaveUpdateOnlineItem(ShowOnLineProduct product)
        {
            string sql = @"update OnlineProduct set  
                        jsonStr=@jsonStr,
                        title=@title,
                        mainSku=@mainSku,
                        sellersku=@sellersku,
                        url=@url,
                        updateTime=@updateTime 
                        WHERE siteid=@siteid AND itemid=@itemid and UserName=@UserName";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("UserName",GlobalUserClass.uname),
                new SQLiteParameter("siteid",product.Siteid),
                new SQLiteParameter("itemid",product.Itemid),
                new SQLiteParameter("jsonStr",product.JsonStr),
                new SQLiteParameter("title",product.Title),
                new SQLiteParameter("mainSku",product.MainSku),
                new SQLiteParameter("sellersku",product.Sellersku),
                new SQLiteParameter("url",product.Url),
                new SQLiteParameter("createTime",product.CreateTime),
                new SQLiteParameter("localTime",product.LocalTime),
                new SQLiteParameter("updateTime",product.UpdateTime),
            };
            bool a= new SQLiteHelp().ExecuteNonQuery(sql, paramList) > 0;
            return a;
        }

        public bool SaveLocalOnlineProduct(ShowOnLineProduct product)
        {
            string sql = @"update OnlineProduct set  
                        jsonStr=@jsonStr,
                        title=@title,
                        mainSku=@mainSku,
                        sellersku=@sellersku,
                        url=@url,
                        updateTime=@updateTime 
                        WHERE siteid=@siteid AND itemid=@itemid and UserName=@UserName";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("UserName",GlobalUserClass.uname),
                new SQLiteParameter("siteid",GlobalUserClass.SiteId),
                new SQLiteParameter("itemid",product.Itemid),
                new SQLiteParameter("jsonStr",product.JsonStr),
                new SQLiteParameter("title",product.Title),
                new SQLiteParameter("mainSku",product.MainSku),
                new SQLiteParameter("sellersku",product.Sellersku),
                new SQLiteParameter("url",product.Url),
                new SQLiteParameter("createTime",product.CreateTime),
                new SQLiteParameter("localTime",product.LocalTime),
                new SQLiteParameter("updateTime",product.UpdateTime),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) > 0;
        }

        /// <summary>
        /// 更新同步过来的产品数据
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool SaveOnlineProduct(ShowOnLineProduct product)
        {
            string sql = "SELECT COUNT(*) FROM OnlineProduct WHERE siteid=@siteid AND itemid=@itemid and UserName=@UserName and StoreName=@StoreName ";
            SQLiteParameter[] _paramList = new SQLiteParameter[] {
                new SQLiteParameter("UserName",GlobalUserClass.uname),
                new SQLiteParameter("siteid",product.Siteid),
                new SQLiteParameter("itemid",product.Itemid),
                new SQLiteParameter("StoreName",product.StoreName)
            };
            var rs = new SQLiteHelp().ExecuteScalar<Int64>(sql, _paramList);
            if (rs > 0)
            {
                sql = @"update OnlineProduct set  
                        jsonStr=@jsonStr,
                        title=@title,
                        mainSku=@mainSku,
                        sellersku=@sellersku,
                        url=@url,
                        localTime=@localTime,
                        updateTime=@updateTime,
                        StoreName=@StoreName
                        WHERE siteid=@siteid AND itemid=@itemid and UserName=@UserName";
            }
            else
            {
                sql = @"INSERT INTO OnlineProduct VALUES(@UserName,@siteid,@itemid,@jsonStr,@title,@mainSku,@sellersku,@url,@createTime,@localTime,@updateTime,@StoreName)";
            }
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                new SQLiteParameter("UserName",GlobalUserClass.uname),
                new SQLiteParameter("siteid",product.Siteid),
                new SQLiteParameter("itemid",product.Itemid),
                new SQLiteParameter("jsonStr",product.JsonStr),
                new SQLiteParameter("title",product.Title),
                new SQLiteParameter("mainSku",product.MainSku),
                new SQLiteParameter("sellersku",product.Sellersku),
                new SQLiteParameter("url",product.Url),
                new SQLiteParameter("createTime",product.CreateTime),
                new SQLiteParameter("localTime",product.LocalTime),
                new SQLiteParameter("updateTime",product.UpdateTime),
                new SQLiteParameter("StoreName", product.StoreName),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) > 0;
        }

        public List<string[]> GetLocalOnlineProduct(PagingViewModel paging, string SQLWhere, Dictionary<string, string> dic)
        {
            string whereSql = "SELECT itemid FROM OnlineProduct WHERE siteid=@siteid and UserName=@UserName and StoreName=@StoreName " + SQLWhere;
            string sql = "SELECT localTime,updateTime,jsonStr FROM OnlineProduct WHERE siteid=@siteid and UserName=@UserName and StoreName=@StoreName and itemid not in ([whereSql])" + SQLWhere;
            string countSql = "SELECT count(*) FROM OnlineProduct WHERE siteid=@siteid and UserName=@UserName and StoreName=@StoreName " + SQLWhere;
            SQLiteParameter[] paramList = new SQLiteParameter[dic.Count + 3];
            paramList[0] = new SQLiteParameter("siteid", GlobalUserClass.SiteId);
            paramList[1] = new SQLiteParameter("UserName", GlobalUserClass.uname);
            paramList[2] = new SQLiteParameter("StoreName", Constants.OnlineLAZADA_ACCOUNT);
            int index = 2;
            foreach (var item in dic.Keys)
            {
                //whereSql += " and " + item + "=@" + item;
                //countSql += " and " + item + "=@" + item;
                //sql += " and " + item + "=@" + item;
                paramList[index] = new SQLiteParameter(item, dic[item]);
                index++;
            }
            whereSql += " order by localTime desc limit " + (paging.CurrentPage - 1) * paging.PageSize;
            sql += " order by localTime desc limit " + paging.PageSize;
            sql = sql.Replace("[whereSql]", whereSql);
            var list = new SQLiteHelp().GetList(sql, paramList);
            var count = new SQLiteHelp().ExecuteScalar<Int64>(countSql, paramList);
            paging.CountNumber = Convert.ToInt32(count);
            return list;
        }


        public void UpdateOnlineProduct(JObject jObject, ShowOnLineProduct online)
        {
            try
            {
                online.UpdateTime = DateTime.Now;
                var productObjcet = JsonConvert.DeserializeObject<JObject>(jObject["Request"]["Product"].ToString());
                var onlineObject = JsonConvert.DeserializeObject<JObject>(online.JsonStr);
                online.Title = productObjcet["Attributes"]["name"].ToString();
                onlineObject["attributes"] = productObjcet["Attributes"];
                online.Siteid = GlobalUserClass.SiteId;
                var obj = JsonConvert.DeserializeObject<JObject>(productObjcet["Skus"][0].ToString());
                var productSkus = JsonConvert.DeserializeObject<JArray>(obj["Sku"].ToString());
                var onlineSkus = JsonConvert.DeserializeObject<JArray>(onlineObject["skus"].ToString());
                JArray newskus = new JArray();
                foreach (var item in productSkus)
                {
                    var psku = JsonConvert.DeserializeObject<JObject>(item.ToString());
                    var pname = psku["SellerSku"].ToString();
                    try
                    {
                        online.MainSku = pname.Split('-')[0];
                    }
                    catch { }
                    foreach (var ol in onlineSkus)
                    {
                        var sku = JsonConvert.DeserializeObject<JObject>(ol.ToString());
                        var name = sku["SellerSku"].ToString();
                        if (pname == name)
                        {
                            sku["package_weight"] = psku["package_weight"];
                            sku["price"] = psku["price"];
                            sku["special_price"] = psku["special_price"];
                            sku["package_content"] = psku["package_content"];
                            try
                            {
                                sku["tax_class"] = psku["tax_class"];
                            }
                            catch { }
                            sku["Images"] = psku["Images"]["Image"];
                            newskus.Add(sku);
                        }
                    }
                }
                onlineObject["skus"] = newskus;
                online.JsonStr = JsonConvert.SerializeObject(onlineObject);
            }
            catch (Exception ex)
            {
                var a = ex.Message;
            }
        }
    }
}
