﻿using PublicFunction.Entity.DBEntity;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    public class SiteCore
    {
        public List<SiteEntity> GetSiteList(string sqlWhere = "")
        {
            string sql = "SELECT * FROM Site " + sqlWhere;
            return new SQLiteHelp().GetList<SiteEntity>(sql);
        }
    }
}
