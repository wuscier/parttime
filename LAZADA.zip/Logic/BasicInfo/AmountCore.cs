﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Entity.RequestModel;
using PublicFunction.Entity.ResponseModel;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.BasicInfo
{
    /// <summary>
    /// 用户条数额度业务类
    /// </summary>
    public class AmountCore
    {
        /// <summary>
        /// 获取当前可用额度
        /// </summary>
        /// <returns></returns>
        public string GetRemainAmount()
        {
            RemainAmount_Req req = new RemainAmount_Req();
            MyHttpClient client = new MyHttpClient();
            var rep = client.PostEntity<RemainAmount_Rep>(HttpClientMode.GetRemainAmount, req);
            if (rep.rcode != "CheckSucceed")
            {
                new LogOutput.LogTo().WriteErrorLine("请求用户额度剩余值出错");
                return "0";
            }
            JObject jsondata = (JObject)JsonConvert.DeserializeObject(EncryptionWay.Decrypt(rep.msg, Constants.REMAINAMOUNT_RESPONSEKEY));
            return jsondata["myBalance"].ToString();
        }

        /// <summary>
        /// 减少用户额度
        /// </summary>
        /// <returns></returns>
        public bool ReduceAmount()
        {
            ReduceAmount_Req req = new ReduceAmount_Req();
            MyHttpClient client = new MyHttpClient();
            var rep = client.PostEntity<ReduceAmount_Rep>(HttpClientMode.ReduceAmount, req);
            if (rep.rcode != "ReduceSucceed")
            {
                new LogOutput.LogTo().WriteErrorLine("减少用户额度剩余值出错");
                return false;
            }
            return true;
        }
    }
}
