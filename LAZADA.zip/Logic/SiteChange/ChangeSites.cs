﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Logic.SiteChange
{
    /// <summary>
    /// 选择站点
    /// </summary>
   public  class ChangeSites
    {
        public void CloseWindow(Window window)
        {
            window.Close();
        }
    }
}
