﻿using LAZADA;
using Logic.BasicInfo;
using Logic.DataCollect;
using Logic.SystemSole;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.Entity;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.RequestModel;
using PublicFunction.Entity.ResponseModel;
using PublicFunction.Entity.ViewModel;
using PublicFunction.SaveHelp;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Logic.Link
{
    public class GetLinkCore
    {
        /// <summary>
        /// 获取新增链接
        /// </summary>
        /// <returns></returns>
        public JObject GetNewLinks()
        {
            GetLinkBase_Req req = new GetLinkBase_Req("getNewLink", "0");
            MyHttpClient client = new MyHttpClient();
            var rep = client.PostEntityAsync(HttpClientMode.GetLink, req);
            return rep;
        }
        /// <summary>
        /// 获取新增链接
        /// </summary>
        /// <returns></returns>
        public JObject GetAllLinks(string max = "0")
        {
            GetLinkBase_Req req = new GetLinkBase_Req("getAllLink", "0");
            MyHttpClient client = new MyHttpClient();
            //var rep = client.PostEntityAsync<GetLink_Rep>(HttpClientMode.GetLink, req);
            var rep = client.PostEntityAsync(HttpClientMode.GetLink, req);
            return rep;
        }

        /// <summary>
        /// 获取所有连接数量
        /// </summary>
        /// <returns></returns>
        public JObject GetAllCount()
        {
            GetLinkBase_Req req = new GetLinkBase_Req("getAllCount", "0");
            MyHttpClient client = new MyHttpClient();
            var rep = client.PostEntityAsync(HttpClientMode.GetLink, req);
            //var rep = client.PostEntityAsync<GetLink_Rep>(HttpClientMode.GetLink, req);
            return rep;
        }

        /// <summary>
        /// 获取新增链接数量
        /// </summary>
        /// <returns></returns>
        public JObject GetNewCount()
        {
            GetLinkBase_Req req = new GetLinkBase_Req("getNewCount", "0");
            MyHttpClient client = new MyHttpClient();
            var rep = client.PostEntityAsync(HttpClientMode.GetLink, req);
            return rep;
        }

        /// <summary>
        /// 更新已经获取的链接
        /// </summary>
        /// <returns></returns>
        public GetLink_Rep SetHaveDown(int count)
        {
            GetLinkBase_Req req = new GetLinkBase_Req("setHaveDown", count.ToString());
            MyHttpClient client = new MyHttpClient();
            var rep = client.PostEntityAsync<GetLink_Rep>(HttpClientMode.GetLink, req);
            return rep.Result;
        }


        /// <summary>
        /// 新增链接
        /// </summary>
        /// <param name="txtUrlBox">填写链接的用户控件</param>
        /// <param name="priceTemplate">选择的计价模板的ID</param>
        /// <param name="checkRepeat">是否去重</param>
        ///  <param name="imagePath">图片保存路径</param>
        public List<Product> AddNewLinks(TextBox txtUrlBox, PriceTemplateEntity priceTemplate, bool checkRepeat, string imagePath, NewTaskViewModel ownVM)
        {
            List<Product> returnList = new List<Product>();
            var pc = new ProductCore();
            var ftc = new FromTypeCore();
            var ac = new AmountCore();
            List<string> addLinks = new List<string>();
            var links = txtUrlBox.Text.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries).ToList();
            txtUrlBox.Text = "正在检查...";
            int currentSiteNumber = pc.GetNextProductNumber();
            int currentSkuNumber = pc.GetNextSKUNumberByIdprefix(priceTemplate.Jprfix);
            foreach (var item in links)
            {
                //检查链接
                var linkInfo = ftc.GetFromTypeByLink(item);
                if (linkInfo == null)
                {
                    txtUrlBox.AppendText($"\n {item} 链接未匹配到平台");
                    continue;
                }
                if (addLinks.Contains(linkInfo[1]) && checkRepeat)
                {
                    txtUrlBox.AppendText($"\n {item} 链接重复存在,需要重复添加,请去掉下方去重勾选");
                    continue;
                }
                if (!pc.CheckLinkExists(linkInfo[2]) && checkRepeat)
                {
                    txtUrlBox.AppendText($"\n {item} 链接重复存在,需要重复添加,请去掉下方去重勾选");
                    continue;
                }
                addLinks.Add(item);
                Product product = new Product()
                {
                    SiteID = GlobalUserClass.SiteId,
                    Number = currentSiteNumber,
                    Pfromtype = linkInfo[0],
                    Ppid = linkInfo[1],
                    Poriglink = linkInfo[2],
                    Pidprefix = priceTemplate.Jprfix,
                    Pjisangongshi = priceTemplate.Jname.ToString(),
                    Padddate = DateTime.Now.ToString(),
                    Pusername = GlobalUserClass.uname,
                    Pstate = "未采集",
                    Pstatetype = "0",
                    Lazadaisparent = "1",
                    Plocalimgpath = string.Format(imagePath + "\\" + linkInfo[0] + linkInfo[1]),
                    SKUNumber = currentSkuNumber,
                    Pkuchen = priceTemplate.Jkuchen,
                    PackageLength = priceTemplate.Jpkglength,
                    PackageHight = priceTemplate.Jpkghight,
                    PackageWidth = priceTemplate.Jpkgwidth,
                    Peditdate = DateTime.Now.ToString()
                };

                //检查额度
                //var remainAmount = Convert.ToInt32(ac.GetRemainAmount());
                //if (remainAmount <= 0)
                //{
                //    txtUrlBox.AppendText($"\n {item} 额度不足未添加");
                //    continue;
                //}
                //else
                //{
                //    if (!ac.ReduceAmount())
                //    {
                //        txtUrlBox.AppendText($"\n {item} 添加失败");
                //        continue;
                //    }
                if (pc.AddProduct(product))
                {
                    returnList.Add(product);
                    currentSiteNumber++;
                    currentSkuNumber++;
                    SystemSoleEntity.GetProductList().Insert(0, product);
                }
                else
                {
                    txtUrlBox.AppendText($"\n {item} 添加失败");
                }
                //}
            }
            return returnList;
        }


        private void DoCheckLink()
        {

        }

        /// <summary>
        /// 采集产品数据
        /// </summary>
        /// <param name="list">产品列表</param>
        /// <param name="isDownImage">是否下载图片</param>
        public void DownProductInfo(Product product, bool isDownImage)
        {
            //Task.Run(new Action(() =>
            //{
            BaseDataCollectCore collect = null;
            switch (product.Pfromtype)
            {
                case "1688":
                    collect = new AlibabaCore();
                    break;
                case "LAZADATH":
                case "LAZADAVN":
                case "LAZADASG":
                case "LAZADAPH":
                case "LAZADAMY":
                case "LAZADAID":
                    collect = new LazadaDataCollectCore();
                    break;
                case "SHOPEETW":
                case "SHOPEETH":
                case "SHOPEEVN":
                case "SHOPEESG":
                case "SHOPEEPH":
                case "SHOPEEMY":
                case "SHOPEEID":
                case "17HY":
                //case "PDD":
                case "SKW":
                case "SXW":
                case "BNN":
                case "3E3E":
                case "QCW":
                case "HQHP":
                case "GTW":
                    collect = new INewCollect();
                    break;
                default:
                    collect = new OtherCollectCore();
                    break;
            }
            bool bol = true;
            for (int i = 0; i < 3; i++)
            {
                if (collect.CollectProduct(product) || product.Pstate == "产品下架" || product.Pstate == "此链接采集不到数据！")
                {
                    bol = true;
                    break;
                }
                bol = false;
                Thread.Sleep(200);
            }
            if (bol && product.Pstate != "产品下架" && product.Pstate != "此链接采集不到数据！")
            {
                if (new ProductCore().UpdateCollectProduct(product))
                {
                    if (isDownImage)
                    {
                        new DownImageCore().DownProductImage(product);
                    }
                }
            }
            MySoundPlay.PlayMusic();
            //}));
        }



        /// <summary>
        /// 修改图片保存的地址
        /// </summary>
        /// <param name="path">地址</param>
        public void UpdateImageSavePath(string path)
        {
            string sql = "Update SystemConfiguration SET Value=@path where Name='NewLinkImageSavePath'";
            System.Data.SQLite.SQLiteParameter[] myParams = new System.Data.SQLite.SQLiteParameter[] {
                new System.Data.SQLite.SQLiteParameter("@path",path)
            };
            new SQLiteHelp().ExecuteNonQuery(sql, myParams);
        }

        /// <summary>
        /// 获取图片保存的地址
        /// </summary>
        /// <returns></returns>
        public string GetImageSavePath()
        {
            string sql = "SELECT VALUE FROM SystemConfiguration WHERE NAME='NewLinkImageSavePath'";
            return new SQLiteHelp().ExecuteScalar<string>(sql);
        }


        /// <summary>
        /// 保存采集到的链接到本地
        /// </summary>
        /// <param name="list"></param>
        public void SaveLinks(JArray list)
        {
            if (list.Count == 0) return;
            string sql = "insert into SourceLink(SiteID,rusername,rlink,AddDate) values ";
            foreach (var item in list)
            {
                sql += string.Format($"(1,'{GlobalUserClass.uname}','{item}',{DateTime.Now.ToString("yyyy-MM-dd")}),");
            }
            sql = sql.Substring(0, sql.Length - 1);
            new SQLiteHelp().ExecuteNonQuery(sql);
        }
    }
}
