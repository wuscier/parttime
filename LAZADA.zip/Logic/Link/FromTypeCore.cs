﻿using PublicFunction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Logic.Link
{
    /// <summary>
    /// 平台相关操作类
    /// </summary>
    public class FromTypeCore
    {

        /// <summary>
        /// 检查当前链接所属的平台信息
        /// </summary>
        /// <param name="link">当前链接</param>
        /// <returns>平台信息数组 长度为3 下标0:平台类型,下标1:平台下的产品ID,下标2:平台下的产品采集链接</returns>
        public string[] GetFromTypeByLink(string link)
        {
            if (link.Length < 10) return null;

            //检查链接类型，分配下载类
            #region 1688
            Regex regexstr = new Regex(Constants.REGEX_FROMTYPE_1688, RegexOptions.Compiled);
            Match matchstr = regexstr.Match(link);
            if (matchstr.Success)
            {
                string type = "1688";
                string pid = matchstr.Groups["offerID"].Value; //1688ID
                string newlink = "http://detail.1688.com/offer/" + pid + ".html";
                return new string[] { type, pid, newlink };
            }
            #endregion

            #region SHOPEE
            Regex regexstr11 = new Regex(Constants.REGEX_FROMTYPE_SHOPEETW, RegexOptions.Compiled);
            Match matchstr11 = regexstr11.Match(link);
            if (matchstr11.Success)
                return new string[] { "SHOPEETW", "", link };

            Regex regexstr15 = new Regex(Constants.REGEX_FROMTYPE_SHOPEEMY, RegexOptions.Compiled);
            Match matchstr15 = regexstr15.Match(link);
            if (matchstr15.Success)
                return new string[] { "SHOPEEMY", "", link };

            Regex regexstr16 = new Regex(Constants.REGEX_FROMTYPE_SHOPEESG, RegexOptions.Compiled);
            Match matchstr16 = regexstr16.Match(link);
            if (matchstr16.Success)
                return new string[] { "SHOPEESG", "", link };

            Regex regexstr17 = new Regex(Constants.REGEX_FROMTYPE_SHOPEETH, RegexOptions.Compiled);
            Match matchstr17 = regexstr17.Match(link);
            if (matchstr17.Success)
                return new string[] { "SHOPEETH", "", link };

            Regex regexstr18 = new Regex(Constants.REGEX_FROMTYPE_SHOPEEPH, RegexOptions.Compiled);
            Match matchstr18 = regexstr18.Match(link);
            if (matchstr18.Success)
                return new string[] { "SHOPEEPH", "", link };

            Regex regexstr19 = new Regex(Constants.REGEX_FROMTYPE_SHOPEEVN, RegexOptions.Compiled);
            Match matchstr19 = regexstr19.Match(link);
            if (matchstr19.Success)
                return new string[] { "SHOPEEVN", "", link };

            Regex regexstr110 = new Regex(Constants.REGEX_FROMTYPE_SHOPEEID, RegexOptions.Compiled);
            Match matchstr110 = regexstr110.Match(link);
            if (matchstr110.Success)
                return new string[] { "SHOPEEID", "", link };
            
            #endregion
            Regex regexstr12 = new Regex(Constants.REGEX_FROMTYPE_17HY, RegexOptions.Compiled);
            Match matchstr12 = regexstr12.Match(link);
            if (matchstr12.Success)
                return new string[] { "17HY", matchstr12.Groups["offerID"].Value, link };

            Regex regexstr13 = new Regex(Constants.REGEX_FROMTYPE_PDD, RegexOptions.Compiled);
            Match matchstr13 = regexstr13.Match(link);
            if (matchstr13.Success)
                return new string[] { "PDD", matchstr13.Groups["offerID"].Value, link };

            Regex regexstr14 = new Regex(Constants.REGEX_FROMTYPE_SKW, RegexOptions.Compiled);
            Match matchstr14 = regexstr14.Match(link);
            if (matchstr14.Success)
                return new string[] { "SKW", matchstr14.Groups["offerID"].Value, link };

            Regex regexstr21 = new Regex(Constants.REGEX_FROMTYPE_SXW, RegexOptions.Compiled);
            Match matchstr21 = regexstr21.Match(link);
            if (matchstr21.Success)
                return new string[] { "SXW", matchstr21.Groups["offerID"].Value, link };

            Regex regexstr22 = new Regex(Constants.REGEX_FROMTYPE_BNN, RegexOptions.Compiled);
            Match matchstr22 = regexstr22.Match(link);
            if (matchstr22.Success)
                return new string[] { "BNN", matchstr22.Groups["offerID"].Value, link };

            Regex regexstr23 = new Regex(Constants.REGEX_FROMTYPE_3E3E, RegexOptions.Compiled);
            Match matchstr23 = regexstr23.Match(link);
            if (matchstr23.Success)
                return new string[] { "3E3E", matchstr23.Groups["offerID"].Value, link };

            Regex regexstr24 = new Regex(Constants.REGEX_FROMTYPE_QCW, RegexOptions.Compiled);
            Match matchstr24 = regexstr24.Match(link);
            if (matchstr24.Success)
                return new string[] { "QCW", matchstr24.Groups["offerID"].Value, link };

            Regex regexstr25 = new Regex(Constants.REGEX_FROMTYPE_GTW, RegexOptions.Compiled);
            Match matchstr25 = regexstr25.Match(link);
            if (matchstr25.Success)
                return new string[] { "GTW", matchstr25.Groups["offerID"].Value, link };

            Regex regexstr26 = new Regex(Constants.REGEX_FROMTYPE_HQHP, RegexOptions.Compiled);
            Match matchstr26 = regexstr26.Match(link);
            if (matchstr26.Success)
                return new string[] { "HQHP", "", link };
            //REGEX_FROMTYPE_SXW
            //
            //
            //
            //
            //
            else
            {
                string productLink = link.Replace("store/product/", "item/");
                Regex reg = new Regex("/\\d{3,}_");
                productLink = reg.Replace(productLink, "/");
                Regex regexstr4 = new Regex(Constants.REGEX_FROMTYPE_SMT, RegexOptions.Compiled);
                Match matchstr4 = regexstr4.Match(link);
                if (matchstr4.Success)
                {
                    string type = "SMT";
                    string pid = matchstr4.Groups["offerID"].Value; //1688ID
                    string newlink = "http://www.aliexpress.com/item/id/" + pid + ".html";

                    return new string[] { type, pid, newlink };

                }

                else
                {
                    Regex regexTB = new Regex(Constants.REGEX_FROMTYPE_TaoBao, RegexOptions.Compiled);
                    Regex regexJD = new Regex(Constants.REGEX_FROMTYPE_JD, RegexOptions.Compiled);
                    Regex regexTM = new Regex(Constants.REGEX_FROMTYPE_TianMao, RegexOptions.Compiled);
                    Regex regexYMX = new Regex(Constants.REGEX_FROMTYPE_YMX, RegexOptions.Compiled);
                    //Match matchstr = regexstr.Match(_link);
                    if (regexTB.Match(link).Success)
                    {
                        //https://item.taobao.com/item.htm?id=580399588450
                        //https://detail.tmall.com/item.htm?id=581642564729
                        //https://item.jd.com/1592724647.html
                        //https://www.amazon.com/dp/B00IOXVW8Y
                        string type = "TaoBao";
                        string pid = regexTB.Match(link).Groups["offerID"].Value; //1688ID
                        string newlink = "http://item.taobao.com/item.htm?id=" + pid;

                        return new string[] { type, pid, newlink };
                    }
                    else if (regexJD.Match(link).Success)
                    {
                        string type = "JD";
                        string pid = regexJD.Match(link).Groups["offerID"].Value; //1688ID
                        string newlink = "http://item.jd.com/" + pid + ".html";

                        return new string[] { type, pid, newlink };
                    }
                    else if (regexTM.Match(link).Success)
                    {
                        string type = "TianMao";
                        string pid = regexTM.Match(link).Groups["offerID"].Value; //1688ID
                        string newlink = "http://detail.tmall.com/item.htm?id=" + pid;

                        return new string[] { type, pid, newlink };
                    }
                    else if (regexYMX.Match(link).Success)
                    {
                        string type = "YMX";
                        string pid = regexYMX.Match(link).Groups["offerID"].Value; //1688ID
                        string newlink = link;// "http://www.amazon.cn/gp/product/" + pid;

                        return new string[] { type, pid, newlink };
                    }
                    else// if (regexLAZADA.Match(link).Success)
                    {
                        Regex regexLAZADAMY = new Regex(Constants.REGEX_FROMTYPE_LAZADAMY, RegexOptions.Compiled);
                        Regex regexLAZADAID = new Regex(Constants.REGEX_FROMTYPE_LAZADAID, RegexOptions.Compiled);
                        Regex regexLAZADASG = new Regex(Constants.REGEX_FROMTYPE_LAZADASG, RegexOptions.Compiled);
                        Regex regexLAZADATH = new Regex(Constants.REGEX_FROMTYPE_LAZADATH, RegexOptions.Compiled);
                        Regex regexLAZADAVN = new Regex(Constants.REGEX_FROMTYPE_LAZADAVN, RegexOptions.Compiled);
                        Regex regexLAZADAPH = new Regex(Constants.REGEX_FROMTYPE_LAZADAPH, RegexOptions.Compiled);
                        if (regexLAZADAMY.Match(link).Success)
                        {
                            string type = "LAZADAMY";
                            string pid = ""; //1688ID
                            string newlink = link;// "https://www.amazon.cn/gp/product/" + pid;

                            return new string[] { type, pid, newlink };
                        }
                        if (regexLAZADAPH.Match(link).Success)
                        {
                            string type = "LAZADAPH";
                            string pid = ""; //1688ID
                            string newlink = link;// "https://www.amazon.cn/gp/product/" + pid;

                            return new string[] { type, pid, newlink };
                        }
                        if (regexLAZADATH.Match(link).Success)
                        {
                            string type = "LAZADATH";
                            string pid = ""; //1688ID
                            string newlink = link;// "https://www.amazon.cn/gp/product/" + pid;

                            return new string[] { type, pid, newlink };
                        }
                        if (regexLAZADAVN.Match(link).Success)
                        {
                            string type = "LAZADAVN";
                            string pid = ""; //1688ID
                            string newlink = link;// "https://www.amazon.cn/gp/product/" + pid;

                            return new string[] { type, pid, newlink };
                        }
                        if (regexLAZADASG.Match(link).Success)
                        {
                            string type = "LAZADASG";
                            string pid = ""; //1688ID
                            string newlink = link;// "https://www.amazon.cn/gp/product/" + pid;

                            return new string[] { type, pid, newlink };
                        }
                        if (regexLAZADAID.Match(link).Success)
                        {
                            string type = "LAZADAID";
                            string pid = ""; //1688ID
                            string newlink = link;// "https://www.amazon.cn/gp/product/" + pid;

                            return new string[] { type, pid, newlink };
                        }
                    }
                }

            }
            return null;
        }
    }
}
