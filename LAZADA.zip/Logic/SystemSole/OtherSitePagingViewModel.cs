﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.SystemSole
{
    public class OtherSitePagingViewModel : PagingViewModel
    {
        Action doSearchAction = null;
        public OtherSitePagingViewModel(Action action)
        {
            PageSize = 50;
            doSearchAction = action;
        }
        //protected override void DoSearch()
        //{
        //    //base.DoSearch();
        //    doSearchAction.Invoke();

        //}
    }
}
