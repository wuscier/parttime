﻿using LAZADA;
using Logic.BasicInfo;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.SystemSole
{
    /// <summary>
    /// 系统全局静态变量
    /// </summary>
    public class SystemSoleEntity
    {
        public static string queryWhere = "";

        /// <summary>
        /// 当前选择的产品
        /// </summary>
        private static Product _selectedProduct;
        /// <summary>
        /// 当前选择的标签页
        /// </summary>
        private static CurrentSelectedTab _selectedTab = CurrentSelectedTab.ShowSKU;

        /// <summary>
        /// 用来保存当前已选中的产品列表
        /// </summary>
        public static List<long> SelectedProductNumberList = new List<long>();

        /// <summary>
        /// 类目树缓存
        /// </summary>
        public static JObject CategoryObject = null;

        /// <summary>
        /// 主窗体视图模型单例
        /// </summary>
        private static MainWinViewModel _vm;

        /// <summary>
        /// 私有构造函数
        /// 关闭实例化
        /// </summary>
        private SystemSoleEntity() { }

        /// <summary>
        /// 私有静态类目集合
        /// </summary>
        private static List<Category> categoryList;

        public static List<Category> RefrushCategoryList()
        {
            categoryList = null;
            return GetCategoryList();
        }

        /// <summary>
        /// 主窗体视图模型单例
        /// </summary>
        public static MainWinViewModel GetMainWinModel()
        {
            if (_vm == null)
            {
                _vm = new MainWinViewModel();
            }
            return _vm;
        }

        public static List<Category> GetCategoryList()
        {
            if (categoryList == null)
            {
                categoryList = new CategoryCore().GetCategoryList();
            }
            return categoryList;
        }

        /// <summary>
        /// 私有静态产品集合
        /// </summary>
        private static AsyncObservableCollection<Product> productList;

        /// <summary>
        /// 私有静态店铺集合
        /// </summary>
        private static AsyncObservableCollection<Store> storeList;

        public static AsyncObservableCollection<Product> GetProductList()
        {
            if (productList == null)
            {
                productList = new AsyncObservableCollection<Product>();
            }
            return productList;
        }

        public static AsyncObservableCollection<Store> GetStoreList()
        {
            if (storeList == null)
            {
                storeList = new AsyncObservableCollection<Store>();
            }
            return storeList;
        }

        public static void LoadStoreList(PagingViewModel vm)
        {
            GetStoreList().Clear();
            vm.CountNumber = 100;
            if (vm.CountNumber > 0)
            {
                List<Store> list = new SqlAuthorization().GetStoreList(" and user='" + GlobalUserClass.uname + "' and region=" + GlobalUserClass.SiteId);
                foreach (var item in list)
                {
                    GetStoreList().Add(item);
                }
            }
        }

        public static void LoadProductList(PagingViewModel vm)
        {
            GetProductList().Clear();
            SelectedProductNumberList.Clear();
            int count = Convert.ToInt32(new ProductCore().GetProductListCount(queryWhere));
            vm.CountNumber = count;
            if (vm.CountNumber > 0)
            {
                List<Product> list = new ProductCore().GetProductList(vm.PageSize, vm.CurrentPage, queryWhere);
                //vm.CountNumber = list.Count();
                //list = list.Skip((vm.PageSize * (vm.CurrentPage - 1))).Take(vm.PageSize).ToList();
                foreach (var item in list)
                {
                    GetProductList().Add(item);
                }
            }
        }
        /// <summary>
        /// 在线产品集合
        /// </summary>
        private static AsyncObservableCollection<OnlineProduct> onlineProductList;

        public static AsyncObservableCollection<OnlineProduct> GetOnlineProducts()
        {
            if (onlineProductList == null)
            {
                onlineProductList = new AsyncObservableCollection<OnlineProduct>();
            }
            return onlineProductList;
        }
        public static void LoadOnlineProductList(PagingViewModel vm)
        {
            GetOnlineProducts().Clear();
            SelectedProductNumberList.Clear();

        }
        /// <summary>
        /// 设置当前已经选中的产品
        /// </summary>
        /// <param name="siteId"></param>
        /// <param name="number"></param>
        public static void SetCurrentProduct(long siteId, long number)
        {
            _selectedProduct = GetProductList().Where(p => p.SiteID == siteId && p.Number == number).FirstOrDefault();
        }

        /// <summary>
        /// 获取当前选中的产品
        /// </summary>
        /// <returns></returns>
        public static Product GetCurrentProduct()
        {
            return _selectedProduct;
        }

        /// <summary>
        /// 更新当前选择的标签页
        /// </summary>
        /// <param name="tab"></param>
        public static void UpdateSelectedTab(CurrentSelectedTab tab)
        {
            _selectedTab = tab;
        }

        /// <summary>
        /// 获取当前选择的标签页
        /// </summary>
        /// <returns></returns>
        public static CurrentSelectedTab GetSelectedTab()
        {
            return _selectedTab;
        }

    }

    /// <summary>
    /// 任务栏标签页
    /// </summary>
    public enum CurrentSelectedTab
    {
        ShowSKU,
        EditSpu,
        EditDetail,
        EditImages,
        AttachSKU,
    }
}
