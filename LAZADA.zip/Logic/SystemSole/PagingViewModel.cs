﻿
using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;

namespace Logic.SystemSole
{
    public class PagingViewModel : BaseViewModel
    {

        //当前页
        private int currentPage = 1;
        //每页多少条
        private int pageSize = 20;
        //总共多少条
        private int countNumber = 0;

        private string inputNumber = "";

        public Action QueryAction { get; set; }


        /// <summary>
        /// 当前第几页
        /// </summary>
        public int CurrentPage
        {
            get => currentPage;
            set
            {
                if (currentPage != value)
                {
                    currentPage = value;
                    base.RaisePropertyChanged("CurrentPage");
                    base.RaisePropertyChanged("BtnFirstEnable");
                    base.RaisePropertyChanged("BtnPrevEnable");
                    base.RaisePropertyChanged("BtnNextEnable");
                    base.RaisePropertyChanged("BtnLastEnable");
                    base.RaisePropertyChanged("CurrentNumber");
                }
            }
        }

        /// <summary>
        /// 每页多少条
        /// </summary>
        public int PageSize
        {
            get => pageSize;
            set
            {
                if (pageSize != value)
                {
                    pageSize = value;
                    base.RaisePropertyChanged("PageSize");
                }
            }
        }

        /// <summary>
        /// 共T条
        /// </summary>
        public int CountNumber
        {
            get => countNumber;
            set
            {
                if (countNumber != value)
                {
                    countNumber = value;
                    base.RaisePropertyChanged("CountNumber");
                    base.RaisePropertyChanged("PageCount");
                    base.RaisePropertyChanged("BtnFirstEnable");
                    base.RaisePropertyChanged("BtnPrevEnable");
                    base.RaisePropertyChanged("BtnNextEnable");
                    base.RaisePropertyChanged("BtnLastEnable");
                    base.RaisePropertyChanged("CurrentNumber");
                }
            }
        }

        public string InputNumber
        {
            get => inputNumber;
            set
            {
                if (inputNumber != value)
                {
                    int num = 0;
                    try
                    {
                        num = Convert.ToInt32(value);
                    }
                    catch
                    {
                        inputNumber = "";
                        base.RaisePropertyChanged("InputNumber");
                        return;
                    }
                    if (num <= 0)
                    {
                        inputNumber = "";
                        base.RaisePropertyChanged("InputNumber");
                        return;
                    }
                    if (num > PageCount)
                    {
                        inputNumber = PageCount.ToString();
                        base.RaisePropertyChanged("InputNumber");
                        return;
                    }
                    inputNumber = value;
                    base.RaisePropertyChanged("InputNumber");
                }
            }
        }

        /// <summary>
        /// 共多少页
        /// </summary>
        public int PageCount
        {
            get
            {
                var rs = (countNumber / pageSize) + (countNumber % pageSize == 0 ? 0 : 1);
                return rs == 0 ? 1 : rs;
            }

        }

        /// <summary>
        /// 当前n-m条
        /// </summary>
        public string CurrentNumber
        {
            get
            {
                int count = CurrentPage * PageSize > CountNumber ? CountNumber : CurrentPage * PageSize;
                return countNumber == 0 ? "0" : $"{1 + (CurrentPage - 1) * PageSize}-{count}";
            }
        }


        public bool BtnFirstEnable
        {
            get
            {
                if (CurrentPage == 1)
                    return false;
                return true;
            }
        }
        public bool BtnPrevEnable
        {
            get
            {
                if (CurrentPage == 1)
                    return false;
                return true;
            }
        }
        public bool BtnNextEnable
        {
            get
            {
                if (CurrentPage == PageCount)
                    return false;
                return true;
            }
        }

        public bool BtnLastEnable
        {
            get
            {
                if (CurrentPage == PageCount)
                    return false;
                return true;
            }
        }

        RelayCommand toFirstCommand;

        RelayCommand toPrevCommand;

        RelayCommand toNextCommand;

        RelayCommand toLastCommand;

        RelayCommand toSearchCommand;

        public ICommand ToFirstCommand
        {
            get
            {
                if (toFirstCommand == null)
                {
                    toFirstCommand = new RelayCommand(

                        param =>
                        {
                            CurrentPage = 1;
                            //DoSearch();
                            QueryAction.Invoke();
                        });
                }
                return toFirstCommand;
            }
        }
        public ICommand ToPrevCommand
        {
            get
            {
                if (toPrevCommand == null)
                {
                    toPrevCommand = new RelayCommand(

                        param =>
                        {
                            if (CurrentPage > 1)
                                CurrentPage -= 1;
                            //DoSearch();
                            QueryAction.Invoke();
                        });
                }
                return toPrevCommand;
            }
        }
        public ICommand ToNextCommand
        {
            get
            {
                if (toNextCommand == null)
                {
                    toNextCommand = new RelayCommand(

                        param =>
                        {
                            if (CurrentPage < PageCount)
                                CurrentPage += 1;
                            //DoSearch();
                            QueryAction.Invoke();
                        });
                }
                return toNextCommand;
            }
        }
        public ICommand ToLastCommand
        {
            get
            {
                if (toLastCommand == null)
                {
                    toLastCommand = new RelayCommand(

                        param =>
                        {
                            CurrentPage = PageCount;
                            //DoSearch();
                            QueryAction.Invoke();
                        });
                }
                return toLastCommand;
            }
        }

        //protected virtual void DoSearch()
        //{
        //    SystemSoleEntity.LoadProductList(this);
        //}

        public ICommand ToSearchCommand
        {
            get
            {
                if (toSearchCommand == null)
                {
                    toSearchCommand = new RelayCommand(

                        param =>
                        {
                            if (InputNumber != string.Empty)
                                CurrentPage = Convert.ToInt32(InputNumber);
                            //DoSearch();
                            QueryAction.Invoke();
                        });
                }
                return toSearchCommand;
            }
        }

    }
}
