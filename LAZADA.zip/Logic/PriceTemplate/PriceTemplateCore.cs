﻿using LAZADA;
using PublicFunction.Entity.DBEntity;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Logic.PriceTemplate
{
    /// <summary>
    /// 计价模板业务操作类
    /// </summary>
    public class PriceTemplateCore
    {
        /// <summary>
        /// 获取当前所有计价模板
        /// </summary>
        /// <returns></returns>
        public List<PriceTemplateEntity> GetPriceTemplateList()
        {
            string sql = @"Select jnumber,jname,SiteID,jprfix,jkuchen,jpkghight,jpkgwidth,jpkglength,
                            jMSRPtype,jMSRPjiajabi,jMSRPjiajashou,jliyunbi,jyunfeigs,jjiagegs,jrate,jhometran
                            from PriceFormula where SiteID=@SiteID";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
            };
            List<PriceTemplateEntity> list = new SQLiteHelp().GetList<PriceTemplateEntity>(sql, paramList);
            return list;
        }

        /// <summary>
        /// 获取当前所有计价模板
        /// </summary>
        /// <returns></returns>
        public List<PriceTemplateEntity> GetAllPriceTemplateList()
        {
            string sql = @"Select jnumber,jname,SiteID,jprfix,jkuchen,jpkghight,jpkgwidth,jpkglength,
                            jMSRPtype,jMSRPjiajabi,jMSRPjiajashou,jliyunbi,jyunfeigs,jjiagegs,jrate,jhometran
                            from PriceFormula ";
            List<PriceTemplateEntity> list = new SQLiteHelp().GetList<PriceTemplateEntity>(sql);
            return list;
        }

        /// <summary>
        /// 根据计价模板的名称，获取计价模板
        /// </summary>
        /// <param name="jname"></param>
        /// <returns></returns>
        public PriceTemplateEntity GetPriceTemplate(string jname)
        {
            string sql = @"Select jnumber,jname,SiteID,jprfix,jkuchen,jpkghight,jpkgwidth,jpkglength,
                            jMSRPtype,jMSRPjiajabi,jMSRPjiajashou,jliyunbi,jyunfeigs,jjiagegs,jrate,jhometran
                            from PriceFormula where jname=@jname and SiteID=@SiteID";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@jname",jname),
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
            };
            List<PriceTemplateEntity> priceTemplateEntities = new SQLiteHelp().GetList<PriceTemplateEntity>(sql, paramList);
            PriceTemplateEntity entity = new PriceTemplateEntity();
            if (priceTemplateEntities.Count() == 0)
            {
                priceTemplateEntities = new SQLiteHelp().GetList<PriceTemplateEntity>(sql, paramList);

                if (priceTemplateEntities.Count() == 0)
                {
                    return GetPriceTemplate(jname);

                }
                else
                    entity = priceTemplateEntities.First();
            }
            else
                entity = priceTemplateEntities.First();
            return entity;
        }


        /// <summary>
        /// 检查模板名称是否已经存在
        /// </summary>
        /// <param name="newName"></param>
        /// <returns></returns>
        public bool CheckNewName(string newName)
        {
            string sql = @"select count(*) from PriceFormula 
                                            where SiteID=@SiteID and jname=@newName";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                 new SQLiteParameter("@newName",newName),
            };
            return new SQLiteHelp().ExecuteScalar<long>(sql, paramList) == 1;
        }


        /// <summary>
        /// 新增计价模板
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public bool InsertNewTemplate(PriceTemplateEntity entity)
        {
            string sql = @"INSERT INTO PriceFormula(SiteID,jname,jprfix,jkuchen,jpkghight,jpkgwidth,jpkglength,jMSRPtype,jMSRPjiajabi,jMSRPjiajashou,jliyunbi,jyunfeigs,jjiagegs,jrate,jhometran)
                                       Values(@SiteID,@Jname,@Jprfix,@Jkuchen,@Jpkghight,@Jpkgwidth,@Jpkglength,@JMSRPtype,@JMSRPjiajabi,@JMSRPjiajashou,@Jliyunbi,@Jyunfeigs,@Jjiagegs,@jrate,@jhometran)";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                 new SQLiteParameter("@Jname",entity.Jname),
                 new SQLiteParameter("@Jprfix",entity.Jprfix),
                 new SQLiteParameter("@Jkuchen",entity.Jkuchen),
                 new SQLiteParameter("@Jpkghight",entity.Jpkghight),
                 new SQLiteParameter("@Jpkgwidth",entity.Jpkgwidth),
                 new SQLiteParameter("@Jpkglength",entity.Jpkglength),
                 new SQLiteParameter("@JMSRPtype",entity.JMSRPtype),
                 new SQLiteParameter("@JMSRPjiajabi",entity.JMSRPjiajabi),
                 new SQLiteParameter("@JMSRPjiajashou",entity.JMSRPjiajashou),
                 new SQLiteParameter("@Jliyunbi",entity.Jliyunbi),
                 new SQLiteParameter("@Jyunfeigs",entity.Jyunfeigs),
                 new SQLiteParameter("@Jjiagegs",entity.Jjiagegs),
                 new SQLiteParameter("@jrate",entity.Jrate),
                 new SQLiteParameter("@jhometran",entity.Jhometran),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }


        /// <summary>
        /// 更新计价模板
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public bool UpdateTemplate(PriceTemplateEntity entity)
        {
            string sql = @"Update PriceFormula set 
                                        Jprfix=@Jprfix,
                                        Jkuchen=@Jkuchen,
                                        Jpkghight=@Jpkghight,
                                        Jpkgwidth=@Jpkgwidth,
                                        Jpkglength=@Jpkglength,
                                        JMSRPtype=@JMSRPtype,
                                        JMSRPjiajabi=@JMSRPjiajabi,
                                        JMSRPjiajashou=@JMSRPjiajashou,
                                        Jliyunbi=@Jliyunbi,
                                        Jyunfeigs=@Jyunfeigs,
                                        Jjiagegs=@Jjiagegs,
                                        jrate=@jrate,
                                        jhometran=@jhometran


                                        WHERE SiteID=@SiteID and Jname=@Jname";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                 new SQLiteParameter("@Jname",entity.Jname),
                 new SQLiteParameter("@Jprfix",entity.Jprfix),
                 new SQLiteParameter("@Jkuchen",entity.Jkuchen),
                 new SQLiteParameter("@Jpkghight",entity.Jpkghight),
                 new SQLiteParameter("@Jpkgwidth",entity.Jpkgwidth),
                 new SQLiteParameter("@Jpkglength",entity.Jpkglength),
                 new SQLiteParameter("@JMSRPtype",entity.JMSRPtype),
                 new SQLiteParameter("@JMSRPjiajabi",entity.JMSRPjiajabi),
                 new SQLiteParameter("@JMSRPjiajashou",entity.JMSRPjiajashou),
                 new SQLiteParameter("@Jliyunbi",entity.Jliyunbi),
                 new SQLiteParameter("@Jyunfeigs",entity.Jyunfeigs),
                 new SQLiteParameter("@Jjiagegs",entity.Jjiagegs),
                 new SQLiteParameter("@jrate",entity.Jrate),
                 new SQLiteParameter("@jhometran",entity.Jhometran),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }


        public bool DeleteTemplate(string templateName)
        {
            string sql = @"Delete FROM PriceFormula 
                                        WHERE SiteID=@SiteID and Jname=@Jname";
            SQLiteParameter[] paramList = new SQLiteParameter[] {
                 new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                 new SQLiteParameter("@Jname",templateName),
            };
            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) == 1;
        }


        /// <summary>
        /// 计算产品和计价模板相关的费用
        /// </summary>
        /// <param name="priceTemplate">计价模板对象</param>
        /// <param name="product">产品对象</param>
        /// <param name="oriPrice">成本价</param>
        public void CalcProductCost(PriceTemplateEntity priceTemplate, Product product, double oriPrice)
        {
            var shipFeeStr = CalcInternationalCost(priceTemplate.Jyunfeigs, product.Lazadapackageweight);
            var priceStr = default(double);
            if (shipFeeStr > 0 || GlobalUserClass.SiteId == 9)
            {
                priceStr = CalcDiscount(priceTemplate.Jjiagegs, product.Porigprice, shipFeeStr.ToString("#.#"), priceTemplate.Jhometran, priceTemplate.Jrate, priceTemplate.Jliyunbi, product.Lazadapackageweight);
            }
            if (priceStr > 0)
            {
                var rate = 1d;
                try
                {
                    rate = Convert.ToDouble(priceTemplate.Jrate);
                    if (rate == 0)
                        rate = 1;
                }
                catch
                {
                    rate = 1;
                }
                product.Lazadapromprice = priceStr.ToString("#");
                if (GlobalUserClass.SiteId == 9)
                    product.Pprofit = (oriPrice * Convert.ToDouble(priceTemplate.Jliyunbi)).ToString("#");
                else
                    product.Pprofit = (priceStr * Convert.ToDouble(priceTemplate.Jliyunbi) / rate).ToString("#");
                var t = priceTemplate.JMSRPtype;
                if (priceTemplate.JMSRPtype == "1")  //算原价时，用乘还是加 1是加 2是乘
                {
                    product.Lazadaprice = (Convert.ToDouble(priceTemplate.JMSRPjiajashou) + Convert.ToDouble(product.Lazadapromprice)).ToString("#");
                }
                else
                {
                    product.Lazadaprice = (Convert.ToDouble(priceTemplate.JMSRPjiajabi) * Convert.ToDouble(product.Lazadapromprice)).ToString("#");
                }
            }
        }




        /// <summary>
        /// 计算产品和计价模板相关的费用
        /// </summary>
        /// <param name="priceTemplate">计价模板对象</param>
        /// <param name="product">产品对象</param>
        /// <param name="oriPrice">成本价</param>
        public string[] CalcProductCost(PriceTemplateEntity priceTemplate, string _weight, string price, double oriPrice)
        {
            string[] strs = new string[] { "", "", "" };
            var shipFeeStr = CalcInternationalCost(priceTemplate.Jyunfeigs, _weight);
            var priceStr = default(double);
            if (shipFeeStr > 0 || GlobalUserClass.SiteId == 9)
            {
                priceStr = CalcDiscount(priceTemplate.Jjiagegs, price, shipFeeStr.ToString("#.#"), priceTemplate.Jhometran, priceTemplate.Jrate, priceTemplate.Jliyunbi, _weight);
            }
            if (priceStr > 0)
            {
                var rate = 1d;
                try
                {
                    rate = Convert.ToDouble(priceTemplate.Jrate);
                    if (rate == 0)
                        rate = 1;
                }
                catch
                {
                    rate = 1;
                }
                strs[0] = priceStr.ToString("#");
                if (GlobalUserClass.SiteId == 9)
                    strs[1] = (oriPrice * Convert.ToDouble(priceTemplate.Jliyunbi)).ToString("#");
                else
                    strs[1] = (priceStr * Convert.ToDouble(priceTemplate.Jliyunbi) / rate).ToString("#");
                //product.Lazadapromprice = priceStr.ToString("#.##");

                //product.Pprofit = (oriPrice * Convert.ToDouble(priceTemplate.Jliyunbi)).ToString("#");
                if (priceTemplate.JMSRPtype == "1")  //算原价时，用乘还是加
                {
                    //product.Lazadaprice = (Convert.ToDouble(priceTemplate.JMSRPjiajashou) + priceStr).ToString("#");
                    strs[2] = (Convert.ToDouble(priceTemplate.JMSRPjiajashou) + Convert.ToDouble(strs[0])).ToString("#");

                }
                else
                {
                    //product.Lazadaprice = (Convert.ToDouble(priceTemplate.JMSRPjiajabi) * priceStr).ToString("#");
                    strs[2] = (Convert.ToDouble(priceTemplate.JMSRPjiajabi) * Convert.ToDouble(strs[0])).ToString("#");
                }
            }
            return strs;
        }



        /// <summary>
        /// 计算国际运费的
        /// </summary>
        /// <returns></returns>
        public Double CalcInternationalCost(string _express, string _weight)
        {
            double wt = -1;

            if (Double.TryParse(_weight, out wt))
            {
                try
                {
                    _express = _express.Replace(" ", "").Replace("，", ",").Replace("（", "(").Replace("）", ")");
                    if (_express == "") return 0;

                    Regex regex0 = new Regex(@"\{(?<lowp>\d.*?),(?<highp>\d.*?)\}\{(?<onegs>.+?)\}", RegexOptions.Compiled);
                    string[] conditions = _express.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string str in conditions)
                    {
                        Match matchS = regex0.Match(str);
                        if (matchS.Success)
                        {
                            double lp = -1;
                            double hp = -1;

                            if (Double.TryParse(matchS.Groups["lowp"].Value.Trim(), out lp) && Double.TryParse(matchS.Groups["highp"].Value.Trim(), out hp))
                            {
                                if (wt >= lp && wt < hp)
                                {
                                    return CalcDiscount(matchS.Groups["onegs"].Value.Trim(), "0", "0", "1", "1", "0", _weight);
                                }

                            }


                        }

                    }


                }
                catch
                {

                    return 0;
                }
            }

            return 0;
        }

        /// <summary>
        /// 计算折扣价的
        /// </summary>
        /// <param name="_express">计价公式</param>
        /// <param name="_jinhoujia">采购成本</param>
        /// <param name="_goujiyufei">国际运费</param>
        /// <param name="_guoneiyufei">国内运费</param>
        /// <param name="_huilv">汇率</param>
        /// <param name="_liyunli">利润率</param>
        /// <param name="_weight">包裹重量</param>
        /// <returns></returns>
        public Double CalcDiscount(string _express, string _jinhoujia, string _goujiyufei, string _guoneiyufei, string _huilv, string _liyunli, string _weight)
        {
            try
            {
                var tt = _express;
                _express = _express.Replace(" ", "").Replace(",", "").Replace("（", "(").Replace("）", ")");
                if (_express == "") return 0;

                Regex regex0 = new Regex(@"[^0-9\.\*\+\(\)-/\u91c7\u8d2d\u6210\u672c\u56fd\u9645\u8fd0\u8d39\u5229\u6da6\u7387\u91cd\u91cf]+");
                //_express = regex0.Replace(_express, "").Replace("国运费", "国内运费");
                //"([采购成本]+[国际运费])/1.55/(1-0.15-[利润率])";
                //  _textbox.Text = _express.Replace("进货价", "[进货价]").Replace("利润", "[利润]").Replace("重量", "[重量]");
                _express = _express.Replace("重量", _weight).Replace("采购成本", _jinhoujia).Replace("国际运费", _goujiyufei).Replace("国内运费", _guoneiyufei).Replace("利润率", _liyunli).Replace("汇率", _huilv);
                var t = _express;
                Regex regex = new Regex(@"[^0-9\.\*\+\(\)-/]+");
                _express = regex.Replace(_express, "");

                MSScriptControl.ScriptControl sc = new MSScriptControl.ScriptControlClass();
                sc.Language = "JavaScript";
                return Convert.ToDouble(sc.Eval(_express).ToString());//"((2*3)-5+(3*4))+6/2"
            }
            catch
            {

                return 0;
            }
        }



    }
}
