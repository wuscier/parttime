﻿using LAZADA;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.ControlHelp;
using PublicFunction.Entity;
using PublicFunction.Entity.RequestModel;
using PublicFunction.Entity.ResponseModel;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;
using TextBox = System.Windows.Controls.TextBox;

namespace Logic.Login
{
    public class UserLoginCore
    {
        ControlCheckHelp cch = new ControlCheckHelp();
        WebClient wc = null;
        public static int bolVersion = 0;
        System.Windows.Forms.Control control = new System.Windows.Forms.Control();
        string NewZipFileName = "version.json";

        /// <summary>
        /// 登录认证
        /// </summary>
        /// <param name="txtLoginName"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        public string Token_Req(string txtLoginName, string pwd)
        {
            HttpResponseMessage response = null;
            try
            {
                new LogOutput.LogTo().WriteLine("1");
                var list = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("client_id","fengniao-client"),
                        new KeyValuePair<string, string>("username",txtLoginName),
                        new KeyValuePair<string, string>("password",pwd),
                        new KeyValuePair<string, string>("grant_type","password")
                    };
                new LogOutput.LogTo().WriteLine(list.ToString());
                using (HttpClient httpClient = new HttpClient())
                {
                    //specify to use TLS 1.2 as default connection
                    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    httpClient.Timeout = TimeSpan.FromSeconds(5);
                    var result = new HttpRequestMessage(HttpMethod.Post, Constants.GETLINK_LOGINURLNew) { Content = new FormUrlEncodedContent(list) };
                    new LogOutput.LogTo().WriteLine(result.ToString());
                    response = httpClient.SendAsync(result).Result;
                    new LogOutput.LogTo().WriteLine(Convert.ToInt32(response.StatusCode).ToString());
                    var str = response.Content.ReadAsStringAsync().Result;
                    new LogOutput.LogTo().WriteLine(str);
                    var jsondata = (JObject)JsonConvert.DeserializeObject(str);
                    new LogOutput.LogTo().WriteLine(jsondata.ToString());
                    //获取状态码
                    GlobalUserClass.StatusCode = Convert.ToInt32(response.StatusCode);
                    if (jsondata["error_description"] != null)
                    {
                        GlobalUserClass.Error_Description = jsondata["error_description"].ToString();
                    }
                    else
                    {
                        GlobalUserClass.Error_Description = null;
                    }
                    return jsondata.ToString();
                }
            }
            catch (Exception ex)
            {
                if(response!=null)
                    new LogOutput.LogTo().WriteLine(Convert.ToInt32(response.StatusCode).ToString());
                else
                    new LogOutput.LogTo().WriteLine("response is null");

                new LogOutput.LogTo().WriteLine("Stack" + ex.StackTrace);
                new LogOutput.LogTo().WriteLine("Source" + ex.Source);
                new LogOutput.LogTo().WriteLine("Message" + ex.Message);
                return ex.Message;
            }
        }

        /// <summary>
        /// 登录认证
        /// </summary>
        /// <param name="txtLoginName"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        public string Token_HW(string txtLoginName, string pwd)
        {
            try
            {
                var list = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("client_id","aliyun"),
                        new KeyValuePair<string, string>("username",txtLoginName),
                        new KeyValuePair<string, string>("password",pwd),
                        new KeyValuePair<string, string>("grant_type","password")
                    };
                using (HttpClient httpClient = new HttpClient())
                {
                    //specify to use TLS 1.2 as default connection
                    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    httpClient.Timeout = TimeSpan.FromSeconds(5);
                    var result = new HttpRequestMessage(HttpMethod.Post, Constants.GETLINK_LOGINURLNew) { Content = new FormUrlEncodedContent(list) };
                    HttpResponseMessage response = httpClient.SendAsync(result).Result;
                    var str = response.Content.ReadAsStringAsync().Result;
                    new LogOutput.LogTo().WriteLine(str);
                    var jsondata = (JObject)JsonConvert.DeserializeObject(str);
                    //获取状态码


                    return jsondata["access_token"].ToString();
                }
            }
            catch (Exception ex)
            {

                return ex.Message;
            }
        }

        #region 检查版本

        // <summary>
        /// 下载更新
        /// </summary>

        public int checkVersion()
        {
            try
            {

                if (!Directory.Exists(Application.StartupPath + "\\Version\\newVersion\\"))
                {
                    Directory.CreateDirectory(Application.StartupPath + "\\Version\\newVersion\\");
                }



                wc = new WebClient();
                //wc.DownloadProgressChanged += new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged);
                //wc.DownloadFileCompleted += new AsyncCompletedEventHandler(wc_DownloadFileCompleted);
                wc.DownloadFile(new Uri("http://updatefn.oss-cn-shanghai.aliyuncs.com/lazadaupdate/version.json"), Application.StartupPath + "\\Version\\newVersion\\" + NewZipFileName);
                Thread.Sleep(1000);


            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.Message);
            }
            return wc_DownloadFileCompleted();
        }

        /// <summary>
        /// 下载完成后触发
        /// </summary>

        public int wc_DownloadFileCompleted()
        {
            try
            {
                string a = "";
                string jsonfile = Application.StartupPath + "\\Version\\newVersion\\" + NewZipFileName;
                using (System.IO.StreamReader file = new StreamReader(jsonfile, Encoding.Default))
                {
                    using (JsonTextReader reader = new JsonTextReader(file))
                    {
                        JObject o = (JObject)JToken.ReadFrom(reader);
                        a = o["content"].ToString();

                        //var b = o["other"];
                        //var c = b["lotaddress"];
                        //var d = o["devices"];
                        //foreach (JObject s in d)
                        //{
                        //    var deviceID = s[0];
                        //    var name = s["name"];
                        //    var IP = s["IP"];
                        //}
                    }
                }
                string jsonfile1 = Application.StartupPath + "\\Version\\" + NewZipFileName;
                using (System.IO.StreamReader file = new StreamReader(jsonfile1, Encoding.Default))
                {
                    using (JsonTextReader reader = new JsonTextReader(file))
                    {
                        JObject o = (JObject)JToken.ReadFrom(reader);
                        string b = o["content"].ToString();
                        Constants.VERSIONNUMBER = o["version"].ToString().ToUpper();
                        if (a == b)
                        {
                            bolVersion = 1;
                        }
                        else
                            bolVersion = -1;
                    }
                }

            }
            catch
            { }
            return bolVersion;
        }


        ///// <summary>
        ///// 下载时触发
        ///// </summary>

        //void wc_DownloadProgressChanged()
        //{
        //    if (control.InvokeRequired)
        //    {

        //        control.Invoke(new DownloadProgressChangedEventHandler(wc_DownloadProgressChanged), new object[] { });

        //    }

        //    else
        //    {
        //        // currBytes = e.BytesReceived;//当前下载流量
        //    }
        //}


        #endregion

        /// <summary>
        /// 获取个人信息
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public string GetProfile(string token)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                //specify to use TLS 1.2 as default connection
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
                var pro = new HttpRequestMessage(HttpMethod.Get, Constants.GETPROFILEURL);
                HttpResponseMessage response = httpClient.SendAsync(pro).Result;
                var msg = response.Content.ReadAsStringAsync().Result;
                return msg.ToString();
            }
        }


        /// <summary>
        /// 记住账号密码
        /// </summary>
        /// <param name="name"></param>
        /// <param name="pwd"></param>
        public static void LoginData(string name, string pwd)
        {
            JObject jsondata = new JObject();
            jsondata["uname"] = name;
            jsondata["uepwd"] = pwd;
            FileStream fst3 = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\userinfo.act", FileMode.OpenOrCreate);
            StreamWriter sw3 = new StreamWriter(fst3, System.Text.Encoding.Default);
            //清空后再写
            fst3.Seek(0, SeekOrigin.Begin);
            fst3.SetLength(0); //清空txt文件
            string initdataStr3 = "{\"uname\": \"" + jsondata["uname"] + "\", \"uepwd\": \"" + jsondata["uepwd"] + "\", \"uharddiskid\": \"" + Constants.HARD_DISKID + "\"}";
            sw3.Write(EncryptionWay.Encrypt(initdataStr3, Constants.GETLINK_LOGIN_ENCRYPT));
            sw3.Flush();
            sw3.Close();
            fst3.Close();
        }
        /// <summary>
        /// 保存登录错误次数
        /// </summary>
        /// <param name="count"></param>
        public static void SaveLoginCount(int count)
        {
            JObject jbdata = new JObject();
            jbdata["count"] = count;
            FileStream file = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\loginCount.act", FileMode.OpenOrCreate);
            StreamWriter stream = new StreamWriter(file, System.Text.Encoding.Default);
            file.Seek(0, SeekOrigin.Begin);
            file.SetLength(0);
            string CountData = "{\"count\":\"" + jbdata["count"] + "\"}";
            stream.Write(EncryptionWay.Encrypt(CountData, Constants.GETLINK_LOGIN_ENCRYPT));
            stream.Flush();
            stream.Close();
            file.Close();
        }
        /// <summary>
        /// 检查非空
        /// </summary>
        /// <param name="textBox"></param>
        /// <param name="pwd"></param>
        /// <returns></returns>
        public bool CheckTextBox(TextBox textBox, PasswordBox pwd)
        {
            if (cch.CheckControlIsEmpty(textBox, pwd))
            {
                return false;
            }
            return true;
        }
        /// <summary>
        /// 刷新token
        /// </summary>
        /// <param name="refresh_token"></param>
        /// <returns></returns>
        public string Refreshtoken(string refresh_token)
        {
            var list = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("client_id","fengniao-client"),
                         new KeyValuePair<string, string>("grant_type","refresh_token"),
                        new KeyValuePair<string, string>("refresh_token",refresh_token)
                    };
            using (HttpClient httpClient = new HttpClient())
            {
                //specify to use TLS 1.2 as default connection
                System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                var result = new HttpRequestMessage(HttpMethod.Post, Constants.GETLINK_LOGINURLNew) { Content = new FormUrlEncodedContent(list) };
                HttpResponseMessage response = httpClient.SendAsync(result).Result;
                var str = response.Content.ReadAsStringAsync().Result;
                var jsondata = (JObject)JsonConvert.DeserializeObject(str);
                //获取状态码
                GlobalUserClass.StatusCode = Convert.ToInt32(response.StatusCode);
                return jsondata["access_token"].ToString();
            }
        }

        //阿里云账号创建获取
        public static string ALY_FWQ(string UserName, string ID, string Secret, string strId = "")
        {
            try
            {
                JObject _jsondata = new JObject();
                //var x2teaTime = new Xxtea("XCJ9JmI9LsxSAPYzYWhiemhHBmddpjaGFv");
                string timestamp1 = DateTime.Now.GetDateTimeFormats('r')[0].ToString() + UserName;
                string timestamp2 = EncryptionWay.Encrypt(timestamp1, EncryptionWay.MD5Encrypt(GlobalUserClass.uepwd));

                _jsondata["UserName"] = UserName;
                if (ID != "")
                {
                    _jsondata["AppKey"] = ID;
                    _jsondata["AppSecret"] = Secret;
                    if (strId != "")
                        _jsondata["Id"] = strId;

                }

                string EncrytDataContent = EncryptionWay.Encrypt(JsonConvert.SerializeObject(_jsondata), "EyNjE1LjIxNzc3MDEuMC4wLnlZUXFDZX0mbT");

                string dzb = "{'arg1':'" + timestamp1 + "','arg2':'" + timestamp2 + "','arg3':'" + EncrytDataContent + "'}";

                byte[] postContentBytes = Encoding.UTF8.GetBytes(dzb);

                // 创建request对象
                // HttpWebRequest webrequest = (HttpWebRequest)WebRequest.Create(MainWindow.serverUrl + "BukClientLogin");  
                HttpWebRequest webrequest;
                if (ID == "")
                    webrequest = (HttpWebRequest)WebRequest.Create(Constants.GETLINK_LOGINURL + "GetAliyunTrans");
                else
                    webrequest = (HttpWebRequest)WebRequest.Create(Constants.GETLINK_LOGINURL + "UpdateAliyunTrans");
                webrequest.UserAgent = "User-Agent:Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705";
                webrequest.ContentType = "application/json; charset=utf-8";
                webrequest.Timeout = 30000;//设置超时为0.5分钟
                webrequest.Method = "POST";
                webrequest.KeepAlive = true;
                webrequest.ContentLength = postContentBytes.Length;

                Stream requestStream = webrequest.GetRequestStream();
                requestStream.Write(postContentBytes, 0, postContentBytes.Length);
                requestStream.Close();



                WebResponse response = webrequest.GetResponse();
                Stream sp = response.GetResponseStream();
                StreamReader sr = new StreamReader(sp, Encoding.UTF8);

                string ret = sr.ReadToEnd();
                sr.Close();
                sp.Close();
                response.Close();

                //  MessageBox.Show(ret);
                return ret;
            }
            catch (Exception es)
            {
                // return "{\"d\":\"{\"rcode\":\"netErrow\",\"msg\":\"netErrow\"}\"}";
                return es.Message;
            }
        }

        /// <summary>
        /// 判断长度
        /// </summary>
        /// <param name="txtLoginName"></param>
        /// <returns></returns>
        public bool CheckTextBoxLength(TextBox txtLoginName, int Minlength, int Maxlength)
        {
            if (cch.CheckLength(txtLoginName, Minlength, Maxlength))
            {
                return false;
            }
            return true;
        }
        public bool CheckPasswordLength(PasswordBox pwd, int Minlength, int Maxlength)
        {
            if (cch.CheckPwdLength(pwd, Minlength, Maxlength))
            {
                return false;
            }
            return true;
        }

        public JObject DoUserLogin(string name, string pwd)
        {
            var list = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("client_id","fengniao-client"),
                         new KeyValuePair<string, string>("username",name),
                         new KeyValuePair<string, string>("password",pwd),
                        new KeyValuePair<string, string>("grant_type","password")
                    };
            MyHttpClient client = new MyHttpClient();
            //specify to use TLS 1.2 as default connection
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            var json = client.AsyncPostWithFormEncoded(Constants.GETLINK_LOGINURLNew, list);
            return json;
        }
    }
}
