﻿using Aliyun.Acs.alimt.Model.V20181012;
using Aliyun.Acs.Core;
using Aliyun.Acs.Core.Http;
using Aliyun.Acs.Core.Profile;
using PublicFunction;
using PublicFunction.ConfigHelp;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.Translation
{
    /// <summary>
    /// 阿里翻译业务类
    /// </summary>
    public class ALiCore
    {
        public string ChangeZhToEn(string content)
        {
            return Translation(content, "zh", "en");
        }
        public string ChangeZhToSiteDefaultLangauge(string content, string strScene = "title")
        {
            return Translation(content, "zh", new SiteChangeHelp().GetToLanguage(), strScene);
        }
        public string ChangeSiteDefaultLangaugeToZh(string content)
        {
            var lan = new SiteChangeHelp().GetToLanguage();
            if (lan != "en")
            {
                var str = Translation(content, lan, "en");
                return ChangeEnToZh(str);
            }
            else
                return Translation(content, new SiteChangeHelp().GetToLanguage(), "zh");
        }

        public string ChangeEnToZh(string content)
        {
            return Translation(content, "en", "zh");
        }

        private string Translation(string content, string sourceLangauge, string targetLangauge, string strScene = "offer")
        {
            var response = new HaiWangRequestClient().GetTranslateResponse(content, sourceLangauge, targetLangauge, strScene);
            if (response == null) return "";
            if (response.IsError) return "";
            return response.Result;
            //if (content.Trim() == string.Empty) return "";
            //string result = "";
            //IClientProfile profile = DefaultProfile.GetProfile(
            //   "cn-hangzhou",
            //   Constants.ACCESSKEYID,
            //   Constants.ACCESSKEYSECRET);
            //DefaultAcsClient client = new DefaultAcsClient(profile);
            //try
            //{
            //    // 构造请求

            //    // 构造请求
            //    TranslateECommerceRequest request = new TranslateECommerceRequest();
            //    request.Scene = "description";
            //    request.Method = MethodType.POST; //设置请求
            //    request.FormatType = "text"; //翻译文本的格式  c
            //    request.SourceText = content; //原文  
            //    request.SourceLanguage = sourceLangauge; //源语言  
            //    request.TargetLanguage = targetLangauge; //目标语言  
            //                                             // 发起请求，并得到 Response
            //    TranslateECommerceResponse response = client.GetAcsResponse(request);
            //    result = response.Data.Translated;
            //}
            //catch (Exception ex)
            //{
            //    new LogOutput.LogTo().WriteErrorLine(ex.Message);
            //}
            //return result;
        }
    }
}
