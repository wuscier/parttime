﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Logic.Translation
{
    /// <summary>
    /// 百度翻译业务类
    /// </summary>
    public class BaiDuCore
    {
        /// <summary>
        /// 标题中译英
        /// </summary>
        /// <param name="oldTitle">中文标题</param>
        /// <returns></returns>
        public string TransTitle_ChineseToEnglish(string oldTitle)
        {
            if (oldTitle.Trim() == string.Empty) return "";
            try
            {
                string enTitle = "";
                string rp = @"[0-9a-zA-Z\s]+";
                string newtitle = new Regex(rp).Replace(oldTitle.Trim(), "\r\n$&\r\n");
                enTitle = oldTitle.Trim();
                if (String.IsNullOrEmpty(enTitle)) return "";
                enTitle = upFirstCharWithSpace(enTitle).Replace("\r\n", " ").Replace("The ", " ").Replace(" And ", " ").Replace("-", " ").Replace(",", " ");
                enTitle = Regex.Replace(enTitle, @"\s+", " ");
                return enTitle;
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return "";
            }
        }

        /// <summary>
        /// 首字母大写
        /// </summary>
        /// <param name="_str"></param>
        /// <returns></returns>
        public  string upFirstCharWithSpace(string _str)
        {
            if (_str.Trim() == "") return " ";
            string[] words = _str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > 1)
                {
                    words[i] = words[i].Substring(0, 1).ToUpper() + words[i].Substring(1).ToLower();
                }
                else
                {

                    words[i] = words[i].ToUpper();
                }
            }

            return string.Join(" ", words);
        }

        /// <summary>
        /// 单词首字母大字并保留单个空格
        /// </summary>
        /// <param name="_str"></param>
        /// <returns></returns>
        public string upFirstCharWithSpaceX(string _str)
        {
            if (_str.Trim() == "") return " ";

            _str = _str.Trim();

            Regex reg = new Regex(@"^(?<A>.+)\((?<B>[^\(\)]+?)\)$");

            Match matchSw = reg.Match(_str);
            if (matchSw.Success)
            {
                return upFirstCharWithSpace(matchSw.Groups["A"].Value) + " (" + matchSw.Groups["B"].Value + ")";
            }


            string[] words = _str.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > 1)
                {
                    words[i] = words[i].Substring(0, 1).ToUpper() + words[i].Substring(1).ToLower();
                }
                else
                {

                    words[i] = words[i].ToUpper();
                }
            }

            return string.Join(" ", words);
        }
    }
}
