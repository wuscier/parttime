﻿using LAZADA;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Top.Api.Response;

namespace Logic.Platform
{
    public class HaiWangCore
    {
        SiteChangeHelp sch = new SiteChangeHelp();
        HaiWangRequestClient hwrc = new HaiWangRequestClient();
        public void GetUserAuthorized()
        {
            var json = hwrc.GetServicepackResponse();
            if (json == null)
            {
                GlobalUserClass.GetHaiWangModel().IsAuthorized = false;
            }
            else if (Convert.ToBoolean(json["IsError"]))
            {
                GlobalUserClass.GetHaiWangModel().IsAuthorized = false;
            }
            else if (!json["ServicePackList"].HasValues)
            {
                GlobalUserClass.GetHaiWangModel().IsAuthorized = false;
            }
            else
            {
                GlobalUserClass.GetHaiWangModel().IsAuthorized = true;
            }
        }

        public string TranslateZhToSiteDefaultResponse(string source)
        {
            return hwrc.GetTranslateZhToSiteDefaultResponse(source);
        }

        public string TranslateSiteDefaultToZhResponse(string source)
        {

            return hwrc.GetTranslateSiteDefaultToZhResponse(source);
        }

        public long PostImagesToTranslate(long producttId, List<string> images, string targetLang)
        {
            return hwrc.PostImagesToTranslate(producttId, images, targetLang);
        }

        public string PostSeakingImagetranslate( string image, string targetLang)
        {
            return hwrc.PostSeakingImagetranslate(image, targetLang);
        }

        public List<string> GetTranslateImages(long taskId)
        {
            return hwrc.GetTranslateImages(taskId);
        }

        public long PostTitleToTranslate(long producttId, List<string> titles, List<long> categoryids, List<string> categorynames, List<string> images, string targetLang)
        {
            return hwrc.PostTitleToTranslate(producttId, titles, categoryids, categorynames, images, targetLang);
        }

        public List<string> GetTranslateTitle(long taskId)
        {
            return hwrc.GetTranslateTitle(taskId);
        }

        public void ProductTaskReport(long lazadaid, long titleTaskId, long picTaskId)
        {
            if (titleTaskId != 0)
            {
                hwrc.ProductTaskReport(lazadaid, titleTaskId, "title");
            }
            if (picTaskId != 0)
            {
                hwrc.ProductTaskReport(lazadaid, picTaskId, "image");
            }
        }
        public string Aititlegenerate(Product product, string text, string Language = "en")
        {
            return hwrc.Aititlegenerate(product, text, Language);
        }
        public AlibabaSeakingDiagnosistitleResponse Diagnosistitle(Product product, string text, string Language = "en")
        {
            return hwrc.Diagnosistitle(product, text, Language);
        }
    }
}
