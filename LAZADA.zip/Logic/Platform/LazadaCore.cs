﻿using LAZADA;
using Logic.BasicInfo;
using Logic.PriceTemplate;
using Logic.SystemSole;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Logic.Platform
{
    /// <summary>
    /// Lazada平台业务操作
    /// </summary>
    public class LazadaCore
    {
        int LazadaMaxPrice = 21562500;

        string ReadResponse(HttpWebResponse response)
        {
            //Constants.GETLAZADA_APPSECRET();
            string result = string.Empty;
            bool flag = response.ContentEncoding.ToLower().Contains("gzip");
            if (flag)
            {
                using (GZipStream gzipStream = new GZipStream(response.GetResponseStream(), CompressionMode.Decompress))
                {
                    using (StreamReader streamReader = new StreamReader(gzipStream))
                    {
                        result = streamReader.ReadToEnd();
                    }
                }
            }
            else
            {
                bool flag2 = response.ContentEncoding.ToLower().Contains("deflate");
                if (flag2)
                {
                    using (DeflateStream deflateStream = new DeflateStream(response.GetResponseStream(), CompressionMode.Decompress))
                    {
                        using (StreamReader streamReader2 = new StreamReader(deflateStream, Encoding.UTF8))
                        {
                            result = streamReader2.ReadToEnd();
                        }
                    }
                }
                else
                {
                    using (Stream responseStream = response.GetResponseStream())
                    {
                        using (StreamReader streamReader3 = new StreamReader(responseStream, Encoding.UTF8))
                        {
                            result = streamReader3.ReadToEnd();
                        }
                    }
                }
            }
            return result;
        }

        Dictionary<string, string> InitRequestParamDic(Dictionary<string, string> _paradic)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            string value = "";
            bool flag = _paradic.Keys.Contains("Action");
            if (flag)
            {
                value = _paradic["Action"];
                _paradic.Remove("Action");
            }
            _paradic.Add("app_key", Constants.LAZADA_APPKEY);
            _paradic.Add("access_token", Constants.LAZADA_ACCESSTOKEN);
            _paradic.Add("sign_method", "sha256");
            _paradic.Add("timestamp", Convert.ToString((DateTime.UtcNow.Ticks - new DateTime(1970, 1, 1, 0, 0, 0, 0).Ticks) / 10000L));
            List<string> list = new List<string>();
            foreach (KeyValuePair<string, string> keyValuePair in _paradic)
            {
                bool flag2 = string.IsNullOrEmpty(keyValuePair.Key) || string.IsNullOrEmpty(keyValuePair.Value);
                if (!flag2)
                {
                    list.Add(keyValuePair.Key);
                }
            }
            list.Sort();
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(value);
            foreach (string text in list)
            {
                dictionary.Add(text, _paradic[text]);
                stringBuilder.Append(text).Append(_paradic[text]);
            }
            string value2 = EncryptionWay.CGHP68GFqi(stringBuilder.ToString(), Constants.LAZADA_APPSECRET, true);
            dictionary.Add("sign", value2);
            return dictionary;
        }

        /// <summary>
        /// 根据ITEMID查询产品信息
        /// </summary>
        /// <param name="itemid"></param>
        /// <returns></returns>
        public JObject GetProductItem(string itemid)
        {
            LazadaRequestClient client = new LazadaRequestClient();
            var dic = new Dictionary<string, string> { { "item_id", itemid } };
            var jsondata = client.GetResponseToken(Constants.LAZADA_GetProductItem, "Get", dic);
            return jsondata;
        }

        /// <summary>
        /// 判断该平台是否已经存在某个SKU
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool CheckProductExist(Product product)
        {
            //JArray array = JsonConvert.DeserializeObject<JArray>(product.SKUDetail);
            //foreach (var item in array)
            //{
            //    LazadaRequestClient client = new LazadaRequestClient();
            //    JObject json = JsonConvert.DeserializeObject<JObject>(item.ToString());
            //    var dic = new Dictionary<string, string> { { "seller_sku", json["SellerSku"].ToString() } };
            //    var jsondata = client.GetResponseToken(Constants.LAZADA_GetProductItem, "Get", dic);
            //    if (Convert.ToString(jsondata["code"]) != "207")
            //        return true;
            //}
            //string skuName = "";
            //var skuArr = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
            //var skuy = product.Lazadaskuy ?? "";
            //Regex regex = new Regex("[^a-zA-Z0-9]+");
            //foreach (var item in skuArr)
            //{
            //    var array1 = ((JArray)item["sku"]);
            //    var value_first = regex.Replace((array1[0]["value"]).ToString(), "");
            //    skuName = string.Concat(new string[] { product.Pidprefix, product.SKUNumber.ToString(), "-", skuy, "-", (array1[0]["value"]).ToString(), "-" });
            //    for (int i = 1; i < array1.Count; i++)
            //    {
            //        var attrs = array1[i]["value"].ToString().Split(',');
            //        foreach (var attr in attrs)
            //        {
            //            var seller_sku = skuName + attr;
            //            seller_sku = seller_sku.Replace(" ", "").Replace(":", "").Replace("--", "-").Replace("--", "-");
            //            //if (seller_sku != string.Empty)
            //            //{
            //            //    LazadaRequestClient client = new LazadaRequestClient();
            //            //    var dic = new Dictionary<string, string> { { "seller_sku", seller_sku } };
            //            //    var jsondata = client.GetResponseToken(Constants.LAZADA_GetProductItem, "Get", dic);
            //            //    if (Convert.ToString(jsondata["code"]) != "207")
            //            //        return true;
            //            //}
            //        }
            //    }
            //}
            return false;
        }

        public bool PushUpdateProduct(JObject jobject, ShowOnLineProduct OnlineProduct)
        {
            if (jobject == null) return false;
            string text14 = JsonConvert.SerializeObject(jobject);
            string outerXml = JsonConvert.DeserializeXmlNode(text14).OuterXml;
            string u = "<?xml version = \"1.0\" encoding = \"UTF-8\" ?> " + outerXml;
            try
            {
                JObject jobject12 = UpdateProduct(u);
                try
                {
                    MySoundPlay.PlayPushMusic();
                }
                catch { }

                if (Convert.ToString(jobject12["code"]) == "0" || Convert.ToString(jobject12["code"]) == "ServiceTimeout")
                {
                    new OnlineProductFunctionUpadteCore().UpdateOnlineProduct(jobject, OnlineProduct);
                    ///上传到服务器
                    //new HummingbirdCore().UploadPorductInfo(product);
                    return true;
                }
                else
                {
                    var obj = new JObject();
                    try
                    {
                        obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                        //product.Pcancsv = obj["error"]["sku_info"]["sku0"]["special_price"].ToString();
                    }
                    catch
                    {
                        try
                        {
                            obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                            //product.Pcancsv = obj["error"]["global_error"].ToString();
                        }
                        catch
                        {
                            try
                            {
                                obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                                //product.Pcancsv = obj["error"].ToString();
                            }
                            catch
                            {
                                try
                                {
                                    //product.Pcancsv = jobject12.ToString();
                                    //product.Pcancsv = jobject12["message"].ToString();
                                }
                                catch
                                {

                                }
                            }
                            new LogOutput.LogTo().WriteErrorLine(JsonConvert.SerializeObject(jobject12));
                        }
                    }
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public bool PushUpdateProduct(Product product, ShowOnLineProduct OnlineProduct)
        {
            JObject jobject = new JObject();
            jobject = CreateXMLNew(product);
            if (jobject == null) return false;
            string text14 = JsonConvert.SerializeObject(jobject);
            string outerXml = JsonConvert.DeserializeXmlNode(text14).OuterXml;
            string u = "<?xml version = \"1.0\" encoding = \"UTF-8\" ?> " + outerXml;
            try
            {
                JObject jobject12 = UpdateProduct(u);
                try
                {
                    MySoundPlay.PlayPushMusic();
                }
                catch { }
                if (jobject12 == null)
                    product.Pcancsv = "发布出错...";
                if (jobject12["code"] == null)
                    product.Pcancsv = "发布超时...";
                if (Convert.ToString(jobject12["code"]) == "0" || Convert.ToString(jobject12["code"]) == "ServiceTimeout")
                {
                    new OnlineProductFunctionUpadteCore().UpdateOnlineProduct(jobject, OnlineProduct);
                    ///上传到服务器
                    new HummingbirdCore().UploadPorductInfo(product, "0");
                    return true;
                }
                else
                {
                    var obj = new JObject();
                    try
                    {
                        obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                        product.Pcancsv = obj["error"]["sku_info"]["sku0"]["special_price"].ToString();
                    }
                    catch
                    {
                        try
                        {
                            obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                            product.Pcancsv = obj["error"]["global_error"].ToString();
                        }
                        catch
                        {
                            try
                            {
                                obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                                product.Pcancsv = obj["error"].ToString();
                            }
                            catch
                            {
                                try
                                {
                                    product.Pcancsv = jobject12.ToString();
                                    //product.Pcancsv = jobject12["message"].ToString();
                                }
                                catch
                                {

                                }
                            }
                            new LogOutput.LogTo().WriteErrorLine(JsonConvert.SerializeObject(jobject12));
                        }
                    }
                }
                return false;

            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 推送产品
        /// </summary>
        /// <param name="product"></param>
        public void PushProduct(Product product)
        {
            JObject jobject = new JObject();
            if (GlobalUserClass.SiteId == 9)
            {
                jobject = CreateXML_Six(product);
            }
            else
            {
                jobject = CreateXMLNew(product);
            }
            if (!GlobalUserClass.IsNoImg)
            {
                product.Pcancsv = "产品主图异常,请重新选择";
                return;
            }
            string text14 = JsonConvert.SerializeObject(jobject);
            string outerXml = JsonConvert.DeserializeXmlNode(text14).OuterXml;
            ///开始发布
            product.Pcancsv = "正在发布...";
            string u = "<?xml version = \"1.0\" encoding = \"UTF-8\" ?> " + outerXml;
            bool isError = false;
            try
            {
                MySoundPlay.PlayPushMusic();
                JObject jobject12 = CreateProduct(u, out isError);
                string str = "";
                string strE = "1";
                foreach (var objc in jobject12)
                {
                    if (objc.Value == null)
                    {
                        str+= objc.Key.Split(',')[0]+ ":发布出错...\n";
                        strE = "2";
                    }
                    else if (objc.Value["code"] == null)
                    {
                        str += objc.Key.Split(',')[0] + ":发布超时...\n";
                        strE = "2";
                    }
                    else if (Convert.ToString(objc.Value["code"]) == "0" || Convert.ToString(objc.Value["code"]) == "ServiceTimeout")
                    {
                        str += objc.Key.Split(',')[0] + ":发布OK...\n";
                        product.LazadaItemid = Convert.ToInt64(objc.Value["data"]["item_id"]);
                        Task.Run(() =>
                        {
                            new HaiWangCore().ProductTaskReport(Convert.ToInt64(product.LazadaItemid), product.TitleTaskId, product.PicTaskId);
                        });
                        ///上传到服务器
                        new HummingbirdCore().UploadPorductInfo(product, objc.Key.Split(',')[1]);
                    }
                    else
                    {
                        strE = "2";
                        var obj = new JObject();
                        try
                        {
                            obj = JsonConvert.DeserializeObject<JObject>(objc.Value["detail"][0].ToString());
                            str += objc.Key.Split(',')[0] + ":" + "发布失败:" + obj["error"]["sku_info"]["sku0"]["special_price"].ToString() + "\n";
                        }
                        catch
                        {
                            try
                            {
                                obj = JsonConvert.DeserializeObject<JObject>(objc.Value["detail"][0].ToString());
                                str += objc.Key.Split(',')[0] + ":" + "发布失败:" + obj["error"]["global_error"].ToString() + "\n";
                            }
                            catch
                            {
                                try
                                {
                                    obj = JsonConvert.DeserializeObject<JObject>(objc.Value["detail"][0].ToString());
                                    str += objc.Key.Split(',')[0] + ":" + "发布失败:" + obj["error"].ToString() + "\n";
                                }
                                catch
                                {
                                    try
                                    {
                                        obj = JsonConvert.DeserializeObject<JObject>(objc.Value["detail"][0].ToString());
                                        str += objc.Key.Split(',')[0] + ":" + "发布失败:" + obj["message"].ToString() + "\n";
                                        //product.Pcancsv = jobject12["message"].ToString();
                                    }
                                    catch
                                    {
                                        str += objc.Key.Split(',')[0] + ":" + "发布失败:" + objc.Value.ToString() + "\n";
                                    }
                                }
                                new LogOutput.LogTo().WriteErrorLine(objc.Key.Split(',')[0] + ":" + JsonConvert.SerializeObject(objc.Value));
                            }
                        }
                    }
                }
                product.Pcancsv = strE=="1"? ("发布OK\n" + str):("发布存在错误：\n" + str);
                product.Pstatetype = strE;
                //}
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                product.Pcancsv = "发布出错:\n"+ ex.Message;
            }
            if (product.Pstatetype != "1")
            {
                product.ChildSku = "";
            }
            new ProductCore().UpdatePushProduct(product);
        }

        /// <summary>
        /// 生成发送的文件
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        private JObject CreateXML(Product product)
        {
            product.Pcancsv = "检查完整性";
            JObject jobject = new JObject();
            JObject jobject2 = new JObject();
            jobject["Request"] = jobject2;
            JObject jobject3 = new JObject();
            jobject2["Product"] = jobject3;
            jobject3.Add("PrimaryCategory", product.Lazadacategoryid);
            JObject jobject4 = new JObject();
            jobject3["Attributes"] = jobject4;
            jobject4["name"] = product.Pbrand + product.PnewtitleX;
            jobject4["video"] = product.Video ?? "";
            jobject4["name_en"] = product.Pbrand + product.PnewtitleX;


            jobject4["short_description_en"] = product.Lazadahighlight.Replace("UL", "ul").Replace("LI", "li").Replace("\r\n", "");
            jobject4["short_description"] = product.Lazadahighlight.Replace("UL", "ul").Replace("LI", "li").Replace("\r\n", "");
            var imageInfo = "";
            foreach (var item in product.Pnewimgsurl.Split(','))
            {
                imageInfo += "<img src=\"" + item.Replace("http:", "https:") + "\"  style=\"width:80%;\" />";
            }
            jobject4["description"] = product.Lazadadescription;
            jobject4["description"] = string.Concat(new string[]
                        {
                            "<div style=\"font-size:14px\"> ",
                            jobject4["description"].ToString(),
                            "<p>",
                            imageInfo,
                            "</p></div>"
                        });
            jobject4["description_en"] = jobject4["description"];
            JArray jarray = (JArray)JsonConvert.DeserializeObject(product.Lazadaattributs);
            foreach (JToken jtoken in jarray)
            {
                JObject jobject5 = (JObject)jtoken;
                jobject4.Add(jobject5["name"].ToString(), jobject5["value"].ToString());
            }
            JObject jobject6 = new JObject
            {
                ["quantity"] = product.Pkuchen,
                ["price"] = (Convert.ToDouble(product.Lazadaprice) > LazadaMaxPrice) ? LazadaMaxPrice.ToString() : product.Lazadaprice,
                ["package_content"] = product.Lazadapackageincluding,//XWFSHY.BaiduFY(kb["lazadapackageincluding"].ToString(), "auto", AppConfigConst.GetAppLanguage, false); 
                ["package_contents_en"] = product.Lazadapackageincluding,//XWFSHY.BaiduFY(kb["lazadapackageincluding"].ToString(),"auto","en",false);
                ["tax_class"] = product.Lazadatax,
                ["published_date"] = DateTime.Now.ToString(),
                ["package_length"] = product.PackageLength,
                ["package_width"] = product.PackageWidth,
                ["package_height"] = product.PackageHight,
                ["package_weight"] = (Convert.ToDouble(product.Lazadapackageweight) / 1000.0).ToString("F3"),
                ["special_price"] = (Convert.ToDouble(product.Lazadapromprice) > LazadaMaxPrice) ? LazadaMaxPrice.ToString() : product.Lazadapromprice,
                ["special_from_date"] = product.Lazadapromstart,
                ["special_to_date"] = product.Lazadapromend
            };
            JArray jarray2 = new JArray();
            jobject3["Skus"] = jarray2;
            JArray jarray3 = new JArray();
            JArray jarray4 = new JArray();
            string text3 = product.Lazadazhusku;
            JArray jarray5 = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
            foreach (JToken jtoken2 in jarray5)
            {
                if (jtoken2["sku"] != null)
                {
                    if (jtoken2["sku"].HasValues)
                    {
                        if (((JArray)jtoken2["sku"]).Count > 0)
                        {
                            JArray jarray6 = (JArray)jtoken2["sku"];
                            bool flag29 = jarray6.Count == 2 && ((jarray6[0]["name"].ToString() == "color_family" && jarray6[1]["name"].ToString() == "size") || (jarray6[1]["name"].ToString() == "color_family" && jarray6[0]["name"].ToString() == "size"));
                            if (flag29)
                            {
                                JToken jtoken3 = jarray6[0];
                                JToken jtoken4 = jarray6[1];
                                bool flag30 = jtoken3["name"].ToString() == "color_family" && jtoken4["name"].ToString() == "size";
                                JToken jtoken5;
                                JToken jtoken6;
                                if (flag30)
                                {
                                    jtoken5 = jtoken3;
                                    jtoken6 = jtoken4;
                                }
                                else
                                {
                                    jtoken5 = jtoken4;
                                    jtoken6 = jtoken3;
                                }
                                JArray jarray7 = new JArray();

                                JArray jarray8 = (JArray)jtoken2["leftimages"];
                                bool flag32 = false;
                                for (int j = 0; j < jarray8.Count; j++)
                                {
                                    bool flag33 = jarray8[j].ToString().Trim().StartsWith("http");
                                    if (!flag33)
                                    {
                                        flag32 = true;
                                        break;
                                    }
                                    jarray7.Add(jarray8[j].ToString().Trim().Replace("http:", "https:"));
                                }
                                bool flag34 = flag32;

                                string[] array3 = jtoken6["value"].ToString().Split(new char[]
                                {
                                                ',',
                                                '\n'
                                }, StringSplitOptions.RemoveEmptyEntries);

                                foreach (string text4 in array3)
                                {
                                    string text5 = text4.Trim();
                                    JObject jobject7 = (JObject)jobject6.DeepClone();

                                    Regex regex = new Regex("[^a-zA-Z0-9]+");
                                    string text7 = regex.Replace(jtoken5["value"].ToString(), "") + "-" + regex.Replace(text5, "");
                                    var skuy = product.Lazadaskuy ?? "";
                                    string text8 = string.Concat(new string[]
                                    {
                                                    product.Pidprefix,
                                                    product.SKUNumber.ToString(),
                                                    "-",
                                                    PublicFunctions.ATjWj6oy0m(regex.Replace(skuy, " ")),
                                                    "-",
                                                    text7
                                                                                    });
                                    text8 = text8.Replace(" ", "");
                                    text8 = text8.Replace("--", "-");
                                    text8 = text8.Replace("--", "-");
                                    jarray4.Add(text8);
                                    jobject7.Add("SellerSku", text8);
                                    jobject7.Add("color_family", jtoken5["value"].ToString());
                                    jobject7.Add("size", text5);
                                    JObject jobject8 = new JObject
                                    {
                                        { "Image", jarray7 }
                                    };
                                    jobject7.Add("Images", jobject8);
                                    jarray3.Add(jobject7);
                                }
                            }
                            else
                            {
                                JObject jobject9 = (JObject)jobject6.DeepClone();
                                string text10 = string.Empty;
                                foreach (JToken jtoken7 in ((JArray)jtoken2["sku"]))
                                {
                                    bool flag44 = jtoken7["name"].ToString() != "DEFAULT";
                                    if (flag44)
                                    {
                                        bool flag45 = jtoken7["name"].ToString() == "color_hb";
                                        if (flag45)
                                        {
                                            string[] array5 = jtoken7["value"].ToString().Split(new char[]
                                            {
                                                            ')'
                                            });
                                            string text11 = array5[0].Replace("(", "").Trim();
                                            string text12 = array5.Last<string>().Trim();
                                            jobject9.Add("color_hb", text11);
                                            jobject9.Add("color_text", text12);
                                        }
                                        else
                                        {
                                            jobject9.Add(jtoken7["name"].ToString(), jtoken7["value"].ToString());
                                        }
                                    }
                                    text10 += jtoken7["value"].ToString();
                                }
                                Regex regex2 = new Regex("[^a-zA-Z0-9]+");
                                var skuy = product.Lazadaskuy ?? "";
                                string text13 = string.Concat(new string[]
                                {
                                                product.Pidprefix,
                                                    product.SKUNumber.ToString(),
                                                "-",
                                                PublicFunctions.ATjWj6oy0m(regex2.Replace(skuy, " ")),
                                                "-",
                                                regex2.Replace(text10, "")
                                                                            });
                                text13 = text13.Replace(" ", "");
                                text13 = text13.Replace("--", "-");
                                text13 = text13.Replace("--", "-");
                                jarray4.Add(text13);
                                jobject9.Add("SellerSku", text13);
                                bool flag46 = jtoken2["leftimages"] != null && jtoken2["leftimages"].HasValues && ((JArray)jtoken2["leftimages"]).Count > 0;
                                if (flag46)
                                {
                                    JArray jarray9 = (JArray)jtoken2["leftimages"];
                                    JArray jarray10 = new JArray();
                                    for (int l = 0; l < jarray9.Count; l++)
                                    {
                                        bool flag48 = jarray9[l].ToString().Trim().StartsWith("http");
                                        if (!flag48)
                                        {
                                            break;
                                        }
                                        jarray10.Add(jarray9[l].ToString().Trim());
                                    }
                                    JObject jobject10 = new JObject
                                    {
                                        { "Image", jarray10 }
                                    };
                                    jobject9.Add("Images", jobject10);
                                    jarray3.Add(jobject9);
                                }

                            }
                        }
                    }
                }
            }
            JObject jobject11 = new JObject
            {
                { "Sku", jarray3 }
            };
            ((JArray)jobject3["Skus"]).RemoveAll();
            ((JArray)jobject3["Skus"]).Add(jobject11);
            product.ChildSku = string.Join(",", jarray4);
            return jobject;
        }

        /// <summary>
        /// 生成发送的文件
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        private JObject CreateXMLNew(Product product)
        {
            var ptc = new PriceTemplateCore();

            product.Pcancsv = "检查完整性";
            JObject jobject = new JObject();
            JObject jobject2 = new JObject();
            jobject["Request"] = jobject2;
            JObject jobject3 = new JObject();
            jobject2["Product"] = jobject3;
            jobject3.Add("PrimaryCategory", product.Lazadacategoryid);
            JObject jobject4 = new JObject();
            jobject3["Attributes"] = jobject4;
            jobject4["name"] = product.Pbrand + product.PnewtitleX;
            jobject4["video"] = product.Video ?? "";
            //jobject4["name_en"] = product.Pbrand + product.PnewtitleX;


            //jobject4["short_description_en"] = product.Lazadahighlight.Replace("UL", "ul").Replace("LI", "li").Replace("\r\n", "");
            jobject4["short_description"] = product.Lazadahighlight.Replace("UL", "ul").Replace("LI", "li").Replace("\r\n", "");
            var imageInfo = "";
            foreach (var item in product.Pnewimgsurl.Split(','))
            {
                imageInfo += "<img src=\"" + item.Replace("http:", "https:") + "\"  style=\"width:100%;\" />";
            }
            jobject4["description"] = product.Lazadadescription;
            jobject4["description"] = string.Concat(new string[]
                        {
                            "<div style=\"font-size:14px\"> ",
                            jobject4["description"].ToString(),
                            "<p>",
                            imageInfo,
                            "</p></div>"
                        });
            //jobject4["description_en"] = jobject4["description"];
            JArray jarray = (JArray)JsonConvert.DeserializeObject(product.Lazadaattributs);
            foreach (JToken jtoken in jarray)
            {
                JObject jobject5 = (JObject)jtoken;
                jobject4.Add(jobject5["name"].ToString(), jobject5["value"].ToString());
            }
            JArray jarray2 = new JArray();
            jobject3["Skus"] = jarray2;
            JArray jarray3 = new JArray();
            JArray jarray4 = new JArray();
            string text3 = product.Lazadazhusku;

            //Dictionary<string, JArray> dic = new Dictionary<string, JArray>();
            //JArray jarray5 = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
            //foreach (JToken jtoken2 in jarray5)
            //{
            //    if (jtoken2["sku"] != null)
            //    {
            //        if (jtoken2["sku"].HasValues)
            //        {
            //            JArray jarray7 = new JArray();
            //            if (((JArray)jtoken2["sku"]).Count > 0)
            //            {
            //                JArray jarray6 = (JArray)jtoken2["sku"];
            //                JArray jarray8 = (JArray)jtoken2["leftimages"];
            //                for (int j = 0; j < jarray8.Count; j++)
            //                {
            //                    jarray7.Add(jarray8[j].ToString().Trim().Replace("http:", "https:"));
            //                }
            //                var skuname = product.Pidprefix + product.SKUNumber;
            //                for (int j = 0; j < jarray6.Count; j++)
            //                {
            //                    var json = JsonConvert.DeserializeObject<JObject>(jarray6[j].ToString());
            //                    skuname += "-" + json["value"].ToString().Replace(" ", "");
            //                }
            //                if (!dic.ContainsKey(skuname))
            //                {
            //                    dic.Add(skuname, jarray7);
            //                }
            //            }
            //        }
            //    }
            //}

            Dictionary<string, JArray> dic = new Dictionary<string, JArray>();
            JArray jarray5 = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
            List<string> skus = new List<string>();
            List<string> skuNames = new List<string>();
            List<string> clearList = new List<string>();
            foreach (JToken jtoken2 in jarray5)
            {
                if (jtoken2["sku"] != null)
                {
                    if (jtoken2["sku"].HasValues)
                    {
                        JArray jarray7 = new JArray();
                        if (((JArray)jtoken2["sku"]).Count > 0)
                        {
                            JArray jarray6 = (JArray)jtoken2["sku"];
                            JArray jarray8 = (JArray)jtoken2["leftimages"];
                            if (jarray8.Count == 0)
                            {
                                GlobalUserClass.IsNoImg = false;
                                break;
                            }
                            else
                            {
                                GlobalUserClass.IsNoImg = true;
                            }
                            for (int j = 0; j < jarray8.Count; j++)
                            {
                                jarray7.Add(jarray8[j].ToString().Trim().Replace("http:", "https:"));
                            }
                            var skuname = product.Pidprefix + (product.SKUNumber == 0 ? "" : product.SKUNumber.ToString());
                            skus.Clear();
                            for (int j = 0; j < jarray6.Count; j++)
                            {
                                var json = JsonConvert.DeserializeObject<JObject>(jarray6[j].ToString());
                                skus.Add(json["value"].ToString().Replace(" ", "").Replace(":", ""));
                            }
                            for (int j = 0; j < skus.Count; j++)
                            {
                                var items = skus[j].Replace("，", ",").Split(',');
                                if (j == 0)
                                {
                                    foreach (var item in items)
                                    {
                                        var newName = skuname + "-" + item;
                                        if (!dic.ContainsKey(newName))
                                        {
                                            dic.Add(newName, jarray7);
                                            clearList.Add(newName);
                                        }
                                    }
                                }
                                else
                                {
                                    var list = new List<string>();
                                    foreach (var key in clearList)
                                    {
                                        list.Add(key);
                                    }
                                    foreach (var name in list)
                                    {
                                        foreach (var item in items)
                                        {
                                            var newName = name + "-" + item;
                                            if (!dic.ContainsKey(newName))
                                            {
                                                dic.Add(newName, jarray7);
                                                clearList.Add(newName);
                                            }
                                        }
                                    }
                                    foreach (var name in list)
                                    {
                                        if (dic.ContainsKey(name))
                                            dic.Remove(name);
                                        if (clearList.Contains(name))
                                            clearList.Remove(name);
                                    }
                                }
                            }


                        }
                    }
                }
                clearList.Clear();
            }

            JArray array = JsonConvert.DeserializeObject<JArray>(product.SKUDetail);
            foreach (var item in array)
            {
                JObject obj = new JObject();
                var json = JsonConvert.DeserializeObject<JObject>(item.ToString());
                var ps = json.Properties();
                JArray img = null;
                var name = "";
                var name1 = "";
                foreach (var p in ps)
                {
                    if (p.Name == "Pjijiamuban" || p.Name == "CostPrice")
                    {
                        continue;
                    }
                    if (p.Name == "package_weight")
                    {
                        var weight = (Convert.ToDouble(product.Lazadapackageweight) / 1000.0).ToString("F3");
                        obj.Add(p.Name, weight);
                    }
                    else
                        obj.Add(p.Name, p.Value);
                    if (p.Name == "SellerSku")
                    {
                        name = p.Value.ToString();
                        string[] strs = name.Split('-');

                        name1 = strs.Count() ==3 ? strs[0]+"-"+ strs[2] + "-"+ strs[1] : "";
                    }
                    if (dic.ContainsKey(name)||(name1!=""&& dic.ContainsKey(name1)))
                    {
                        img = dic.ContainsKey(name)?dic[name]: dic[name1];
                        product.ChildSku = product.ChildSku == "" ? (dic.ContainsKey(name) ? name : name1) : (","+(dic.ContainsKey(name) ? name : name1));
                    }
                }
                obj.Add("package_length", product.PackageLength);
                obj.Add("package_width", product.PackageWidth);
                obj.Add("package_height", product.PackageHight);
                obj.Add("package_content", product.Lazadapackageincluding);
                obj.Add("package_contents_en", product.Lazadapackageincluding);
                obj.Add("published_date", DateTime.Now.ToString());
                obj.Add("special_from_date", product.Lazadapromstart);
                obj.Add("special_to_date", product.Lazadapromend);
                obj.Add("tax_class", product.Lazadatax);
                obj.Add("Images", new JObject { { "Image", img } });
                jarray3.Add(obj);
            }

            JObject jobject11 = new JObject
            {
                { "Sku", jarray3 }
            };
            ((JArray)jobject3["Skus"]).RemoveAll();
            ((JArray)jobject3["Skus"]).Add(jobject11);
            //product.ChildSku = string.Join(",", jarray4);
            return jobject;
        }


        /// <summary>
        /// 生成六合一的发送文件
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        private JObject CreateXML_Six(Product product)
        {
            #region 新版
            var ptc = new PriceTemplateCore();

            product.Pcancsv = "检查完整性";
            JObject jobject = new JObject();
            JObject jobject2 = new JObject();
            jobject["Request"] = jobject2;
            JObject jobject3 = new JObject();
            jobject2["Product"] = jobject3;
            JObject jobVentures = new JObject();
            var site = new SiteChangeHelp().GetPushSiteSimple(GlobalUserClass.PublishingSite);
            jobVentures.Add("Venture", site);
            jobject3.Add("AutoAllocateStock", product.AutoAllocateStock);
            jobject3["Ventures"] = jobVentures;
            jobject3.Add("PrimaryCategory", product.Lazadacategoryid);
            JObject jobject4 = new JObject();
            jobject3["Attributes"] = jobject4;
            jobject4.Add("package_length", product.PackageLength);
            jobject4.Add("package_width", product.PackageWidth);
            jobject4.Add("package_height", product.PackageHight);
            var weight = (Convert.ToDouble(product.Lazadapackageweight) / 1000.0).ToString("F3");
            jobject4.Add("package_weight", weight);

            jobject4.Add("package_content", product.Lazadapackageincluding);
            jobject4.Add("package_contents_en", product.Lazadapackageincluding);

            jobject4["name"] = product.Pbrand + product.PnewtitleX;
            jobject4["video"] = product.Video ?? "";
            jobject4["name_en"] = product.Pbrand + product.PnewtitleX;


            jobject4["short_description_en"] = product.Lazadahighlight.Replace("UL", "ul").Replace("LI", "li").Replace("\r\n", "");
            jobject4["short_description"] = product.Lazadahighlight.Replace("UL", "ul").Replace("LI", "li").Replace("\r\n", "");
            var imageInfo = "";
            foreach (var item in product.Pnewimgsurl.Split(','))
            {
                imageInfo += "<img src=\"" + item.Replace("http:", "https:") + "\"  style=\"width:100%;\" />";
            }
            jobject4["description"] = product.Lazadadescription;
            jobject4["description"] = string.Concat(new string[]
                        {
                            "<div style=\"font-size:14px\"> ",
                            jobject4["description"].ToString(),
                            "<p>",
                            imageInfo,
                            "</p></div>"
                        });
            jobject4["description_en"] = jobject4["description"];
            JArray jarray = (JArray)JsonConvert.DeserializeObject(product.Lazadaattributs);
            foreach (JToken jtoken in jarray)
            {
                JObject jobject5 = (JObject)jtoken;
                jobject4.Add(jobject5["name"].ToString(), jobject5["value"].ToString());
            }
            JArray jarray2 = new JArray();
            jobject3["Skus"] = jarray2;
            JArray jarray3 = new JArray();
            JArray jarray4 = new JArray();
            string text3 = product.Lazadazhusku;

            Dictionary<string, JArray> dic = new Dictionary<string, JArray>();
            JArray jarray5 = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
            List<string> skus = new List<string>();
            List<string> skuNames = new List<string>();
            List<string> clearList = new List<string>();
            foreach (JToken jtoken2 in jarray5)
            {
                if (jtoken2["sku"] != null)
                {
                    if (jtoken2["sku"].HasValues)
                    {
                        JArray jarray7 = new JArray();
                        if (((JArray)jtoken2["sku"]).Count > 0)
                        {
                            JArray jarray6 = (JArray)jtoken2["sku"];
                            JArray jarray8 = (JArray)jtoken2["leftimages"];
                            if (jarray8.Count == 0)
                            {
                                GlobalUserClass.IsNoImg = false;
                                break;
                            }
                            else
                            {
                                GlobalUserClass.IsNoImg = true;
                            }
                            for (int j = 0; j < jarray8.Count; j++)
                            {
                                jarray7.Add(jarray8[j].ToString().Trim().Replace("http:", "https:"));
                            }
                            var skuname = product.Pidprefix + product.SKUNumber;
                            skus.Clear();
                            for (int j = 0; j < jarray6.Count; j++)
                            {
                                var json = JsonConvert.DeserializeObject<JObject>(jarray6[j].ToString());
                                skus.Add(json["value"].ToString().Replace(" ", "").Replace(":", ""));
                            }
                            for (int j = 0; j < skus.Count; j++)
                            {
                                var items = skus[j].Replace("，", ",").Split(',');
                                if (j == 0)
                                {
                                    foreach (var item in items)
                                    {
                                        var newName = skuname + "-" + item;
                                        if (!dic.ContainsKey(newName))
                                        {
                                            dic.Add(newName, jarray7);
                                            clearList.Add(newName);
                                        }
                                    }
                                }
                                else
                                {
                                    var list = new List<string>();
                                    foreach (var key in clearList)
                                    {
                                        list.Add(key);
                                    }
                                    foreach (var name in list)
                                    {
                                        foreach (var item in items)
                                        {
                                            var newName = name + "-" + item;
                                            //skuNames.Add(name + "-" + item);
                                            if (!dic.ContainsKey(newName))
                                            {
                                                dic.Add(newName, jarray7);
                                                clearList.Add(newName);
                                            }
                                            //clearList.Add(name);
                                        }
                                    }
                                    foreach (var name in list)
                                    {
                                        if (dic.ContainsKey(name))
                                            dic.Remove(name);
                                        if (clearList.Contains(name))
                                            clearList.Remove(name);
                                    }
                                }
                            }


                        }
                    }
                }
                clearList.Clear();
            }

            JArray array = JsonConvert.DeserializeObject<JArray>(product.SKUDetail);
            foreach (var item in array)
            {
                JObject obj = new JObject();
                var json = JsonConvert.DeserializeObject<JObject>(item.ToString());
                var ps = json.Properties();
                JArray img = null;
                var name = "";
                var name1 = "";
                foreach (var p in ps)
                {
                    if (p.Name == "Pjijiamuban" || p.Name == "CostPrice")
                    {
                        continue;
                    }

                    if (dic.ContainsKey(p.Value.ToString()))
                    {
                        img = dic[p.Value.ToString()];
                    }
                    if (p.Name == "special_price")
                    {
                        obj.Add("sales_price", (double)p.Value);
                    }
                    if (p.Name == "price")
                    {
                        obj.Add("retail_price", p.Value);
                    }
                    else
                    {
                        if (!obj.ContainsKey(p.Name))
                        {
                            obj.Add(p.Name, p.Value);
                        }
                    }
                    if (p.Name == "SellerSku")
                    {
                        name = p.Value.ToString();
                        string[] strs = name.Split('-');

                        name1 = strs.Count() == 3 ? strs[0] + "-" + strs[2] + "-" + strs[1] : "";
                    }
                    if (dic.ContainsKey(name))
                    {
                        img = dic.ContainsKey(name) ? dic[name] : dic[name1];
                        product.ChildSku = product.ChildSku == "" ? (dic.ContainsKey(name) ? name : name1) : ("," + (dic.ContainsKey(name) ? name : name1));
                    }
                    obj.Remove("special_price");
                }

                obj.Add("published_date", DateTime.Now.ToString());
                obj.Add("special_from_date", product.Lazadapromstart);
                obj.Add("special_to_date", product.Lazadapromend);
                obj.Add("tax_class", product.Lazadatax);

                obj.Add("Images", new JObject { { "Image", img } });
                jarray3.Add(obj);
            }

            JObject jobject11 = new JObject
            {
                { "Sku", jarray3 }
            };
            ((JArray)jobject3["Skus"]).RemoveAll();
            ((JArray)jobject3["Skus"]).Add(jobject11);
            //product.ChildSku = string.Join(",", jarray4);
            return jobject;
            #endregion

        }

        public JObject UpdateProduct(string productxml)
        {
            bool isError = false;
            LazadaRequestClient client = new LazadaRequestClient();
            var dic = new Dictionary<string, string>();
            dic.Add("payload", productxml);
            var jsondata = new JObject();
            jsondata = client.UpdateGetResponseToken(Constants.LAZADA_UpdateProduct, out isError, dic);
            return jsondata;
        }

        public JObject CreateProduct(string productxml, out bool isError)
        {
            LazadaRequestClient client = new LazadaRequestClient();
            var dic = new Dictionary<string, string>();
            dic.Add("payload", productxml);
            var jsondata = new JObject();
            if (GlobalUserClass.SiteId == 9)
            {
                jsondata = client.GetResponseToken("/product/global/create", out isError, dic);///product/global/create
            }
            else
            {
                jsondata = client.GetResponseToken(Constants.LAZADA_CreateProduct, out isError, dic);
            }
            return jsondata;
        }

        public JObject GetCategoryTree()
        {
            if (SystemSoleEntity.CategoryObject == null)
            {
                LazadaRequestClient client = new LazadaRequestClient();
                var dic = new Dictionary<string, string>();
                SystemSoleEntity.CategoryObject = client.GetResponse(Constants.LAZADA_GetCategoryTree, "Get");
            }
            return SystemSoleEntity.CategoryObject;
        }

        /// <summary>
        /// 获取类目
        /// </summary>
        /// <param name="_paradic"></param>
        /// <param name="_filePath"></param>
        /// <returns></returns>
        public JObject GetCategroyWhenUpImg(Dictionary<string, string> _paradic, Dictionary<string, string> _filePath = null)
        {
            string result;
            try
            {
                string text = "http://api.lazada.com.my/rest/image/upload";
                Dictionary<string, string> dictionary = InitRequestParamDic(_paradic);
                string str2 = DateTime.Now.Ticks.ToString("X");
                HttpWebRequest httpWebRequest3 = (HttpWebRequest)WebRequest.Create(text);
                httpWebRequest3.Method = "POST";
                httpWebRequest3.ContentType = "multipart/form-data;charset=utf-8;boundary=" + str2;
                Stream requestStream2 = httpWebRequest3.GetRequestStream();
                byte[] bytes2 = Encoding.UTF8.GetBytes("\r\n--" + str2 + "\r\n");
                byte[] bytes3 = Encoding.UTF8.GetBytes("\r\n--" + str2 + "--\r\n");
                string format = "Content-Disposition:form-data;name=\"{0}\"\r\nContent-Type:text/plain\r\n\r\n{1}";
                foreach (KeyValuePair<string, string> keyValuePair in dictionary)
                {
                    string s2 = string.Format(format, keyValuePair.Key, keyValuePair.Value);
                    byte[] bytes4 = Encoding.UTF8.GetBytes(s2);
                    requestStream2.Write(bytes2, 0, bytes2.Length);
                    requestStream2.Write(bytes4, 0, bytes4.Length);
                }
                string format2 = "Content-Disposition:form-data;name=\"{0}\";filename=\"{1}\"\r\nContent-Type:{2}\r\n\r\n";
                foreach (KeyValuePair<string, string> keyValuePair2 in _filePath)
                {
                    string key = keyValuePair2.Key;
                    string value = keyValuePair2.Value;
                    bool flag3 = string.IsNullOrEmpty(value) || !File.Exists(value);
                    if (!flag3)
                    {
                        FileInfo fileInfo = new FileInfo(value);
                        string s3 = string.Format(format2, key, fileInfo.Name, "application/octet-stream");
                        byte[] bytes5 = Encoding.UTF8.GetBytes(s3);
                        requestStream2.Write(bytes2, 0, bytes2.Length);
                        requestStream2.Write(bytes5, 0, bytes5.Length);
                        using (BufferedStream bufferedStream = new BufferedStream(fileInfo.OpenRead()))
                        {
                            byte[] array = new byte[4096];
                            int count;
                            while ((count = bufferedStream.Read(array, 0, array.Length)) > 0)
                            {
                                requestStream2.Write(array, 0, count);
                            }
                        }
                    }
                }
                requestStream2.Write(bytes3, 0, bytes3.Length);
                requestStream2.Close();
                HttpWebResponse u3 = (HttpWebResponse)httpWebRequest3.GetResponse();
                string text2 = ReadResponse(u3);
                result = text2;
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                result = null;
            }
            return result == null ? null : (JObject)JsonConvert.DeserializeObject(result);
        }

        /// <summary>
        /// 根据已经选择的类目，加载类目相关的属性
        /// </summary>
        /// <param name="leafId"></param>
        /// <returns></returns>
        public JObject GetCategoryAttr(string leafId)
        {
            LazadaRequestClient client = new LazadaRequestClient();
            var dic = new Dictionary<string, string>();
            dic.Add("primary_category_id", leafId);
            var jsondata = client.GetResponse("/category/attributes/get", "GET", dic);
            return jsondata;
        }

        /// <summary>
        /// 获取Lazada的Brand
        /// </summary>
        /// <param name="textBox"></param>
        public JObject GetBrands()
        {
            LazadaRequestClient client = new LazadaRequestClient();
            var dic = new Dictionary<string, string>();
            dic.Add("offset", "0");
            dic.Add("limit", "1000");
            var jsondata = client.GetResponse("/brands/get", "GET", dic);
            return jsondata;
        }
        private string CGHP68GFqi(string a, string b, bool c = true)
        {
            byte[] array;
            if (c)
            {
                HMACSHA256 hmacsha = new HMACSHA256(Encoding.UTF8.GetBytes(b));
                array = hmacsha.ComputeHash(Encoding.UTF8.GetBytes(a));
            }
            else
            {
                HMACMD5 hmacmd = new HMACMD5(Encoding.UTF8.GetBytes(b));
                array = hmacmd.ComputeHash(Encoding.UTF8.GetBytes(a));
            }
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < array.Length; i++)
            {
                stringBuilder.Append(array[i].ToString("X2"));
            }
            return stringBuilder.ToString();
        }

        /// <summary>
        /// 旧版的上传图片
        /// </summary>
        /// <param name="imgPath"></param>
        /// <returns></returns>
        public string UpLoadImageNew(string imgPath)
        {
            ////切换分支测试
            var timestamp = (DateTime.UtcNow.Ticks - new DateTime(1970, 1, 1, 0, 0, 0, 0).Ticks) / 10000L;
            Dictionary<string, string> _paradic = new Dictionary<string, string>();
            var key = Constants.LAZADA_APPKEY;
            var token = Constants.LAZADA_ACCESSTOKEN;
            _paradic.Add("app_key", key);
            _paradic.Add("access_token", token);
            _paradic.Add("sign_method", "sha256");
            _paradic.Add("timestamp", timestamp.ToString());
            var secret = Constants.LAZADA_APPSECRET;
            //{/ image / uploadaccess_token50000200803cDOe16e33282sEoEw1QyZa6I2DHtAsul9dErgNwVFlgvG3X9OKlapp_key100755sign_methodsha256timestamp1562902653322}
            var str = $"/image/uploadaccess_token{token}app_key{key}sign_methodsha256timestamp{timestamp.ToString()}";
            _paradic.Add("sign", CGHP68GFqi(str, secret, true));

            string str2 = DateTime.Now.Ticks.ToString("X");
            HttpWebRequest httpWebRequest3 = (HttpWebRequest)WebRequest.Create(new SiteChangeHelp().GetPushLazadaUrl() + "/image/upload");
            httpWebRequest3.Method = "POST";
            httpWebRequest3.ContentType = $"multipart/form-data;charset=utf-8;boundary={str2}";
            Stream requestStream2 = httpWebRequest3.GetRequestStream();
            byte[] bytes2 = Encoding.UTF8.GetBytes("\r\n--" + str2 + "\r\n");
            byte[] bytes3 = Encoding.UTF8.GetBytes("\r\n--" + str2 + "--\r\n");
            string format = "Content-Disposition:form-data;name=\"{0}\"\r\nContent-Type:text/plain\r\n\r\n{1}";
            foreach (KeyValuePair<string, string> keyValuePair in _paradic)
            {
                string s2 = string.Format(format, keyValuePair.Key, keyValuePair.Value);
                byte[] bytes4 = Encoding.UTF8.GetBytes(s2);
                requestStream2.Write(bytes2, 0, bytes2.Length);
                requestStream2.Write(bytes4, 0, bytes4.Length);
            }
            string format2 = "Content-Disposition:form-data;name=\"{0}\";filename=\"{1}\"\r\nContent-Type:{2}\r\n\r\n";
            if (File.Exists(imgPath))
            {
                FileInfo fileInfo = new FileInfo(imgPath);
                string s3 = string.Format(format2, "image", fileInfo.Name, "application/octet-stream");
                byte[] bytes5 = Encoding.UTF8.GetBytes(s3);
                requestStream2.Write(bytes2, 0, bytes2.Length);
                requestStream2.Write(bytes5, 0, bytes5.Length);
                using (BufferedStream bufferedStream = new BufferedStream(fileInfo.OpenRead()))
                {
                    byte[] array = new byte[4096];
                    int count;
                    while ((count = bufferedStream.Read(array, 0, array.Length)) > 0)
                    {
                        requestStream2.Write(array, 0, count);
                    }
                }
            }

            requestStream2.Write(bytes3, 0, bytes3.Length);
            requestStream2.Close();
            HttpWebResponse u3 = (HttpWebResponse)httpWebRequest3.GetResponse();
            string result = string.Empty;
            using (Stream responseStream = u3.GetResponseStream())
            {
                using (StreamReader streamReader3 = new StreamReader(responseStream, Encoding.UTF8))
                {
                    result = streamReader3.ReadToEnd();
                }
            }
            var obj = JsonConvert.DeserializeObject<JObject>(result);
            if (obj == null)
                return imgPath;
            try {
                return obj["data"]["image"]["url"].ToString();
            }
            catch
            {
                return imgPath;
            }
        }

        /// <summary>
        /// 上传图片
        /// </summary>
        /// <param name="imgPath"></param>
        /// <returns></returns>
        public JObject UpLoadImage(string imgPath)
        {
            LazadaRequestClient client = new LazadaRequestClient();
            var jsondata = client.UploadImage(imgPath);
            return jsondata;
        }
        /// <summary>
        /// 六合一发布
        /// </summary>
        public void LazadaPublish_Six()
        {
            var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            SystemSoleEntity.GetMainWinModel().InitModel("发布产品", list.Count);
            Task.Run(() =>
            {
                foreach (var product in list)
                {
                    try
                    {
                        product.Pcancsv = "开始检查数据...";
                        Thread.Sleep(100);
                        CheckAndPush(product);
                    }
                    catch (Exception ex)
                    {
                        SystemSoleEntity.GetMainWinModel().IbulkErrowCount++;
                        new LogOutput.LogTo().WriteErrorLine("发布产品出错：" + product.Porigimgsurl + "///" + ex.Message);
                    }
                    SystemSoleEntity.GetMainWinModel().Ipbvalue += SystemSoleEntity.GetMainWinModel().TaskAdd;
                    SystemSoleEntity.GetMainWinModel().TaskRunCount++;
                }
            });
        }
        private void CheckAndPush(Product product)
        {
            //if (product.Pstatetype == "1")
            //{
            //    product.Pcancsv = "已经发布";
            //    return;
            //}
            if ((product.SPUEditError != null && product.SPUEditError != string.Empty) ||
            (product.DetailsEditError != null && product.DetailsEditError != string.Empty) ||
            (product.UploadImgError != null && product.UploadImgError != string.Empty))
            {
                product.Pcancsv = "存在异常";
                return;
            }
            if (Convert.ToDateTime(product.Lazadapromstart) <= DateTime.Now)
            {
                product.Pcancsv = "促销开始时间错误";
                return;
            }
            if (Convert.ToDateTime(product.Lazadapromend) <= Convert.ToDateTime(product.Lazadapromstart))
            {
                product.Pcancsv = "促销结束时间错误";
                return;
            }
            var imgs = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var img in imgs)
            {
                if (!img.StartsWith("http"))
                {
                    product.Pcancsv = "有描述图片没上传";
                    return;
                }
            }
            if (product.SKUDetail == string.Empty || product.SKUDetail == null)
            {
                product.Pcancsv = "SKU属性缺失,请去SPU界面重新保存";
                return;
            }
            product.Pcancsv = "准备发布...";
            PushProduct(product);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pageModel"></param>
        /// <param name="mode">Returns the products with the status matching this parameter.Possible values are all, live, inactive, deleted, image-missing, pending, rejected, sold-out. Mandatory.
        /// 返回状态与此参数匹配的产品。 可能的值包括全部，实时，不活动，已删除，图像丢失，待处理，已拒绝，已售罄。强制性。
        /// </param>
        public JObject GetOnLineProduct(Dictionary<string, string> dic)
        {
            LazadaRequestClient client = new LazadaRequestClient();
            var jsondata = client.GetResponseToken(Constants.LAZADA_GetProducts, "Get", dic);
            return jsondata;
        }

        public JObject PushUpdate(string productxml)
        {
            bool isError = false;
            LazadaRequestClient client = new LazadaRequestClient();
            var dic = new Dictionary<string, string>();
            dic.Add("payload", productxml);
            var jsondata = new JObject();
            jsondata = client.UpdateGetResponseToken(Constants.LAZADA_UpdatePriceQuantity, out isError, dic);
            return jsondata;
        }

        /// <summary>
        /// 批量更新SKU 价格，活动时间，库存（20条）
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        public JObject UpdatePriceQuantity(List<ChildSKU> collection)
        {
            JObject jobject = UpdatePriceQuantity_CreateXML(collection);
            string text14 = JsonConvert.SerializeObject(jobject);
            string outerXml = JsonConvert.DeserializeXmlNode(text14).OuterXml;
            string u = "<?xml version = \"1.0\" encoding = \"UTF-8\" ?> " + outerXml;
            try
            {
                MySoundPlay.PlayPushMusic();
            }
            catch { }
            return PushUpdate(u); ;
        }

        /// <summary>
        /// 生成XML
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        private JObject UpdatePriceQuantity_CreateXML(List<ChildSKU> collection)
        {
            JObject jobject = new JObject();
            JObject jobject1 = new JObject();
            JObject jobject2 = new JObject();
            JArray jArray = new JArray();
            jobject["Request"] = jobject1;
            jobject1["Product"] = jobject2;

            foreach (var item in collection)
            {
                JObject obj = new JObject();
                obj["SellerSku"] = item.SellerSku;
                obj["Quantity"] = item.Quantity;
                obj["Price"] = item.Price;
                obj["SalePrice"] = item.Special_price;
                obj["SaleStartDate"] = item.Special_from_time;
                obj["SaleEndDate"] = item.Special_to_time;
                jArray.Add(obj);
            }
            JObject jobject3 = new JObject
            {
                { "Sku", jArray }
            };
            jobject2["Skus"] = jobject3;
            return jobject;
        }
    }
}
