﻿using LAZADA;
using Logic.BasicInfo;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logic.Platform
{
    /// <summary>
    /// 蜂鸟接口
    /// </summary>
    public class HummingbirdCore
    {
        /// <summary>
        /// 上传发布成功的产品到服务器
        /// 返回的JSON里应该包含服务器为他创建的ID，保存
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UploadPorductInfo(Product product,string strShopID)
        {
            //var obj = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(product));

            JObject jObject = new JObject()
            {
                { "siteType",1},
                { "region",GlobalUserClass.SiteId},
                { "title",product.Pnewtitle},
                { "mainSku",product.Pidprefix+product.SKUNumber},
                { "mainPicture",product.Pimgurl},
                { "remark","" },//useid="+GlobalUserClass.GetHaiWangModel().UserID+",LazadaItemid="+product.LazadaItemid+",TitleTaskId=["+product.TitleTaskId+"],PicTaskId=["+product.PicTaskId+"],CreateTime="+DateTime.Now.ToString()},
                { "from",product.Pfromtype},
                { "linkUrl",product.Poriglink},
                { "price",Convert.ToDecimal(product.Porigprice)},
                { "weight",product.Pweight},
                { "currency","CNY"},
                { "childSku",product.ChildSku},
                { "category",product.Lazadacategoryid},
                { "spuData",JsonConvert.SerializeObject(product) },
                { "shopId",Convert.ToInt64(strShopID)},
            };
            var jsonData = new MyHttpClient().PostDataWithToken(Constants.HB_ClientGatewayUrl + Constants.HB_API_SPUCREATE, jObject);
            if (jsonData == null) return false;
            if (Convert.ToBoolean(jsonData["success"]))
            {
                product.ServerID = Convert.ToString(jsonData["result"]["id"]);
            }
            return false;
        }

        /// <summary>
        /// 更新店铺名称到服务器
        /// 返回的JSON里应该包含服务器为他创建的ID，保存
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool UploadShopName(string Name, string strShopID)
        {
            //var obj = JsonConvert.DeserializeObject<JObject>(JsonConvert.SerializeObject(product));

            JObject jObject = new JObject()
            {
                { "id",Convert.ToInt64(strShopID)},
                { "shopName",Name},
                { "remark",""},
            };
            var jsonData = new MyHttpClient().PutDataWithToken(Constants.HB_ClientGatewayUrl + "/AuthorizedShop/UpdateShopName", jObject);
            if (jsonData == null) return false;
            if (jsonData["success"].ToString() == "True")
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// 获取产品信息列表
        /// </summary>
        /// <param name="token"></param>
        /// <param name="siteID"></param>
        /// <param name="pidprefix"></param>
        /// <param name="titleKey"></param>
        /// <param name="pageSize"></param>
        /// <param name="currentPage"></param>
        /// <returns></returns>
        public JObject GetUploadProduct(string token, int siteID, string pidprefix, string titleKey, int pageSize, int currentPage)
        {
            JObject jObject = new JObject()
            {
                { "siteType",1},
                { "region",siteID},
                { "mainSku",pidprefix},
                { "title",titleKey},
                { "pageIndex",currentPage},
                { "pageSize",pageSize},
            };
            var jsonData = new MyHttpClient().PostDataWithToken(Constants.HB_ClientGatewayUrl + Constants.HB_API_SPUPAGED, jObject, token);
            return jsonData;
        }

        /// <summary>
        /// 获取发布产品的明细
        /// </summary>
        /// <param name="token"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public JObject GetProductDetail(string token, string id)
        {
            List<KeyValuePair<string, string>> pairs = new List<KeyValuePair<string, string>>() {
                new KeyValuePair<string, string>("id",id),
            };
            var jsonData = new MyHttpClient().GetWithToken(Constants.HB_ClientGatewayUrl + Constants.HB_API_SPUGET, pairs, token);
            return jsonData;
        }

        /// <summary>
        /// 获取用户当前积分
        /// </summary>
        /// <returns></returns>
        public JObject GetPoints()
        {
            var jsonData = new MyHttpClient().GetWithToken(Constants.HB_ClientGatewayUrl + Constants.HB_API_GETPOINTS);
            return jsonData;
        }

        /// <summary>
        /// 获取新采集的链接
        /// </summary>
        /// <returns></returns>
        public JObject GetNewLinks()
        {
            List<KeyValuePair<string, string>> pairs = new List<KeyValuePair<string, string>>() {
                new KeyValuePair<string, string>("SiteType","1"),
                new KeyValuePair<string, string>("Region",GlobalUserClass.SiteId.ToString()),
            };
            var jsonData = new MyHttpClient().GetWithToken(Constants.HB_ClientGatewayUrl + Constants.HB_API_GETNEWLINKS, pairs);
            return jsonData;
        }

        /// <summary>
        /// 扣除积分
        /// 上传当前手动链接，成功返回TRUE，失败返回FALSE，接口自动扣除当前用户积分
        /// </summary>
        /// <param name="link"></param>
        /// <param name="from"></param>
        /// <returns></returns>
        public bool CheckPoint(string link, string from)
        {
            JObject jObject = new JObject() {
                { "linkUrl",link},
                { "from",from},
            };
            var jsonData = new MyHttpClient().PostDataWithToken(Constants.HB_ClientGatewayUrl + Constants.HB_API_CREATE, jObject);
            if (jsonData == null)
                return false;
            if (!Convert.ToBoolean(jsonData["success"]))
                return false;
            return true;
        }

        /// <summary>
        /// 查询历史采集数据
        /// </summary>
        /// <param name="jObject"></param>
        /// <returns></returns>
        public JObject GetHistoryLinks(JObject jObject)
        {
            var jsonData = new MyHttpClient().PostDataWithToken(Constants.HB_ClientGatewayUrl + Constants.HB_API_COLLECTHISTORY, jObject);
            return jsonData;
        }
    }
}
