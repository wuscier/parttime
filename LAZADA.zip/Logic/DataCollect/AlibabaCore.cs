﻿using LAZADA;
using Logic.BasicInfo;
using Logic.Platform;
using Logic.PriceTemplate;
using Logic.Translation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Logic.DataCollect
{

    /// <summary>
    /// 1688数据采集业务类
    /// </summary>
    public class AlibabaCore : BaseDataCollectCore
    {
        //string token_1688 = "1fbce612-cb9f-45ac-9789-f63722f2d7b2";
        /// <summary>
        /// 采集产品数据
        /// </summary>
        /// <param name="product"></param>
        public override bool CollectProduct(Product product)
        {
            try
            {
                UpdatePlocalimgpath(product);
                if (SyncProductListPushed(product.Ppid))
                {
                    //跨境场景获取商品详情
                    var jsondata = GetProductInfo(product.Ppid);
                    if (jsondata == null)
                    {
                        product.Pstate = "采集失败";
                        return false;
                    }
                    else
                    {
                        if (Convert.ToString(jsondata["productInfo"]["status"]) == "published" || Convert.ToString(jsondata["productInfo"]["status"]) == "online")
                        {
                            product.Pstate = "正在采集";
                            //分析采集下来的数据
                            try
                            {
                                UpdateCollectProductInfo(jsondata, product);
                            }
                            catch (Exception ex)
                            {
                                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                                product.Pstate = "采集失败B";
                                return false;
                            }
                        }
                        else if (Convert.ToString(jsondata["productInfo"]["status"]) == "-4" || Convert.ToString(jsondata["productInfo"]["status"]) == "member expired")
                        {
                            product.Pstate = "产品下架";
                            return false;
                        }
                        else if (Convert.ToString(jsondata["productInfo"]["status"]) == "-4")
                        {
                            product.Pstate = "网络不畅";
                            return false;
                        }
                        else
                        {
                            product.Pstate = "采集出错B";
                            return false;
                        }
                    }
                }
                else
                {
                    product.Pstate = "采集失败";
                    return false;
                }
                return true;
            }
            catch
            {
                product.Pstate = "采集失败";
                return false;
            }

        }

        /// <summary>
        /// 检查更新下载地址
        /// </summary>
        /// <param name="product"></param>
        private void UpdatePlocalimgpath(Product product)
        {
            string saveFolder = "";
            if (product.Plocalimgpath != null && product.Plocalimgpath.Trim() != string.Empty)
            {
                try
                {
                    string newdir = System.IO.Path.GetDirectoryName(product.Plocalimgpath);
                    if (!System.IO.Directory.Exists(newdir))
                    {
                        Directory.CreateDirectory(newdir);
                    }
                    saveFolder = newdir;
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
            }
            else
            {
                saveFolder = Constants.DEFAULTIMAGESAVEPATH;
            }
            product.Plocalimgpath = saveFolder + "阿里下载" + product.Number.ToString() + "-TSC" + DateTime.Now.ToString("MMddhhmmss") + PublicFunctions.CreateRandomCode();
        }

        /// <summary>
        /// 跨境场景下将商品加入铺货列表
        /// 只有加入店铺以后，才能通过1688的接口采集到当前商品的信息
        /// </summary>
        /// <returns></returns>
        private bool SyncProductListPushed(string pid)
        {
            //globalUser.RefreshAli1688Token();
            Dictionary<string, string> dictionary = new Dictionary<string, string>
            {
                { "productIdList", "[" + pid + "]" },
                { "access_token", Constants.Ali1688_ACCESSTOKEN }
            };
            string text = Constants.ALIBABA_OPEN_URL;
            string text2 = Constants.ALIBABA_OPENAPI_PUSHED + Constants.ALIBABA_ID;
            string text3 = ChangeNewUrl(text2, dictionary);
            string requestUriString = string.Concat(new string[]
                {
                    text,
                    text2,
                    "?productIdList=[",
                    pid,
                    "]&access_token=",
                    Constants.Ali1688_ACCESSTOKEN,
                    "&_aop_signature=",
                    text3
                });
            new LogOutput.LogTo().WriteLine(Constants.Ali1688_ACCESSTOKEN);
            var result = new MyHttpClient().SendResponseAsync(HttpMethod.Get, requestUriString).Result;
            try
            {
                var jsondata = (JObject)JsonConvert.DeserializeObject(result);
                if ((bool)jsondata["result"]["success"])
                    return true;
                return false;
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message); 
                result = new MyHttpClient().SendResponseAsync(HttpMethod.Get, requestUriString).Result;
                try
                {
                    var jsondata = (JObject)JsonConvert.DeserializeObject(result);
                    if ((bool)jsondata["result"]["success"])
                        return true;
                    return false;
                }
                catch (Exception ex1)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex1.Message);
                    return false;
                }
            }

        }

        /// <summary>
        /// 通过1688的接口，采集商品的数据
        /// </summary>
        /// <param name="pid"></param>
        /// <returns></returns>
        private JObject GetProductInfo(string pid)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>
            {
                { "productId", pid },
                { "access_token", Constants.Ali1688_ACCESSTOKEN }
            };
            string text = Constants.ALIBABA_OPEN_URL;
            string text2 = Constants.ALIBABA_OPENAPI_GETPRODUCT + Constants.ALIBABA_ID;
            string text3 = ChangeNewUrl(text2, dictionary);
            string requestUriString = string.Concat(new string[]
                {
                    text,
                    text2,
                    "?productId=",
                    pid,
                    "&access_token=",
                    Constants.Ali1688_ACCESSTOKEN,
                    "&_aop_signature=",
                    text3
                });
            var result = new MyHttpClient().SendResponseAsync(HttpMethod.Get, requestUriString).Result;
            try
            {
                return (JObject)JsonConvert.DeserializeObject(result);

            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                return null;
            }
        }

        /// <summary>
        /// 更新采集的数据
        /// </summary>
        /// <param name="jsonData"></param>
        /// <param name="product"></param>
        private void UpdateCollectProductInfo(JObject jsonData, Product product)
        {
            var baidu = new BaiDuCore();
            var ptc = new PriceTemplateCore();
            var priceTemplate = ptc.GetPriceTemplate(product.Pjisangongshi);
            if (jsonData["productInfo"]["mainVedio"] != null)
            {
                product.Video = jsonData["productInfo"]["mainVedio"].ToString();
            }
            string title = jsonData["productInfo"]["subject"].ToString().ToUpper().
                Replace("爆款", "").Replace("热卖", "").Replace("热销", "").Replace("一件代发", "").Replace("一件代发", "").Replace("定制", "").
                Replace("订制", "").Replace("批发", "").Replace("厂家直销", "").Replace("欧美", " ").Replace("速卖通", " ").Replace("亚马逊", "").
                Replace("WISH", "").Replace("EBAY", "").Replace("淘宝", "").Replace("外贸", "").Replace("货源", "").Replace("经典", "").
                Replace("【", "").Replace("】", "").Replace(" ", "").Trim();  //中文的;
            //string[] jtitles = title.Split(new char[] { '_', '-' }, StringSplitOptions.RemoveEmptyEntries);
            //if (jtitles.Length > 2)
            //{
            //    title = jtitles[1];

            //}
            product.Porigtitle = Regex.Replace(title, @"([a-zA-Z]+[0-9]+)|([0-9]{5})", " ");
            string jweight = Constants.DEFAULTWEIGHT;
            if (jsonData["productInfo"]["shippingInfo"] != null && jsonData["productInfo"]["shippingInfo"]["unitWeight"] != null)
            {
                jweight = jsonData["productInfo"]["shippingInfo"]["unitWeight"].ToString();
            }
            if (jweight == "null" || jweight == "0") jweight = Constants.DEFAULTWEIGHT;
            string jprice = jsonData["productInfo"]["saleInfo"]["priceRanges"][0]["price"].ToString();
            if (jprice.Contains("$"))
                jprice = (Convert.ToDouble(jprice.Replace("$", "")) * 6.9476).ToString();

            //product.Pimgurl = "";
            product.Pprofit = Convert.ToDouble(jsonData["productInfo"]["saleInfo"]["priceRanges"][0]["price"]).ToString("#");
            product.Plowestprice = 0.0d.ToString("#");
            product.Porigtitle = title;
            product.Pnewtitle = baidu.TransTitle_ChineseToEnglish(title);
            product.PnewtitleX = baidu.upFirstCharWithSpaceX((GlobalUserClass.GetHaiWangModel().IsAuthorized ? new HaiWangCore().TranslateZhToSiteDefaultResponse(title) : new ALiCore().ChangeZhToSiteDefaultLangauge(title)));
            product.Pweight = (Convert.ToDouble(jweight) < 5 ? Convert.ToDouble(jweight) * 1000 : Convert.ToDouble(jweight)).ToString("#");
            product.Lazadapackageweight = (Convert.ToDouble(product.Pweight) + 100).ToString("#");
            product.Porigprice = (Convert.ToDouble(jprice) + 0.4).ToString("#");
            product.Pallsoldcount = "";
            product.Plinkcreatedate = "";
            product.Peditdate = DateTime.Now.ToString();
            ///计算计价模板相关的产品费用
            ptc.CalcProductCost(priceTemplate, product, Convert.ToDouble(jprice));
            if (jsonData["productInfo"]["attributes"] != null && jsonData["productInfo"]["attributes"].HasValues)
            {
                try
                {
                    JArray jatrr = (JArray)(jsonData["productInfo"]["attributes"]);

                    string tdesc = "";

                    Dictionary<string, string> needAttr = new Dictionary<string, string>();

                    // List<string> needAtrr = new List<string>();                               

                    for (int ia = 0; ia < jatrr.Count; ia++)
                    {
                        string cattrname = jatrr[ia]["attributeName"].ToString();
                        if (needAttr.ContainsKey(cattrname))
                        {
                            needAttr[cattrname] = needAttr[cattrname] + " , " + jatrr[ia]["value"].ToString();
                        }
                        else
                        {
                            needAttr.Add(cattrname, jatrr[ia]["value"].ToString());

                        }

                    }

                    foreach (KeyValuePair<string, string> kv in needAttr)
                    {
                        tdesc += kv.Key + " : " + kv.Value + " ; \r\n";
                    }

                    if (!String.IsNullOrEmpty(tdesc.Trim()))
                    {
                        product.Porigattribute = tdesc;
                        product.Lazadahighlight = tdesc.Replace("\n", "<br/>");
                    }


                    needAttr = null;

                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
            }
            DownImages(jsonData, product);
        }

        /// <summary>
        /// 保存图片
        /// </summary>
        /// <param name="jsondata"></param>
        /// <param name="product"></param>
        private void DownImages(JObject jsondata, Product product)
        {
            //声明图片保存数组，用于保存图片的本地路径和远程路径，[,0]表示远程路径[,1]表示本地路径
            string[,] imageArr = null;
            //声明图片保存数组，用于保存图片的本地路径和远程路径，[,0]表示远程路径[,1]表示本地路径
            string[,] attrArr = null;
            //用于保存SKU 属性值
            List<string> attrList = null;
            //用于保存SKU 属性图片
            List<string> sizeList = null;
            Dictionary<string, string> dic = null;
            List<string> colorList = null;
            List<string> downImageList = null;
            try
            {
                ///产品图片信息
                if (jsondata["productInfo"] != null)
                {
                    JArray jarray = (JArray)jsondata["productInfo"]["image"]["images"];
                    if (jarray.Count > 0)
                    {
                        imageArr = new string[jarray.Count, 2];
                        for (int i = 0; i < jarray.Count; i++)
                        {
                            imageArr[i, 0] = jarray[i].ToString().StartsWith("http") ? (jarray[i].ToString()) : ("http://cbu01.alicdn.com/" + jarray[i].ToString());
                            imageArr[i, 1] = product.Plocalimgpath + "\\" + (i < 5 ? ("Azt" + i.ToString("0#") + ".jpg") : ("Czt" + i.ToString("0#") + ".jpg"));
                        }
                        product.Pimgurl = imageArr[0, 0];
                    }
                }
            }
            catch
            {
                product.Pstate = "采集失败A";
            }
            try
            {
                ///获取SKU信息
                if (jsondata["productInfo"]["skuInfos"] != null)
                {
                    attrList = new List<string>();
                    sizeList = new List<string>();
                    dic = new Dictionary<string, string>();
                    JArray jarray = (JArray)jsondata["productInfo"]["skuInfos"];
                    for (int i = 0; i < jarray.Count; i++)
                    {
                        if (jarray[i]["attributes"][0]["attributeValue"] != null)
                        {
                            var attr = jarray[i]["attributes"][0]["attributeValue"].ToString().Trim();
                            if (!attrList.Contains(attr))
                            {
                                attrList.Add(attr);
                                if (jarray[i]["attributes"][0]["skuImageUrl"] != null)
                                {
                                    var picUrl = jarray[i]["attributes"][0]["skuImageUrl"].ToString();
                                    picUrl = picUrl.StartsWith("http") ? picUrl : string.Format("http://cbu01.alicdn.com/" + picUrl);
                                    dic.Add(attr, picUrl);
                                }
                                else
                                {
                                    dic.Add(attr, "");
                                }
                            }
                        }
                        if (((JArray)jarray[i]["attributes"]).Count > 1)
                        {
                            if (jarray[i]["attributes"][1]["attributeValue"] != null)
                            {
                                var attr2 = jarray[i]["attributes"][1]["attributeValue"].ToString();
                                if (!attrList.Contains(attr2))
                                {
                                    attrList.Add(attr2);
                                    if (jarray[i]["attributes"][1]["skuImageUrl"] != null)
                                    {
                                        var picUrl = jarray[i]["attributes"][1]["skuImageUrl"].ToString();
                                        picUrl = picUrl.StartsWith("http") ? picUrl : string.Format("http://cbu01.alicdn.com/" + picUrl);
                                        dic.Add(attr2, picUrl);
                                    }
                                    else
                                    {
                                        dic.Add(attr2, "");
                                    }
                                }
                                if (!sizeList.Contains(attr2))
                                {
                                    sizeList.Add(attr2);
                                }
                            }
                        }
                    }
                    foreach (var item in sizeList)
                    {
                        if (attrList.Contains(item))
                        {
                            attrList.Remove(item);
                        }
                        if (dic.Keys.Contains(item))
                        {
                            dic.Remove(item);
                        }
                    }
                    if (dic.Count > 0)
                    {
                        attrArr = new string[dic.Count, 4];
                        colorList = new List<string>();
                        int arrIndex = -1;
                        foreach (var item in dic)
                        {
                            arrIndex++;
                            attrArr[arrIndex, 0] = item.Value;
                            var input = item.Key.Replace("色", "").Replace("的", "").Replace("款", "").Replace("如图", "").Replace("图片", "").Replace("图", "").Trim();
                            var color = Regex.Replace(input, "[^\\u4E00-\\u9FFFA-Za-z0-9\\s]+", "").Trim();
                            var enColor = ColorMatch.GetENcolor3(color, colorList);
                            attrArr[arrIndex, 3] = enColor;
                            attrArr[arrIndex, 2] = color;
                            attrArr[arrIndex, 1] = string.Format(product.Plocalimgpath + "\\" + "Bys" + (arrIndex + 1).ToString("0#") + attrArr[arrIndex, 2] + (enColor == "" ? "" : ("_" + enColor)) + ".jpg");
                        }
                    }

                }
            }
            catch
            {
                product.Pstate = "采集失败B";
            }
            try
            {
                ///获取描述
                if (jsondata["productInfo"]["description"] != null)
                {
                    downImageList = new List<string>();
                    var data = GetData(product.Ppid);
                    var desc = jsondata["productInfo"]["description"].ToString();
                    desc = Regex.Replace(desc, "<a .*?</a>", "").Trim();
                    Regex regex = new Regex("<img\\b[^<>]*?\\bsrc[\\s\\t\\r\\n]*=[\\s\\t\\r\\n]*[\"']?[\\s\\t\\r\\n]*(?<imgUrl>[^\\s\\t\\r\\n\"'<>]*)[^<>]*?/?[\\s\\t\\r\\n]*>", RegexOptions.IgnoreCase);
                    MatchCollection matchCollection = regex.Matches((desc + data).Replace("\\", ""));
                    var imageIndex = 1;
                    foreach (object obj in matchCollection)
                    {
                        Match match = (Match)obj;
                        var imageUrl = match.Groups["imgUrl"].Value.Split(new char[] { '?' })[0].Trim().Replace("_.webp", "");
                        if (imageUrl.EndsWith(".jpg"))
                        {
                            imageUrl = (imageUrl.StartsWith("http") ? "" : "http:") + imageUrl;
                            if (!downImageList.Contains(imageUrl))
                            {
                                imageUrl += "?tnm=d" + imageIndex.ToString("0#");
                                imageIndex++;
                                downImageList.Add(imageUrl);
                            }
                        }
                    }
                    desc = Regex.Replace(desc, "<td.*?>", "<td>");
                    desc = Regex.Replace(desc, "<td>(.*?)</p>(.*?)</td>", "\t$1$2\t");
                    desc = desc.Replace("</div>", "\r\n").Replace("</p>", "\r\n").Replace("<tr>", "\r\n").Replace("<td>", "\t").Replace("</td>", "\t").Replace("&lsquo;", " ").Replace("&lrquo;", " ");
                    desc = Regex.Replace(desc, "<br.*?>", "\r\n");
                    desc = Regex.Replace(desc, "&[^\\s].*?;", " ");
                    desc = Regex.Replace(desc, "<.*?>", "").Trim();
                    string[] array = desc.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var item in array)
                    {
                        if (item.Trim() != "" && item.Trim().Length > 2 && !item.Contains("<img"))
                            product.Pdescription += "\r\n" + item;
                    }
                }
            }
            catch
            {
                product.Pstate = "采集失败C";
            }
            try
            {
                var p1 = product.Lazadahighlight;
                var p2 = product.Pdescription == null ? "" : product.Pdescription.Replace("\r", "").Replace("\r", "").Replace("\n", "<br/>");
                product.Lazadadescription = p1 + "<br/>" + p2;
                product.Psizes = GetPsizes(sizeList);
                product.Pcolors = GetProductPcolors(attrArr);
                product.Pcolormatch = GetPcolormatch(attrArr);
                product.Punfanyiimgs = GetPunfanyiimgs(attrArr);
                product.Pfanyidcolors = "";
                product.Porigimgsurl = GetPorigimgsurl(imageArr, attrArr, downImageList);
                product.Pstate = "基本数据采集OK";
            }
            catch
            {

                product.Pstate = "采集失败D";
            }
        }

        /// <summary>
        /// 将请求加密（阿里的加密KEY）成加密请求
        /// </summary>
        /// <param name="oldurl">旧的请求</param>
        /// <param name="paramDic">请求参数键值对</param>
        /// <returns></returns>
        private string ChangeNewUrl(string oldurl, Dictionary<string, string> paramDic)
        {
            //Constants.GETALIBABA_KEY();
            byte[] bytes = Encoding.UTF8.GetBytes(Constants.ALIBABA_KEY);
            List<string> list = new List<string>();
            foreach (KeyValuePair<string, string> keyValuePair in paramDic)
            {
                list.Add(keyValuePair.Key + keyValuePair.Value);
            }
            list.Sort();
            string text = oldurl;
            foreach (string str in list)
            {
                text += str;
            }
            HMACSHA1 hmacsha = new HMACSHA1(bytes);
            hmacsha.ComputeHash(Encoding.UTF8.GetBytes(text));
            byte[] hash = hmacsha.Hash;
            return BitConverter.ToString(hash).Replace("-", string.Empty).ToUpper();
        }


    }
}
