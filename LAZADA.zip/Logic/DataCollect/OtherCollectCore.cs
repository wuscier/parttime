﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LAZADA;
using Logic.Platform;
using Logic.PriceTemplate;
using Logic.Translation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;

namespace Logic.DataCollect
{
    public class OtherCollectCore : BaseDataCollectCore
    {
        public override bool CollectProduct(Product product)
        {
            try
            {
                UpdatePlocalimgpath(product);
                var jsondata = GetProductInfo(product.Poriglink);
                if (jsondata == null)
                {
                    product.Pstate = "采集失败";
                    return false;
                }
                else
                {
                    if (jsondata["error_code"] == null)
                    {
                        product.Pstate = "采集出错B";
                        return false;
                    }
                    else
                    {
                        if (Convert.ToString(jsondata["error_code"]) == "110")
                        {
                            product.Pstate = "采集失败请联系客服处理";
                            return false;
                        }
                        else
                        if (Convert.ToString(jsondata["error_code"]) == "114")
                        {
                            product.Pstate = "此链接采集不到数据！";
                            return false;
                        }
                        else
                        if (Convert.ToString(jsondata["error_code"]) == "-1")
                        {
                            product.Pstate = "网络不畅";
                            return false;
                        }
                        else
                        if (Convert.ToString(jsondata["error_code"]) == "-4")
                        {
                            product.Pstate = "产品下架";
                            return false;
                        }
                        else if (Convert.ToString(jsondata["error_code"]) == "0")
                        {
                            try
                            {
                                UpdateCollectProductInfo(jsondata, product);
                            }
                            catch (Exception ex)
                            {
                                new LogOutput.LogTo().WriteErrorLine(ex.Message);
                                product.Pstate = "采集失败B";
                                return false;
                            }
                        }
                        else
                        {
                            product.Pstate = "采集出错B";
                            return false;
                        }
                    }
                    return true;
                }
            }
            catch
            {
                product.Pstate = "采集失败";
                return false;
            }
        }

        /// <summary>
        /// 更新采集的数据
        /// </summary>
        /// <param name="jsonData"></param>
        /// <param name="product"></param>
        private void UpdateCollectProductInfo(JObject jsonData, Product product)
        {
            try
            {
                var baidu = new BaiDuCore();
                var ptc = new PriceTemplateCore();
                var priceTemplate = ptc.GetPriceTemplate(product.Pjisangongshi);
                //if (jsonData["productInfo"]["mainVedio"] != null)
                //{
                //    product.Video = jsonData["productInfo"]["mainVedio"].ToString();
                //}
                Regex reg = new Regex("[\u4e00-\u9fa5]+");
                string jtitle = reg.IsMatch(jsonData["data"]["product_details"]["name"].ToString(), 0) ? jsonData["data"]["product_details"]["name"].ToString().ToUpper()
                    .Replace("爆款", "").Replace("热卖", "").Replace("热销", "").Replace("一件代发", "").Replace("一件代发", "").Replace("定制", "").Replace("订制", "")
                    .Replace("批发", "").Replace("厂家直销", "").Replace("欧美", " ").Replace("速卖通", " ").Replace("亚马逊", "").Replace("WISH", "").Replace("EBAY", "")
                    .Replace("淘宝", "").Replace("外贸", "").Replace("货源", "").Replace("经典", "").Replace("【", "").Replace("】", "").Replace(" ", "").Trim() :
                    jsonData["data"]["product_details"]["name"].ToString().Replace("WISH", "").Replace("EBAY", "").Trim();  //中文的;
                                                                                                                            //jtitle = Regex.Replace(jtitle, @"([a-zA-Z]+[0-9]+)|([0-9]{5})", " ");
                string jweight = Constants.DEFAULTWEIGHT;
                //if (jsonData["productInfo"]["shippingInfo"] != null && jsonData["productInfo"]["shippingInfo"]["unitWeight"] != null)
                //{
                //    jweight = jsonData["productInfo"]["shippingInfo"]["unitWeight"].ToString();
                //}
                //if (jweight == "null" || jweight == "0") jweight = Constants.DEFAULTWEIGHT;
                //string jprice = jsonData["data"]["product_details"]["current_price"].ToString();
                string jprice = "";
                try
                {
                    if (product.Pfromtype == "SMT")
                        jprice = jsonData["data"]["product_details"].ToString().Contains("current_price") ? jsonData["data"]["product_details"]["current_price"].ToString() : null;
                    else
                        jprice = jsonData["data"]["product_details"].ToString().Contains("original_price") ? jsonData["data"]["product_details"]["original_price"].ToString() : null;
                    if (jprice == string.Empty || jprice == null)
                    {
                        try
                        {
                            jprice = jsonData["data"]["product_details"]["current_price"].ToString();
                        }
                        catch
                        {
                            jprice = jsonData["data"]["product_details"]["original_price"].ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (product.Pfromtype == "SMT")
                        jprice = jsonData["data"]["product_details"].ToString().Contains("original_price") ? jsonData["data"]["product_details"]["original_price"].ToString() : null;
                    else
                        jprice = jsonData["data"]["product_details"].ToString().Contains("current_price") ? jsonData["data"]["product_details"]["current_price"].ToString() : null;

                }
                if (jprice == string.Empty || jprice == null)
                {
                    jprice = "0";
                }
                if (jprice.Contains("$") && product.Pfromtype == "SMT")
                {
                    jprice = jprice.Contains("-") ? (Convert.ToDouble(jprice.Substring(jprice.IndexOf("-") + 1)) * 6.9476).ToString() : (Convert.ToDouble(jprice.Replace("$", "").Replace("US", "")) * 6.9476).ToString();
                }
                else if (product.Pfromtype == "SMT")
                {
                    jprice = jprice.Contains("-") ? (Convert.ToDouble(jprice.Substring(jprice.IndexOf("-") + 1)) * 6.9476).ToString() : (Convert.ToDouble(jprice.Replace("$", "").Replace("US", "")) * 6.9476).ToString();
                }
                else if (jprice.Contains("$"))
                {
                    jprice = jprice.Contains("-") ? (Convert.ToDouble(jprice.Substring(jprice.IndexOf("-") + 1)) * 6.9476).ToString() : (Convert.ToDouble(jprice.Replace("$", "").Replace("US", "")) * 6.9476).ToString();
                }
                if (jprice.Contains("-"))
                    jprice = jprice.Substring(0, jprice.IndexOf('-'));
                //if (jprice.Contains("$"))
                //    jprice = (Convert.ToDouble(jprice.Replace("$", "").Replace("US", "")) * 6.9476).ToString();

                //product.Pimgurl = "";
                product.Pprofit = Convert.ToDouble(jprice).ToString("#");
                product.Plowestprice = 0.0d.ToString("#");
                product.Porigtitle = jtitle;
                product.Pnewtitle = baidu.TransTitle_ChineseToEnglish(jtitle);
                product.PnewtitleX = baidu.upFirstCharWithSpaceX((GlobalUserClass.GetHaiWangModel().IsAuthorized ? new HaiWangCore().TranslateZhToSiteDefaultResponse(jtitle) : new ALiCore().ChangeZhToSiteDefaultLangauge(jtitle)));
                //product.PnewtitleX = baidu.upFirstCharWithSpaceX(new ALiCore().ChangeZhToSiteDefaultLangauge(jtitle));
                product.Pweight = (Convert.ToDouble(jweight) < 5 ? Convert.ToDouble(jweight) * 1000 : Convert.ToDouble(jweight)).ToString("#");
                product.Lazadapackageweight = (Convert.ToDouble(jweight) + 100).ToString("#");
                product.Porigprice = (Convert.ToDouble(jprice) + 0.4).ToString("#");
                product.Pallsoldcount = "";
                product.Plinkcreatedate = "";
                product.Peditdate = DateTime.Now.ToString();
                var sizeJson = jsonData["data"]["product_details"]["sku"];
                List<string> sizeList = new List<string>();
                List<string> colorlist = new List<string>();
                List<string> colorlists = new List<string>();
                foreach (var item in sizeJson)
                {
                    //if (item["label"].ToString() == "Size" || item["label"].ToString() == "尺码" || item["label"].ToString() == "Material"
                    //    || item["label"].ToString() == "Bundle" || item["label"].ToString() == "尺寸" || item["label"].ToString() == "Shoe Size"
                    //    || item["label"].ToString() == "Kid Size")
                    if(item["label"].ToString().Contains("尺")|| item["label"].ToString().Contains("寸")|| item["label"].ToString().Contains("码")
                        || item["label"].ToString().Contains("Size") || item["label"].ToString().Contains("Material")|| item["label"].ToString().Contains("Bundle")
                        || item["label"].ToString().Contains("Length")
                        )
                    {
                        foreach (var token in item["values"])
                        {
                            if (product.Pfromtype != "SMT")
                            {
                                if (token["desc"].ToString() != string.Empty)
                                {
                                    sizeList.Add(token["desc"].ToString());
                                }

                            }
                            if (product.Pfromtype == "SMT")
                            {
                                if (token.ToString().Contains("desc"))
                                {
                                    sizeList.Add(token["desc"].ToString());
                                }
                                else
                                {
                                    sizeList.Add(token.ToString());
                                }
                            }
                        }
                    }
                    if (item["label"].ToString().Contains("色") || item["label"].ToString().Contains("Color"))
                    {
                        foreach (var token in item["values"])
                        {
                            if (product.Pfromtype != "SMT")
                            {
                                if (token["desc"].ToString() != string.Empty)
                                {
                                    colorlist.Add(token["desc"].ToString());
                                    var enColor = "";
                                    foreach (var coloritem in colorlist)
                                    {
                                        if (ContainChinese(coloritem))
                                        {
                                            var input = coloritem.Replace("色", "").Replace("的", "").Replace("款", "").Replace("如图", "").Replace("图片", "").Replace("图", "").Trim();
                                            var color = Regex.Replace(input, "[^\\u4E00-\\u9FFFA-Za-z0-9\\s]+", "").Trim();
                                            enColor = ColorMatch.GetENcolor3(color, colorlist);
                                            if (enColor == "" || enColor == string.Empty)
                                            {
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            string color = token["desc"].ToString();
                                            if (!colorlists.Contains(color) && !ContainChinese(color))
                                            {
                                                colorlists.Add(color);
                                            }

                                        }

                                    }
                                    if (enColor == string.Empty || enColor == "")
                                    {
                                        if (!colorlist.Contains(token["desc"].ToString()))
                                        {
                                            colorlist.Add(token["desc"].ToString());
                                        }

                                    }
                                    else
                                    {
                                        if (!colorlists.Contains(enColor))
                                        {
                                            colorlists.Add(enColor);
                                        }
                                    }
                                }

                            }
                            if (product.Pfromtype == "SMT")
                            {
                                if (token.ToString().Contains("desc"))
                                {
                                    colorlist.Add(token["desc"].ToString());
                                    var enColor = "";
                                    foreach (var coloritem in colorlist)
                                    {
                                        var input = coloritem.Replace("色", "").Replace("的", "").Replace("款", "").Replace("如图", "").Replace("图片", "").Replace("图", "").Trim();
                                        var color = Regex.Replace(input, "[^\\u4E00-\\u9FFFA-Za-z0-9\\s]+", "").Trim();
                                        enColor = ColorMatch.GetENcolor3(color, colorlist);
                                        if (enColor == "" || enColor == string.Empty)
                                        {
                                            enColor = color;
                                            //break;
                                        }
                                    }
                                    if (enColor == string.Empty || enColor == "")
                                    {
                                        if (!colorlist.Contains(token["desc"].ToString()))
                                        {
                                            colorlist.Add(token["desc"].ToString());
                                        }

                                    }
                                    else
                                    {
                                        if (!colorlists.Contains(enColor))
                                        {
                                            colorlists.Add(enColor);
                                        }

                                    }

                                }
                                else
                                {
                                    colorlist.Add(token.ToString());
                                }
                            }
                        }
                    }
                }
                product.Psizes = string.Join(",", sizeList);
                product.Lazadasizes = string.Join(",", sizeList);
                if (colorlists.Count > 0)
                {
                    product.Pcolors = string.Join(",", colorlists);
                }
                else
                {
                    product.Pcolors = string.Join(",", colorlist);
                }

                ///计算计价模板相关的产品费用
                ptc.CalcProductCost(priceTemplate, product, Convert.ToDouble(jprice));
                if (jsonData["data"]["product_details"]["params"] != null && jsonData["data"]["product_details"]["params"].HasValues)
                {
                    try
                    {
                        JArray jatrr = (JArray)(jsonData["data"]["product_details"]["params"]);

                        string tdesc = "";

                        Dictionary<string, string> needAttr = new Dictionary<string, string>();

                        // List<string> needAtrr = new List<string>();                               

                        for (int ia = 0; ia < jatrr.Count; ia++)
                        {
                            string cattrname = jatrr[ia]["label"].ToString();
                            if (cattrname == "商品名称")
                                continue;
                            if (needAttr.ContainsKey(cattrname))
                            {
                                needAttr[cattrname] = needAttr[cattrname] + " , " + jatrr[ia]["value"].ToString();
                            }
                            else
                            {
                                needAttr.Add(cattrname, jatrr[ia]["value"].ToString());

                            }

                        }

                        foreach (KeyValuePair<string, string> kv in needAttr)
                        {
                            tdesc += kv.Key + " : " + kv.Value + " ; \r\n";
                        }

                        if (!String.IsNullOrEmpty(tdesc.Trim()))
                        {
                            product.Porigattribute = tdesc;
                            product.Lazadahighlight = tdesc.Replace("\n", "<br/>");
                        }


                        needAttr = null;

                    }
                    catch
                    { }
                }
                DownImages(jsonData, product);
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public static bool ContainChinese(string input)
        {
            string pattern = "[\u4e00-\u9fbb]";
            return Regex.IsMatch(input, pattern);
        }
        /// <summary>
        /// 保存图片
        /// </summary>
        /// <param name="jsondata"></param>
        /// <param name="product"></param>
        private void DownImages(JObject jsondata, Product product)
        {
            //声明图片保存数组，用于保存图片的本地路径和远程路径，[,0]表示远程路径[,1]表示本地路径
            string[,] imageArr = null;
            //声明图片保存数组，用于保存图片的本地路径和远程路径，[,0]表示远程路径[,1]表示本地路径
            string[,] attrArr = null;
            //用于保存SKU 属性值
            List<string> attrList = null;
            //用于保存SKU 属性图片
            List<string> sizeList = null;
            Dictionary<string, string> dic = null;
            List<string> colorList = null;
            List<string> downImageList = new List<string>();

            try
            {
                ///产品图片信息
                if (jsondata["data"] != null)
                {
                    JArray jarray = (JArray)jsondata["data"]["product_details"]["images"];
                    if (jarray.Count > 0)
                    {
                        imageArr = new string[jarray.Count, 2];
                        for (int i = 0; i < jarray.Count; i++)
                        {
                            var uri = jarray[i].ToString().Replace("{\r\n  \"image_url\": \"", "").Replace("\"\r\n}", "");
                            imageArr[i, 0] = uri.StartsWith("http") ? (uri) : ("http://cbu01.alicdn.com/" + uri);
                            imageArr[i, 1] = product.Plocalimgpath + "\\" + (i < 5 ? ("Azt" + i.ToString("0#") + ".jpg") : ("Czt" + i.ToString("0#") + ".jpg"));
                        }
                        product.Pimgurl = imageArr[0, 0];
                    }
                }
            }
            catch
            {
                product.Pstate = "采集失败A";
            }
            try
            {
                ///获取SKU信息
                if (jsondata["data"]["product_details"]["sku"] != null)
                {
                    attrList = new List<string>();
                    sizeList = new List<string>();
                    colorList = new List<string>();
                    dic = new Dictionary<string, string>();
                    JArray jarray = (JArray)jsondata["data"]["product_details"]["sku"];
                    for (int j = 0; j < jarray.Count; j++)
                    {
                        if (jarray[j]["values"] != null)
                        {
                            JArray jarValues = (JArray)jarray[j]["values"];
                            for (int i = 0; i < jarValues.Count; i++)
                            {
                                string text = "";
                                try
                                {
                                    text = jarValues[i]["desc"].ToString().Trim();
                                    if (jarray.Count > 1 && j < 1 ? !colorList.Contains(text) : !attrList.Contains(text))
                                    {
                                        if (!jarray[j]["label"].ToString().Contains("色"))
                                        {
                                            attrList.Add(text);
                                            //continue;
                                        }
                                        else
                                            colorList.Add(text);
                                        bool flag14 = jarValues[i]["image"] != null && jarValues[i]["image"].ToString() != "";
                                        if (flag14)
                                        {
                                            string text2 = jarValues[i]["image"].ToString().Trim();
                                            bool flag15 = !text2.StartsWith("http");
                                            if (flag15)
                                            {
                                                text2 = "http://cbu01.alicdn.com/" + text2;
                                            }
                                            dic.Add(text, text2);
                                        }
                                        else
                                        {
                                            dic.Add(text, "");
                                        }
                                    }
                                }
                                catch
                                {
                                    text = jarValues[i].ToString();
                                    var name = jarray[j]["label"].ToString();
                                    if (name == "Color")
                                        colorList.Add(text);
                                    if (name == "Size")
                                        sizeList.Add(text);
                                }
                            }
                        }
                    }
                    if (dic.Count > 0)
                    {
                        attrArr = new string[dic.Count, 4];
                        int arrIndex = -1;
                        foreach (var item in dic)
                        {
                            arrIndex++;
                            attrArr[arrIndex, 0] = item.Value;
                            var input = item.Key.Replace("色", "").Replace("的", "").Replace("款", "").Replace("如图", "").Replace("图片", "").Replace("图", "").Trim();
                            var color = Regex.Replace(input, "[^\\u4E00-\\u9FFFA-Za-z0-9\\s]+", "").Trim();
                            var enColor = ColorMatch.GetENcolor3(color, colorList);
                            attrArr[arrIndex, 3] = enColor;
                            attrArr[arrIndex, 2] = color;
                            attrArr[arrIndex, 1] = string.Format(product.Plocalimgpath + "\\" + "Bys" + (arrIndex + 1).ToString("0#") + attrArr[arrIndex, 2] + (enColor == "" ? "" : ("_" + enColor)) + ".jpg");
                        }
                    }

                }
            }
            catch
            {
                product.Pstate = "采集失败B";
            }
            try
            {
                ///获取描述
                if (jsondata["data"]["product_details"]["detail"] != null)
                {
                    var data = GetData(product.Ppid);
                    var desc = jsondata["data"]["product_details"]["detail"].ToString();
                    desc = Regex.Replace(desc, "<a.*?</a>", "").Trim();
                    Regex regex = new Regex("<img\\b[^<>]*?\\bsrc[\\s\\t\\r\\n]*=[\\s\\t\\r\\n]*[\"']?[\\s\\t\\r\\n]*(?<imgUrl>[^\\s\\t\\r\\n\"'<>]*)[^<>]*?/?[\\s\\t\\r\\n]*>", RegexOptions.IgnoreCase);
                    MatchCollection matchCollection = regex.Matches((desc + data).Replace("\\", ""));
                    var imageIndex = 1;
                    foreach (object obj in matchCollection)
                    {
                        Match match = (Match)obj;
                        var imageUrl = match.Groups["imgUrl"].Value.Split(new char[] { '?' })[0].Trim().Replace("_.webp", "");
                        if (imageUrl.EndsWith(".jpg") || imageUrl.EndsWith(".png"))
                        {
                            imageUrl = (imageUrl.StartsWith("http") ? "" : "http:") + imageUrl;
                            if (!downImageList.Contains(imageUrl))
                            {
                                imageUrl += "?tnm=d" + imageIndex.ToString("0#");
                                imageIndex++;
                                imageUrl = imageUrl.ToString().Replace(",", "");
                                downImageList.Add(imageUrl);
                            }
                        }
                    }
                    desc = Regex.Replace(desc, "<td.*?>", "<td>");
                    desc = Regex.Replace(desc, "<td>(.*?)</p>(.*?)</td>", "\t$1$2\t");
                    desc = desc.Replace("</div>", "\r\n").Replace("</p>", "\r\n").Replace("<tr>", "\r\n").Replace("<td>", "\t").Replace("</td>", "\t").Replace("&lsquo;", " ").Replace("&lrquo;", " ");
                    desc = Regex.Replace(desc, "<br.*?>", "\r\n");
                    desc = Regex.Replace(desc, "&[^\\s].*?;", " ");
                    desc = Regex.Replace(desc, "<.*?>", "").Trim();
                    string[] array = desc.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var item in array)
                    {
                        if (item.Trim() != "" && item.Trim().Length > 2 && !item.Contains("<img"))
                            product.Pdescription += "\r\n" + item;
                    }
                }
            }
            catch
            {
                product.Pstate = "采集失败C";
            }
            try
            {
                var p1 = product.Lazadahighlight;
                var p2 = product.Pdescription == null ? "" : product.Pdescription.Replace("\r", "").Replace("\r", "").Replace("\n", "<br/>");
                product.Lazadadescription = p1 + "<br/>" + p2;
                //    product.Psizes = GetPsizes(sizeList);
                //    product.Pcolors = GetProductPcolors(attrArr);
                if (product.Pcolors == "")
                    product.Pcolors = GetPsizes(colorList);
                product.Pcolormatch = GetPcolormatch(attrArr);
                product.Punfanyiimgs = GetPunfanyiimgs(attrArr);
                product.Pfanyidcolors = "";
                product.Porigimgsurl = GetPorigimgsurl(imageArr, attrArr, downImageList);
                product.Pstate = "基本数据采集OK";
            }
            catch
            {
                product.Pstate = "采集失败D";
            }
        }

        /// <summary>
        /// 通过三方接口获取产品信息
        /// </summary>
        /// <param name="link"></param>
        /// <returns></returns>
        private JObject GetProductInfo(string link)
        {
            Constants.GETOTHERCOLLECT_APPID();
            Constants.OTHERCOLLECT_APPID = "5cf66ce8d350bcd92a49380063ada9b0";
        string requestUriString = string.Format($"{Constants.OTHERCOLLECT_URI}appid={Constants.OTHERCOLLECT_APPID}&scanUrl={link}");
            var result = new MyHttpClient().GetResponse(requestUriString);
            return result == "" ? null : (JObject)JsonConvert.DeserializeObject(result);
        }

        /// <summary>
        /// 检查更新下载地址
        /// </summary>
        /// <param name="product"></param>
        private void UpdatePlocalimgpath(Product product)
        {
            string saveFolder = "";
            if (product.Plocalimgpath != null && product.Plocalimgpath.Trim() != string.Empty)
            {
                try
                {
                    string newdir = System.IO.Path.GetDirectoryName(product.Plocalimgpath);
                    if (!System.IO.Directory.Exists(newdir))
                    {
                        Directory.CreateDirectory(newdir);
                    }
                    saveFolder = newdir;
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
            }
            else
            {
                saveFolder = Constants.DEFAULTIMAGESAVEPATH;
            }
            product.Plocalimgpath = saveFolder + "阿里下载" + product.Number.ToString() + "-TSC" + DateTime.Now.ToString("MMddhhmmss") + PublicFunctions.CreateRandomCode();
        }
    }
}
