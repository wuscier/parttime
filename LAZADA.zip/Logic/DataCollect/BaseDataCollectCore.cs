﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Logic.DataCollect
{
    public abstract class BaseDataCollectCore
    {
        public abstract bool CollectProduct(Product product);

        /// <summary>
        /// 获取尺寸信息
        /// </summary>
        /// <param name="sizeList"></param>
        /// <returns></returns>
        protected string GetPsizes(List<string> sizeList)
        {
            var result = "";
            if (sizeList != null)
                foreach (var item in sizeList)
                {
                    Regex regex = new Regex("[\\^\\[\\]\\-*×――()（）【】$%~!@#$…&%￥—+=<>《》!！??？:：•`·、。，,;；\"‘’“”≤]+");
                    var size = regex.Replace(item, "").Trim().ToUpper();
                    switch (size.ToUpper())
                    {
                        case "XXL":
                            result += "2XL,";
                            break;
                        case "XXXL":
                            result += "3XL,";
                            break;
                        case "XXXXL":
                            result += "4XL,";
                            break;
                        case "XXXXXL":
                            result += "5XL,";
                            break;
                        case "XXXXXXL":
                            result += "6XL,";
                            break;
                        case "XXXXXXXL":
                            result += "7XL,";
                            break;
                        default:
                            result += size + ",";
                            break;
                    }

                }
            return result.Length > 0 ? result.Substring(0, result.Length - 1) : result;
        }

        /// <summary>
        /// 获取网络图片链接 以,分割
        /// </summary>
        /// <param name="imageArr"></param>
        /// <param name="attrArr"></param>
        /// <param name="downImageList"></param>
        /// <returns></returns>
        protected string GetPorigimgsurl(string[,] imageArr, string[,] attrArr, List<string> downImageList)
        {
            List<string> list = new List<string>();
            if (imageArr != null)
                for (int i = 0; i < imageArr.GetLength(0); i++)
                {
                    var item = imageArr[i, 0] + "?tnm=" + Path.GetFileNameWithoutExtension(imageArr[i, 1]);
                    if (!list.Contains(item))
                        list.Add(item);
                }
            if (attrArr != null)
                for (int i = 0; i < attrArr.GetLength(0); i++)
                {
                    var item = attrArr[i, 0] + "?tnm=" + Path.GetFileNameWithoutExtension(attrArr[i, 1]);
                    if (!list.Contains(item))
                        list.Add(item);
                }
            if (downImageList != null)
                for (int i = 0; i < downImageList.Count; i++)
                {
                    var item = downImageList[i];
                    if (!list.Contains(item))
                        list.Add(item);
                }
            return string.Join(",", list.ToArray());
        }

        /// <summary>
        /// 下载图片详细集合
        /// </summary>
        /// <param name="imageArr"></param>
        /// <returns></returns>
        protected string GetPunfanyiimgs(string[,] attrArr)
        {
            var result = "";
            if (attrArr != null)
                for (int i = 0; i < attrArr.GetLength(0); i++)
                {
                    if (attrArr[i, 0].Trim().Length > 0 && (attrArr[i, 3].Trim() == "" || attrArr[i, 3].Trim() == "-"))
                    {
                        result += attrArr[i, 1] + ",";
                    }
                }
            return result.Length > 0 ? result.Trim(new char[] { ',' }) : result;
        }

        /// <summary>
        /// 获取颜色尺码组合出的规格
        /// </summary>
        /// <param name="imageArr"></param>
        /// <returns></returns>
        protected string GetPcolormatch(string[,] attrArr)
        {
            JArray jarray = new JArray();
            if (attrArr != null)
                for (int i = 0; i < attrArr.GetLength(0); i++)
                {
                    JObject jobject = new JObject();
                    jarray.Add(jobject);
                    jobject["chcolor"] = attrArr[i, 2];
                    jobject["encolor"] = attrArr[i, 3];
                }
            return jarray.Count > 0 ? JsonConvert.SerializeObject(jarray) : "";
        }

        /// <summary>
        /// 获取产品颜色 以,分割
        /// </summary>
        /// <param name="imageArr"></param>
        /// <returns></returns>
        protected string GetProductPcolors(string[,] attrArr)
        {
            var result = "";
            if (attrArr != null)
                for (int i = 0; i < attrArr.GetLength(0); i++)
                {
                    if (attrArr[i, 3] != string.Empty)
                    {
                        result += attrArr[i, 3] + ",";
                    }
                    else
                    {
                        result += attrArr[i, 2] + ",";
                    }
                }
            return result.Length > 0 ? result.Substring(0, result.Length - 1) : result;
        }


        protected string GetData(string pid)
        {
            string requestUriString = "https://laputa.1688.com/offer/ajax/widgetList.do?callback=jQuery17209&data=offerdetail_ditto_offerSatisfaction%2Cofferdetail_ditto_postage&offerId=" + pid;
            return "";
        }

    }
}
