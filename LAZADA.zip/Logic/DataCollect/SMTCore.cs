﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PublicFunction;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;
using HtmlAgilityPack;
using Logic.Translation;
using System.Text.RegularExpressions;
using Logic.PriceTemplate;
using LAZADA;
using Logic.Platform;

namespace Logic.DataCollect
{
    public class SMTCore : BaseDataCollectCore
    {
        public override bool CollectProduct(Product product)
        {
            try
            {
                UpdatePlocalimgpath(product);
                product.Pstate = "开始采集";
                GetProductHtml(product);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 通过请求获取商品页面
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        private void GetProductHtml(Product product)
        {
            var baidu = new BaiDuCore();
            var ptc = new PriceTemplateCore();
            var priceTemplate = ptc.GetPriceTemplate(product.Pjisangongshi);

            string uri = "http://www.aliexpress.com/item/id/" + product.Ppid + ".html";
            string html = new MyHttpClient().GetResponse(uri);
            HtmlDocument htmlDocument = new HtmlDocument();
            htmlDocument.LoadHtml(html);
            HtmlNode documentNode = htmlDocument.DocumentNode;
            try
            {
                //HtmlNode htmlNode = documentNode.SelectSingleNode("//*[@id=\"j-sku-price\"]");
                HtmlNode htmlNode = documentNode.SelectSingleNode("//*[@class=\"product-price-value\"]");
                if (htmlNode != null)
                {
                    string text = htmlNode.InnerText;
                    bool flag4 = text.Contains("-");
                    if (flag4)
                    {
                        text = text.Split(new char[]
                        {
                                '-'
                        })[1].Trim();
                    }
                    product.Pchenbenjia = text;
                    product.Plowestprice = text;
                }
            }
            catch { }
            try
            {
                HtmlNode htmlNode2 = documentNode.SelectSingleNode("//*[@id=\"j-sku-discount-price\"]");
                if (htmlNode2 != null)
                {
                    string text2 = htmlNode2.InnerText;
                    bool flag6 = text2.Contains("-");
                    if (flag6)
                    {
                        text2 = text2.Split(new char[]
                        {
                                    '-'
                        })[1].Trim();
                    }
                    product.Pchenbenjia = text2;
                    product.Plowestprice = text2;
                }
            }
            catch { }
            try
            {
                //HtmlNode htmlNode4 = documentNode.SelectSingleNode("//*[@class=\"product-name\"]");
                HtmlNode htmlNode4 = documentNode.SelectSingleNode("//*[@class=\"product-title\"]");
                if (htmlNode4 != null)
                {
                    string innerText = htmlNode4.InnerText;
                    var title = PublicFunctions.upFirstCharWithSpace(innerText.Replace("&#39;", " ").Replace(",", "")).Replace("Free Shipping", "").Replace("Freeshipping", "").Replace("   ", " ").Replace("  ", " ").Replace("  ", " ").Trim();
                    product.Porigtitle = title;
                    product.Pnewtitle = baidu.TransTitle_ChineseToEnglish(title);
                    //product.PnewtitleX = baidu.upFirstCharWithSpaceX(new ALiCore().ChangeZhToSiteDefaultLangauge(title));
                    product.PnewtitleX = baidu.upFirstCharWithSpaceX((GlobalUserClass.GetHaiWangModel().IsAuthorized ? new HaiWangCore().TranslateZhToSiteDefaultResponse(title) : new ALiCore().ChangeZhToSiteDefaultLangauge(title)));
                }
            }
            catch { }
            try
            {
                //HtmlNode htmlNode5 = documentNode.SelectSingleNode("//*[@id=\"j-order-num\"]");
                HtmlNode htmlNode5 = documentNode.SelectSingleNode("//*[@class=\"add-wishlistnum\"]");
                if (htmlNode5 != null)
                {
                    product.Pallsoldcount = htmlNode5.InnerText.Trim().Split(new char[] { ' ' })[0];
                }
            }
            catch { }
            try
            {
                HtmlNodeCollection htmlNodeCollection = documentNode.SelectNodes("//*[@class=\"product-packaging-list util-clearfix\"]");
                if (htmlNodeCollection != null && htmlNodeCollection.Count > 0)
                {
                    HtmlNodeCollection htmlNodeCollection2 = HtmlNode.CreateNode(htmlNodeCollection[0].InnerHtml).SelectNodes("//li");
                    if (htmlNodeCollection2 != null)
                    {
                        List<string> list = new List<string>();
                        foreach (HtmlNode htmlNode6 in htmlNodeCollection2)
                        {
                            try
                            {
                                if (htmlNode6.InnerText.ToLower().Contains("weight"))
                                {
                                    string value = htmlNode6.SelectSingleNode("./*[@class=\"packaging-des\"]").Attributes["rel"].Value;
                                    product.Pweight = Convert.ToString(Convert.ToDouble(value) * 1000.0);
                                    product.Lazadapackageweight = product.Pweight;
                                }
                                if (htmlNode6.InnerText.ToLower().Contains("size"))
                                {
                                    string[] array = htmlNode6.SelectSingleNode("./*[@class=\"packaging-des\"]").Attributes["rel"].Value.Split(new char[] { '|' });
                                    if (array.Length > 2)
                                    {
                                        product.PackageLength = array[0];
                                        product.PackageWidth = array[1];
                                        product.PackageHight = array[2];
                                    }
                                }
                            }
                            catch { }
                        }

                    }
                }
            }
            catch { }
            try
            {
                HtmlNode htmlNode7 = documentNode.SelectSingleNode("//*[@id=\"j-product-desc\"]");
                if (htmlNode7 != null)
                {
                    HtmlNode htmlNode8 = htmlNode7.SelectSingleNode("//*[@class=\"product-property-list util-clearfix\"]");
                    if (htmlNode8 != null)
                    {
                        HtmlNodeCollection htmlNodeCollection3 = HtmlNode.CreateNode(htmlNode8.InnerHtml).SelectNodes("//li");
                        if (htmlNodeCollection3 != null)
                        {
                            List<string> list2 = new List<string>();
                            foreach (HtmlNode htmlNode9 in htmlNodeCollection3)
                            {
                                bool flag18 = !htmlNode9.InnerText.ToLower().Contains("brand");
                                if (flag18)
                                {
                                    list2.Add(Regex.Replace(htmlNode9.InnerText, "\\s{3,}", "  "));
                                }
                            }
                            var attr = string.Join(";\r\n", list2.ToArray()) + ";";
                            product.Porigattribute = attr.Replace("&amp;", "&");
                        }
                    }
                }
            }
            catch { }
            product.Peditdate = DateTime.Now.ToString();
            product.Porigprice = (Convert.ToDouble(product.Pchenbenjia) * 6.5).ToString("#");
            ///计算计价模板相关的产品费用
            ptc.CalcProductCost(priceTemplate, product, Convert.ToDouble(product.Porigprice));
            DownImages(html, product);
        }

        private void DownImages(string html, Product product)
        {
            //声明图片保存数组，用于保存图片的本地路径和远程路径，[,0]表示远程路径[,1]表示本地路径
            string[,] imageArr = null;
            //声明图片保存数组，用于保存图片的本地路径和远程路径，[,0]表示远程路径[,1]表示本地路径
            string[,] attrArr = null;
            //用于保存SKU 属性图片
            List<string> sizeList = null;
            List<string> colorList = null;
            List<string> downImageList = null;
            ///产品图片信息
            string pattern = "window.runParams.imageBigViewURL=\\[(?<zhutuUrl>.*?)]";
            Regex regex = new Regex(pattern, RegexOptions.Singleline);
            Match match = regex.Match(html);
            if (match.Success)
            {
                string[] array = match.Groups["zhutuUrl"].Value.Replace("\"", "").Split(new char[] { ',' });
                if (array.Length > 0)
                {
                    imageArr = new string[array.Length, 2];
                    for (int i = 0; i < array.Length; i++)
                    {
                        imageArr[i, 0] = array[i].ToString();
                        imageArr[i, 1] = product.Plocalimgpath + "\\" + (i < 5 ? ("Azt" + i.ToString("0#") + ".jpg") : ("Czt" + i.ToString("0#") + ".jpg"));
                    }
                    product.Pimgurl = imageArr[0, 0] + "_220x220.jpg";
                }
            }
            ///获取SKU信息
            {
                HtmlDocument htmlDocument = new HtmlDocument();
                htmlDocument.LoadHtml(html);
                HtmlNode documentNode = htmlDocument.DocumentNode;
                HtmlNode htmlNode = documentNode.SelectSingleNode("//*[@id=\"j-product-info-sku\"]");
                if (htmlNode != null && htmlNode.InnerHtml.Trim().Length > 10)
                {
                    HtmlNode htmlNode2 = null;
                    HtmlNode htmlNode3 = null;
                    HtmlNodeCollection htmlNodeCollection = htmlNode.SelectNodes("child::dl");
                    if (htmlNodeCollection != null)
                    {
                        sizeList = new List<string>();
                        foreach (HtmlNode htmlNode4 in htmlNodeCollection)
                        {
                            try
                            {
                                if (htmlNode4.SelectSingleNode("child::dt[1]").InnerText.ToLower().Contains("color"))
                                {
                                    htmlNode2 = htmlNode4;
                                }
                                else
                                {
                                    if (htmlNode4.SelectSingleNode("child::dt[1]").InnerText.ToLower().Contains("size") || htmlNode4.SelectSingleNode("child::dt[1]").InnerText.ToLower().Contains("length"))
                                    {
                                        htmlNode3 = htmlNode4;
                                        break;
                                    }
                                    if (!htmlNode4.SelectSingleNode("child::dt[1]").InnerText.ToLower().Contains("from"))
                                    {
                                        htmlNode3 = htmlNode4;
                                        if (htmlNode2 != null)
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                            catch { }
                        }
                        try
                        {
                            if (htmlNode3 != null)
                            {
                                HtmlNodeCollection htmlNodeCollection2 = HtmlNode.CreateNode(htmlNode3.OuterHtml).SelectNodes("//li/a/span");
                                bool flag12 = htmlNodeCollection2 != null;
                                if (flag12)
                                {
                                    foreach (HtmlNode htmlNode5 in htmlNodeCollection2)
                                    {
                                        sizeList.Add(htmlNode5.InnerText);
                                    }
                                }
                            }
                            if (htmlNode2 != null)
                            {
                                HtmlNodeCollection htmlNodeCollection3 = HtmlNode.CreateNode(htmlNode2.OuterHtml).SelectNodes("//li/a");
                                int num2 = 0;
                                if (htmlNodeCollection3 != null)
                                {
                                    num2 = htmlNodeCollection3.Count;
                                }
                                if (num2 > 0)
                                {
                                    attrArr = new string[num2, 4];
                                    for (int j = 0; j < num2; j++)
                                    {
                                        attrArr[j, 0] = "";
                                        attrArr[j, 1] = "";
                                        attrArr[j, 2] = "";
                                        attrArr[j, 3] = "";
                                        HtmlNode htmlNode6 = htmlNodeCollection3[j];
                                        if (htmlNode6.SelectSingleNode("child::img[1]") != null)
                                        {
                                            HtmlNode htmlNode7 = htmlNode6.SelectSingleNode("child::img[1]");
                                            if (htmlNode7.Attributes["bigpic"] != null)
                                            {
                                                attrArr[j, 0] = htmlNode7.Attributes["bigpic"].Value.Trim();
                                            }
                                            if (htmlNode7.Attributes["title"] != null)
                                            {
                                                attrArr[j, 2] = htmlNode7.Attributes["title"].Value;
                                                string str2 = "Bys" + (j + 1).ToString("0#") + PublicFunctions.ATjWj6oy0m(attrArr[j, 2]) + ".jpg";
                                                attrArr[j, 1] = product.Plocalimgpath + "\\" + str2;
                                            }
                                        }
                                        else
                                        {
                                            if (htmlNode6.SelectSingleNode("child::span[1]") != null)
                                            {
                                                if (htmlNode6.SelectSingleNode("child::span[1]").Attributes["title"] != null)
                                                {
                                                    attrArr[j, 2] = htmlNode6.SelectSingleNode("child::span[1]").Attributes["title"].Value;
                                                    string str3 = "Bys" + (j + 1).ToString("0#") + PublicFunctions.ATjWj6oy0m(attrArr[j, 2]) + ".jpg";
                                                    attrArr[j, 1] = product.Plocalimgpath + "\\" + str3;
                                                }
                                                else
                                                {
                                                    attrArr[j, 2] = htmlNode6.InnerText;
                                                    string str4 = "Bys" + (j + 1).ToString("0#") + PublicFunctions.ATjWj6oy0m(attrArr[j, 2]) + ".jpg";
                                                    attrArr[j, 1] = product.Plocalimgpath + "\\" + str4;
                                                }
                                            }
                                            else
                                            {
                                                string str5 = "Bys" + (j + 1).ToString("0#") + ".jpg";
                                                attrArr[j, 1] = product.Plocalimgpath + "\\" + str5;
                                                attrArr[j, 2] = "";
                                            }
                                        }
                                    }

                                    if (ColorMatch.SysColor != "")
                                    {
                                        colorList = new List<string>();
                                        int num3 = 0;
                                        for (int k = 0; k < attrArr.GetLength(0); k++)
                                        {
                                            string text = attrArr[k, 2];
                                            if (string.IsNullOrEmpty(text.Trim()))
                                            {
                                                attrArr[k, 2] = "未知色" + (k + 1).ToString("0#");
                                            }
                                            else
                                            {
                                                string text2 = ColorMatch.GetENcolor3(text, colorList).Trim();
                                                if (text != "")
                                                {
                                                    num3++;
                                                    colorList.Add(text2);
                                                    attrArr[k, 3] = text2;
                                                    string str6 = string.Concat(new string[]
                                                    {
                                                "Bys",
                                                k.ToString("0#"),
                                                attrArr[k, 2],
                                                "_",
                                                PublicFunctions.ATjWj6oy0m(attrArr[k, 3].Replace("&", "")),
                                                ".jpg"
                                                    });
                                                    attrArr[k, 1] = product.Plocalimgpath + "\\" + str6;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch { }
                    }
                }
            }
            ///获取描述
            string text3 = "";
            string pattern2 = "window.runParams.descUrl=\"(?<descData>.*?)\"";
            Regex regex2 = new Regex(pattern2, RegexOptions.Compiled);
            Match match2 = regex2.Match(html);
            if (match2.Success)
            {
                downImageList = new List<string>();
                string text4 = match2.Groups["descData"].Value.Trim();
                if (!text4.StartsWith("http"))
                {
                    text4 = "http:" + text4;
                }
                text3 = new MyHttpClient().GetResponse(text4).Trim();
                if (!string.IsNullOrEmpty(text3))
                {
                    int num4 = 0;
                    try
                    {
                        text3 = Regex.Replace(text3, "<div style=\"border: 1.0px solid #dedede;.*?</div>", "");
                        text3 = Regex.Replace(text3, "<a.*?</a>", "").Trim();
                        int num5 = text3.IndexOf("<");
                        int num6 = text3.LastIndexOf("<img");
                        text3 = text3.Substring(num5, num6 - num5 - 1);
                    }
                    catch
                    {
                    }
                    Regex regex3 = new Regex("<img\\b[^<>]*?\\bsrc[\\s\\t\\r\\n]*=[\\s\\t\\r\\n]*[\"']?[\\s\\t\\r\\n]*(?<imgUrl>[^\\s\\t\\r\\n\"'<>]*)[^<>]*?/?[\\s\\t\\r\\n]*>", RegexOptions.IgnoreCase);
                    MatchCollection matchCollection = regex3.Matches(text3.Replace("\\", ""));
                    if (matchCollection.Count > 0)
                    {
                        foreach (object obj in matchCollection)
                        {
                            Match match3 = (Match)obj;
                            string text6 = match3.Groups["imgUrl"].Value.Split(new char[]
                            {
                                    '?'
                            })[0].Trim();
                            bool flag27 = text6.ToLower().EndsWith(".jpg") && text6.ToLower().StartsWith("http");
                            if (flag27)
                            {
                                num4++;
                                downImageList.Add(text6 + "?tnm=d" + num4.ToString("0#"));
                            }
                        }
                    }
                    text3 = Regex.Replace(text3, "<td.*?>", "<td>");
                    text3 = Regex.Replace(text3, "<td>(.*?)</p>(.*?)</td>", "$1$2\t");
                    text3 = text3.Replace("</div>", "</div>\r\n").Replace("</p>", "\r\n").Replace("</table>", "\r\n").Replace("<tr>", "\r\n").Replace("<td>", "\t").Replace("</td>", "\t").Replace("&lsquo;", " ").Replace("&lrquo;", " ");
                    text3 = Regex.Replace(text3, "<br.*?>", "\r\n");
                    text3 = Regex.Replace(text3, "&[^\\s].*?;", " ");
                    text3 = Regex.Replace(text3, "<.*?>", "").Trim();
                    string[] array2 = text3.Split(new char[]
                        {
                            '\n'
                        }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string text7 in array2)
                    {
                        if (text7.Trim() != "" && text7.Trim().Length > 2 && !text7.Contains("<img"))
                            product.Pdescription += "\r\n" + text7;
                    }
                }
            }
            product.Lazadadescription = (product.Porigattribute + "<BR/><BR/><BR/>" + product.Pdescription).Replace("\r\n", "<BR/>");
            product.Lazadahighlight = product.Porigattribute.Replace("\r\n", "<BR/>");
            product.Psizes = GetPsizes(sizeList);
            product.Pcolors = GetProductPcolors(attrArr);
            product.Punfanyiimgs = GetPunfanyiimgs(attrArr);
            product.Pfanyidcolors = "";
            product.Porigimgsurl = GetPorigimgsurl(imageArr, attrArr, downImageList);
            product.Pstate = "基本数据采集OK";
        }

        /// <summary>
        /// 检查更新下载地址
        /// </summary>
        /// <param name="product"></param>
        private void UpdatePlocalimgpath(Product product)
        {
            string saveFolder = "";
            if (product.Plocalimgpath != null && product.Plocalimgpath.Trim() != string.Empty)
            {
                try
                {
                    string newdir = System.IO.Path.GetDirectoryName(product.Plocalimgpath);
                    if (!System.IO.Directory.Exists(newdir))
                    {
                        Directory.CreateDirectory(newdir);
                    }
                    saveFolder = newdir;
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
            }
            else
            {
                saveFolder = Constants.DEFAULTIMAGESAVEPATH;
            }
            product.Plocalimgpath = saveFolder + "\\速卖通下载" + product.Number.ToString() + "-DT" + DateTime.Now.ToString("MMddhhmmss") + PublicFunctions.CreateRandomCode();
        }

    }
}
