﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HtmlAgilityPack;
using LAZADA;
using Logic.PriceTemplate;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;

namespace Logic.DataCollect
{
    public class LazadaDataCollectCore : BaseDataCollectCore
    {
        public override bool CollectProduct(Product product)
        {
            try
            {
                UpdatePlocalimgpath(product);
                product.Pstate = "开始采集";
                GetProductHtml(product);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 检查更新下载地址
        /// </summary>
        /// <param name="product"></param>
        private void UpdatePlocalimgpath(Product product)
        {
            string saveFolder = "";
            if (product.Plocalimgpath != null && product.Plocalimgpath.Trim() != string.Empty)
            {
                try
                {
                    string newdir = System.IO.Path.GetDirectoryName(product.Plocalimgpath);
                    if (!System.IO.Directory.Exists(newdir))
                    {
                        Directory.CreateDirectory(newdir);
                    }
                    saveFolder = newdir;
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
            }
            else
            {
                saveFolder = Constants.DEFAULTIMAGESAVEPATH;
            }
            product.Plocalimgpath = saveFolder + "LAZADA下载" + "\\" + product.Number.ToString() + "-DT" + DateTime.Now.ToString("MMddhhmmss") + PublicFunctions.CreateRandomCode();
        }

        /// <summary>
        /// 通过请求获取商品页面
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        private void GetProductHtml(Product product)
        {
            var ptc = new PriceTemplateCore();
            JObject jObject = null;
            var priceTemplate = ptc.GetPriceTemplate(product.Pjisangongshi);
            List<Dictionary<string, string>> list = new List<Dictionary<string, string>>();
            string uri = product.Poriglink;
            string html = new MyHttpClient().GetResponse(uri);
            HtmlDocument htmlDocument = new HtmlDocument();
            htmlDocument.LoadHtml(html);
            HtmlNode documentNode = htmlDocument.DocumentNode;
            try
            {
                var nodes = documentNode.ChildNodes[3].ChildNodes[3];
                var innerHtml = nodes.ChildNodes[nodes.ChildNodes.Count - 4].InnerHtml;
                var datas = innerHtml.Split(new char[] { '\n' });
                var data = "";
                foreach (var item in datas)
                {
                    if (item.IndexOf("app.run") > -1)
                    {
                        data = item;
                        break;
                    }
                }
                var str = data.Substring(data.IndexOf('{'));
                str = str.TrimEnd(';').TrimEnd(')');
                jObject = JsonConvert.DeserializeObject<JObject>(str);
                var rate = new SiteChangeHelp().GetDefaultRate(product.Poriglink);
                var siteid = (int)new SiteChangeHelp().GetCurrentRegion(product.Poriglink);
                var baseProduct = JsonConvert.DeserializeObject<JObject>(jObject["data"]["root"]["fields"]["skuInfos"]["0"].ToString());
                if (siteid == GlobalUserClass.SiteId)
                {
                    product.Lazadacategoryid = baseProduct["categoryId"].ToString();
                    List<string> namepath = new List<string>();
                    JArray namepathArr = JsonConvert.DeserializeObject<JArray>(baseProduct["dataLayer"]["pdt_category"].ToString());
                    foreach (var item in namepathArr)
                    {
                        namepath.Add(item.ToString());
                    }
                    product.Lazadacategorynamepath = string.Join(">>", namepath);
                }
                product.Porigprice = Math.Round(Convert.ToDouble(baseProduct["price"]["salePrice"]["value"]) / rate).ToString();

                var skuInfo = jObject["data"]["root"]["fields"]["specifications"].Children().First();
                //var skuInfo = JsonConvert.DeserializeObject<JObject>(jObject["data"]["root"]["fields"]["specifications"].Children().First().ToString());
                if (skuInfo.Contains("boxContent"))
                {
                    product.Lazadapackageincluding = skuInfo["boxContent"].ToString();
                }
                var productInfo = JsonConvert.DeserializeObject<JObject>(jObject["data"]["root"]["fields"]["product"].ToString());

                product.Porigtitle = productInfo["title"].ToString();
                product.Pnewtitle = productInfo["title"].ToString();
                product.PnewtitleX = productInfo["title"].ToString();

                product.PackageLength = "1";
                product.PackageWidth = "1";
                product.PackageHight = "1";

                product.Pweight = Convert.ToString(Convert.ToDouble(Constants.DEFAULTWEIGHT));
                product.Lazadapackageweight = product.Pweight;

                var properties = JsonConvert.DeserializeObject<JArray>(jObject["data"]["root"]["fields"]["productOption"]["skuBase"]["properties"].ToString());
                foreach(var item in properties)
                {
                    if(item["name"].ToString()== "Color Family"|| item["name"].ToString() == "Color family")
                    {
                        var skus = JsonConvert.DeserializeObject<JArray>(item["values"].ToString());
                        foreach(var sku in skus)
                        {
                            product.Pcolors += product.Pcolors == "" || product.Pcolors == null ? sku["name"].ToString() : ("," + sku["name"].ToString());
                        }
                    }
                    if (item["name"].ToString() == "Size")
                    {
                        var skus = JsonConvert.DeserializeObject<JArray>(item["values"][0]["value"].ToString());
                        foreach (var sku in skus)
                        {
                            product.Psizes += product.Psizes == "" || product.Psizes == null ? sku["name"].ToString() : ("," + sku["name"].ToString());
                        }
                    }
                }
            }
            catch { }

            product.Peditdate = DateTime.Now.ToString();
            //product.Porigprice = (Convert.ToDouble(product.Pchenbenjia) * 6.5).ToString("#");
            ///计算计价模板相关的产品费用
            ptc.CalcProductCost(priceTemplate, product, Convert.ToDouble(product.Porigprice));
            DownImages(jObject, product);
        }

        private void DownImages(JObject jObject, Product product)
        {
            //声明图片保存数组，用于保存图片的本地路径和远程路径，[,0]表示远程路径[,1]表示本地路径
            string[,] imageArr = null;
            //声明图片保存数组，用于保存图片的本地路径和远程路径，[,0]表示远程路径[,1]表示本地路径
            string[,] attrArr = null;
            Dictionary<string, string> dic = new Dictionary<string, string>();
            List<string> downImageList = new List<string>();
            List<string> needToDown = new List<string>();
            try
            {
                var jarray = JsonConvert.DeserializeObject<JArray>(jObject["data"]["root"]["fields"]["skuGalleries"]["0"].ToString());
                if (jarray.Count > 0)
                {
                    imageArr = new string[jarray.ToString().Contains("youtu.be")?jarray.Count-1: jarray.Count, 2];
                    int j = 0;
                    for (int i = 0; i < jarray.Count; i++)
                    {
                        if (jarray[i]["src"].ToString().Contains("youtu.be"))
                            continue;

                        imageArr[j, 0] = "https:" + jarray[i]["src"].ToString();
                        imageArr[j, 1] = product.Plocalimgpath + "\\" + (i < 5 ? ("Azt" + i.ToString("0#") + ".jpg") : ("Czt" + i.ToString("0#") + ".jpg"));
                        j++;
                    }
                    product.Pimgurl = imageArr[0, 0];//.Contains("youtu.be")? imageArr[1, 0]: imageArr[0, 0];
                }
            }
            catch { product.Pstate = "采集失败A"; }

            try
            {
                var arr = JsonConvert.DeserializeObject<JArray>(jObject["data"]["root"]["fields"]["productOption"]["skuBase"]["properties"].ToString());
                foreach (var item in arr)
                {
                    var pro = JsonConvert.DeserializeObject<JObject>(item.ToString());
                    if (pro["name"].ToString() == "Style" || pro["name"].ToString() == "Color Family")
                    {
                        List<string> colors = new List<string>();
                        var colorArr = JsonConvert.DeserializeObject<JArray>(item["values"].ToString());
                        foreach (var color in colorArr)
                        {
                            if (!colors.Contains(color["name"].ToString()))
                            {
                                colors.Add(color["name"].ToString());
                                dic.Add(color["name"].ToString(), "http:" + color["image"].ToString());
                            }

                        }
                        product.Pcolors = string.Join(",", colors);
                    }
                    else if (pro["name"].ToString() == "Size")
                    {
                        List<string> sizes = new List<string>();
                        JArray sizeArr = null;
                        try
                        {
                            sizeArr = JsonConvert.DeserializeObject<JArray>(JsonConvert.DeserializeObject<JArray>(item["values"].ToString()).First()["value"].ToString());
                        }
                        catch
                        {
                            sizeArr = JsonConvert.DeserializeObject<JArray>(item["values"].ToString());
                        }
                        foreach (var color in sizeArr)
                        {
                            if (!sizes.Contains(color["name"].ToString()))
                            {
                                sizes.Add(color["name"].ToString());
                            }
                        }
                        product.Psizes = string.Join(",", sizes);
                    }
                    else
                    {
                        List<string> sizes = new List<string>();
                        var sizeArr = JsonConvert.DeserializeObject<JArray>(item["values"].ToString());
                        foreach (var color in sizeArr)
                        {
                            if (!sizes.Contains(color["name"].ToString()))
                            {
                                sizes.Add(color["name"].ToString());
                            }
                        }
                        dic.Add(pro["name"].ToString(), string.Join(",", sizes));
                    }
                }
                if (dic.Count > 0)
                {
                    attrArr = new string[dic.Count, 4];
                    int arrIndex = -1;
                    foreach (var item in dic)
                    {
                        arrIndex++;
                        attrArr[arrIndex, 0] = item.Value;
                        attrArr[arrIndex, 1] = string.Format(product.Plocalimgpath + "\\" + "Bys" + (arrIndex + 1).ToString("0#") + item.Key + ".jpg");
                        attrArr[arrIndex, 3] = item.Value;
                        attrArr[arrIndex, 2] = item.Value;
                    }
                }

            }
            catch (Exception ex)
            {
                product.Pstate = "采集失败B";
            }

            try
            {
                var productInfo = JsonConvert.DeserializeObject<JObject>(jObject["data"]["root"]["fields"]["product"].ToString());
                if (productInfo.ContainsKey("desc"))
                {
                    var desc = productInfo["desc"].ToString();
                    desc = Regex.Replace(desc, "<a .*?</a>", "").Trim();
                    Regex regex = new Regex("<img\\b[^<>]*?\\bsrc[\\s\\t\\r\\n]*=[\\s\\t\\r\\n]*[\"']?[\\s\\t\\r\\n]*(?<imgUrl>[^\\s\\t\\r\\n\"'<>]*)[^<>]*?/?[\\s\\t\\r\\n]*>", RegexOptions.IgnoreCase);
                    MatchCollection matchCollection = regex.Matches((desc).Replace("\\", ""));
                    var imageIndex = 1;
                    foreach (object obj in matchCollection)
                    {
                        Match match = (Match)obj;
                        desc.Replace(match.Value, "");
                        var imageUrl = match.Groups["imgUrl"].Value.Split(new char[] { '?' })[0].Trim().Replace("_.webp", "");
                        if (imageUrl.EndsWith(".jpg") || imageUrl.EndsWith(".png"))
                        {
                            imageUrl = (imageUrl.StartsWith("http") ? "" : "http:") + imageUrl;
                            if (!downImageList.Contains(imageUrl))
                            {
                                imageUrl += "?tnm=d" + imageIndex.ToString("0#");
                                imageIndex++;
                                downImageList.Add(imageUrl);
                            }
                        }
                    }
                    desc = Regex.Replace(desc, "<img .*? />", "").Trim();
                    product.Lazadadescription = desc;
                }
                product.Lazadahighlight = productInfo["highlights"].ToString();
                product.Punfanyiimgs = GetPunfanyiimgs(attrArr);
                product.Pfanyidcolors = "";
                product.Porigimgsurl = GetPorigimgsurl(imageArr, attrArr, downImageList);
                product.Pstate = "基本数据采集OK";
            }
            catch
            {
                product.Pstate = "采集失败C";
            }
        }
    }
}
