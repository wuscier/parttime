﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Threading;

namespace LAZADA
{
    /// <summary>
    /// App.xaml 的交互逻辑
    /// </summary>
    public partial class App : Application
    {
        [DllImport("User32.dll")]
        private static extern bool SetForegroundWindow(System.IntPtr hWnd);
        [DllImport("user32.dll")]
        internal static extern bool ShowWindow(IntPtr hWnd, int wstyle);

        /// <summary>
        /// 重写启动项
        /// </summary>
        /// <param name="e"></param>
        protected override void OnStartup(StartupEventArgs e)
        {
            Process thisProc = Process.GetCurrentProcess();
            Process[] others = Process.GetProcessesByName(thisProc.ProcessName);
            if (others.Length > 10)
            {

                foreach (Process process in others)
                {
                    if (process.Id != thisProc.Id)
                    {
                        SetForegroundWindow(process.MainWindowHandle);
                        ShowWindow(process.MainWindowHandle, 3);
                        break;
                    }
                }


                Application.Current.Shutdown();
            }
            else
            {
                Application.Current.ShutdownMode = System.Windows.ShutdownMode.OnExplicitShutdown;
                LoginWindow window = new LoginWindow();
                bool? dialogResult = window.ShowDialog();
                if ((dialogResult.HasValue == true) && (dialogResult.Value == true))
                {
                    base.OnStartup(e);
                    //注册程序异常委托处理事件
                    this.DispatcherUnhandledException += new DispatcherUnhandledExceptionEventHandler(App_DispatcherUnhandledException);
                    Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
                }
                else
                {
                    Application.Current.Shutdown();
                }
                //shoushi,dy910114

            }
        }
        void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            //处理完后，我们需要将Handler=true表示已此异常已处理过
            new LogOutput.LogTo().WriteErrorLine(e.Exception.Message);
            e.Handled = true;
        }
    }
}
