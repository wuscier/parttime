﻿using LAZADA.HaiWang;
using LAZADA.TasksBtns.CustomerControl;
using Logic.Author;
using Logic.BasicInfo;
using Logic.Platform;
using Logic.SystemSole;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Author;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static LAZADA.GlobalUserClass;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// NewSetWindow.xaml 的交互逻辑
    /// </summary>
    public partial class NewSetWindow : UserControl
    {
        private PublicFunctions publicFunctions = new PublicFunctions();
        private bool lazadaisauthor = false;
        private PagingViewModel vm = new PagingViewModel();
        public NewSetWindow()
        {
            InitializeComponent();
            this.txtName.Text = "LAZADA-" + GlobalUserClass.SiteName + "站点授权";

            GETLazada();
            GET1688();
            if (Constants.Ali1688_ACCESSTOKEN != string.Empty)
            {
                lblAuthor1688.Content = "重新授权";
                Ref_flg.Content = "已授权";
                btnBBGetCd.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
                lblAuthor1688.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
                this.btnBBGetCd.IsEnabled = true;
            }
            else if (Constants.Ali1688_ACCESSTOKEN == string.Empty && Constants.Ali1688_REFRESHTOKEN != string.Empty)
            {
                lblAuthor1688.Content = "重新授权";
                Ref_flg.Content = "1688授权异常";
                btnBBGetCd.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
                lblAuthor1688.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
                this.btnBBGetCd.IsEnabled = true;
            }
            else
            {
                lblAuthor1688.Content = "授权";
                this.btnBBGetCd.IsEnabled = true;
                btnBBGetCd.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
                lblAuthor1688.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
            }

            //if (lazadaisauthor == true)//Convert.ToString(this.lblAuthHint.Content) == "账户" + AuthedShopsItem.Account + "已授权"
            //{
            //    lblAuthorlazada.Content = "重新授权";
            //    btnGetCode.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
            //    lblAuthorlazada.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
            //    this.btnGetCode.IsEnabled = true;
            //}
            //else
            //{
            //    lblAuthorlazada.Content = "授权";
            //    btnGetCode.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
            //    lblAuthorlazada.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
            //}

            if (new SystemConfigCore().SetAliAuthorization() == 0 && GlobalUserClass.GetHaiWangModel().IsAuthorized)
            {
                lblAuthorHW.Content = "已授权";
                btnHWGetCd.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
                lblAuthorHW.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
                this.btnHWGetCd.IsEnabled = false;
            }
            else
            {
                lblAuthorHW.Content = "授权";
                btnHWGetCd.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
                lblAuthorHW.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
            }


            #region lazada授权图片
            switch (GlobalUserClass.SiteName)
            {
                case "马来西亚":
                    site.Source = new BitmapImage(new Uri("/Images/MYIMG.png", UriKind.Relative));
                    break;
                case "越南":
                    site.Source = new BitmapImage(new Uri("/Images/VNIMG.png", UriKind.Relative));
                    break;
                case "新加坡":
                    site.Source = new BitmapImage(new Uri("/Images/SGIMG.png", UriKind.Relative));
                    break;
                case "印度尼西亚":
                    site.Source = new BitmapImage(new Uri("/Images/IDIMG.png", UriKind.Relative));
                    break;
                case "泰国":
                    site.Source = new BitmapImage(new Uri("/Images/THIMG.png", UriKind.Relative));
                    break;
                case "菲律宾":
                    site.Source = new BitmapImage(new Uri("/Images/PHIMG.png", UriKind.Relative));
                    break;
                case "六合一":
                    site.Source = new BitmapImage(new Uri("/Images/CrossBorder.png", UriKind.Relative));
                    break;
                default:
                    site.Source = new BitmapImage(new Uri("/Images/Head.png", UriKind.Relative));
                    break;
            }
            #endregion

        }
        /// <summary>
        /// lazada授权获取
        /// </summary>
        public void GETLazada()
        {
            try
            {

                string accesstoken = Access_Token;
                string authorMsg = GetSiteProfile(accesstoken);
                int siteId = SiteId;
                JObject result = (JObject)JsonConvert.DeserializeObject(authorMsg);
                int iNumSum = 0;
                int iNum = 0;
                JArray arryresult = (JArray)result["result"];
                string strSQL = "; ";
                string strDel = " delete from Store where user='" + GlobalUserClass.uname + "' and region=" + siteId;
                foreach (var item in arryresult)
                {
                    if ((int)item["siteType"] == (int)WebSiteType.Lazada)
                    {
                        if ((int)item["region"] == siteId)
                        {
                            iNumSum++;
                            if (item["account"].ToString() != "")
                                iNum++;
                            List<Store> lStore = new SqlAuthorization().GetStoreList(" and account<>'' and id='" + item["id"] + "' ");
                            strSQL += "Insert into Store(id,IsDefault,Name,account,authTime,expirationTime,user,region,accessToken) Values(" + item["id"] + "," + (lStore.Count > 0 ? (lStore[0].IsDefault == "true" ? "1" : "0") : "1") + ",'" + (item["shopName"].ToString() == "" ? item["account"].ToString() : item["shopName"].ToString()) + "','"
                                + item["account"].ToString() + "','" + item["authTime"].ToString().Split('T')[0].Replace("/", "-").Replace("-1-", "-01-").Replace("-2-", "-02-").Replace("-3-", "-03-").Replace("-4-", "-04-").Replace("-5-", "-05-").Replace("-6-", "-06-").Replace("-7-", "-07-").Replace("-8-", "-08-").Replace("-9-", "-09-").Replace("-1 ", "-01 ").Replace("-2 ", "-02 ").Replace("-3 ", "-03 ").Replace("-4 ", "-04 ").Replace("-5 ", "-05 ").Replace("-6 ", "-06 ").Replace("-7 ", "-07 ").Replace("-8 ", "-08 ").Replace("-9 ", "-09 ") + "','"
                                + item["expirationTime"].ToString().Split('T')[0].Replace("/", "-").Replace("-1-", "-01-").Replace("-2-", "-02-").Replace("-3-", "-03-").Replace("-4-", "-04-").Replace("-5-", "-05-").Replace("-6-", "-06-").Replace("-7-", "-07-").Replace("-8-", "-08-").Replace("-9-", "-09-").Replace("-1 ", "-01 ").Replace("-2 ", "-02 ").Replace("-3 ", "-03 ").Replace("-4 ", "-04 ").Replace("-5 ", "-05 ").Replace("-6 ", "-06 ").Replace("-7-", "-07 ").Replace("-8 ", "-08 ").Replace("-9 ", "-09 ") + "','" + GlobalUserClass.uname + "',"
                                + siteId + ",'" + item["accessToken"].ToString() + "'); ";
                            //strSQL += "Insert into Store(id,IsDefault,Name,account,authTime,expirationTime,user,region,accessToken) Values(" + item["id"] + "," + (lStore.Count > 0 ? (lStore[0].IsDefault == "true" ? "1" : "0") : "1") + ",'" + (item["shopName"].ToString() == "" ? item["account"].ToString().Replace("'", "''") : item["shopName"].ToString().Replace("'", "''")) + "','"
                            //               + item["account"].ToString().Replace("'", "''") + "','" + item["authTime"].ToString().Split('T')[0].Replace("/", "-").Replace("-1-", "-01-").Replace("-2-", "-02-").Replace("-3-", "-03-").Replace("-4-", "-04-").Replace("-5-", "-05-").Replace("-6-", "-06-").Replace("-7-", "-07-").Replace("-8-", "-08-").Replace("-9-", "-09-") + "','" + item["expirationTime"].ToString().Split('T')[0].Replace("/", "-").Replace("-1-", "-01-").Replace("-2-", "-02-").Replace("-3-", "-03-").Replace("-4-", "-04-").Replace("-5-", "-05-").Replace("-6-", "-06-").Replace("-7-", "-07-").Replace("-8-", "-08-").Replace("-9-", "-09-") + "','" + GlobalUserClass.uname + "',"
                            //               + siteId + ",'" + item["accessToken"].ToString() + "'); ";
                        }
                    }
                }
                this.lvShowStore.ItemsSource = SystemSoleEntity.GetStoreList();
                txtAuthResult.Text = iNum.ToString() + "/" + iNumSum.ToString();
                new SqlAuthorization().Edit(strDel + strSQL);
                Thread.Sleep(200);
                SystemSoleEntity.LoadStoreList(vm);
            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// 百度授权
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnBDSave_Click(object sender, RoutedEventArgs e)
        {

        }
        /// <summary>
        /// 阿里授权
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AliSaveBtn_Click(object sender, RoutedEventArgs e)
        {

        }
        /// <summary>
        /// 获取1688授权信息
        /// </summary>
        public void GET1688()
        {
            try
            {
                string accesstoken = Access_Token;
                string authorMsg = GetSiteProfile(accesstoken);
                int siteId = SiteId;
                JObject result = (JObject)JsonConvert.DeserializeObject(authorMsg);

                JArray arryresult = (JArray)result["result"];
                foreach (var item in arryresult)
                {
                    if ((int)item["siteType"] == (int)WebSiteType.Ali1688)
                    {

                        if ((int)item["region"] == 8 || item.Count() > 0 || (int)item["region"] == siteId)
                        {
                            //lblBBHint.Content = "1688授权正常,请勿重复授权";
                            if (Convert.ToString(item["accessToken"]) != "")
                            {
                                Constants.Ali1688_ACCESSTOKEN = Convert.ToString(item["accessToken"]);
                                Constants.Ali1688_REFRESHTOKEN = Convert.ToString(item["refreshToken"]);
                                if (Constants.Ali1688_REFRESHTOKEN != string.Empty && Constants.Ali1688_ACCESSTOKEN == string.Empty)
                                {
                                    R_Token();
                                }
                                this.btnBBGetCd.IsEnabled = true;
                                return;
                            }
                        }
                        else
                        {
                            lblAuthor1688.Content = "授权";
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// 1688授权
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnBBGetCd_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GlobalUserClass globalUser = new GlobalUserClass();
            long Id = globalUser.GetAlibabaAuthorTableId();
            string stg = "http://client-api-staging.fengniaoerp.com";
            
            try
            {
                if (lblAuthor1688.Content.ToString() == "重新授权")
                {
                    //GlobalUserClass globalUser = new GlobalUserClass();
                    //globalUser.RefreshAli1688Token();
                    //R_Token();
                    if (Constants.HB_ClientGatewayUrl == stg)//测试
                    {
                        GlobalUserClass.redirectUrl = Constants.My1688redirectUrl
                        + $"shopId={AuthedShopsItem.ShopId}"
                        + $"&siteId=8"
                        //+ $"&access_token={GlobalUserClass.Access_Token}"
                        + $"&siteType={(int)GlobalUserClass.WebSiteType.Ali1688}"
                        + $"&staging=5&id=" + Id + $"&loginaccount={Constants.LoginAccount}&pwd={EncryptionWay.base64Encode(Constants.LoginPwd)}";
                    }
                    else
                    {
                        GlobalUserClass.redirectUrl = Constants.My1688redirectUrl
                        + $"shopId={AuthedShopsItem.ShopId}"
                        + $"&siteId=8"
                        //+ $"&access_token={GlobalUserClass.Access_Token}"
                        + $"&siteType={(int)GlobalUserClass.WebSiteType.Ali1688}"
                        + $"&staging=104&id=" + Id + $"&loginaccount={Constants.LoginAccount}&pwd={EncryptionWay.base64Encode(Constants.LoginPwd)}";
                    }

                    Process.Start(My1688Collect.GetCollectUrl());

                    //Sav_TokenMsg();
                }
                else
                {
                    if (Constants.HB_ClientGatewayUrl == stg)
                    {
                        GlobalUserClass.redirectUrl = Constants.My1688redirectUrl
                        + $"shopId={AuthedShopsItem.ShopId}"
                        + $"&siteId=8"
                        //+ $"&access_token={GlobalUserClass.Access_Token}"
                        + $"&siteType={(int)GlobalUserClass.WebSiteType.Ali1688}"
                        + $"&staging=8" + $"&loginaccount={Constants.LoginAccount}&pwd={EncryptionWay.base64Encode(Constants.LoginPwd) }";
                    }
                    else
                    {
                        GlobalUserClass.redirectUrl = Constants.My1688redirectUrl
                        + $"shopId={AuthedShopsItem.ShopId}"
                        + $"&siteId=8"
                        + $"&siteType={(int)GlobalUserClass.WebSiteType.Ali1688}" + $"&staging=103" + $"&loginaccount={Constants.LoginAccount}&pwd={EncryptionWay.base64Encode(Constants.LoginPwd) }";
                    }

                    Process.Start(My1688Collect.GetCollectUrl());
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// 获取新的1688token
        /// </summary>
        public void R_Token()
        {
            //string r = Token().ToString();
            //JObject loginresult = new JObject();
            //loginresult = (JObject)JsonConvert.DeserializeObject(r);
            //GlobalUserClass.Access_Token = Convert.ToString(loginresult["access_token"]);
            //Constants.GETALIBABA_KEY();
            var list_ref_prm = new List<KeyValuePair<string, string>>()
                    {
                        new KeyValuePair<string, string>("grant_type","refresh_token"),
                        new KeyValuePair<string, string>("client_id",Constants.ALIBABA_ID),
                        new KeyValuePair<string, string>("client_secret",Constants.ALIBABA_KEY),
                        new KeyValuePair<string, string>("refresh_token",Constants.Ali1688_REFRESHTOKEN)
                    };
            HttpClient httpClient = new HttpClient();
            string myapiurl = "https://gw.open.1688.com/openapi/param2/1/system.oauth2/getToken/5723483";
            var val = new HttpRequestMessage(HttpMethod.Post, myapiurl) { Content = new FormUrlEncodedContent(list_ref_prm) };
            HttpResponseMessage res_Ref = httpClient.SendAsync(val).Result;


            var str = res_Ref.Content.ReadAsStringAsync().Result;
            var jsondata = (JObject)JsonConvert.DeserializeObject(str);
            Constants.Ali1688_ACCESSTOKEN = Convert.ToString(jsondata["access_token"]);
        }
        /// <summary>
        /// lazada授权
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnGetCode_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GlobalUserClass globalUser = new GlobalUserClass();
            globalUser.GETLAZADATOKEN(SiteId);
            string lazadatoken = Constants.LAZADA_ACCESSTOKEN;
            string lazadareftoken = Constants.LAZADA_REFERSHTOKEN;
            try
            {

                string stg = "http://client-api-staging.fengniaoerp.com";
                if (Constants.HB_ClientGatewayUrl == stg)
                {
                    GlobalUserClass.MyStoreAuthrect_Url = Constants.MyStoreredirectUrl + $"shopId={AuthedShopsItem.ShopId}" + $"&siteId={GlobalUserClass.SiteId}" + $"&access_token={GlobalUserClass.Access_Token}" + $"&siteType={(int)GlobalUserClass.WebSiteType.Lazada}" + $"&staging=8";
                }
                else
                {
                    GlobalUserClass.MyStoreAuthrect_Url = Constants.MyStoreredirectUrl + $"shopId={AuthedShopsItem.ShopId}" + $"&siteId={GlobalUserClass.SiteId}" + $"&access_token={GlobalUserClass.Access_Token}" + $"&siteType={(int)GlobalUserClass.WebSiteType.Lazada}";
                }
                string GET_StoreAuthor_Url = "";//= $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }"+ "&client_id=100755&country=vn";
                #region lazada分站点授权
                switch (GlobalUserClass.SiteId)
                {
                    case 1:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=sg";
                        break;
                    case 2:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=th";
                        break;
                    case 3:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=my";
                        break;
                    case 4:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=vn";
                        break;
                    case 5:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=ph";
                        break;
                    case 6:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=id";
                        break;
                    case 9:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=cb";
                        break;
                    default:
                        break;
                }
                #endregion
                Process.Start(GET_StoreAuthor_Url);
                //Process.Start(MyStoreAuthor.GetStoreUrl());
                GETLazada();
                //if (lazadaisauthor == true)//Convert.ToString(this.lblAuthHint.Content) == "账户" + AuthedShopsItem.Account + "已授权"
                //{
                //    lblAuthorlazada.Content = "已授权";
                //    btnGetCode.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
                //    lblAuthorlazada.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
                //    this.btnGetCode.IsEnabled = false;
                //}
                //else
                //{
                //    lblAuthorlazada.Content = "授权";
                //    btnGetCode.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
                //    lblAuthorlazada.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
                //}


            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// lazada重新授权
        /// </summary>
        public void LazadaAnewAuthor()
        {
            //GlobalUserClass globalUserClass = new GlobalUserClass();
            //globalUserClass.Ref_lazadaToken(SiteId);
            GlobalUserClass.MyStoreAuthrect_Url = Constants.MyStoreredirectUrl + $"shopId={AuthedShopsItem.ShopId}" + $"&siteId={GlobalUserClass.SiteId}" + $"&access_token={GlobalUserClass.Access_Token}" + $"&siteType={(int)GlobalUserClass.WebSiteType.Lazada}" + $"&staging=1";
            string GET_StoreAuthor_Url = "";
            #region lazada分站点授权
            switch (GlobalUserClass.SiteId)
            {
                case 1:
                    GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=sg";
                    break;
                case 2:
                    GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=th";
                    break;
                case 3:
                    GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=my";
                    break;
                case 4:
                    GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=vn";
                    break;
                case 5:
                    GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=ph";
                    break;
                case 6:
                    GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=id";
                    break;
                case 9:
                    GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=cb";
                    break;
                default:
                    break;
            }
            #endregion
            Process.Start(GET_StoreAuthor_Url);

        }
        /// <summary>
        /// 1688授权刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AlibbRef_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GET1688();
            if (Constants.Ali1688_ACCESSTOKEN != string.Empty)
            {
                lblAuthor1688.Content = "重新授权";
                Ref_flg.Content = "已授权";
                this.btnBBGetCd.IsEnabled = true;
                btnBBGetCd.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
                lblAuthor1688.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));

            }
            else
            {
                lblAuthor1688.Content = "授权";
                this.btnBBGetCd.IsEnabled = true;
                btnBBGetCd.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
                lblAuthor1688.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
            }
            TimeSpan ts1 = new TimeSpan(0, 0, 0, 0, 300);
            publicFunctions.AngleEasingAnimationShow(AlibbRef, 0, 180, 3, ts1);
        }
        /// <summary>
        /// lazada授权刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LazadaRef_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GETLazada();
            //if (lazadaisauthor == true)//Convert.ToString(this.lblAuthHint.Content) == "账户" + AuthedShopsItem.Account + "已授权"
            //{
            //    lblAuthorlazada.Content = "重新授权";
            //    this.btnGetCode.IsEnabled = true;
            //    btnGetCode.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
            //    lblAuthorlazada.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
            //}
            //else
            //{
            //    lblAuthorlazada.Content = "授权";
            //    btnGetCode.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
            //    lblAuthorlazada.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
            //}
            //TimeSpan ts1 = new TimeSpan(0, 0, 0, 0, 300);
            //publicFunctions.AngleEasingAnimationShow(lazadaRef, 0, 180, 3, ts1);
        }
        /// <summary>
        /// 百度翻译教程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtTeachSet_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }
        /// <summary>
        /// 阿里翻译教程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtAliTeach_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void AliSaveBtn_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            bool flag = this.AliIdTB.Text.Trim().Length < 5;
            if (!flag)
            {
                bool flag2 = this.AliKey.Text.Trim().Length < 5;
                if (!flag2)
                {
                    this.AliHintlb.Content = "正在验证...";
                    this.AliSaveBtn.IsEnabled = false;
                    new Thread(new ParameterizedThreadStart(this.SZjt9l5VdU))
                    {
                        IsBackground = true
                    }.Start(new KeyValuePair<string, string>(this.AliIdTB.Text.Trim(), this.AliKey.Text.Trim()));
                }
            }
        }
        public static string wxn6BCGxXt = "";
        public static string wO261jaFmd = "";
        private void SZjt9l5VdU(object d)
        {
            KeyValuePair<string, string> keyValuePair = (KeyValuePair<string, string>)d;
            bool flag = string.IsNullOrEmpty(ku2WvOIrME("测试", null, null, keyValuePair.Key, keyValuePair.Value));
            if (flag)
            {
                base.Dispatcher.BeginInvoke(new Action<string>(this.X6EtbZvb2E), new object[]
                {
                    "无效ID或密码"
                });
            }
            else
            {
                bool flag2 = MgXWc2qEf1(keyValuePair.Key, keyValuePair.Value);
                if (flag2)
                {
                    wxn6BCGxXt = keyValuePair.Key;
                    wO261jaFmd = keyValuePair.Value;
                    base.Dispatcher.BeginInvoke(new Action<string>(this.FdutaKI12Z), new object[]
                    {
                        "已保存"
                    });
                }
                else
                {
                    base.Dispatcher.BeginInvoke(new Action<string>(this.VwStut2DfM), new object[]
                    {
                        "保存失败，请重试"
                    });
                }
            }
        }
        public static string ku2WvOIrME(string a, string b, string c, string d, string e)
        {
            bool flag = string.IsNullOrEmpty(a);
            string result;
            if (flag)
            {
                result = null;
            }
            else
            {
                bool flag2 = string.IsNullOrEmpty(b);
                if (flag2)
                {
                    b = "auto";
                }
                bool flag3 = string.IsNullOrEmpty(c);
                if (flag3)
                {
                    c = GetAppLanguage;
                }
                string text = DateTime.Now.ToLongTimeString();
                string text2 = "http://api.fanyi.baidu.com/api/trans/vip/translate";
                string u = d + a + text + e;
                string text3 = D9NWUNPMRY(u);
                string requestUriString = string.Concat(new string[]
                {
                    text2,
                    "?q=",
                    HttpUtility.UrlEncode(a),
                    "&from=",
                    b,
                    "&to=",
                    c,
                    "&appid=",
                    d,
                    "&salt=",
                    text,
                    "&sign=",
                    text3
                });
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
                httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0";
                httpWebRequest.Method = "GET";
                httpWebRequest.Timeout = 10000;
                try
                {
                    HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                    Stream responseStream = httpWebResponse.GetResponseStream();
                    StreamReader streamReader = new StreamReader(responseStream, Encoding.Default);
                    string text4 = streamReader.ReadToEnd();
                    streamReader.Close();
                    responseStream.Close();
                    httpWebResponse.Close();
                    JObject jobject = (JObject)JsonConvert.DeserializeObject(text4);
                    string text5 = jobject["trans_result"][0]["dst"].ToString();
                    result = text5;
                }
                catch
                {
                    result = null;
                }
            }
            return result;
        }
        public static string D9NWUNPMRY(string a)
        {
            string text = "";
            MD5 md = MD5.Create();
            byte[] array = md.ComputeHash(Encoding.UTF8.GetBytes(a));
            for (int i = 0; i < array.Length; i++)
            {
                text += array[i].ToString("x2");
            }
            return text;
        }
        public static string GetAppLanguage
        {
            get
            {
                return "en";//ConfigurationManager.AppSettings.Get("Language");
            }
        }
        private void X6EtbZvb2E(string b)
        {
            this.AliHintlb.Content = b;
            this.AliSaveBtn.IsEnabled = true;
        }
        public static bool MgXWc2qEf1(string a, string b)
        {
            JObject jobject = new JObject();
            jobject.Add("Fid", a);
            jobject.Add("Fsecret", b);
            return cLdW2FVQOI(jobject, "SetBaiduFanyiToken") != null;
        }
        public static string cLdW2FVQOI(JObject c, string b)
        {
            try
            {
                string text = mQwWIDQiIQ(c, b);
                string text2 = ((JObject)JsonConvert.DeserializeObject(text))["d"].ToString();
                JObject jobject = (JObject)JsonConvert.DeserializeObject(text2);
                string a = jobject["rcode"].ToString();
                string result = jobject["msg"].ToString();
                bool flag = a == "Succeed";
                if (flag)
                {
                    return result;
                }
            }
            catch
            {
            }
            return null;
        }
        public static string mQwWIDQiIQ(JObject a, string b)
        {
            string result;
            try
            {
                JObject jobject = (a == null) ? new JObject() : a;
                jobject["uname"] = GlobalUserClass.uname;
                string text = DateTime.Now.GetDateTimeFormats('r')[0].ToString() + GlobalUserClass.uname;
                string text2 = EncryptionWay.Encrypt(text, "BvcnQsY3R5cGUlM2FpbmR1c3RyeXxjX2JpZD0yMDEyMjJfMS0yMDE");
                string text3 = EncryptionWay.Encrypt(JsonConvert.SerializeObject(jobject), "RyeXxjX2JpZD0yMDEyMjJfMS0yMDE");
                string s = string.Concat(new string[]
                {
                    "{'arg1':'",
                    text,
                    "','arg2':'",
                    text2,
                    "','arg3':'",
                    text3,
                    "'}"
                });
                byte[] bytes = Encoding.UTF8.GetBytes(s);
                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(Constants.GETLINK_LOGINURLNew + b);
                httpWebRequest.UserAgent = "User-Agent:Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705";
                httpWebRequest.ContentType = "application/json; charset=utf-8";
                httpWebRequest.Timeout = 30000;
                httpWebRequest.Method = "POST";
                httpWebRequest.KeepAlive = true;//保持浏览器和服务器长时间连接
                httpWebRequest.ContentLength = (long)bytes.Length;
                Stream requestStream = httpWebRequest.GetRequestStream();
                requestStream.Write(bytes, 0, bytes.Length);
                requestStream.Close();
                WebResponse response = httpWebRequest.GetResponse();
                Stream responseStream = response.GetResponseStream();
                StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8);
                string text4 = streamReader.ReadToEnd();
                streamReader.Close();
                responseStream.Close();
                response.Close();
                result = text4;
            }
            catch
            {
                result = "{\"d\":\"{\"rcode\":\"Fail\",\"msg\":\"netErrow\"}\"}";
            }
            return result;
        }
        private void FdutaKI12Z(string b)
        {
            this.AliHintlb.Content = b;
        }
        private void VwStut2DfM(string b)
        {
            this.AliHintlb.Content = b;
            this.AliSaveBtn.IsEnabled = true;
        }

        private void BtnHWGetCd_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if(new SqlAuthorization().GetStoreList(" and account<>'' and user='" + GlobalUserClass.uname + "'").Count == 0)
            {
                MessageBox.Show("请先进行店铺授权！","提示",MessageBoxButton.OK);
                return;
            }
            aliAuthorization set = new aliAuthorization();
            //BaicWindow baic = new BaicWindow(400, 604, set, "账号授权设置");
            //baic.ShowDialog();d:DesignWidth="800" Height="568"
            BaicWindow baseWindow = new BaicWindow(804, 610, set, "账号阿里授权");
            baseWindow.ShowDialog();
        }

        private void WHWRef_MouseDown(object sender, MouseButtonEventArgs e)
        {
            new HaiWangCore().GetUserAuthorized();
            if (new SystemConfigCore().SetAliAuthorization() == 0 && GlobalUserClass.GetHaiWangModel().IsAuthorized)
            {
                lblAuthorHW.Content = "已授权";
                btnHWGetCd.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
                lblAuthorHW.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
                this.btnHWGetCd.IsEnabled = false;
            }
            else
            {
                lblAuthorHW.Content = "授权";
                btnHWGetCd.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
                lblAuthorHW.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
            }
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://15592546.s21v.faiusr.com/58/ABUIABA6GAAgkN7x6AUompuR0wc.mp4");
            }
            catch
            {

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            GlobalUserClass globalUser = new GlobalUserClass();
            globalUser.GETLAZADATOKEN(SiteId);
            string lazadatoken = Constants.LAZADA_ACCESSTOKEN;
            string lazadareftoken = Constants.LAZADA_REFERSHTOKEN;
            try
            {

                string stg = "http://client-api-staging.fengniaoerp.com";
                if (Constants.HB_ClientGatewayUrl == stg)
                {
                    GlobalUserClass.MyStoreAuthrect_Url = Constants.MyStoreredirectUrl + $"shopId={AuthedShopsItem.ShopId}" + $"&siteId={GlobalUserClass.SiteId}" + $"&access_token={GlobalUserClass.Access_Token}" + $"&siteType={(int)GlobalUserClass.WebSiteType.Lazada}" + $"&staging=101&id="+ ((Button)sender).Tag;
                }
                else
                {
                    GlobalUserClass.MyStoreAuthrect_Url = Constants.MyStoreredirectUrl + $"shopId={AuthedShopsItem.ShopId}" + $"&siteId={GlobalUserClass.SiteId}" + $"&access_token={GlobalUserClass.Access_Token}" + $"&siteType={(int)GlobalUserClass.WebSiteType.Lazada}" + $"&staging=102&id=" + ((Button)sender).Tag;
                }
                string GET_StoreAuthor_Url = "";//= $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }"+ "&client_id=100755&country=vn";
                #region lazada分站点授权
                switch (GlobalUserClass.SiteId)
                {
                    case 1:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=sg";
                        break;
                    case 2:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=th";
                        break;
                    case 3:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=my";
                        break;
                    case 4:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=vn";
                        break;
                    case 5:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=ph";
                        break;
                    case 6:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=id";
                        break;
                    case 9:
                        GET_StoreAuthor_Url = $"https://auth.lazada.com/oauth/authorize?response_type=code&force_auth=true&redirect_uri={ WebUtility.UrlEncode(GlobalUserClass.MyStoreAuthrect_Url) }" + "&client_id=100755&country=cb";
                        break;
                    default:
                        break;
                }
                #endregion
                Process.Start(GET_StoreAuthor_Url);
                //Process.Start(MyStoreAuthor.GetStoreUrl());
                GETLazada();
                if (lazadaisauthor == true)//Convert.ToString(this.lblAuthHint.Content) == "账户" + AuthedShopsItem.Account + "已授权"
                {
                    lblAuthorlazada.Content = "已授权";
                    btnGetCode.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#3BA0F9"));
                    lblAuthorlazada.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
                    this.btnGetCode.IsEnabled = false;
                }
                else
                {
                    lblAuthorlazada.Content = "授权";
                    btnGetCode.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
                    lblAuthorlazada.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
                }


            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }

        private void LvShowProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void AllCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            new SqlAuthorization().Edit("UPDATE Store SET IsDefault='1' where user='" + GlobalUserClass.uname + "' and region=" + GlobalUserClass.SiteId);
        }

        private void AllCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            new SqlAuthorization().Edit("UPDATE Store SET IsDefault='0' where user='" + GlobalUserClass.uname + "' and region=" + GlobalUserClass.SiteId);
        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            new SqlAuthorization().Edit("UPDATE Store SET IsDefault='1' where id=" + ((CheckBox)sender).Tag.ToString());
        }

        private void CheckBox_Unchecked_1(object sender, RoutedEventArgs e)
        {
            new SqlAuthorization().Edit("UPDATE Store SET IsDefault='0' where id=" + ((CheckBox)sender).Tag.ToString());
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            this.lvShowStore.ItemsSource = SystemSoleEntity.GetStoreList();
            PublicFunction.Constants.iChooseStore= new SystemConfigCore().SetOpenChooseStore();
            checkBox.IsChecked = PublicFunction.Constants.iChooseStore == 1;
        }

        private void checkBox_Checked(object sender, RoutedEventArgs e)
        {
            new SqlAuthorization().Edit("UPDATE SystemConfiguration SET VALUE='1' where Name='OpenChooseStore'");
            Constants.iChooseStore = 1;
        }

        private void checkBox_Unchecked(object sender, RoutedEventArgs e)
        {
            new SqlAuthorization().Edit("UPDATE SystemConfiguration SET VALUE='0' where Name='OpenChooseStore'");
            Constants.iChooseStore = 0;
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (oldName != ((TextBox)sender).Text)
            {
                if (MessageBoxResult.Yes == MessageBox.Show("是否修改店铺名称为" + ((TextBox)sender).Text, "提示", MessageBoxButton.YesNo))
                {
                    if (new HummingbirdCore().UploadShopName(((TextBox)sender).Text, ((TextBox)sender).Tag.ToString()))
                    {
                        new SqlAuthorization().Edit("UPDATE Store SET Name='" + ((TextBox)sender).Text.Replace("'", "''") + "' where id=" + ((TextBox)sender).Tag.ToString());
                        label.Content = "店铺名称修改成功：" + ((TextBox)sender).Text;
                        label.Visibility = Visibility.Visible;
                    }
                    else
                        label.Content = "店铺名称修改失败：" + ((TextBox)sender).Text;
                }
            }
        }
        string oldName = "";
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            oldName=((TextBox)sender).Text;
        }
    }
}
