﻿using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// AddSourceUrl.xaml 的交互逻辑
    /// </summary>
    public partial class AddSourceUrl : UserControl
    {
        private long num = 0;
        public AddSourceUrl(long Number)
        {
            InitializeComponent();
            num = Number;
            TextBox textBox = new TextBox()
            {
                Width = 400,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Left,
                Name = "txtUrl"

            };
            grdbody.Children.Add(textBox);
            Grid.SetColumn(textBox, 1);

            Label label = new Label()
            {
                Content = "访问",
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EDF7FF")),
                Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1F9EFF")),
                Width = 76,
                Height = 26,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Right,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 2, 0),
                Cursor = Cursors.Hand,
            };
            grdbody.Children.Add(label);
            Grid.SetColumn(label, 1);
            label.MouseLeftButtonDown += new MouseButtonEventHandler(label_MouseLeftButtonDown);
        }

        private void BtnAddUrl_Click(object sender, RoutedEventArgs e)
        {
            Grid grid = new Grid();
            grid.Name = "grdBodys";
            ColumnDefinition col1 = new ColumnDefinition();
            col1.Width = new GridLength(2, GridUnitType.Star);
            ColumnDefinition col2 = new ColumnDefinition();
            col2.Width = new GridLength(6, GridUnitType.Star);
            ColumnDefinition col3 = new ColumnDefinition();
            col3.Width = new GridLength(2, GridUnitType.Star);

            TextBox textBox = new TextBox()
            {
                Width = 400,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Left,
                Name = "txtUrl"
                
            };
            grid.Children.Add(textBox);
            Grid.SetColumn(textBox, 1);


            Label label = new Label()
            {
                Content = "访问",
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EDF7FF")),
                Foreground=new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1F9EFF")),
                Width=76,
                Height=26,
                FontSize=14,
                HorizontalAlignment=HorizontalAlignment.Right,
                HorizontalContentAlignment=HorizontalAlignment.Center,
                Margin=new Thickness(0,0,2,0),
                Cursor=Cursors.Hand,
            };
            grid.Children.Add(label);
            Grid.SetColumn(label, 1);
            label.MouseLeftButtonDown += new MouseButtonEventHandler(label_MouseLeftButtonDown);


            Label close = new Label()
            {
                Content = "X",
                FontSize=14,
                Cursor=Cursors.Hand
            };
            grid.Children.Add(close);
            Grid.SetColumn(close, 2);
            close.MouseLeftButtonDown += new MouseButtonEventHandler(close_MouseLeftButtonDown);


            grid.ColumnDefinitions.Add(col1);
            grid.ColumnDefinitions.Add(col2);
            grid.ColumnDefinitions.Add(col3);

            grid.Margin = new Thickness(0,10,0,10);
            stkUrlBody.Children.Add(grid);
        }

        private void label_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            
            foreach (var item in ((Grid)((Label)sender).Parent).Children)
            {

                if (item is TextBox)
                {
                    TextBox text = (TextBox)item;
                    Process.Start(text.Text);

                }
            }
        }

        private void close_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            stkUrlBody.Children.Remove((Grid)((Label)sender).Parent);
            
        }

        private void BtnCloseAddWin_Click(object sender, RoutedEventArgs e)
        {
            
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSavePoriglink_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
