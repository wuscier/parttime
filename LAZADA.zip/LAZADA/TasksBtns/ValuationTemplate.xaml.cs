﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.PriceTemplate;
using PublicFunction.AlertHelp;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// ValuationTemplate.xaml 的交互逻辑
    /// </summary>
    public partial class ValuationTemplate : Window
    {
        List<PriceTemplateEntity> entities = null;
        PriceTemplateCore ptc = new PriceTemplateCore();
        SiteChangeHelp sch = new SiteChangeHelp();

        public ValuationTemplate()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            var currency = sch.GetCurrency();
            lblPriceType.Content = currency + "ⓘ";
            Init();
        }

        private void Init()
        {
            ValuTemMdeleft.Children.Clear();
            entities = ptc.GetPriceTemplateList();
            foreach (var item in entities)
            {
                Label oneLabel = new Label();
                oneLabel.Content = item.Jname;
                oneLabel.Style = Resources["LableMouseOver"] as Style;
                oneLabel.MouseLeftButtonDown += new MouseButtonEventHandler(oneLabel_MouseLeftButtonDown);
                ValuTemMdeleft.Children.Add(oneLabel);
            }
        }

        //左边点选时
        private void oneLabel_MouseLeftButtonDown(object sender, RoutedEventArgs e)
        {

            foreach (Label oneLabel in ValuTemMdeleft.Children)
            {
                System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(209, 209, 209));
                oneLabel.Background = brsA;
            }
            System.Windows.Media.Brush brsB = new SolidColorBrush(System.Windows.Media.Color.FromRgb(100, 200, 200));
            ((Label)sender).Background = brsB;
            var jname = ((Label)sender).Content.ToString();
            var entity = entities.Where(p => p.Jname == jname).First();

            // int cindex = cDTB.Rows.IndexOf(allrows[0]);
            //  DataRowView cDRV = cDTB.DefaultView[]
            txtMdeName.Text = entity.Jname;
            txtNewxyfgs.Text = "";
            displayData(entity);

        }

        private void displayData(PriceTemplateEntity entity)
        {
            SidePratio.Value = Convert.ToDecimal(entity.Jpkglength);  //长
            WidthPratio.Value = Convert.ToDecimal(entity.Jpkgwidth);  //宽
            HeightPratio.Value = Convert.ToDecimal(entity.Jpkghight);  //包裹高

            StockPratio.Value = Convert.ToDecimal(entity.Jkuchen);  //库存

            txtPrfix.Text = entity.Jprfix;  //sku前缀

            Multipratio.Value = Convert.ToDecimal(entity.JMSRPjiajabi);  //原价是折扣价的多少倍
            AddPratio.Value = Convert.ToDecimal(entity.JMSRPjiajashou);  //原价是折扣价加多少钱

            if (entity.JMSRPtype == "2")  //算原价时，用乘还是加
            {
                rdoOldpriceTypeCheng.IsChecked = true;
            }
            else
            {
                rdoOldpriceTypeJia.IsChecked = true;
            }
            MarginValue.Value = Convert.ToDecimal(entity.Jliyunbi);  //利润率 ，相对于折扣价

            txtFreightValue.Text = entity.Jyunfeigs;  //国际运费计算公式
            txtPriceVal.Text = entity.Jjiagegs; //售价计算公式
        }


        //保存模板
        private void BtnSaveMde_Click(object sender, RoutedEventArgs e)
        {
            if (txtMdeName.Text == "")
            {
                CMessageBox.Show("没有要保存的模板");
                return;
            }

            PriceTemplateEntity entity = new PriceTemplateEntity()
            {
                Jname = txtMdeName.Text,
                SiteID = GlobalUserClass.SiteId,
                Jprfix = txtPrfix.Text.ToString(),
                Jpkglength = SidePratio.Value.ToString(),
                Jpkgwidth = HeightPratio.Value.ToString(),
                Jpkghight = HeightPratio.Value.ToString(),
                Jkuchen = StockPratio.Value.ToString(),
                JMSRPjiajabi = Multipratio.Value.ToString(),
                JMSRPjiajashou = AddPratio.Value.ToString(),
                Jliyunbi = MarginValue.Value.ToString(),
                JMSRPtype = rdoOldpriceTypeCheng.IsChecked == true ? "2" : "1"
            };
            if (yfgsCheckX(txtFreightValue.Text) != "设置正确")
            {
                System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
                txtFreightValue.BorderBrush = brsA;
                CMessageBox.Show("运费计算公式错误");
                return;
            }
            else
            {
                System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(205, 197, 140));
                txtFreightValue.BorderBrush = brsA;

                txtFreightValue.Text = adaptGjyunfeiGS(txtFreightValue.Text);
                entity.Jyunfeigs = txtFreightValue.Text;
            }

            if (!chekjggs(txtPriceVal.Text))
            {
                System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
                txtPriceVal.BorderBrush = brsA;
                CMessageBox.Show("折扣价计算公式错误");
                return;
            }
            else
            {
                System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(205, 197, 140));
                txtPriceVal.BorderBrush = brsA;
                txtPriceVal.Text = adaptJiageGS(txtPriceVal.Text);
                entity.Jjiagegs = txtPriceVal.Text;
            }
            if (new PriceTemplateCore().UpdateTemplate(entity))
            {
                CMessageBox.Show("保存成功");
                Init();
            }

        }


        private string adaptJiageGS(string _oldgs)
        {
            string newgs = _oldgs.Replace(" ", "").Replace(",", "").Replace("（", "(").Replace("）", ")");
            if (newgs == "") return "";

            Regex regex0 = new Regex(@"[^0-9\.\*\+\(\)-/\u91c7\u8d2d\u6210\u672c\u56fd\u9645\u8fd0\u8d39\u5229\u6da6\u7387\u91cd\u91cf]+");
            newgs = (regex0.Replace(newgs, "")).Replace("采购成本", "[采购成本]").Replace("国际运费", "[国际运费]").Replace("国内运费", "[国内运费]").Replace("国运费", "[国内运费]").Replace("利润率", "[利润率]").Replace("重量", "[重量]");
            return newgs;

            // string _jyunfeigs = "(([重量]+50)*0.07+10)/0.8/6";
            // string _jjiagegs = "([进货价]+8+[利润])/0.8/6";

            //促销价=（采购成本+运费） ÷ （1-15%-35%） x  1.55
        }

        private bool chekjggs(string _express)
        {
            if (string.IsNullOrEmpty(_express))
            {
                return false;
            }
            else
            {
                double jgg = ptc.CalcDiscount(txtPriceVal.Text, "100", "50", "1", "1", "0.5", "10");

                if (jgg > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }

        private string adaptGjyunfeiGS(string _oldgs)
        {


            _oldgs = _oldgs.Replace(" ", "").Replace("，", ",").Replace("（", "(").Replace("）", ")");
            if (_oldgs == "") return _oldgs;

            List<string> list = new List<string>();
            Regex regex0 = new Regex(@"\{(?<lowp>\d.*?),(?<highp>\d.*?)\}\{(?<onegs>.+?)\}", RegexOptions.Compiled);
            string[] conditions = _oldgs.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string str in conditions)
            {
                Match matchS = regex0.Match(str);
                if (matchS.Success)
                {
                    //  list.Add(string.Format("{{0},{1}{2}}" , matchS.Groups["lowp"].Value.Trim(), matchS.Groups["highp"].Value.Trim(), adaptJiageGS(matchS.Groups["onegs"].Value)) );
                    list.Add("{" + matchS.Groups["lowp"].Value + "," + matchS.Groups["highp"].Value + "}{" + adaptJiageGS(matchS.Groups["onegs"].Value) + "}");
                }
            }
            return string.Join("\r\n", list.ToArray());
        }


        //新建模板
        private void BtnNewMde_Click(object sender, RoutedEventArgs e)
        {
            if (entities.Count == 10)
            {
                CMessageBox.Show("计价模板不能多于10个");
                return;
            }
            if (txtNewName.Text.Trim() == string.Empty)
            {
                CMessageBox.Show("请输入新模板名称");
                return;
            }
            if (ptc.CheckNewName(txtNewName.Text.Trim()))
            {
                CMessageBox.Show("名称重复了");
                return;
            }
            PriceTemplateEntity newEntity = new PriceTemplateEntity()
            {
                Jname = txtNewName.Text.Trim(),
                SiteID = GlobalUserClass.SiteId,
                Jyunfeigs = sch.GetDefaultJyunfeigs(),
                Jjiagegs = sch.GetDefaultJjiagegs(),
                Jkuchen = "100",
                Jliyunbi = "0.99",
                Jprfix = "UID",
                Jpkglength = "20",
                Jpkgwidth = "10",
                Jpkghight = "5",
                JMSRPjiajabi = "3",
                JMSRPjiajashou = "10",
                JMSRPtype = "1"
            };
            if (!ptc.InsertNewTemplate(newEntity))
            {
                CMessageBox.Show("新增失败,请重试", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            entities.Add(newEntity);

            Label oneLabel = new Label();
            oneLabel.Content = newEntity.Jname;
            oneLabel.Style = Resources["LableMouseOver"] as Style;
            oneLabel.MouseLeftButtonDown += new MouseButtonEventHandler(oneLabel_MouseLeftButtonDown);
            ValuTemMdeleft.Children.Add(oneLabel);

            oneLabel_MouseLeftButtonDown(oneLabel, new RoutedEventArgs());

        }

        //删除选中的模板
        private void BtnDelSel_Click(object sender, RoutedEventArgs e)
        {
            if (txtMdeName.Text.Trim() == "")
            {
                CMessageBox.Show("没有选中的模板");
                return;
            }
            if (txtMdeName.Text.Trim() == "系统预置")
            {
                CMessageBox.Show("预置模板不能删");
                return;
            }
            if (ptc.DeleteTemplate(txtMdeName.Text))
            {
                var entity = entities.Where(p => p.Jname == txtMdeName.Text).First();
                entities.Remove(entity);
                foreach (Label oneLabel in ValuTemMdeleft.Children)
                {
                    if (oneLabel.Content.ToString() == txtMdeName.Text)
                    {
                        ValuTemMdeleft.Children.Remove(oneLabel);
                        break;
                    }
                }
                txtMdeName.Text = "";
            }
            else
            {
                CMessageBox.Show("删除失败请重试", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
            }
        }

        //计算原价说明
        private void LblMultiplication_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }
        //货币说明
        private void LblPriceType_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }

        //利润率书名
        private void LblMarginSta_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }

        //选中 乘
        private void RdoOldpriceTypeCheng_Checked(object sender, RoutedEventArgs e)
        {

        }
        //选中 加
        private void RdoOldpriceTypeJia_Checked(object sender, RoutedEventArgs e)
        {

        }
        //SKU前缀
        private void TxtPrfix_MouseLeave(object sender, MouseEventArgs e)
        {

        }
        //SKU前缀说明
        private void LblPrfixState_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }
        //编辑折扣价公式
        private void BtnPriceEdit_Click(object sender, RoutedEventArgs e)
        {
            if (txtPriceVal.IsReadOnly)
            {
                txtPriceVal.IsReadOnly = false;
                txtPriceVal.Focus();

                btnPriceEdit.Content = "校验";
            }
            else
            {
                if (string.IsNullOrEmpty(txtPriceVal.Text))
                {
                    // explainText.Text = "";
                    //  Pop_explain.PlacementTarget = txtPriceVal;
                    //  Pop_explain.Placement = PlacementMode.Bottom;
                    // Pop_explain.IsOpen = true;
                    System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
                    txtPriceVal.BorderBrush = brsA;
                    return;
                }
                else
                {
                    double jgg = ptc.CalcDiscount(txtPriceVal.Text, "100", "50", "1", "1", "0.5", "10");

                    if (jgg > 0)
                    {
                        System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(205, 197, 140));
                        txtFreightValue.BorderBrush = brsA;

                        txtPriceVal.IsReadOnly = true;

                        btnPriceEdit.Content = "编辑";
                    }
                    else
                    {
                        System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
                        txtPriceVal.BorderBrush = brsA;

                        explainText.Text = "公式中有错误 ，请重新编辑";
                        Pop_explain.PlacementTarget = txtPriceVal;
                        Pop_explain.Placement = PlacementMode.Bottom;
                        Pop_explain.IsOpen = true;
                    }
                }

            }
        }
        //重置折扣价公式
        private void BtnRePrice_Click(object sender, RoutedEventArgs e)
        {
            txtPriceVal.Text = sch.GetDefaultJjiagegs();
        }

        //编辑运费公式
        private void BtnFreight_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtNewxyfgs.Text))
            {
                txtNewxyfgs.Text = txtFreightValue.Text;
            }
            Pop_setShips.PlacementTarget = txtFreightValue;
            Pop_setShips.Placement = PlacementMode.Bottom;

            Pop_setShips.IsOpen = true;
        }


        //确认编辑运费公式后关闭
        private void BtnShip_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtNewxyfgs.Text)) return;

            string chkresult = yfgsCheckX(txtNewxyfgs.Text.Trim());

            lbyfgstips.Content = chkresult;

            if (chkresult == "设置正确")
            {
                txtFreightValue.Text = txtNewxyfgs.Text;
                Pop_setShips.IsOpen = false;
            }
        }

        //检查在编辑的运费公式
        private void BtnShipcheckIsRight_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtNewxyfgs.Text)) return;

            lbyfgstips.Content = yfgsCheckX(txtNewxyfgs.Text);
        }

        private string yfgsCheckX(string _express)
        {

            double wt = -1;

            _express = _express.Replace(" ", "").Replace("，", ",").Replace("（", "(").Replace("）", ")");
            if (_express == "") return "无内容";

            Regex regex0 = new Regex(@"\{(?<lowp>\d.*?),(?<highp>\d.*?)\}\{(?<onegs>.+?)\}", RegexOptions.Compiled);
            string[] conditions = _express.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string str in conditions)
            {
                if (string.IsNullOrEmpty(str)) continue;
                Match matchS = regex0.Match(str);
                if (matchS.Success)
                {
                    double lp = -1;
                    double hp = -1;

                    if (Double.TryParse(matchS.Groups["lowp"].Value.Trim(), out lp) && Double.TryParse(matchS.Groups["highp"].Value.Trim(), out hp))
                    {
                        wt = (lp + hp) / 2;

                        double result = ptc.CalcDiscount(matchS.Groups["onegs"].Value.Trim(), "0", "0", "1", "1", "0", wt.ToString());

                        if (result <= 0) return "行 " + str + " 格式错误";
                    }
                    else
                    {
                        return "行 " + str + " 格式错误";
                    }


                }
                else
                {
                    return "行 " + str + " 格式错误";
                }

            }

            return "设置正确";

        }


        //重置运费公式
        private void BtnShipreset_Click(object sender, RoutedEventArgs e)
        {
            txtNewxyfgs.Text = sch.GetDefaultJyunfeigs();
        }
    }
}
