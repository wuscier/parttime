﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// MutiAttrSelector.xaml 的交互逻辑
    /// </summary>
    public partial class MutiAttrSelector : UserControl
    {
        public static readonly DependencyProperty AttributValueProperty = DependencyProperty.Register("AttributValue", typeof(string), typeof(MutiAttrSelector));
        public string AttributValue  //不在此作验证
        {
            get { return (string)GetValue(AttributValueProperty); }
            set { SetValue(AttributValueProperty, value); }
        }

        public static readonly DependencyProperty SearchTextProperty = DependencyProperty.Register("SearchText", typeof(string), typeof(MutiAttrSelector));
        public string SearchText  //不在此作验证
        {
            get { return (string)GetValue(SearchTextProperty); }
            set { SetValue(SearchTextProperty, value); }
        }

        public List<string> oldvalues = new List<string>();
        public List<string> OrderedValues = null;

        public MutiAttrSelector()
        {
            InitializeComponent();
        }

        private void PART_TextBox_MouseDown(object sender, MouseButtonEventArgs e)
        {
            PART_AttrPopup.IsOpen = true;
        }


        public void RefreshOpints(Dictionary<string, string> dic)
        {
            if (PART_ListBox.Items.Count > 0 && dic.Count > 0)
            {
                foreach (CheckBox tcbx in PART_ListBox.Items)
                {
                    if (dic.ContainsKey(tcbx.Tag.ToString())) tcbx.Content = tcbx.Tag.ToString() + "(" + dic[tcbx.Tag.ToString()] + ")";
                }

            }


        }

        public void AddOpints(List<OptionItem> _ops)
        {
            if (_ops.Count > 0)
            {
                if (_ops.Count > 20)// _ops = _ops.OrderBy(x => x.EnName).ToList();
                {
                    _ops.Sort(delegate (OptionItem x, OptionItem y)
                    {
                        return x.EnName.CompareTo(y.EnName);
                    });
                }

                //给出已选过了的
                foreach (OptionItem vstr in _ops)
                {
                    string eename = vstr.EnName.Trim();
                    string chname = vstr.ChName.Trim();
                    CheckBox mcb = new CheckBox();
                    mcb.Content = chname;
                    mcb.Tag = eename;

                    PART_ListBox.Items.Add(mcb);

                    if (oldvalues != null && oldvalues.Contains(eename)) mcb.IsChecked = true;

                    mcb.Checked += Mcb_Checked;
                    mcb.Unchecked += Mcb_Unchecked;

                    int pwidth = 15;
                    if (chname.Length > pwidth) pwidth = chname.Length;

                    PART_ListBox.Width = pwidth * 15;
                }

                if (_ops.Count > 50)
                {
                    OrderedValues = _ops.Select(x => x.EnName.ToUpper()).ToList();

                    string[] strs = { "-", "?", "A", "M", "B", "N", "C", "O", "D", "P", "E", "Q", "F", "R", "G", "S", "H", "T", "I", "U", "J", "V", "K", "W", "L", "Y", "X", "Z" };

                    WrapPanel LSTB = new WrapPanel();
                    LSTB.Width = 50;
                    // LSTB.Orientation = Orientation.Vertical;
                    for (int i = 0; i < strs.Length; i++)
                    {
                        Label ABL = new Label();
                        ABL.Content = strs[i];
                        // ABL.SetValue(Label.StyleProperty, Application.Current.Resources["LableMouseOverMS"]);
                        ABL.Style = this.FindResource("LableMouseOverMS") as Style;
                        ABL.ApplyTemplate();

                        ABL.MouseLeftButtonUp += ABL_MouseLeftButtonUp;
                        ABL.MouseRightButtonUp += ABL_MouseRightButtonUp;

                        LSTB.Children.Add(ABL);

                    }

                    M_grid.Children.Add(LSTB); //添加到Grid控件

                    LSTB.SetValue(Grid.ColumnProperty, 1); //设置按钮所在Grid控件的列
                    LSTB.SetValue(Grid.RowProperty, 1); //设置按钮所在Grid控件的列


                    TextBox TBX = new TextBox();
                    TBX.Width = 150;
                    TBX.Height = 22;
                    TBX.HorizontalAlignment = HorizontalAlignment.Left;
                    TBX.Margin = new Thickness(3);

                    TBX.KeyDown += SearchBox_KeyDown;


                    Binding bd = new Binding { Source = this, Path = new PropertyPath("SearchText") };
                    bd.Mode = BindingMode.TwoWay;
                    bd.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                    TBX.SetBinding(TextBox.TextProperty, bd);

                    M_grid.Children.Add(TBX); //添加到Grid控件
                    TBX.SetValue(Grid.ColumnProperty, 0); //设置按钮所在Grid控件的列
                    TBX.SetValue(Grid.RowProperty, 0); //设置按钮所在Grid控件的列

                }


            }



        }

        private void ABL_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            string fstr = ((Label)sender).Content.ToString();
            if (fstr != "-" && fstr != "?")
            {
                SearchText = SearchText + fstr;
                ScrollToIndex(SearchText);
            }

        }

        private void ABL_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            string fstr = ((Label)sender).Content.ToString();
            if (fstr == "-")
            {
                SearchText = "";
            }
            else if (fstr == "?")
            {
                ScrollToIndex(SearchText);
            }
            else
            {
                SearchText = fstr;
                ScrollToIndex(SearchText);
            }




        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyboardDevice.IsKeyDown(Key.Enter))
            {
                e.Handled = true;

                TextBox tbx = (TextBox)sender;
                if (string.IsNullOrEmpty(tbx.Text.Trim())) return;
                tbx.Text = tbx.Text.Trim();
                ScrollToIndex(tbx.Text);
            }

        }


        //  navItemsListBox.ScrollIntoView(navItemsListBox.Items[++CurrentRightIndex]);
        private void ScrollToIndex(string _str)
        {
            _str = _str.Trim().ToUpper();

            if (OrderedValues != null && OrderedValues.Count > 0 && _str.Length < 1)
            {
                PART_ListBox.ScrollIntoView(PART_ListBox.Items[0]);
                PART_ListBox.SelectedIndex = 0;
                return;
            }


            if (OrderedValues != null && OrderedValues.Count > 0 && _str.Length > 0)
            {
                for (int i = 0; i < OrderedValues.Count; i++)
                {
                    if (OrderedValues[i].StartsWith(_str))
                    {
                        if (i > 30 && i < OrderedValues.Count - 30)
                        {
                            PART_ListBox.ScrollIntoView(PART_ListBox.Items[i + 13]);
                        }
                        else
                        {
                            PART_ListBox.ScrollIntoView(PART_ListBox.Items[i]);
                        }
                        PART_ListBox.SelectedIndex = i;
                        ((FrameworkElement)(PART_ListBox.Items[i])).Focus();

                        return;
                    }
                }

            }


        }



        private void Mcb_Unchecked(object sender, RoutedEventArgs e)
        {
            string cbstr = ((CheckBox)sender).Tag.ToString();
            if (oldvalues != null && oldvalues.Contains(cbstr))
            {
                oldvalues.Remove(cbstr);
                if (oldvalues.Count > 0)
                {
                    AttributValue = string.Join(",", oldvalues.ToArray());
                }
                else
                {
                    AttributValue = "";
                }
            }
        }

        private void Mcb_Checked(object sender, RoutedEventArgs e)
        {
            string cbstr = ((CheckBox)sender).Tag.ToString();
            if (oldvalues != null && !oldvalues.Contains(cbstr))
            {
                oldvalues.Add(cbstr);
                AttributValue = string.Join(",", oldvalues.ToArray());
            }

        }
    }
}
