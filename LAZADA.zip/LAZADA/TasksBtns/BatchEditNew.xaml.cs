﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Logic.PriceTemplate;
using Logic.SystemSole;
using Logic.Translation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.AlertHelp;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// BatchEditNew.xaml 的交互逻辑
    /// </summary>
    public partial class BatchEditNew : UserControl
    {
        public Window parent;
        private CategorySelector selector = null;
        #region 过滤掉已经有的属性
        List<string> attrlist = new List<string>
            {
                "name",
                "short_description",
                "description",
                "video",
                "size",
                "SellerSku",
                "barcode_ean",
                //"product_warranty",
                "quantity",
                "name_ms",
                "product_warranty_en",
                "price",
                "special_price",
                "special_from_date",
                "special_to_date",
                "description_ms",
                "seller_promotion",
                "package_content",
                "package_weight",
                "package_length",
                "package_width",
                "package_height",
                "__images__",
                //"tax_class",
                "published_date",
                "external_url",
                "std_search_keywords"
            };

        #endregion
        List<Aattribute> categoryOtherAttrs = new List<Aattribute>();
        string oldSreachContect = "";
        public BatchEditNew()
        {
            InitializeComponent();
            txtAffectRow.Text = "选中" + SystemSoleEntity.SelectedProductNumberList.Count + "行";
        }
        private void BtnExecute_Click(object sender, RoutedEventArgs e)
        {
            if (EditMode.Children.Count == 0) return;
            var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            SystemSoleEntity.GetMainWinModel().InitModel("批量编辑", list.Count);
            Task.Run(() =>
            {
                foreach (var product in list)
                {
                    try
                    {
                        this.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            foreach (Canvas control in EditMode.Children)
                            {
                                switch (Convert.ToString(control.Tag))
                                {
                                    case "标题变更":
                                        TileChange(product);
                                        break;
                                    case "描述头变更":
                                        DescChange(product);
                                        break;
                                    case "卖点变更":
                                        SalePointChange(product);
                                        break;
                                    case "计价模板变更":
                                        PriceTemplateChange(product);
                                        break;
                                    case "选择类目":
                                        ChoooseCategory(product);
                                        break;
                                }
                            }
                            new ProductCore().UpdateBatchEdit(product);
                        }));
                    }
                    catch (Exception ex)
                    {
                        SystemSoleEntity.GetMainWinModel().IbulkErrowCount++;
                        new LogOutput.LogTo().WriteErrorLine("批量编辑出错：" + product.Porigimgsurl + "///" + ex.Message);
                    }
                    SystemSoleEntity.GetMainWinModel().Ipbvalue += SystemSoleEntity.GetMainWinModel().TaskAdd;
                    SystemSoleEntity.GetMainWinModel().TaskRunCount++;
                }
                //EditMode.Children.Clear();
                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    MySoundPlay.PlayMusic();
                    CMessageBox.Show("修改完成");
                    parent.Close();
                }));
            });
            //CMessageBox.Show("编辑成功");
            //this.Close();
        }

        /// <summary>
        /// 标题变更
        /// </summary>
        /// <param name="product"></param>
        private void TileChange(Product product)
        {
            if (txtTitleEditVal.Text != string.Empty)
                product.Pnewtitle = txtTitleEditVal.Text;
            else
            {
                if (txtTitleAddFrVal.Text != string.Empty)
                {
                    product.Pnewtitle = txtTitleAddFrVal.Text + " " + product.Pnewtitle;
                }
                if (txtTitleAddBeVal.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle + " " + txtTitleAddBeVal.Text;
                }
                if (txtTitleReplyValA.Text != string.Empty && txtTitleAsValA.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle.Replace(txtTitleReplyValA.Text, txtTitleAsValA.Text);
                }
                if (txtTitleReplyValB.Text != string.Empty && txtTitleAsValB.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle.Replace(txtTitleReplyValB.Text, txtTitleAsValB.Text);
                }
                if (txtTitleReplyValC.Text != string.Empty && txtTitleAsValC.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle.Replace(txtTitleReplyValC.Text, txtTitleAsValC.Text);
                }
                if (txtTitleReplyValD.Text != string.Empty && txtTitleAsValD.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle.Replace(txtTitleReplyValD.Text, txtTitleAsValD.Text);
                }
            }
        }

        /// <summary>
        /// 描述头变更
        /// </summary>
        /// <param name="product"></param>
        private void DescChange(Product product)
        {
            if (Convert.ToString(HtmlEditorDesc.BindingContent) != string.Empty)
            {
                product.Lazadadescription = Convert.ToString(HtmlEditorDesc.BindingContent);
                if (chkDescTranslate.IsChecked ?? false)
                {
                    product.Lazadadescription = new ALiCore().ChangeZhToSiteDefaultLangauge(product.Lazadadescription, "offer");
                }
            }
            else
            {
                if (txtDescAddFrontVal.Text != string.Empty)
                    product.Lazadadescription = "<P>" + txtDescAddFrontVal.Text + "</P>" + product.Lazadadescription;
                if (txtDescAddBehindVal.Text != string.Empty)
                    product.Lazadadescription = "<P>" + txtDescAddBehindVal.Text + "</P>" + product.Lazadadescription;
            }
            if (chkDescTranslate.IsChecked ?? false)
            {
                product.Lazadadescription = product.Lazadadescription.Replace("\t", "-#").Replace("\r\n", "♂").Replace("\n\n", "♂").Replace("\r", "♂").Replace("\n", "♂");
                Regex reg = new Regex("[\u4e00-\u9fa5]+");
                string restr1 = !reg.IsMatch(product.Lazadadescription, 0) ? product.Lazadadescription : new ALiCore().ChangeZhToEn(product.Lazadadescription).Replace("♂", "\n").Replace("^", " ").Replace("-#", "\t").Trim();
            }
        }

        /// <summary>
        /// 卖点变更
        /// </summary>
        /// <param name="product"></param>
        private void SalePointChange(Product product)
        {
            if (Convert.ToString(HtmlEditorHLight.BindingContent) != string.Empty)
                product.Lazadahighlight = Convert.ToString(HtmlEditorHLight.BindingContent);
            else
            {
                if (txtSellForntAdd.Text != string.Empty)
                {
                    product.Lazadahighlight = "<P>" + txtSellForntAdd.Text + "</P>" + product.Lazadahighlight;
                }
                if (txtSellBehindAdd.Text != string.Empty)
                {
                    product.Lazadahighlight = product.Lazadahighlight + "<P>" + txtSellBehindAdd.Text + "</P>";
                }
            }
        }

        /// <summary>
        /// 计价模板变更
        /// </summary>
        /// <param name="product"></param>
        private void PriceTemplateChange(Product product)
        {
            bool needReCalc = false;
            var ptc = new PriceTemplateCore();
            var jname = cmbValua.Text;
            if (jname == string.Empty)
                jname = product.Pjisangongshi;
            var template = ptc.GetPriceTemplate(jname);
            if (chkBoxWeight.IsChecked ?? false)
            {
                product.Lazadapackageweight = Convert.ToString(PkgWight.Value);
                needReCalc = true;
            }
            if ((BoxWeightCK.IsChecked ?? false && cmboBoxCondition.Text != string.Empty && comboBoxAction.Text != string.Empty))
            {
                var weight = Convert.ToDecimal(product.Lazadapackageweight);
                var condition1 = NumericUpDownConditionWeight.Value;
                var condition2 = NumericUpDownConditionWeight.Value;

                if (Convert.ToString(cmboBoxCondition.Text) == "小于" && weight < condition1)
                {
                    if (Convert.ToString(comboBoxAction.Text) == "增加")
                    {
                        weight += condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "减少" && weight > condition2)
                    {
                        weight -= condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "改为" && condition2 > 0)
                    {
                        weight = condition2;
                        needReCalc = true;
                    }
                }
                else if (Convert.ToString(cmboBoxCondition.Text) == "等于" && weight == condition1)
                {
                    if (Convert.ToString(comboBoxAction.Text) == "增加")
                    {
                        weight += condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "减少" && weight > condition2)
                    {
                        weight -= condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "改为" && condition2 > 0)
                    {
                        weight = condition2;
                        needReCalc = true;
                    }
                }
                else if (Convert.ToString(cmboBoxCondition.Text) == "大于" && weight > condition1)
                {
                    if (Convert.ToString(comboBoxAction.Text) == "增加")
                    {
                        weight += condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "减少" && weight > condition2)
                    {
                        weight -= condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "改为" && condition2 > 0)
                    {
                        weight = condition2;
                        needReCalc = true;
                    }
                }

            }

            if ((cmbValua.Text != string.Empty && cmbValua.Text != "不更改"))
            {
                product.Pjisangongshi = template.Jname;
                needReCalc = true;
            }
            if (chkStock.IsChecked ?? false)
            {
                product.Pkuchen = NumericUpDownKuchen.ContentText;
            }
            if (chkMeasure.IsChecked ?? false)
            {
                product.PackageLength = NumericUpDownPkgLength.ContentText.ToString();
                product.PackageWidth = NumericUpDownPkgWidth.ContentText.ToString();
                product.PackageHight = NumericUpDownPkgHight.ContentText.ToString();
            }
            if ((chkHOTGroupBox.IsChecked ?? false && StartDate.PickedDateTime != string.Empty && EndDate.PickedDateTime != string.Empty))
            {
                //if (rdoTimeAlll.IsChecked ?? false)
                //{
                product.Lazadapromstart = StartDate.PickedDateTime;
                product.Lazadapromend = EndDate.PickedDateTime;
                //}
                //else
                //{
                //if (product.Lazadapromstart != string.Empty && product.Lazadapromend != string.Empty)
                //{
                //    if (rdoTimePartReset.IsChecked ?? false)
                //    {
                //        var start = Convert.ToDateTime(product.Lazadapromstart);
                //        var end = Convert.ToDateTime(product.Lazadapromend);
                //        if (start < DateTime.Now)
                //        {
                //            product.Lazadapromstart = StartDate.PickedDateTime;
                //            product.Lazadapromend = Convert.ToDateTime(EndDate.PickedDateTime).AddDays((end - start).Days).AddHours((end - start).Hours).ToString();
                //        }
                //    }
                //}
                if (product.Lazadapromstart == string.Empty)
                    product.Lazadapromstart = StartDate.PickedDateTime;
                if (product.Lazadapromend == string.Empty)
                    product.Lazadapromend = EndDate.PickedDateTime;
                //}
            }
            if (needReCalc)
            {
                ptc.CalcProductCost(template, product, Convert.ToDouble(product.Porigprice));
            }
        }

        private void LblTitle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            ChangeFontColor((Label)sender);
            CvTitle.Visibility = Visibility.Visible;
        }
        private void ChangeLabelBgColor(Label label)
        {
            System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(209, 209, 209));
            lblTitle.Background = brsA;
            lblDescribe.Background = brsA;
            lblSelling.Background = brsA;
            lblValua.Background = brsA;
            lblCategoryTi.Background = brsA;

            System.Windows.Media.Brush brsB = new SolidColorBrush(System.Windows.Media.Color.FromRgb(31, 158, 255));
            label.Background = brsB;
            CvTitle.Visibility = System.Windows.Visibility.Collapsed;
            CanvasDesc.Visibility = System.Windows.Visibility.Collapsed;
            CanvasSelling.Visibility = System.Windows.Visibility.Collapsed;
            CanvasValuaMode.Visibility = System.Windows.Visibility.Collapsed;
            CavCategory.Visibility = System.Windows.Visibility.Collapsed;
        }
        private void ChangeFontColor(Label label)
        {
            System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 0, 0));
            lblTitle.Foreground = brsA;
            lblDescribe.Foreground = brsA;
            lblSelling.Foreground = brsA;
            lblValua.Foreground = brsA;
            lblCategoryTi.Foreground = brsA;


            System.Windows.Media.Brush brsB = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 255, 255));
            label.Foreground = brsB;
            CvTitle.Visibility = System.Windows.Visibility.Collapsed;
            CanvasDesc.Visibility = System.Windows.Visibility.Collapsed;
            CanvasSelling.Visibility = System.Windows.Visibility.Collapsed;
            CanvasValuaMode.Visibility = System.Windows.Visibility.Collapsed;
            CavCategory.Visibility = System.Windows.Visibility.Collapsed;
        }

        private void LblDescribe_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            ChangeFontColor((Label)sender);
            CanvasDesc.Visibility = Visibility.Visible;
        }

        private void LblSelling_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            ChangeFontColor((Label)sender);
            CanvasSelling.Visibility = Visibility.Visible;
        }

        private void LblValua_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            ChangeFontColor((Label)sender);
            CanvasValuaMode.Visibility = Visibility.Visible;
        }

        private void LblCategoryTi_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            ChangeFontColor((Label)sender);
            CavCategory.Visibility = Visibility.Visible;
        }

        private void Rootgrid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSelect_Click(object sender, RoutedEventArgs e)
        {
            this.Pop_category.IsOpen = true;
            bool flag = this.selector == null;
            if (flag)
            {
                this.selector = new CategorySelector();
                this.selector.CategoryChanged += this.CategroyChange;
            }
            this.contentControlCategory.Content = this.selector;
        }
        private void CategroyChange(object sender, RoutedEventArgs e)
        {
            var selector = (CategorySelector)sender;
            string text = selector.namePath.Trim();
            bool flag = string.IsNullOrEmpty(text);
            if (flag)
            {
                this.lblCategoryResult.Content = "无效类目，请重新选择";
            }
            else
            {
                this.lblCategoryResult.Content = text;
                this.lblCategoryResult.Tag = selector.leafId;
            }
            if (selector.leafId.Trim() != string.Empty)
            {
                this.Pop_category.IsOpen = false;
                btnConfirm.IsEnabled = true;
                LoadCategoryDetailNew(selector.leafId);
            }
        }

        private void LoadCategoryDetailNew(string leafId)
        {
            JObject jsondata = new LazadaCore().GetCategoryAttr(leafId);
            //Product product = (Product)this.DataContext;
            if (jsondata["data"] == null) return;
            var list = ((JArray)jsondata["data"]).ToList();
            categoryOtherAttrs.Clear();
            WrpPnlProRequired.Children.Clear();
            WrpPnlProChoosable.Children.Clear();
            list.ForEach(item =>
            {
                var name = item["name"].ToString();
                ///去除系统自带属性
                if (attrlist.Contains(name))
                    return;
                ///是否是销售属性,(用于判断是否是上方的辩题属性)
                bool isSaleProp = Convert.ToBoolean(item["is_sale_prop"]);
                if (!isSaleProp)
                {
                    bool isMandatory = Convert.ToBoolean(item["is_mandatory"]);
                    if (isMandatory)
                    {
                        Aattribute aattribute = new Aattribute();
                        aattribute.Aname = item["name"].ToString();
                        aattribute.IsSku = true;
                        categoryOtherAttrs.Add(aattribute);
                        caMlKHhf7i(this.WrpPnlProRequired, (JObject)item, aattribute);
                    }
                    else
                    {
                        Aattribute aattribute = new Aattribute();
                        aattribute.Aname = item["name"].ToString();
                        aattribute.IsSku = false;
                        categoryOtherAttrs.Add(aattribute);
                        caMlKHhf7i(this.WrpPnlProChoosable, (JObject)item, aattribute);
                    }
                }
            });
        }
        private void LoadCategoryDetail(string leafId)
        {
            JObject jsondata = new LazadaCore().GetCategoryAttr(leafId);
            //Product product = (Product)this.DataContext;
            if (jsondata["data"] == null) return;
            var list = ((JArray)jsondata["data"]).ToList();
            categoryOtherAttrs.Clear();
            WrpPnlProRequired.Children.Clear();
            WrpPnlProChoosable.Children.Clear();
            //SKU 必要属性
            list.Where(p => Convert.ToString(p["attribute_type"]) == "sku").ToList().ForEach(item =>
            {
                if (item["input_type"].ToString() == "singleSelect" && item["is_mandatory"].ToString() == "1" && item["options"].HasValues)
                {
                    //税种
                    if (item["name"].ToString() == "tax_class")
                    {
                        if (item["options"] != null && item["options"].HasValues)
                        {
                            Aattribute aattribute6 = new Aattribute();
                            aattribute6.Aname = item["name"].ToString();
                            aattribute6.IsSku = true;
                            categoryOtherAttrs.Add(aattribute6);
                            caMlKHhf7i(this.WrpPnlProChoosable, (JObject)item, aattribute6);
                        }
                    }
                }
                else
                {
                    if (((item["input_type"].ToString() == "multiSelect" || item["input_type"].ToString() == "multiEnumInput" || item["input_type"].ToString() == "enumInput")
                    && item["is_mandatory"].ToString() == "1" && item["options"].HasValues) ||
                    item["name"].ToString() == "type_screen_guard" || item["name"].ToString() == "material_screen_guard" || item["name"].ToString() == "eyewear_size")
                    {
                        return;
                    }
                    else
                    {
                        Aattribute aattribute5 = new Aattribute();
                        aattribute5.Aname = item["name"].ToString();
                        aattribute5.IsSku = true;
                        if (!attrlist.Contains(aattribute5.Aname))
                            categoryOtherAttrs.Add(aattribute5);
                        if (attrlist.Contains(aattribute5.Aname)) return;
                        if ((int)item["is_mandatory"] == 1)

                        {
                            bool flag43 = !item["label"].ToString().StartsWith("*");
                            if (flag43)
                            {
                                item["label"] = "*" + item["label"].ToString();
                            }
                            caMlKHhf7i(this.WrpPnlProRequired, (JObject)item, aattribute5);
                        }
                        else

                        {
                            caMlKHhf7i(this.WrpPnlProChoosable, (JObject)item, aattribute5);
                        }
                    }
                }
            });
            //sku 非必要属性
            list.Where(p => Convert.ToString(p["attribute_type"]) != "sku").ToList().ForEach(item =>
            {
                if (attrlist.Contains(item["name"].ToString())) return;
                Aattribute aattribute5 = new Aattribute();
                aattribute5.Aname = item["name"].ToString();
                aattribute5.IsSku = (int)item["is_mandatory"] == 1;
                if (!attrlist.Contains(aattribute5.Aname))
                    categoryOtherAttrs.Add(aattribute5);
                bool flag42 = (int)item["is_mandatory"] == 1;
                if (flag42)

                {
                    bool flag43 = !item["label"].ToString().StartsWith("*");
                    if (flag43)
                    {
                        item["label"] = "*" + item["label"].ToString();
                    }
                    this.caMlKHhf7i(this.WrpPnlProRequired, (JObject)item, aattribute5);
                }
                else

                {
                    this.caMlKHhf7i(this.WrpPnlProChoosable, (JObject)item, aattribute5);
                }

            });
        }
        private void caMlKHhf7i(WrapPanel wp, JObject att, Aattribute od)
        {
            int num = 0;
            Canvas canvas = new Canvas();
            canvas.Height = 25.0;
            canvas.Width = 295;
            if (att["label"].ToString().StartsWith("*") || att["is_mandatory"].ToString() == "1")
            {
                canvas.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFB43F"));
            }
            else
            {
                canvas.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#9DAAC1"));
            }
            canvas.Margin = new Thickness(4.0, 0.0, 0.0, 2.0);
            canvas.DataContext = od;
            Label label = new Label();
            bool flag2 = att["CHlabel"] == null;
            if (flag2)
            {
                label.Content = att["label"].ToString();
            }
            else
            {
                label.Content = att["CHlabel"].ToString();
                label.ToolTip = att["label"].ToString();
            }
            bool flag3 = att["label"].ToString().Length > 15;
            if (flag3)
            {
                label.ToolTip = att["label"].ToString();
                num = 50;
            }
            label.HorizontalAlignment = HorizontalAlignment.Left;
            canvas.Children.Add(label);
            label.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
            //label.MouseEnter += this.aaQlO13fOX;

            //label.MouseLeave += this.LArlUJbNoF;

            label.MouseDoubleClick += this.AttributeDoubleClick;

            string a = att["input_type"].ToString();
            if (!(a == "numeric") && !(a == "text"))

            {
                if (!(a == "multiSelect"))
                {
                    if (!(a == "singleSelect" || a == "multiEnumInput" || a == "enumInput"))
                    {
                        TextBox textBox = new TextBox();
                        textBox.Height = 22.0;
                        textBox.Width = (double)(120);
                        textBox.Margin = new Thickness((double)(150), 2.0, 0.0, 0.0);
                        textBox.HorizontalAlignment = HorizontalAlignment.Right;
                        //textBox.LostFocus += this.NFAl5Wf0JS;
                        Binding binding = new Binding("Avalue");
                        binding.Mode = BindingMode.TwoWay;
                        binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                        textBox.SetBinding(TextBox.TextProperty, binding);
                        canvas.Children.Add(textBox);
                    }
                    else
                    {
                        ComboBox comboBox = new ComboBox();
                        comboBox.Height = 22.0;
                        comboBox.Width = (double)(120);
                        comboBox.Margin = new Thickness((double)(150), 2.0, 0.0, 0.0);
                        comboBox.Tag = od;
                        comboBox.HorizontalAlignment = HorizontalAlignment.Right;
                        JArray jarray = (JArray)att["options"];
                        bool flag4 = jarray.Count > 0;
                        if (flag4)

                        {
                            label.Tag = new FyLabel("", label, comboBox, att);
                            ObservableCollection<OptionItem> observableCollection = new ObservableCollection<OptionItem>();
                            observableCollection.Add(new OptionItem
                            {
                                EnName = " ",
                                ChName = " "
                            });
                            int num2 = -1;
                            for (int i = 0; i < jarray.Count; i++)
                            {
                                string text = ((JObject)jarray[i])["name"].ToString();
                                string chName = text;
                                bool flag5 = ((JObject)jarray[i])["CHname"] != null;
                                if (flag5)
                                {
                                    bool flag6 = !string.IsNullOrEmpty(((JObject)jarray[i])["CHname"].ToString());
                                    if (flag6)
                                    {
                                        chName = ((JObject)jarray[i])["CHname"].ToString();
                                    }
                                }
                                OptionItem item = new OptionItem
                                {
                                    EnName = text,
                                    ChName = chName
                                };
                                observableCollection.Add(item);
                                bool flag7 = od.Avalue == text;
                                if (flag7)
                                {
                                    num2 = observableCollection.IndexOf(item);
                                }
                            }
                            comboBox.ItemsSource = observableCollection;
                            comboBox.DisplayMemberPath = "ChName";
                            comboBox.SelectedValuePath = "EnName";
                            comboBox.SelectionChanged += this.i36lhTIgPS;
                            bool flag8 = num2 >= 0 && comboBox.Items.Count > num2;
                            if (flag8)
                            {
                                comboBox.SelectedIndex = num2;
                            }
                        }
                        else

                        {
                            Binding binding2 = new Binding("Avalue");
                            binding2.Mode = BindingMode.TwoWay;
                            comboBox.SetBinding(ComboBox.TextProperty, binding2);
                            comboBox.IsEditable = true;
                            comboBox.IsTextSearchEnabled = false;
                            bool flag9 = att["name"].ToString() == "brand";
                            if (flag9)

                            {
                                TextBox textBox2 = new TextBox();
                                textBox2.Height = 22.0;
                                textBox2.Width = (double)(215 - num);
                                textBox2.KeyDown += this.auClNmcSBP;
                                textBox2.HorizontalAlignment = HorizontalAlignment.Right;
                                textBox2.Margin = new Thickness((double)(150), 2.0, 0.0, 0.0);
                                comboBox.Items.Add(textBox2);
                                //comboBox.GotFocus += this.akgl7QsrYW;
                                WaittingImg waittingImg = new WaittingImg("Enter后开搜索");
                                waittingImg.pauseWaitting();
                                textBox2.Tag = waittingImg;
                            }
                        }
                        canvas.Children.Add(comboBox);
                    }
                }
                else
                {
                    MutiAttrSelector mutiAttrSelector = new MutiAttrSelector();
                    mutiAttrSelector.Height = 22.0;
                    mutiAttrSelector.Width = (double)(120);
                    mutiAttrSelector.Margin = new Thickness((double)(150), 2.0, 0.0, 0.0);
                    mutiAttrSelector.HorizontalAlignment = HorizontalAlignment.Right;
                    mutiAttrSelector.Tag = od;
                    Binding binding3 = new Binding("Avalue");
                    binding3.Mode = BindingMode.TwoWay;
                    mutiAttrSelector.SetBinding(MutiAttrSelector.AttributValueProperty, binding3);
                    mutiAttrSelector.SetBinding(FrameworkElement.ToolTipProperty, binding3);
                    JArray jarray2 = (JArray)att["options"];
                    bool flag10 = jarray2.Count > 0;
                    if (flag10)
                    {
                        label.Tag = new FyLabel("", label, mutiAttrSelector, att);
                        bool flag11 = !string.IsNullOrEmpty(od.Avalue);
                        if (flag11)
                        {
                            List<string> list = new List<string>();
                            string[] array = od.Avalue.Split(new char[]
                                                        {
                                ','
                                                        }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string text2 in array)
                            {
                                bool flag12 = !list.Contains(text2.Trim());
                                if (flag12)
                                {
                                    list.Add(text2.Trim());
                                }
                            }
                            mutiAttrSelector.oldvalues = list;
                        }
                        List<OptionItem> list2 = new List<OptionItem>();
                        for (int k = 0; k < jarray2.Count; k++)
                        {
                            string text3 = ((JObject)jarray2[k])["name"].ToString().Trim();
                            string chName2 = text3;
                            bool flag13 = ((JObject)jarray2[k])["CHname"] != null;
                            if (flag13)
                            {
                                bool flag14 = !string.IsNullOrEmpty(((JObject)jarray2[k])["CHname"].ToString());
                                if (flag14)
                                {
                                    chName2 = ((JObject)jarray2[k])["CHname"].ToString();
                                }
                            }
                            OptionItem item2 = new OptionItem
                            {
                                EnName = text3,
                                ChName = chName2
                            };
                            list2.Add(item2);
                        }
                        mutiAttrSelector.AddOpints(list2);
                    }
                    canvas.Children.Add(mutiAttrSelector);
                }
            }
            else
            {
                TextBox textBox3 = new TextBox();
                textBox3.Height = 22.0;
                textBox3.Width = (double)(120);
                textBox3.Margin = new Thickness((double)(150), 2.0, 0.0, 0.0);
                textBox3.HorizontalAlignment = HorizontalAlignment.Right;
                //textBox3.LostFocus += this.NFAl5Wf0JS;

                Binding binding4 = new Binding("Avalue");

                binding4.Mode = BindingMode.TwoWay;

                binding4.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;

                textBox3.SetBinding(TextBox.TextProperty, binding4);
                canvas.Children.Add(textBox3);
            }
            wp.Children.Add(canvas);
        }


        #region 属性双击翻译
        private void AttributeDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Label label = (Label)sender;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(label.Content.ToString() + "\r\n");
            bool flag = label.Tag != null;
            if (flag)
            {
                FyLabel fyLabel = (FyLabel)label.Tag;
                JArray jarray = (JArray)fyLabel.FYary["options"];
                foreach (JToken jtoken in jarray)
                {
                    stringBuilder.Append(jtoken["name"].ToString() + "\r\n");
                }
                fyLabel.FYstr = stringBuilder.ToString();
                new Thread(new ParameterizedThreadStart(this.AttributeTranslation)).Start(fyLabel);
            }
            else
            {
                var labelContent = new ALiCore().ChangeEnToZh(label.Content.ToString());
                this.Dispatcher.BeginInvoke(new Action(() => label.Content = labelContent));
            }
        }

        public void AttributeTranslation(object d)
        {
            string text = new ALiCore().ChangeEnToZh(((FyLabel)d).FYstr);
            base.Dispatcher.BeginInvoke(new Action<FyLabel, string>(delegate (FyLabel b, string c)
            {
                try
                {
                    bool flag = string.IsNullOrEmpty(c);
                    if (!flag)
                    {
                        Dictionary<string, string> dictionary = new Dictionary<string, string>();
                        string[] strZH = c.Replace("\n", "●").Split('●');
                        string[] strEN = ((FyLabel)b).FYstr.Replace("\n", "●").Split('●');
                        for (int i = 0; i < strEN.Length; i++)
                        {
                            string key = strEN[i].ToString().Trim();
                            string value = strZH.Length > i ? strZH[i].ToString().Trim() : null;
                            bool flag3 = !dictionary.ContainsKey(key);
                            if (flag3)
                            {
                                dictionary.Add(key, value);
                            }
                        }
                        Label fylb = b.FYlb;
                        bool flag4 = dictionary.ContainsKey(fylb.Content.ToString());
                        if (flag4)
                        {
                            fylb.ToolTip = fylb.Content.ToString();
                            fylb.Content = dictionary[fylb.Content.ToString()];
                        }
                        string key2 = b.FYary["label"].ToString();
                        bool flag5 = dictionary.ContainsKey(key2);
                        if (flag5)
                        {
                            b.FYary["CHlabel"] = dictionary[key2];
                        }
                        JArray jarray = (JArray)b.FYary["options"];
                        foreach (JToken jtoken in jarray)
                        {
                            bool flag6 = dictionary.ContainsKey(jtoken["name"].ToString());
                            if (flag6)
                            {
                                jtoken["CHname"] = jtoken["name"].ToString() + "(" + dictionary[jtoken["name"].ToString()] + ")";
                            }
                        }
                        bool flag7 = b.FYcbx != null;
                        if (flag7)
                        {
                            bool flag8 = b.FYcbx is ComboBox;
                            if (flag8)
                            {
                                ComboBox comboBox = (ComboBox)b.FYcbx;
                                foreach (object obj in ((IEnumerable)comboBox.Items))
                                {
                                    OptionItem optionItem = (OptionItem)obj;
                                    bool flag9 = dictionary.ContainsKey(optionItem.EnName);
                                    if (flag9)
                                    {
                                        optionItem.ChName = optionItem.EnName + "(" + dictionary[optionItem.EnName] + ")";
                                    }
                                }
                                comboBox.Items.Refresh();
                                bool flag10 = comboBox.SelectedIndex > 0;
                                if (flag10)
                                {
                                    int selectedIndex = comboBox.SelectedIndex;
                                    comboBox.SelectedIndex = 0;
                                    comboBox.SelectedIndex = selectedIndex;
                                }
                            }
                            else
                            {
                                bool flag11 = b.FYcbx is MutiAttrSelector;
                                if (flag11)
                                {
                                    ((MutiAttrSelector)b.FYcbx).RefreshOpints(dictionary);
                                }
                            }
                        }
                    }
                }
                catch
                {
                }
            }), new object[]
            {
                (FyLabel)d,
                text
            });
        }
        #endregion


        private void i36lhTIgPS(object w, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)w;
            try
            {
                ((Aattribute)comboBox.Tag).Avalue = comboBox.SelectedValue.ToString();
            }
            catch
            {
            }
        }


        private void auClNmcSBP(object d, KeyEventArgs e)
        {
            bool flag = e.KeyboardDevice.IsKeyDown(Key.Return);
            if (flag)
            {
                e.Handled = true;
                TextBox textBox = (TextBox)d;
                bool flag2 = string.IsNullOrEmpty(textBox.Text.Trim());
                if (!flag2)
                {
                    WaittingImg waittingImg = (WaittingImg)textBox.Tag;
                    waittingImg.setTips("搜索中......");
                    waittingImg.startWaitting();
                    if (oldSreachContect == textBox.Text || textBox.Text.Trim() == string.Empty)
                        return;
                    oldSreachContect = textBox.Text;
                    ComboBox comboBox = (ComboBox)textBox.Parent;
                    comboBox.Items.Clear();
                    comboBox.Items.Add(textBox);
                    comboBox.Items.Add(textBox.Tag);
                    textBox.Focus();
                    Task.Run(() =>
                    {
                        var jsondata = new LazadaCore().GetBrands();
                        if (jsondata == null)
                        {
                            this.Dispatcher.BeginInvoke(new Action<TextBox>(delegate (TextBox b)
                            {
                                ((WaittingImg)b.Tag).setTips("查无结果");
                                ((WaittingImg)b.Tag).pauseWaitting();
                            }), new object[] { d });
                        }
                        else
                        {
                            base.Dispatcher.BeginInvoke(new Action<TextBox, JObject>(delegate (TextBox b, JObject c)
                            {
                                ((WaittingImg)b.Tag).setTips("继续请按Enter");
                                ((WaittingImg)b.Tag).pauseWaitting();
                                try
                                {
                                    string value = b.Text.Trim().ToLower();
                                    JArray jarray = (JArray)c["data"];
                                    foreach (JToken jtoken in jarray)
                                    {
                                        if (jtoken["name"].ToString().ToLower().StartsWith(value))
                                        {
                                            comboBox.Items.Insert(2, jtoken["name"].ToString());
                                        }
                                    }
                                }
                                catch
                                {
                                }
                            }), new object[] { d, jsondata });
                        }
                    });

                }
            }
        }

        //确定按钮
        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            if (lblCategoryResult.Content.ToString() != string.Empty)
                SaveChangeLabel("选择类目");
        }
        /// <summary>
        /// 选择类目
        /// </summary>
        /// <param name="product"></param>
        private void ChoooseCategory(Product product)
        {
            string leafid = Convert.ToString(lblCategoryResult.Tag);
            string namePath = Convert.ToString(lblCategoryResult.Content);
            string tax = "";
            JArray jarray2 = new JArray();
            foreach (var item in categoryOtherAttrs)
            {
                if (item.Avalue != string.Empty && item.Aname != string.Empty)
                {
                    if (item.Aname == "tax_class")
                    {
                        tax = item.Avalue;
                    }
                    JObject jobject = new JObject();
                    jobject.Add("name", item.Aname);
                    jobject.Add("value", item.Avalue);
                    jarray2.Add(jobject);

                }
            }
            var attr = JsonConvert.SerializeObject(jarray2);
            //List<Product> products = new List<Product>();
            //var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            //foreach (var product in list)
            //{
            //var product = SystemSoleEntity.GetProductList().Where(p => p.Number == item).First();
            //if (product.Pstatetype == "1") continue;
            product.LazadaCategoryTreePath = selector.treePath;
            product.Lazadacategoryid = leafid;
            product.Lazadacategorynamepath = namePath;
            product.Lazadaattributs = attr;
            product.Lazadatax = tax;
            if (WhatInBoxTXB.Text != string.Empty)
            {
                product.Lazadapackageincluding = WhatInBoxTXB.Text;
            }
            //new ProductCore().UpdateSKUEdit(product);
            //products.Add(product);
            //}
            //if (products.Count > 0)
            //{
            //    if (new ProductCore().UpdateChoiceCategory(products))
            //    {
            //        CMessageBox.Show("更改成功");
            //    }
            //    else
            //    {
            //        CMessageBox.Show("更改失败");
            //    }
            //}
        }
        private void viblM1hkeC(object sender, RoutedEventArgs e)
        {
            if (WhatInBoxTXB.Text != string.Empty)
                WhatInBoxTXB.Text = new ALiCore().ChangeZhToEn(WhatInBoxTXB.Text);
        }

        private void UdklvHhQRn(object sender, RoutedEventArgs e)
        {
            if (WhatInBoxTXB.Text == string.Empty) return;
            var strArr = WhatInBoxTXB.Text.Split(new char[] { '\n' });
            string rs = "";
            foreach (var item in strArr)
            {
                if (item.Trim() == string.Empty) continue;
                if (!item.StartsWith("1 * "))
                {
                    rs += "1 * " + item + "\n";
                }
                else
                {
                    rs += item + "\n";
                }
            }
            Product product = (Product)this.DataContext;
            //product.Lazadapackageincluding = rs;
            WhatInBoxTXB.Text = rs;
            product.Lazadapackageincluding = rs;
            new LogOutput.LogTo().WriteLine(product.Lazadapackageincluding);
        }
        private void ruNlSIpe3Q(object sender, EventArgs e)
        {

        }

        private void KxGl3D9EJU(object sender, SelectionChangedEventArgs e)
        {

        }
        #region 标题更改
        /// <summary>
        /// 标题变更
        /// 控件事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnTitleAdd_Click(object sender, RoutedEventArgs e)
        {
            if (txtTitleEditVal.Text != string.Empty || txtTitleAddFrVal.Text != string.Empty || txtTitleAddBeVal.Text != string.Empty
                || (txtTitleReplyValA.Text != string.Empty && txtTitleAsValA.Text != string.Empty)
                || (txtTitleReplyValB.Text != string.Empty && txtTitleAsValB.Text != string.Empty)
                || (txtTitleReplyValC.Text != string.Empty && txtTitleAsValC.Text != string.Empty)
                || (txtTitleReplyValD.Text != string.Empty && txtTitleAsValD.Text != string.Empty)
                )
                SaveChangeLabel("标题变更");
        }
        private void SaveChangeLabel(string labelName)
        {
            foreach (Canvas item in EditMode.Children)
            {
                if (Convert.ToString(item.Tag) == labelName)
                {
                    return;
                }
            }
            Canvas acanvas = new Canvas();
            acanvas.Tag = labelName;
            acanvas.Height = 26;
            acanvas.Width = 116;
            acanvas.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 255, 255));
            acanvas.Background = brsA;
            acanvas.Margin = new Thickness(1);

            Label alabel = new Label();
            alabel.Content = labelName;
            alabel.Width = 96;
            alabel.Foreground = new SolidColorBrush(Colors.Red);

            acanvas.Children.Add(alabel);

            Label alabel2 = new Label();
            alabel2.VerticalContentAlignment = System.Windows.VerticalAlignment.Center;
            alabel2.Content = "X";
            alabel2.Width = 20;
            alabel2.Margin = new Thickness(96, 0, 0, 0);
            System.Windows.Media.Brush brsB = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 255, 255));
            alabel2.Background = brsB;
            // alabel2.Style = this.FindResource("LableMouseOver") as Style;
            alabel2.MouseEnter += new MouseEventHandler(alabel2_MouseEnter);
            alabel2.MouseLeave += new MouseEventHandler(alabel2_MouseLeave);
            alabel2.MouseLeftButtonDown += new MouseButtonEventHandler(alabel2_MouseLeftButtonDown);


            acanvas.Children.Add(alabel2);

            EditMode.Children.Add(acanvas);
        }
        private void alabel2_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            EditMode.Children.Remove((Canvas)(((Label)sender).Parent));
        }

        private void alabel2_MouseEnter(object sender, MouseEventArgs e)
        {
            System.Windows.Media.Brush brsBx = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
            ((Label)sender).Background = brsBx;


        }
        private void alabel2_MouseLeave(object sender, MouseEventArgs e)
        {
            System.Windows.Media.Brush brsBx = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 255, 255));
            ((Label)sender).Background = brsBx;


        }
        #endregion

        #region 详情描述
        /// <summary>
        /// 描述头变更
        /// 控件事件
        /// </summary>
        /// <param name="product"></param>
        private void BtnDescAdd_Click(object sender, RoutedEventArgs e)
        {
            if (chkDescTranslate.IsChecked ?? false || Convert.ToString(HtmlEditorDesc.Content) != string.Empty || txtDescAddFrontVal.Text != string.Empty || txtDescAddBehindVal.Text != string.Empty
                || (txtDescReplayA.Text != string.Empty && txtDescAsA.Text != string.Empty) || (txtDescReplayB.Text != string.Empty && txtDescAsB.Text != string.Empty))
                SaveChangeLabel("描述头变更");
        }
        #endregion

        #region 卖点变更

        private void BtnSellAdd_Click(object sender, RoutedEventArgs e)
        {
            if (Convert.ToString(HtmlEditorHLight.Content) != string.Empty || txtSellForntAdd.Text != string.Empty || txtSellBehindAdd.Text != string.Empty
                || (txtSellReplayA.Text != string.Empty && txtSellAsA.Text != string.Empty) || (txtSellReplayB.Text != string.Empty && txtSellAsB.Text != string.Empty))
                SaveChangeLabel("卖点变更");
        }

        #endregion
        /// <summary>
        /// 促销时间调整
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAdjustTime_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(StartDate.PickedDateTime) || string.IsNullOrEmpty(EndDate.PickedDateTime))
            {
                //设置调整的时间范围
                DateTime dt0 = DateTime.Now.AddHours(1);
                StartDate.PickedDateTime = dt0.ToString("yyyy-MM-dd HH:00:00");
                EndDate.PickedDateTime = dt0.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");

            }
            else
            {
                try
                {
                    //调整时间
                    DateTime[] tms = adjustTimes(DateTime.Parse(StartDate.PickedDateTime), DateTime.Parse(EndDate.PickedDateTime));

                    StartDate.PickedDateTime = tms[0].AddHours(1).ToString("yyyy-MM-dd HH:00:00");
                    EndDate.PickedDateTime = tms[1].AddHours(1).ToString("yyyy-MM-dd HH:00:00");
                }
                catch
                {
                }
            }
        }
        //调整时间差 ，当开始时间早于电脑时间时  ，开始时间改为当前时间并 按以前设定的时间差设置结束时间
        public static DateTime[] adjustTimes(DateTime BeginTime, DateTime Endtime)
        {
            if (BeginTime == null || Endtime == null)
            {
                return new DateTime[] { BeginTime, Endtime };
            }
            if (BeginTime.CompareTo(Endtime) > 0)
            {
                return new DateTime[] { BeginTime, Endtime };
            }

            TimeSpan Timeinterval = Endtime.Subtract(BeginTime);

            DateTime now = DateTime.Now;

            if (now.CompareTo(BeginTime) > 0)  //早于开始时间
            {
                return new DateTime[] { now, now.AddTicks(Timeinterval.Ticks) };
            }
            else
            {
                return new DateTime[] { BeginTime, Endtime };
            }

        }

        /// <summary>
        /// 促销时间设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartDate_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {
            if (StartDate.PickedDateTime == null || EndDate.PickedDateTime == null) return;

            try
            {
                DateTime now = DateTime.Now;
                DateTime BeginTime = DateTime.Parse(StartDate.PickedDateTime);

                DateTime EndTime = BeginTime.AddMonths(1);

                if (string.IsNullOrEmpty(EndDate.PickedDateTime))
                {
                    EndDate.PickedDateTime = EndTime.ToString("yyyy-MM-dd HH:00:00");
                }

                EndTime = DateTime.Parse(EndDate.PickedDateTime);
                //时间间隔
                TimeInterval(BeginTime, EndTime);


                if (now.CompareTo(BeginTime) > 0)//设置的开始时间晚于当前时间
                {
                    StartDate.BorderBrush = new SolidColorBrush(Color.FromRgb(255, 0, 0));
                }
                else
                {
                    StartDate.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }


                if (BeginTime.CompareTo(EndTime) > 0)//设置的开始时间晚于结束时间
                {
                    EndDate.BorderBrush = new SolidColorBrush(Color.FromRgb(255, 0, 0));
                }
                else
                {
                    EndDate.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }


            }
            catch
            {
                MessageBox.Show("时间设置错误");
                return;
            }
        }
        //显示时间间隔
        private void TimeInterval(DateTime _BeginTime, DateTime _EndTime)
        {
            int hours = (_EndTime - _BeginTime).Hours;
            int days = (_EndTime - _BeginTime).Days;

            lblTimelength.Content = string.Format("{0}D{1}H", days, hours);
        }

        /// <summary>
        /// 促销时间未设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkHotTime_Unchecked(object sender, RoutedEventArgs e)
        {
            if (chkHOTGroupBox.IsChecked == false)
            {
                StartDate.IsEnabled = false;
                EndDate.IsEnabled = false;
                btnAdjustTime.IsEnabled = false;
            }
        }
        /// <summary>
        /// 促销时间设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkHotTime_Checked(object sender, RoutedEventArgs e)
        {
            if (chkHOTGroupBox.IsChecked == true)
            {
                StartDate.IsEnabled = true;
                EndDate.IsEnabled = true;
                btnAdjustTime.IsEnabled = true;
            }
        }

        /// <summary>
        /// 库存设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkStock_Checked(object sender, RoutedEventArgs e)
        {
            if (chkStock.IsChecked == true)
            {
                NumericUpDownKuchen.IsEnabled = true;
            }
            else
            {
                NumericUpDownKuchen.IsEnabled = false;
            }
        }

        /// <summary>
        /// 包裹大小设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkMeasure_Checked(object sender, RoutedEventArgs e)
        {
            if (chkMeasure.IsChecked == true)
            {
                NumericUpDownPkgLength.IsEnabled = true;
                NumericUpDownPkgWidth.IsEnabled = true;
                NumericUpDownPkgHight.IsEnabled = true;
            }
            else
            {
                NumericUpDownPkgLength.IsEnabled = false;
                NumericUpDownPkgWidth.IsEnabled = false;
                NumericUpDownPkgHight.IsEnabled = false;
            }
        }
        /// <summary>
        /// 包裹重量设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkBoxWeight_Checked(object sender, RoutedEventArgs e)
        {
            if (chkBoxWeight.IsChecked == true)
            {
                PkgWight.IsEnabled = true;
                BoxWeightCK.IsChecked = false;
            }
            else
            {
                PkgWight.IsEnabled = false;
            }
        }

        /// <summary>
        /// 下拉选择计价模板
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CmbValua_DropDownOpened(object sender, EventArgs e)
        {
            if (cmbValua.Items.Count < 1)
            {
                AddValuaModel();
            }
        }
        /// <summary>
        /// 添加计价模板
        /// </summary>
        private void AddValuaModel()
        {
            try
            {
                List<PriceTemplateEntity> ValuaName = new PriceTemplateCore().GetPriceTemplateList();
                if (ValuaName.Count > 0)
                {
                    ComboBoxItem firstValuaName = new ComboBoxItem();
                    firstValuaName.Content = "不更改";
                    cmbValua.Items.Add(firstValuaName);

                    for (int i = 0; i < ValuaName.Count; i++)
                    {
                        ComboBoxItem onejm = new ComboBoxItem
                        {
                            Content = ValuaName[i].Jname
                        };
                        cmbValua.Items.Add(onejm);
                    }
                }
            }
            catch
            {
            }

        }
        /// <summary>
        /// 添加计价模板
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnValua_Click(object sender, RoutedEventArgs e)
        {
            if ((cmbValua.Text != string.Empty && cmbValua.Text != "不更改") || (chkStock.IsChecked ?? false) || (chkMeasure.IsChecked ?? false) || (chkBoxWeight.IsChecked ?? false)
               || (BoxWeightCK.IsChecked ?? false && cmboBoxCondition.Text != string.Empty && comboBoxAction.Text != string.Empty)
               || (chkHOTGroupBox.IsChecked ?? false && StartDate.PickedDateTime != string.Empty && EndDate.PickedDateTime != string.Empty))
                SaveChangeLabel("计价模板变更");
        }


        /// <summary>
        /// 包裹重量范围设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BoxWeightCK_Checked(object sender, RoutedEventArgs e)
        {
            NumericUpDownConditionWeight.IsEnabled = true;
            NumericUpDownActionWeight.IsEnabled = true;
            cmboBoxCondition.IsEnabled = true;
            comboBoxAction.IsEnabled = true;
            chkBoxWeight.IsChecked = false;
        }
        /// <summary>
        /// 包裹重量范围
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BoxWeightCK_Unchecked(object sender, RoutedEventArgs e)
        {
            NumericUpDownConditionWeight.IsEnabled = false;
            NumericUpDownActionWeight.IsEnabled = false;
            cmboBoxCondition.IsEnabled = false;
            comboBoxAction.IsEnabled = false;
        }
    }
}
