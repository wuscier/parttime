﻿using LAZADA.TasksBtns.CustomerControl;
using PublicFunction.Entity.DBEntity;
using PublicFunction.SaveHelp;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// AddSourceUrlWin.xaml 的交互逻辑
    /// </summary>
    public partial class AddSourceUrlWin : Window
    {
        private Product product = new Product();
        public AddSourceUrlWin(long num)
        {
            InitializeComponent();
            product.Number = num;
            string link = SelectUrl(num);
            if (link != null)
            {
                string[] a = link.Split(',');
                
                if (a.Count() == 1 || a.Count() == 0)
                {
                    TextBox textBox = new TextBox()
                    {
                        Width = 405,
                        Name = "FirstTxt",
                        FontSize = 14,
                        HorizontalAlignment = HorizontalAlignment.Left,

                    };
                    grdbody.Children.Add(textBox);
                    Grid.SetColumn(textBox, 1);

                    Label label = new Label()
                    {
                        Content = "访问",
                        Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EDF7FF")),
                        Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1F9EFF")),
                        Width = 76,
                        Height = 26,
                        FontSize = 14,
                        HorizontalAlignment = HorizontalAlignment.Right,
                        HorizontalContentAlignment = HorizontalAlignment.Center,
                        Margin = new Thickness(0, 0, 2, 0),
                        Cursor = Cursors.Hand,
                    };
                    grdbody.Children.Add(label);
                    Grid.SetColumn(label, 1);
                    label.MouseLeftButtonDown += new MouseButtonEventHandler(label_MouseLeftButtonDown);
                    foreach (var item in grdbody.Children)
                    {
                        if (item is TextBox)
                        {
                            TextBox text = (TextBox)item;
                            if (text.Name == "FirstTxt")
                            {
                                text.Text = link;
                            }
                        }
                    }
                }
                else
                {
                    //若保存的前n条为空，后几条有数据
                    if (a[0] == ""||a.Contains(""))
                    {
                        ArrayList al = new ArrayList(a);
                        al.Remove("");
                        string[] ar = (string[])al.ToArray(typeof(string));
                        ar = ar.Where(s => !string.IsNullOrEmpty(s)).ToArray();
                        a = ar;
                    }


                    TextBox textBox = new TextBox()
                    {
                        Width = 405,
                        Name = "FirstTxt",
                        FontSize = 14,
                        HorizontalAlignment = HorizontalAlignment.Left,

                    };
                    grdbody.Children.Add(textBox);
                    Grid.SetColumn(textBox, 1);

                    Label label = new Label()
                    {
                        Content = "访问",
                        Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EDF7FF")),
                        Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1F9EFF")),
                        Width = 76,
                        Height = 26,
                        FontSize = 14,
                        HorizontalAlignment = HorizontalAlignment.Right,
                        HorizontalContentAlignment = HorizontalAlignment.Center,
                        Margin = new Thickness(0, 0, 2, 0),
                        Cursor = Cursors.Hand,
                    };
                    grdbody.Children.Add(label);
                    Grid.SetColumn(label, 1);
                    label.MouseLeftButtonDown += new MouseButtonEventHandler(label_MouseLeftButtonDown);


                    foreach (var item in grdbody.Children)
                    {
                        if (item is TextBox)
                        {
                            TextBox text = (TextBox)item;
                            if (text.Name == "FirstTxt")
                            {
                                foreach (var items in a)
                                {
                                    //显示第一条的
                                    text.Text = a[0];
                                }

                            }
                        }
                    }
                    //显示其余的
                    ArrayList array = new ArrayList(a);
                    array.Remove(array[0]);
                    string[] arr = (string[])array.ToArray(typeof(string));
                    foreach (var item in arr)
                    {
                        if (item==string.Empty)
                        {
                            continue;
                        }
                        else
                        {
                            CreateText(item.ToString());
                        }
                    }

                }
            }
            else
            {
                TextBox textBox = new TextBox()
                {
                    Width = 405,
                    Name = "FirstTxt",
                    FontSize = 14,
                    HorizontalAlignment = HorizontalAlignment.Left,

                };
                grdbody.Children.Add(textBox);
                Grid.SetColumn(textBox, 1);

                Label label = new Label()
                {
                    Content = "访问",
                    Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EDF7FF")),
                    Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1F9EFF")),
                    Width = 76,
                    Height = 26,
                    FontSize = 14,
                    HorizontalAlignment = HorizontalAlignment.Right,
                    HorizontalContentAlignment = HorizontalAlignment.Center,
                    Margin = new Thickness(0, 0, 2, 0),
                    Cursor = Cursors.Hand,
                };
                grdbody.Children.Add(label);
                Grid.SetColumn(label, 1);
                label.MouseLeftButtonDown += new MouseButtonEventHandler(label_MouseLeftButtonDown);
            }

        }
        private string SelectUrl(long num)
        {
            string sql = @"select porigReservelink from ProductList where Number=" + num + " and SiteId=" + GlobalUserClass.SiteId + "";
            SQLiteParameter[] paramList = new SQLiteParameter[]
            {
                new SQLiteParameter("@SiteID",GlobalUserClass.SiteId),
                new SQLiteParameter("@Number",num)
            };
            return new SQLiteHelp().ExecuteScalar<string>(sql, paramList);
        }
        /// <summary>
        /// 生成链接记录
        /// </summary>
        private void CreateText(string item)
        {
            Grid grid = new Grid();
            ColumnDefinition col1 = new ColumnDefinition();
            col1.Width = new GridLength(2, GridUnitType.Star);
            ColumnDefinition col2 = new ColumnDefinition();
            col2.Width = new GridLength(6, GridUnitType.Star);
            ColumnDefinition col3 = new ColumnDefinition();
            col3.Width = new GridLength(2, GridUnitType.Star);

            TextBox textBox1 = new TextBox()
            {
                Width = 405,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Left,
                Text = item

            };
            grid.Children.Add(textBox1);
            Grid.SetColumn(textBox1, 1);


            Label label1 = new Label()
            {
                Content = "访问",
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EDF7FF")),
                Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1F9EFF")),
                Width = 76,
                Height = 26,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Right,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 2, 0),
                Cursor = Cursors.Hand,
            };
            grid.Children.Add(label1);
            Grid.SetColumn(label1, 1);
            label1.MouseLeftButtonDown += new MouseButtonEventHandler(label_MouseLeftButtonDown);


            Label close = new Label()
            {
                Content = "X",
                FontSize = 14,
                Cursor = Cursors.Hand
            };
            grid.Children.Add(close);
            Grid.SetColumn(close, 2);
            close.MouseLeftButtonDown += new MouseButtonEventHandler(close_MouseLeftButtonDown);


            grid.ColumnDefinitions.Add(col1);
            grid.ColumnDefinitions.Add(col2);
            grid.ColumnDefinitions.Add(col3);

            grid.Margin = new Thickness(0, 10, 0, 10);
            stkUrlBody.Children.Add(grid);
        }
        private void lbllink_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            string a = ((Label)sender).ToString().Replace("System.Windows.Controls.Label: ", "");
            Process.Start(a);
        }

        private void CloseWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void Top_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
        private void BtnAddUrl_Click(object sender, RoutedEventArgs e)
        {

            Grid grid = new Grid();
            grid.Name = "grdBodys";
            ColumnDefinition col1 = new ColumnDefinition();
            col1.Width = new GridLength(2, GridUnitType.Star);
            ColumnDefinition col2 = new ColumnDefinition();
            col2.Width = new GridLength(6, GridUnitType.Star);
            ColumnDefinition col3 = new ColumnDefinition();
            col3.Width = new GridLength(2, GridUnitType.Star);

            TextBox textBox = new TextBox()
            {
                Width = 400,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Left,
                Name = "txtUrl"

            };
            grid.Children.Add(textBox);
            Grid.SetColumn(textBox, 1);


            Label label = new Label()
            {
                Content = "访问",
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#EDF7FF")),
                Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1F9EFF")),
                Width = 76,
                Height = 26,
                FontSize = 14,
                HorizontalAlignment = HorizontalAlignment.Right,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 2, 0),
                Cursor = Cursors.Hand,
            };
            grid.Children.Add(label);
            Grid.SetColumn(label, 1);
            label.MouseLeftButtonDown += new MouseButtonEventHandler(label_MouseLeftButtonDown);


            Label close = new Label()
            {
                Content = "X",
                FontSize = 14,
                Width=30,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor = Cursors.Hand
            };
            grid.Children.Add(close);
            Grid.SetColumn(close, 2);
            close.MouseLeftButtonDown += new MouseButtonEventHandler(close_MouseLeftButtonDown);


            grid.ColumnDefinitions.Add(col1);
            grid.ColumnDefinitions.Add(col2);
            grid.ColumnDefinitions.Add(col3);

            grid.Margin = new Thickness(0, 10, 0, 10);
            stkUrlBody.Children.Add(grid);
        }

        private void close_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            stkUrlBody.Children.Remove(((Grid)((Label)sender).Parent));
        }

        private void label_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            foreach (var item in ((Grid)((Label)sender).Parent).Children)
            {

                if (item is TextBox)
                {
                    TextBox text = (TextBox)item;
                    Process.Start(text.Text);

                }
            }
        }

        private void BtnCloseAddWin_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSavePoriglink_Click(object sender, RoutedEventArgs e)
        {
            bool Execute = false;

            List<string> dlink = new List<string>();
            foreach (var item in stkUrlBody.Children)
            {
                Grid grid = (Grid)item;
                foreach (var item2 in grid.Children)
                {
                    if (item2 is TextBox)
                    {
                        TextBox text = (TextBox)item2;

                        dlink.Add(text.Text);
                    }
                }
            }
            if (dlink[0]==string.Empty)
            {
                dlink.Remove(dlink[0]);
            }
            else
            {
                
            }
            Execute = SaveLink(dlink, product.Number);

            if (Execute)
            {
                CMessageBox.Show("保存成功");
            }
        }

        private bool SaveLink(List<string> text, long Number)
        {
            string linktxt = "";
            string links = "";
            List<string> txtlist = new List<string>();
            if (text.Count > 1)
            {
                for (int i = 0; i < text.Count; i++)
                {
                    //if (text[text.Count - 1] != string.Empty)
                    //{
                        linktxt = text[i] + ",";
                    //}
                    txtlist.Add(linktxt);
                }
            }
            else
            {
                for (int i = 0; i < text.Count; i++)
                {

                    linktxt = text[0];
                    links = linktxt;
                }
            }
            
            foreach (var item in txtlist)
            {
                links = links + item;
            }
           
            #region 添加新链接
            string sql = @"Update ProductList SET porigReservelink=@porigReservelink 
                            Where Number=" + Number + " and SiteId=" + GlobalUserClass.SiteId + "";// and SiteId="+GlobalUserClass.SiteId+"
            SQLiteParameter[] paramList = new SQLiteParameter[] { };
                paramList = new SQLiteParameter[]
                {
                    new SQLiteParameter("@porigReservelink",links)
                };
            #endregion

            return new SQLiteHelp().ExecuteNonQuery(sql, paramList) > 0;
        }

    }
}
