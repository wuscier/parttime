﻿using Lazop.Api;
using Logic.Author;
using Logic.BasicInfo;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Author;
using PublicFunction.Entity.DBEntity;
using PublicFunction.SiteImgRequestHelp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static LAZADA.GlobalUserClass;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// SetWindow.xaml 的交互逻辑
    /// </summary>
    public partial class SetWindow : Window
    {
        private PublicFunctions publicFunctions = new PublicFunctions();
        private bool lazadaisauthor = false;
        public SetWindow()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            this.txtName.Text = "LAZADA-" + GlobalUserClass.SiteName + "站点授权";
            
            GETLazada();
            GET1688();
            if (Constants.Ali1688_ACCESSTOKEN!=null)
            {
                lblAuthor1688.Content = "已授权";
                this.btnBBGetCd.IsEnabled = false;
            }
            else
            {
                lblAuthor1688.Content = "授权";
                btnBBGetCd.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16, 1));
                lblAuthor1688.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
            }

            if (lazadaisauthor==true)//Convert.ToString(this.lblAuthHint.Content)== "账户"+ AuthedShopsItem.Account+"已授权"
            {
                lblAuthorlazada.Content = "已授权";
                this.btnGetCode.IsEnabled = false;
            }
            else
            {
                lblAuthorlazada.Content = "授权";
                btnGetCode.Background = new SolidColorBrush(Color.FromScRgb(16, 16, 16,1));
                lblAuthorlazada.Foreground = new SolidColorBrush(Color.FromRgb(16, 16, 16));
            }

            #region lazada授权图片
            switch (GlobalUserClass.SiteName)
            {
                case "马来西亚":
                    site.Source = new BitmapImage(new Uri("/Images/MYIMG.png", UriKind.Relative));
                    break;
                case "越南":
                    site.Source = new BitmapImage(new Uri("/Images/VNIMG.png", UriKind.Relative));
                    break;
                case "新加坡":
                    site.Source = new BitmapImage(new Uri("/Images/SGIMG.png", UriKind.Relative));
                    break;
                case "印度尼西亚":
                    site.Source = new BitmapImage(new Uri("/Images/IDIMG.png", UriKind.Relative));
                    break;
                case "泰国":
                    site.Source = new BitmapImage(new Uri("/Images/THIMG.png", UriKind.Relative));
                    break;
                case "菲律宾":
                    site.Source = new BitmapImage(new Uri("/Images/PHIMG.png", UriKind.Relative));
                    break;
                case "六合一":
                    site.Source = new BitmapImage(new Uri("/Images/CrossBorder.png", UriKind.Relative));
                    break;
                default:
                    site.Source = new BitmapImage(new Uri("/Images/Head.png", UriKind.Relative));
                    break;
            }
            #endregion


        }

        /// <summary>
        /// lazada授权获取
        /// </summary>
        public void GETLazada()
        {
            try
            {

                string accesstoken = Access_Token;
                string authorMsg = GetSiteProfile(accesstoken);
                int siteId = SiteId;
                JObject result = (JObject)JsonConvert.DeserializeObject(authorMsg);
                int iNumSum = 0;
                int iNum = 0;
                JArray arryresult = (JArray)result["result"];
                string strSQL = "; ";
                string strDel = " delete from Store where user='" + GlobalUserClass.uname + "' and region=" + siteId;
                foreach (var item in arryresult)
                {
                    if ((int)item["siteType"] == (int)WebSiteType.Lazada)
                    {
                        if ((int)item["region"] == siteId)
                        {
                            iNumSum++;
                            if (item["account"].ToString() != "")
                                iNum++;
                            List<Store> lStore = new SqlAuthorization().GetStoreList(" and account<>'' and id='" + item["id"] + "' ");
                            if (lStore.Count > 0)
                            {
                                strSQL += "Insert into Store(id,IsDefault,Name,account,authTime,expirationTime,user,region,accessToken) Values(" + item["id"] + "," + lStore[0].IsDefault + ",'" + lStore[0].Name + "','"
                                    + item["account"].ToString() + "','" + item["authTime"].ToString().Split('T')[0] + "','" + item["expirationTime"].ToString().Split('T')[0] + "','" + GlobalUserClass.uname + "',"
                                    + siteId + ",'" + item["accessToken"].ToString() + "'); ";
                            }
                            else
                            {
                                strSQL += "Insert into Store(id,IsDefault,Name,account,authTime,expirationTime,user,region,accessToken) Values(" + item["id"] + ",1,'" + item["account"].ToString() + "','"
                                    + item["account"].ToString() + "','" + item["authTime"].ToString().Split('T')[0] + "','" + item["expirationTime"].ToString().Split('T')[0] + "','" + GlobalUserClass.uname + "',"
                                    + siteId + ",'" + item["accessToken"].ToString() + "'); ";
                            }
                        }
                    }
                }
                txtAuthResult.Text = iNum.ToString() + "/" + iNumSum.ToString();
                new SqlAuthorization().Edit(strDel + strSQL);
            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// 百度授权
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnBDSave_Click(object sender, RoutedEventArgs e)
        {

        }
        /// <summary>
        /// 阿里授权
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AliSaveBtn_Click(object sender, RoutedEventArgs e)
        {

        }
        /// <summary>
        /// 获取1688授权信息
        /// </summary>
        public void GET1688()
        {
            try
            {
                string accesstoken = Access_Token;
                string authorMsg = GetSiteProfile(accesstoken);
                int siteId = SiteId;
                JObject result = (JObject)JsonConvert.DeserializeObject(authorMsg);

                JArray arryresult = (JArray)result["result"];
                foreach (var item in arryresult)
                {
                    if ((int)item["siteType"] == (int)WebSiteType.Ali1688)
                    {

                        if ((int)item["region"] == siteId||item.Count()>0)
                        {
                            //lblBBHint.Content = "1688授权正常,请勿重复授权";
                            //Constants.Ali1688_ACCESSTOKEN = Convert.ToString(item["accessToken"]);
                            new LogOutput.LogTo().WriteLine(Constants.Ali1688_ACCESSTOKEN);
                            this.btnBBGetCd.IsEnabled = false;
                            return;
                        }
                        else
                        {
                            lblAuthor1688.Content = "授权";
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// 1688授权
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnBBGetCd_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                GlobalUserClass.redirectUrl = Constants.My1688redirectUrl + $"shopId={AuthedShopsItem.ShopId}" + $"&siteId={GlobalUserClass.SiteId}" + $"&access_token={GlobalUserClass.Access_Token}" + $"&siteType={(int)GlobalUserClass.WebSiteType.Ali1688}";
                #region 获取1688采集授权链接
                Process.Start(My1688Collect.GetCollectUrl());
                #endregion
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// lazada授权
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnGetCode_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                GlobalUserClass.MyStoreAuthrect_Url = Constants.MyStoreredirectUrl + $"shopId={AuthedShopsItem.ShopId}" + $"&siteId={GlobalUserClass.SiteId}" + $"&access_token={GlobalUserClass.Access_Token}" + $"&siteType={(int)GlobalUserClass.WebSiteType.Lazada}";
                Process.Start(MyStoreAuthor.GetStoreUrl());

            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// 1688授权刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AlibbRef_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GET1688();
            TimeSpan ts1 = new TimeSpan(0, 0, 0, 0, 300);
            publicFunctions.AngleEasingAnimationShow(AlibbRef, 0, 180, 3, ts1);
        }
        /// <summary>
        /// lazada授权刷新
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LazadaRef_MouseDown(object sender, MouseButtonEventArgs e)
        {
            GETLazada();
            TimeSpan ts1 = new TimeSpan(0, 0, 0, 0, 300);
            publicFunctions.AngleEasingAnimationShow(lazadaRef,0,180,3,ts1);
        }
        private void Close_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// 百度翻译教程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtTeachSet_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }
        /// <summary>
        /// 阿里翻译教程
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtAliTeach_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
