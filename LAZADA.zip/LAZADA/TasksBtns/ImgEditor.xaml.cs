﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// ImgEditor.xaml 的交互逻辑
    /// </summary>
    public partial class ImgEditor : Window
    {
        public ImgEditor()
        {
            InitializeComponent();
        }

        private void cvsImgEditor_DragOver(object sender, DragEventArgs e)
        {

        }

        private void cvsImgEditor_DragLeave(object sender, DragEventArgs e)
        {

        }

        private void cvsImgEditor_Drop(object sender, DragEventArgs e)
        {

        }

        private void nudImgWide_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void nudImgHigh_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void btnClearWatermark_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnClearWatermark_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void btnSaveImg_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnAllClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnCheckProduct_Click(object sender, RoutedEventArgs e)
        {

        }

        private void syrangc_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void imgEdit_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void imgEdit_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void txtAddWord_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void btnMatching_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnRefreshWord_Click(object sender, RoutedEventArgs e)
        {

        }

        private void listWord_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void listWord_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void chkMerge_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void chkMerge_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void chkMerge_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void nudRow_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void nudColumn_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void btnDown_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnUp_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnRight_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnLeft_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void popImgDispose_Opened(object sender, EventArgs e)
        {

        }

        private void btnRefreshColor_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSureColor_Click(object sender, RoutedEventArgs e)
        {

        }

        private void cvsImgEditor_DragEnter(object sender, DragEventArgs e)
        {

        }
    }
}
