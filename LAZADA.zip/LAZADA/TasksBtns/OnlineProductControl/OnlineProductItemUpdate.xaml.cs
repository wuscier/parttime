﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.OnlineProductControl
{
    /// <summary>
    /// OnlineProductItemUpdate.xaml 的交互逻辑
    /// </summary>
    public partial class OnlineProductItemUpdate : Window
    {
        CancellationTokenSource tokenSource = new CancellationTokenSource();
        OnlineProductFunctionUpadteCore core = new OnlineProductFunctionUpadteCore();
        OnlineProductItemUpdateModel viewModel = new OnlineProductItemUpdateModel();
        CancellationToken token;
        Task task = null;
        List<string> itemidList = new List<string>();
        public OnlineProductItemUpdate(List<string> list)
        {
            InitializeComponent();
            this.DataContext = viewModel;
            itemidList = list;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Task.Run(() =>
            {
                Thread.Sleep(500);
                task = new Task(UpdateItems, token);
                task.Start();
            });
        }

        private void UpdateItems()
        {
            viewModel.Count = itemidList.Count;
            viewModel.Current = 1;
            var add = 90d / viewModel.Count;
            while (viewModel.Ipbvalue < 5)
            {
                viewModel.Ipbvalue++;
                Thread.Sleep(200);
            }
            foreach (var item in itemidList)
            {
                if (token.IsCancellationRequested)
                {
                    try
                    {
                        token.ThrowIfCancellationRequested();
                    }
                    catch { }
                    Thread.Sleep(1000);
                    this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
                    break;
                }
                viewModel.Ipbvalue += add;
                Thread.Sleep(200);
                JObject jsondata = null;
                try
                {
                    jsondata = new LazadaCore().GetProductItem(item);
                }
                catch
                {
                    Thread.Sleep(500);
                    try
                    {
                        jsondata = new LazadaCore().GetProductItem(item);
                    }
                    catch
                    {
                        Thread.Sleep(500);
                        try
                        {
                            jsondata = new LazadaCore().GetProductItem(item);
                        }
                        catch
                        {
                            Thread.Sleep(500);
                            jsondata = null;
                        }
                    }
                }
                if (jsondata == null)
                {
                    viewModel.Current++;
                    continue;
                }
                if (jsondata["code"].ToString() == "0" && jsondata["data"].HasValues)
                {
                    var obj = jsondata["data"].Contains("products") ? JsonConvert.DeserializeObject<JObject>(JsonConvert.DeserializeObject<JArray>(jsondata["data"]["products"].ToString())[0].ToString()): JsonConvert.DeserializeObject<JObject>(jsondata["data"].ToString());
                    ShowOnLineProduct product = new ShowOnLineProduct()
                    {
                        Title = obj["attributes"]["name"].ToString(),
                        Itemid = obj["item_id"].ToString(),
                        JsonStr = obj.ToString(),
                        Siteid = GlobalUserClass.SiteId
                    };
                    var skus = JsonConvert.DeserializeObject<JArray>(obj["skus"].ToString());

                    var firstSku = JsonConvert.DeserializeObject<JObject>(skus[0].ToString());
                    var sellerSku = firstSku["SellerSku"].ToString();
                    var attrs = sellerSku.Split('-');
                    var name = attrs[0];
                    product.MainSku = name;
                    product.Url = firstSku["Url"].ToString();
                    product.UpdateTime = DateTime.Now;
                    product.LocalTime = product.UpdateTime;
                    List<string> child = new List<string>();
                    foreach (var sku in skus)
                    {
                        var mySku = JsonConvert.DeserializeObject<JObject>(sku.ToString());
                        child.Add(mySku["SellerSku"].ToString());
                    }
                    product.Sellersku = string.Join(",", child);
                    core.SaveUpdateOnlineItem(product);
                    Thread.Sleep(100);
                }
                else
                {
                    viewModel.Current++;
                }

            }
            while (viewModel.Ipbvalue < 100)
            {
                viewModel.Ipbvalue++;
                Thread.Sleep(200);
            }
            this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (CMessageBoxResult.OK == CMessageBox.Show($"确定要终止同步吗?", CMessageBoxButton.OKCancel))
                tokenSource.Cancel();
        }
    }
    public class OnlineProductItemUpdateModel : BaseViewModel
    {
        private double _Ipbvalue;
        private int _count;
        private int _current;
        private string _currentContent;
        private string _countContent;

        public double Ipbvalue
        {
            get => _Ipbvalue;
            set
            {
                if (_Ipbvalue != value)
                {
                    _Ipbvalue = value;
                    base.RaisePropertyChanged("Ipbvalue");
                }
            }
        }

        public int Count
        {
            get => _count;
            set
            {
                if (_count != value)
                {
                    _count = value;
                    base.RaisePropertyChanged("Count");
                    base.RaisePropertyChanged("CountContent");
                    base.RaisePropertyChanged("CurrentContent");
                }
            }
        }
        public string CountContent
        {
            get
            {
                return $"共{Count}条数据";
            }
        }


        public string CurrentContent
        {
            get
            {
                return $"当前第{Current}条数据";
            }
        }
        public int Current
        {
            get => _current;
            set
            {
                if (_current != value)
                {
                    _current = value;
                    base.RaisePropertyChanged("Current");
                    base.RaisePropertyChanged("CountContent");
                    base.RaisePropertyChanged("CurrentContent");
                }
            }
        }

    }
}
