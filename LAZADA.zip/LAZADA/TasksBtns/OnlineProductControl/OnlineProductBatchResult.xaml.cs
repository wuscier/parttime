﻿using Logic.Platform;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.OnlineProductControl
{
    /// <summary>
    /// OnlineProductBatchResult.xaml 的交互逻辑
    /// </summary>
    public partial class OnlineProductBatchResult : Window
    {
        Dictionary<JObject, ShowOnLineProduct> products = new Dictionary<JObject, ShowOnLineProduct>();
        OnlineProductBatchResultViewModel vm = new OnlineProductBatchResultViewModel();
        public OnlineProductBatchResult(Dictionary<JObject, ShowOnLineProduct> dic)
        {
            InitializeComponent();
            this.DataContext = vm;
            products = dic;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var lc = new LazadaCore();
            Task.Run(() =>
            {
                vm.Msg = "准备推送";
                double add = 90d / products.Count;
                while (vm.Ipbvalue < 5)
                {
                    vm.Ipbvalue++;
                    Thread.Sleep(200);
                }
                foreach (var item in products.Keys)
                {
                    vm.Ipbvalue += add;
                    Thread.Sleep(200);
                    vm.Msg = products[item].MainSku + "正在推送";
                    if (lc.PushUpdateProduct(item, products[item]))
                    {
                        Thread.Sleep(1000);
                        vm.Msg = products[item].MainSku + "更新成功";
                    }
                    else
                    {
                        Thread.Sleep(1000);
                        vm.Msg = products[item].MainSku + "更新失败";
                    }
                }
                while (vm.Ipbvalue < 100)
                {
                    vm.Ipbvalue++;
                    Thread.Sleep(200);
                }
                this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
            });
        }
    }

    public class OnlineProductBatchResultViewModel : BaseViewModel
    {
        private double _Ipbvalue;
        private string _Msg;

        public double Ipbvalue
        {
            get => _Ipbvalue;
            set
            {
                if (_Ipbvalue != value)
                {
                    _Ipbvalue = value;
                    base.RaisePropertyChanged("Ipbvalue");
                }
            }
        }
        public string Msg
        {
            get => _Msg;
            set
            {
                if (_Msg != value)
                {
                    _Msg = value;
                    base.RaisePropertyChanged("Msg");
                }
            }
        }
    }
}
