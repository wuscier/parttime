﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.Platform;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.OnlineProductControl
{
    /// <summary>
    /// OnlineProductDetails.xaml 的交互逻辑
    /// </summary>
    public partial class OnlineProductDetails : UserControl
    {
        AsyncObservableCollection<ChildSKU> details = new AsyncObservableCollection<ChildSKU>();
        AsyncObservableCollection<ChildSKU> searchs = new AsyncObservableCollection<ChildSKU>();
        string url = "";
        private string lazada_itemid;
        private ShowOnLineProduct currentProduct;
        List<string> attrList = new List<string>();
        public OnlineProductDetails(ShowOnLineProduct product)
        {
            InitializeComponent();
            currentProduct = product;
            url = product.Url;
            details = product.SKUS;
            lazada_itemid = product.Itemid;
            attrList = product.SkuaAttrs;
            this.gdDetail.ItemsSource = details;
            ComboBoxItem allItem = new ComboBoxItem();
            allItem.Content = "全部";
            num_lazadaprice.Value = Convert.ToDecimal(details[0].Price);
            num_lazadapromprice.Value = Convert.ToDecimal(details[0].Special_price);
            num_kucun.Value = Convert.ToDecimal(details[0].Quantity);
            comboBox1.Items.Add(allItem);
            foreach (var attr in attrList)
            {
                ComboBoxItem item = new ComboBoxItem();
                item.Content = attr;
                comboBox1.Items.Add(item);
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            AsyncObservableCollection<ChildSKU> itemsource = this.gdDetail.ItemsSource as AsyncObservableCollection<ChildSKU>;
            foreach (var item in itemsource)
            {
                item.IsChecked = true;
            }
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {

            AsyncObservableCollection<ChildSKU> itemsource = this.gdDetail.ItemsSource as AsyncObservableCollection<ChildSKU>;
            foreach (var item in itemsource)
            {
                item.IsChecked = false;
            }
        }

        private void dj0xntc6bF(object sender, RoutedEventArgs e)
        {
            ///如果有一个为空，开始时间为当前+1小时，结束时间为一个月后
            if (string.IsNullOrEmpty(this.endTimePicker.PickedDateTime) || string.IsNullOrEmpty(this.startTimePicker.PickedDateTime))
            {
                DateTime dateTime = DateTime.Now.AddHours(2.0);
                this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
            }
            else
            {
                try
                {   //时间格式正确，一起往后顺延一小时
                    if (Convert.ToDateTime(this.endTimePicker.PickedDateTime) > Convert.ToDateTime(startTimePicker.PickedDateTime))
                    {
                        this.endTimePicker.PickedDateTime = Convert.ToDateTime(this.endTimePicker.PickedDateTime).AddHours(1.0).ToString("yyyy-MM-dd HH:00:00");
                        this.startTimePicker.PickedDateTime = DateTime.Now.AddHours(1.0).ToString("yyyy-MM-dd HH:00:00");
                    }
                    else //结束时间>开始时间，开始时间为当前+1小时，结束时间为一个月后
                    {
                        DateTime dateTime = DateTime.Now.AddHours(1.0);
                        this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                        this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
                    }
                }
                catch
                {
                    DateTime dateTime = DateTime.Now.AddHours(1.0);
                    this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                    this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
                }
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            AsyncObservableCollection<ChildSKU> itemsource = this.gdDetail.ItemsSource as AsyncObservableCollection<ChildSKU>;
            foreach (var item in itemsource)
            {
                if (item.IsChecked)
                {
                    item.Price = num_lazadaprice.Value.ToString();
                    item.Special_price = num_lazadapromprice.Value.ToString();
                    item.Quantity = num_kucun.Value.ToString();
                    if (startTimePicker.PickedDateTime != "" && endTimePicker.PickedDateTime != "")
                    {
                        item.Special_from_time = startTimePicker.PickedDateTime.ToString();
                        item.Special_to_time = endTimePicker.PickedDateTime.ToString();
                    }
                }
            }
        }

        private void StartTimePicker_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime now = DateTime.Now;
                DateTime dateTime = DateTime.Parse(this.startTimePicker.PickedDateTime);
                DateTime dateTime2 = dateTime.AddMonths(1);
                bool flag = string.IsNullOrEmpty(this.endTimePicker.PickedDateTime);
                if (flag)
                {
                    this.endTimePicker.PickedDateTime = dateTime2.ToString("yyyy-MM-dd HH:00:00");
                }
                dateTime2 = DateTime.Parse(this.endTimePicker.PickedDateTime);
                this.CalcDays(dateTime, dateTime2);
                bool flag2 = now.CompareTo(dateTime) > 0;
                if (flag2)
                {
                    this.startTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.startTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
                bool flag3 = dateTime.CompareTo(dateTime2) > 0;
                if (flag3)
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// 计算日期差值并显示
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        private void CalcDays(DateTime start, DateTime end)
        {
            int hours = (end - start).Hours;
            int days = (end - start).Days;
            this.timeTips.Content = string.Format("{0}D{1}H", days, hours);
        }

        private void EndTimePicker_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime now = DateTime.Now;
                DateTime u = now.AddHours(1.0);
                DateTime dateTime = DateTime.Parse(this.endTimePicker.PickedDateTime);
                bool flag = string.IsNullOrEmpty(this.startTimePicker.PickedDateTime);
                if (flag)
                {
                    this.startTimePicker.PickedDateTime = u.ToString("yyyy-MM-dd HH:00:00");
                }
                u = DateTime.Parse(this.startTimePicker.PickedDateTime);
                this.CalcDays(u, dateTime);
                bool flag2 = u.CompareTo(dateTime) > 0 || now.CompareTo(dateTime) > 0;
                if (flag2)
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
            }
            catch
            {
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in details)
            {
                item.IsChecked = false;
            }
            string text = comboBox1.Text;
            if (text == "全部")
            {
                this.gdDetail.ItemsSource = details;
                return;
            }
            searchs.Clear();
            foreach (var item in details)
            {
                var count = item.SellerSku.IndexOf(text);
                if (count > 0)
                {
                    searchs.Add(item);
                }
            }
            this.gdDetail.ItemsSource = searchs;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            AsyncObservableCollection<ChildSKU> itemsource = this.gdDetail.ItemsSource as AsyncObservableCollection<ChildSKU>;
            if (itemsource.Count > 0)
            {
                OnlineProductUpdateResult win = new OnlineProductUpdateResult(itemsource, url, currentProduct);
                win.ShowDialog();
            }
        }
    }
}
