﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.OnlineProductControl
{
    /// <summary>
    /// OnlineProductBatch.xaml 的交互逻辑
    /// </summary>
    public partial class OnlineProductBatch : UserControl
    {
        List<ShowOnLineProduct> currentList;
        #region 过滤掉已经有的属性
        List<string> attrlist = new List<string>
        {
            "Url",
            "ShopSku",
            "special_time_format",
            "Available",
            "SkuId",
            "Status",
        };

        #endregion

        public OnlineProductBatch(List<ShowOnLineProduct> list)
        {
            InitializeComponent();
            currentList = list;
            txtAffectRow.Text = list.Count.ToString();
        }

        private void BtnExecute_Click(object sender, RoutedEventArgs e)
        {
            Dictionary<JObject, ShowOnLineProduct> dic = new Dictionary<JObject, ShowOnLineProduct>();
            foreach (var item in currentList)
            {
                var jsondata = CreateJobject(item);
                //var productObjcet = JsonConvert.DeserializeObject<JObject>(jsondata["Request"]["Product"].ToString());
                var productObjcet = JsonConvert.DeserializeObject<JObject>(jsondata["Request"]["Product"].ToString());
                var obj = JsonConvert.DeserializeObject<JObject>(productObjcet["Skus"][0].ToString());
                var skus = JsonConvert.DeserializeObject<JArray>(obj["Sku"].ToString());
                JArray newArr = new JArray();
                var title = productObjcet["Attributes"]["name"].ToString();
                if (txtTitleAddFrVal.Text.Trim() != string.Empty)
                {
                    title = txtTitleAddFrVal.Text + title;
                }
                if (txtTitleAddBeVal.Text.Trim() != string.Empty)
                {
                    title = title + txtTitleAddBeVal.Text;
                }
                if (txtTitleReplyValA.Text != string.Empty)
                {
                    title.Replace(txtTitleReplyValA.Text, txtTitleAsValA.Text);
                }
                if (txtTitleReplyValB.Text != string.Empty)
                {
                    title.Replace(txtTitleReplyValB.Text, txtTitleAsValB.Text);
                }
                if (txtTitleReplyValC.Text != string.Empty)
                {
                    title.Replace(txtTitleReplyValC.Text, txtTitleAsValC.Text);
                }
                if (txtTitleReplyValD.Text != string.Empty)
                {
                    title.Replace(txtTitleReplyValD.Text, txtTitleAsValD.Text);
                }
                //var skus = JsonConvert.DeserializeObject<JArray>(JsonConvert.DeserializeObject<JObject>(jsondata["Request"]["Product"]["Skus"].ToString())[0]["Sku"].ToString());
                foreach (var mySku in skus)
                {
                    var sku = JsonConvert.DeserializeObject<JObject>(mySku.ToString());
                    foreach (var atrr in attrlist)
                    {
                        if (sku.ContainsKey(atrr))
                        {
                            sku.Remove(atrr);
                        }
                    }
                    if (chkprice.IsChecked ?? false)
                    {
                        if (rbtn_price1.IsChecked ?? false)
                        {
                            sku["price"] = num_price.Value.ToString();
                        }
                        else
                        {
                            var price = sku["price"];
                            if (cboPrice.SelectedIndex == 0)
                            {
                                sku["price"] = (Convert.ToDecimal(price) + num_toprice.Value).ToString();
                            }
                            else
                            {
                                sku["price"] = (Convert.ToDecimal(price) + Convert.ToDecimal(price) * num_toprice.Value / 100).ToString();
                            }
                        }
                    }
                    if (chksprice.IsChecked ?? false)
                    {
                        if (rbtn_sprice1.IsChecked ?? false)
                        {
                            sku["special_price"] = num_sprice.Value.ToString();
                        }
                        else
                        {
                            var sprice = sku["special_price"];
                            if (cboSprice.SelectedIndex == 0)
                            {
                                sku["special_price"] = (Convert.ToDecimal(sprice) + num_tosprice.Value).ToString();
                            }
                            else
                            {
                                sku["special_price"] = (Convert.ToDecimal(sprice) + Convert.ToDecimal(sprice) * num_tosprice.Value / 100).ToString();
                            }
                        }
                    }
                    if (chkquantity.IsChecked ?? false)
                    {
                        if (rbtn_quantity1.IsChecked ?? false)
                        {
                            sku["quantity"] = num_quantity.Value.ToString();
                        }
                        else
                        {
                            var quantity = sku["quantity"];
                            if (cboQuantity.SelectedIndex == 0)
                            {
                                sku["quantity"] = (Convert.ToDecimal(quantity) + num_toquantity.Value).ToString();
                            }
                            else
                            {
                                sku["quantity"] = (Convert.ToDecimal(quantity) + Convert.ToDecimal(quantity) * num_toquantity.Value / 100).ToString();
                            }
                        }
                    }
                    if (chkpackageweight.IsChecked ?? false)
                    {
                        sku["package_weight"] = (num_weight.Value / 1000).ToString();
                    }
                    if (chkpackagevolume.IsChecked ?? false)
                    {
                        sku["package_length"] = num_length.Value.ToString();
                        sku["package_width"] = num_width.Value.ToString();
                        sku["package_height"] = num_height.Value.ToString();
                    }
                    if (chkspecialdate.IsChecked ?? false)
                    {
                        if (startTimePicker.PickedDateTime != string.Empty && startTimePicker.PickedDateTime != null && endTimePicker.PickedDateTime != string.Empty && endTimePicker.PickedDateTime != null)
                        {
                            sku["special_from_date"] = startTimePicker.PickedDateTime.ToString();
                            sku["special_to_date"] = endTimePicker.PickedDateTime.ToString(); 
                        }
                    }
                    JArray images = JsonConvert.DeserializeObject<JArray>(sku["Images"].ToString());
                    JObject img = new JObject();
                    //    "Image",images
                    //};
                    //sku.Remove("Images");
                    img["Image"] = images;
                    sku["Images"] = img;
                    newArr.Add(sku);
                }
                obj["Sku"] = newArr;
                productObjcet["Skus"][0] = obj;
                jsondata["Request"]["Product"] = productObjcet;
                jsondata["Request"]["Product"]["Attributes"]["name"] = title;
                dic.Add(jsondata, item);

                //if (new LazadaCore().PushUpdateProduct(jsondata, item))
                //{
                //    new OnlineProductFunctionUpadteCore().SaveLocalOnlineProduct(item);
                //    CMessageBox.Show($"{item.MainSku}更新成功");
                //}
                //else
                //{
                //    CMessageBox.Show($"{item.MainSku}更新失败");
                //}
            }
            OnlineProductBatchResult win = new OnlineProductBatchResult(dic);
            win.ShowDialog();


        }

        private JObject CreateJobject(ShowOnLineProduct currentpro)
        {
            JObject request = new JObject();
            JObject product = new JObject();
            JObject pro = new JObject();
            JArray array = new JArray();
            JObject sku = new JObject();
            JObject online = JsonConvert.DeserializeObject<JObject>(currentpro.JsonStr);
            request["Request"] = product;
            product["Product"] = pro;
            pro["PrimaryCategory"] = online["primary_category"];
            pro["Attributes"] = online["attributes"];
            pro["PrimaryCategory"] = online["item_id"];
            pro["PrimaryCategory"] = online["primary_category"];
            pro["Skus"] = array;
            JObject jobject11 = new JObject
            {
                { "Sku", online["skus"] }
            };
            //sku["Sku"] = online["skus"];
            array.Add(jobject11);
            return request;
        }

        private Product CreateProduct(ShowOnLineProduct currentpro)
        {
            Product product = new Product();
            List<Aattribute> categoryAttrs = new List<Aattribute>();
            this.DataContext = product;
            var currentObj = JsonConvert.DeserializeObject<JObject>(currentpro.JsonStr.ToString());
            var categoryId = currentObj["primary_category"].ToString();
            product.Lazadacategoryid = categoryId;
            product.Pcolors = "";
            product.Psizes = "";
            try
            {
                product.Video = currentObj["attributes"]["video"].ToString();
            }
            catch
            {
                product.Video = "";
            }

            product.Porigtitle = currentObj["attributes"]["name"].ToString();
            //product.Pnewtitle = new ALiCore().ChangeSiteDefaultLangaugeToZh(product.Porigtitle);
            product.Pnewtitle = product.Porigtitle;
            product.PnewtitleX = product.Porigtitle;
            var skus = JsonConvert.DeserializeObject<JArray>(currentObj["skus"].ToString());
            {
                var sku = skus[0];
                try
                {
                    product.Lazadapackageincluding = sku["package_content"].ToString();
                }
                catch
                {
                    product.Lazadapackageincluding = "";
                }
                product.Pidprefix = skus[0]["SellerSku"].ToString().Split('-')[0];
                product.PackageWidth = sku["package_width"].ToString();
                product.PackageHight = sku["package_height"].ToString();
                product.PackageLength = sku["package_length"].ToString();
                product.Lazadapromstart = sku["special_from_time"].ToString();
                product.Lazadapromend = sku["special_to_time"].ToString();
                product.Lazadapackageweight = (Convert.ToDouble(sku["package_weight"]) * 1000).ToString();
            }
            product.Lazadahighlight = currentObj["attributes"]["short_description"].ToString();
            List<string> images = new List<string>();
            var desc = currentObj["attributes"]["description"].ToString();
            {
                Regex regex = new Regex("<img\\b[^<>]*?\\bsrc[\\s\\t\\r\\n]*=[\\s\\t\\r\\n]*[\"']?[\\s\\t\\r\\n]*(?<imgUrl>[^\\s\\t\\r\\n\"'<>]*)[^<>]*?/?[\\s\\t\\r\\n]*>", RegexOptions.IgnoreCase);
                MatchCollection matchCollection = regex.Matches((desc).Replace("\\", ""));
                foreach (object obj in matchCollection)
                {
                    Match match = (Match)obj;
                    var imageUrl = match.Groups["imgUrl"].Value.Split(new char[] { '?' })[0].Trim();
                    if (!images.Contains(imageUrl))
                    {
                        images.Add(imageUrl);
                    }
                }
                product.Pnewimgsurl = string.Join(",", images);
                product.Lazadadescription = regex.Replace(desc, "");
            }

            JArray skusArray = new JArray();
            JArray skuImgArr = new JArray();
            JArray skuxArr = new JArray();
            foreach (var item in skus)
            {
                JObject skuimg = new JObject();
                var sku = JsonConvert.DeserializeObject<JObject>(item.ToString());
                JObject obj = new JObject();
                obj.Add("SellerSku", sku["SellerSku"].ToString());
                obj.Add("package_weight", (Convert.ToDouble(sku["package_weight"]) * 1000).ToString());
                obj.Add("price", sku["price"].ToString());
                obj.Add("special_price", sku["special_price"].ToString());
                obj.Add("quantity", sku["quantity"].ToString());
                JArray skuArr = new JArray();
                foreach (var attr in categoryAttrs)
                {
                    if (sku.ContainsKey(attr.Aname))
                    {
                        obj.Add(attr.Aname, sku[attr.Aname].ToString());
                    }
                    try
                    {
                        JObject attrobj = new JObject() {
                        { "name",attr.Aname},
                        { "value",sku[attr.Aname].ToString()}
                    };
                        skuArr.Add(attrobj);
                    }
                    catch { }
                }
                skuimg["sku"] = skuArr;
                JArray imageArr = JsonConvert.DeserializeObject<JArray>(sku["Images"].ToString());
                skuimg["leftimages"] = imageArr;
                skuimg["rightimages"] = new JArray();
                skusArray.Add(obj);
                skuImgArr.Add(skuimg);
            }
            if (categoryAttrs.Count > 0)
            {
                foreach (var attr in categoryAttrs)
                {
                    skuxArr.Add(new JObject() { { "name", attr.Aname }, { "value", attr.Avalue } });
                }
            }
            else
            {
                skuxArr.Add(new JObject() { { "name", "DEFAULT" }, { "value", "OnlyOne" } });
            }
            product.Lazadaskux = JsonConvert.SerializeObject(skuxArr);
            product.Lazadaskuimages = JsonConvert.SerializeObject(skuImgArr);
            product.SKUDetail = JsonConvert.SerializeObject(skusArray);
            return product;
        }

        private void dj0xntc6bF(object sender, RoutedEventArgs e)
        {
            ///如果有一个为空，开始时间为当前+1小时，结束时间为一个月后
            if (string.IsNullOrEmpty(this.endTimePicker.PickedDateTime) || string.IsNullOrEmpty(this.startTimePicker.PickedDateTime))
            {
                DateTime dateTime = DateTime.Now.AddHours(2.0);
                this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
            }
            else
            {
                try
                {   //时间格式正确，一起往后顺延一小时
                    if (Convert.ToDateTime(this.endTimePicker.PickedDateTime) > Convert.ToDateTime(startTimePicker.PickedDateTime))
                    {
                        this.endTimePicker.PickedDateTime = Convert.ToDateTime(this.endTimePicker.PickedDateTime).AddHours(1.0).ToString("yyyy-MM-dd HH:00:00");
                        this.startTimePicker.PickedDateTime = DateTime.Now.AddHours(1.0).ToString("yyyy-MM-dd HH:00:00");
                    }
                    else //结束时间>开始时间，开始时间为当前+1小时，结束时间为一个月后
                    {
                        DateTime dateTime = DateTime.Now.AddHours(1.0);
                        this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                        this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
                    }
                }
                catch
                {
                    DateTime dateTime = DateTime.Now.AddHours(1.0);
                    this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                    this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
                }
            }
        }

        private void StartTimePicker_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime now = DateTime.Now;
                DateTime dateTime = DateTime.Parse(this.startTimePicker.PickedDateTime);
                DateTime dateTime2 = dateTime.AddMonths(1);
                bool flag = string.IsNullOrEmpty(this.endTimePicker.PickedDateTime);
                if (flag)
                {
                    this.endTimePicker.PickedDateTime = dateTime2.ToString("yyyy-MM-dd HH:00:00");
                }
                dateTime2 = DateTime.Parse(this.endTimePicker.PickedDateTime);
                this.CalcDays(dateTime, dateTime2);
                bool flag2 = now.CompareTo(dateTime) > 0;
                if (flag2)
                {
                    this.startTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.startTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
                bool flag3 = dateTime.CompareTo(dateTime2) > 0;
                if (flag3)
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
            }
            catch
            {
            }
        }

        private void EndTimePicker_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime now = DateTime.Now;
                DateTime u = now.AddHours(1.0);
                DateTime dateTime = DateTime.Parse(this.endTimePicker.PickedDateTime);
                bool flag = string.IsNullOrEmpty(this.startTimePicker.PickedDateTime);
                if (flag)
                {
                    this.startTimePicker.PickedDateTime = u.ToString("yyyy-MM-dd HH:00:00");
                }
                u = DateTime.Parse(this.startTimePicker.PickedDateTime);
                this.CalcDays(u, dateTime);
                bool flag2 = u.CompareTo(dateTime) > 0 || now.CompareTo(dateTime) > 0;
                if (flag2)
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
            }
            catch
            {
            }
        }

        /// <summary>
        /// 计算日期差值并显示
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        private void CalcDays(DateTime start, DateTime end)
        {
            int hours = (end - start).Hours;
            int days = (end - start).Days;
            this.timeTips.Content = string.Format("{0}D{1}H", days, hours);
        }

        private void Chkprice_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkprice_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void Chksprice_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Chksprice_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkquantity_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkquantity_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkpackageweight_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkpackageweight_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkpackagevolume_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkpackagevolume_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkspecialdate_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Chkspecialdate_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void LblValua_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeCanvas(CanvasValuaMode);
        }

        private void LblTitle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeCanvas(CvTitle);
        }

        private void ChangeCanvas(Border canvas)
        {
            CanvasValuaMode.Visibility = Visibility.Collapsed;
            CvTitle.Visibility = Visibility.Collapsed;
            canvas.Visibility = Visibility.Visible;

        }
    }
}
