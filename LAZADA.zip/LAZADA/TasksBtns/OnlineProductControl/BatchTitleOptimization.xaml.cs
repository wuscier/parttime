﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Top.Api.Response;

namespace LAZADA.TasksBtns.OnlineProductControl
{
    /// <summary>
    /// BatchTitleOptimization.xaml 的交互逻辑
    /// </summary>
    public partial class BatchTitleOptimization : UserControl
    {
        AsyncObservableCollection<ShowOnLineProduct> onlineProductList = new AsyncObservableCollection<ShowOnLineProduct>();
        private MainWindow main;
        public BatchTitleOptimization(List<ShowOnLineProduct> list, MainWindow window)
        {
            InitializeComponent();
            main = window;
            for (int i = 0; i < list.Count; i++)
            {
                Product pro = new Product();
                ShowOnLineProduct product = list[i];
                pro.LazadaItemid = Convert.ToInt64(product.Itemid);
                pro.Lazadacategoryid = product.Categoryid;
                AlibabaSeakingDiagnosistitleResponse rep = new HaiWangCore().Diagnosistitle(pro, product.Title, "en");
                if (rep.IsError)
                {
                    product.TitleScore = "诊断出错！";
                    onlineProductList.Add(product);
                    continue;
                }
                product.TitleScore = rep.TotalScore.ToString();
                product.ScoreDetail = "";
                string str = "所有大写字母词:";
                for (int a=0;a< rep.AllUppercaseWords.Count; a++)
                {
                    str += str== "所有大写字母词:"? rep.AllUppercaseWords[a] :(","+rep.AllUppercaseWords[a]) ;
                }
                if (str != "所有大写字母词:")
                    product.ScoreDetail += str+"\n";
                if (rep.ContainCoreClasses)
                    product.ScoreDetail += "包含核心类\n";
                str = "禁用单词列表:";
                for (int a = 0; a < rep.DisableWordList.Count; a++)
                {
                    str += str == "禁用单词列表:" ? rep.DisableWordList[a] : ("," + rep.DisableWordList[a]);
                }
                if (str != "禁用单词列表:")
                    product.ScoreDetail += str + "\n";
                str = "重复的单词列表:";
                for (int a = 0; a < rep.DuplicateWordList.Count; a++)
                {
                    str += str == "重复的单词列表:" ? rep.DuplicateWordList[a] : ("," + rep.DuplicateWordList[a]);
                }
                if (str != "重复的单词列表:")
                    product.ScoreDetail += str + "\n";
                if (rep.LanguageQualityScore != "")
                    product.ScoreDetail += "语言质量分:"+ rep.LanguageQualityScore + "\n";
                str = "首字母未大写单词列表:";
                for (int a = 0; a < rep.NoFirstUppercaseWordList.Count; a++)
                {
                    str += str == "首字母未大写单词列表:" ? rep.NoFirstUppercaseWordList[a] : ("," + rep.NoFirstUppercaseWordList[a]);
                }
                if (str != "首字母未大写单词列表:")
                    product.ScoreDetail += str + "\n";
                if(rep.OverLengthLimit)
                    product.ScoreDetail += "标题长度超出限制\n";
                str = "拼写错误单词列表:";
                for (int a = 0; a < rep.SpellErrorWordList.Count; a++)
                {
                    str += str == "拼写错误单词列表:" ? rep.SpellErrorWordList[a] : ("," + rep.SpellErrorWordList[a]);
                }
                if (str != "拼写错误单词列表:")
                    product.ScoreDetail += str + "\n";

                onlineProductList.Add(product);
                Thread.Sleep(100);
            }
            lvShowProduct.ItemsSource = onlineProductList;

        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            var id = btn.Tag.ToString();
            ShowOnLineProduct product = onlineProductList.Where(p => p.Itemid == id).First();
            product.Title = product.OldTitle;
            //lvShowProduct.ItemsSource = onlineProductList;
        }

        private void txtTitleEn_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox txt = (TextBox)sender;
            var id = txt.Tag.ToString();
            ShowOnLineProduct product = onlineProductList.Where(p => p.Itemid == id).First();
            product.Title = txt.Text;
            product.OldTitle = oldTitle == txt.Text ? product.OldTitle : oldTitle;
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSearch_Copy_Click(object sender, RoutedEventArgs e)
        {
            if (CMessageBoxResult.OK == CMessageBox.Show($"确定更新已经修改的内容?", CMessageBoxButton.OKCancel))
                DoPushProduct();
        }

        private void DoPushProduct()
        {
            var json = new HummingbirdCore().GetPoints();
            if (json == null)
            {
                CMessageBox.Show("服务器链接失败，请稍后重试");
                return;
            }
            if (!Convert.ToBoolean(json["success"]))
            {
                CMessageBox.Show("账号异常，请联系客服");
                return;
            }
            if (Convert.ToInt32(json["result"]) < onlineProductList.Count)
            {
                CMessageBox.Show("发布积分不足，请联系客服");
                return;
            }
            string strResult = "";
            for (int i = 0; i < onlineProductList.Count; i++)
            {
                if (PushUpdateProduct( onlineProductList[i].Title,out string str))
                {
                    new OnlineProductFunctionUpadteCore().SaveLocalOnlineProduct(onlineProductList[i]);
                    strResult += "第" + i + "条数据更新成功！\n";
                    onlineProductList[i].IsUpdate = true;
                    main.ChangeChildControl_OnlineProduct(onlineProductList[i], main, "OnLine");

                }
                else
                {
                    strResult += "第" + i + "条数据更新失败：" + str + "\n";
                }
            }
        }
        public bool PushUpdateProduct(string strName,out string str)
        {
            str = "";
            JObject jobject = new JObject();
            JObject jobject2 = new JObject();
            jobject["Request"] = jobject2;
            JObject jobject3 = new JObject();
            jobject2["Product"] = jobject3;
            JObject jobject4 = new JObject();
            jobject3["Attributes"] = jobject4;
            jobject4["name"] = strName;// onlineProductList[i].Title;
            string text14 = JsonConvert.SerializeObject(jobject);
            string outerXml = JsonConvert.DeserializeXmlNode(text14).OuterXml;
            string u = "<?xml version = \"1.0\" encoding = \"UTF-8\" ?> " + outerXml;
            try
            {
                JObject jobject12 = new LazadaCore().UpdateProduct(u);
                if (jobject12 == null)
                    str = "发布出错...";
                if (jobject12["code"] == null)
                    str = "发布超时...";
                if (Convert.ToString(jobject12["code"]) == "0" || Convert.ToString(jobject12["code"]) == "ServiceTimeout")
                {
                    str = "";
                    return true;
                }
                else
                {
                    var obj = new JObject();
                    try
                    {
                        obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                        str = obj["error"]["sku_info"]["sku0"]["special_price"].ToString();
                    }
                    catch
                    {
                        try
                        {
                            obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                            str = obj["error"]["global_error"].ToString();
                        }
                        catch
                        {
                            try
                            {
                                obj = JsonConvert.DeserializeObject<JObject>(jobject12["detail"][0].ToString());
                                str = obj["error"].ToString();
                            }
                            catch
                            {
                                try
                                {
                                    str = jobject12.ToString();
                                    //product.Pcancsv = jobject12["message"].ToString();
                                }
                                catch
                                {

                                }
                            }
                            new LogOutput.LogTo().WriteErrorLine(JsonConvert.SerializeObject(jobject12));
                        }
                    }
                }
                str =str==""? "更新异常！":str;
                return false;

            }
            catch(Exception ex)
            {
                str = ex.Message;
                return false;
            }
        }
        /// <summary>
        /// 生成更新标题的发送文件
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        private JObject CreateTitleXMLNew(Product product)
        {
            JObject jobject = new JObject();
            JObject jobject2 = new JObject();
            jobject["Request"] = jobject2;
            JObject jobject3 = new JObject();
            jobject2["Product"] = jobject3;
            jobject3.Add("PrimaryCategory", product.Lazadacategoryid);
            JObject jobject4 = new JObject();
            jobject3["Attributes"] = jobject4;
            jobject4["name"] =  product.PnewtitleX;
            return jobject;
        }
        string oldTitle = "";
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox txt = (TextBox)sender;
            var id = txt.Tag.ToString();
            ShowOnLineProduct product = onlineProductList.Where(p => p.Itemid == id).First();
            //product.OldTitle
            oldTitle = txt.Text;
        }
    }
}
