﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.OnlineProductControl
{
    /// <summary>
    /// OnlineProductUploadImage.xaml 的交互逻辑
    /// </summary>
    public partial class OnlineProductUploadImage : Window
    {
        private Product product;
        public OnlineProductUploadImage(Product uploadPro)
        {
            InitializeComponent();
            product = uploadPro;
            this.DataContext = product;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1500);
                int alreadyUploadCount = 0;
                int allcount = 0;
                int errorCount = 0;
                List<string> uploadList = new List<string>();
                var imgarr = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                try
                {
                    if (imgarr.Length == 0)
                    {
                        product.Pstate = String.Format("上传图片[{0}/{1}/{2}]", 0, 0, 0);
                        product.Pupedimg = String.Format("[{0}/{1}]", 0, 0);
                        return;
                    }
                    else
                    {
                        product.Pstate = String.Format("准备上传...");
                        product.Pupedimg = String.Format("[{0}/{1}]", 0, 0);
                        Thread.Sleep(100);
                    }
                    foreach (var item in imgarr)
                    {
                        allcount++;
                        if (item.StartsWith("http"))
                        {
                            alreadyUploadCount++;
                        }
                        else
                        {
                            if (File.Exists(item))
                            {
                                if (!uploadList.Contains(item))
                                    uploadList.Add(item);
                                else
                                    uploadList.Add("");
                            }
                            else
                            {
                                errorCount++;
                            }
                        }
                    }
                    JArray msku = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);
                    if (msku != null)
                    {
                        foreach (JToken jtn in msku) //不同sku组合
                        {
                            if (jtn["leftimages"] != null && jtn["leftimages"].HasValues)
                            {
                                foreach (string jtx in (JArray)jtn["leftimages"])
                                {
                                    allcount++;

                                    string jtxp = jtx.Trim();

                                    if (jtxp.StartsWith("http"))
                                    {
                                        alreadyUploadCount++;
                                    }
                                    else
                                    {
                                        if (File.Exists(jtxp))
                                        {
                                            if (!uploadList.Contains(jtxp))
                                            {
                                                uploadList.Add(jtxp);
                                            }
                                            else
                                                uploadList.Add("");
                                        }
                                        else
                                        {
                                            errorCount++;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (uploadList.Count > 0)
                    {
                        product.Pstate = String.Format("开始上传[{0}/{1}/{2}]", errorCount, alreadyUploadCount, allcount);
                        product.Pupedimg = String.Format("[{0}/{1}]", alreadyUploadCount, allcount);
                        new UpLoadImageCore().AsyncUploadImageNew(product, uploadList, allcount, alreadyUploadCount);
                    }
                    else
                    {
                        if (errorCount > 0)
                        {
                            //product.Pstate = String.Format("传图出错[{0}/{1}/{2}]有{0}张备选本地图片不存在了", errorCount, alreadyUploadCount, allcount);
                            CMessageBox.Show($"{errorCount}张图片上传失败");
                        }
                        else
                        {
                            product.Pstate = String.Format("OK传图完毕[{0}/{1}/{2}]图片已全上传，无错误", errorCount, alreadyUploadCount, allcount);
                        }
                        product.Pupedimg = String.Format("[{0}/{1}]", alreadyUploadCount, allcount);
                    }
                }
                catch
                {
                    product.Pstate = String.Format("传图出错[{0}/{1}/{2}]图片上传出错，可再次上传", 0, alreadyUploadCount, allcount);
                    product.Pupedimg = String.Format("[{0}/{1}]", alreadyUploadCount, allcount);
                }
                Thread.Sleep(500);
                this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
            });
        }
    }
}
