﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.OnlineProductControl
{
    /// <summary>
    /// OnlineProductLoad.xaml 的交互逻辑
    /// </summary>
    public partial class OnlineProductLoad : Window
    {
        OnlineProductLoadModel viewModel = new OnlineProductLoadModel();
        OnlineProductFunctionUpadteCore core = new OnlineProductFunctionUpadteCore();
        Dictionary<string, string> paramDic = new Dictionary<string, string>();
        List<string> productList = new List<string>();
        CancellationTokenSource tokenSource = new CancellationTokenSource();
        CancellationToken token;
        Task task = null;
        OnlinePro proWin;
        public OnlineProductLoad(Dictionary<string, string> dic, OnlinePro win)
        {
            InitializeComponent();
            this.DataContext = viewModel;
            paramDic = dic;
            proWin = win;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Task.Run(() =>
            {
                token = tokenSource.Token;
                Thread.Sleep(500);
                task = new Task(GetProductToLocal);
                task.Start();
            });
            //task=new Task(GetProductToLocal(), token)
            //Task.Run(() => GetProductToLocal());
        }

        private void GetProductToLocal()
        {
            var doCount = 0;
            var countData = new LazadaCore().GetOnLineProduct(new Dictionary<string, string>() { { "filter", "live" }, { "limit", "1" } });
            if (countData == null)
            {
                countData = new LazadaCore().GetOnLineProduct(new Dictionary<string, string>() { { "filter", "live" }, { "limit", "1" } });
            }

            if (countData["code"].ToString() == "0" && countData["data"].HasValues)
            {
                viewModel.Count = Convert.ToInt32(countData["data"]["total_products"]);
                doCount = viewModel.Count * 8;
                if (viewModel.Count > 0)
                {
                    double add = 90d / doCount;
                    int loopCount = doCount / viewModel.PageSize + (doCount % viewModel.PageSize > 0 ? 1 : 0);
                    viewModel.CurrentPage = 1;
                    do
                    {
                        var offset = (viewModel.CurrentPage - 1) * viewModel.PageSize;
                        JObject jsondata = null;
                        try
                        {
                            jsondata = new LazadaCore().GetOnLineProduct(new Dictionary<string, string>() { { "filter", "live" }, { "limit", viewModel.PageSize.ToString() }, { "offset", offset.ToString() } });
                        }
                        catch
                        {
                            Thread.Sleep(500);
                            try
                            {
                                jsondata = new LazadaCore().GetOnLineProduct(new Dictionary<string, string>() { { "filter", "live" }, { "limit", viewModel.PageSize.ToString() }, { "offset", offset.ToString() } });
                            }
                            catch
                            {
                                Thread.Sleep(500);
                                try
                                {
                                    jsondata = new LazadaCore().GetOnLineProduct(new Dictionary<string, string>() { { "filter", "live" }, { "limit", viewModel.PageSize.ToString() }, { "offset", offset.ToString() } });
                                }
                                catch { jsondata = null; }
                            }
                        }
                        if (jsondata == null)
                            continue;
                        if (jsondata["code"].ToString() == "0" && jsondata["data"].HasValues)
                        {
                            //var count = Convert.ToInt32(countData["data"]["total_products"]);
                            //double add = 90d / count;
                            var jarry = JsonConvert.DeserializeObject<JArray>(jsondata["data"]["products"].ToString());
                            foreach (var item in jarry)
                            {
                                if (token.IsCancellationRequested)
                                {
                                    try
                                    {
                                        token.ThrowIfCancellationRequested();
                                    }
                                    catch { }
                                    Thread.Sleep(1000);
                                    this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
                                    break;
                                }
                                viewModel.Ipbvalue += add;
                                Thread.Sleep(200);
                                var obj = JsonConvert.DeserializeObject<JObject>(item.ToString());
                                var itemid = obj["item_id"].ToString();
                                if (productList.Contains(itemid))
                                    continue;
                                else
                                    productList.Add(itemid);
                                viewModel.CurrentContent = $"已经同步了{productList.Count}条产品";
                                ShowOnLineProduct product = new ShowOnLineProduct()
                                {
                                    Title = obj["attributes"]["name"].ToString(),
                                    Itemid = itemid,
                                    JsonStr = item.ToString(),
                                    Siteid = GlobalUserClass.SiteId
                                };

                                var skus = JsonConvert.DeserializeObject<JArray>(obj["skus"].ToString());

                                var firstSku = JsonConvert.DeserializeObject<JObject>(skus[0].ToString());
                                var sellerSku = firstSku["SellerSku"].ToString();
                                var attrs = sellerSku.Split('-');
                                var name = attrs[0];
                                product.MainSku = name;
                                product.Url = firstSku["Url"].ToString();
                                product.CreateTime = DateTime.Now;
                                product.LocalTime = product.CreateTime;
                                product.UpdateTime = product.LocalTime;
                                product.StoreName = Constants.OnlineLAZADA_ACCOUNT;
                                List<string> child = new List<string>();
                                foreach (var sku in skus)
                                {
                                    var mySku = JsonConvert.DeserializeObject<JObject>(sku.ToString());
                                    child.Add(mySku["SellerSku"].ToString());
                                }
                                product.Sellersku = string.Join(",", child);
                                core.SaveOnlineProduct(product);
                                Thread.Sleep(100);
                            }
                        }

                        viewModel.CurrentPage++;

                    } while (viewModel.CurrentPage <= loopCount && (viewModel.Count > productList.Count));

                    while (viewModel.Ipbvalue < 100)
                    {
                        viewModel.Ipbvalue++;
                        Thread.Sleep(200);
                    }
                    this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
                }
                else
                {
                    while (viewModel.Ipbvalue < 100)
                    {
                        viewModel.Ipbvalue++;
                        Thread.Sleep(50);
                    }
                    this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
                }
            }
            else
            {
                while (viewModel.Ipbvalue < 100)
                {
                    viewModel.Ipbvalue++;
                    Thread.Sleep(50);
                }
                this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
            }
            //this.Dispatcher.BeginInvoke(new Action(() => this.Close()));

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (CMessageBoxResult.OK == CMessageBox.Show($"确定要终止同步吗?", CMessageBoxButton.OKCancel))
                tokenSource.Cancel();
        }
    }

    public class OnlineProductLoadModel : BaseViewModel
    {
        private double _Ipbvalue;
        private int pageSize = 50;
        private int currentPage = 1;
        private int _count;
        private string _currentContent;
        private string _countContent;

        public double Ipbvalue
        {
            get => _Ipbvalue;
            set
            {
                if (_Ipbvalue != value)
                {
                    _Ipbvalue = value;
                    base.RaisePropertyChanged("Ipbvalue");
                }
            }
        }

        public int Count
        {
            get => _count;
            set
            {
                if (_count != value)
                {
                    _count = value;
                    base.RaisePropertyChanged("Count");
                    base.RaisePropertyChanged("CountContent");
                    base.RaisePropertyChanged("CurrentContent");
                }
            }
        }
        public string CountContent
        {
            get
            {
                return $"共{Count}条数据";
            }
        }

        public int CurrentPage
        {
            get => currentPage;
            set
            {
                if (currentPage != value)
                {
                    currentPage = value;
                    base.RaisePropertyChanged("CurrentPage");
                    base.RaisePropertyChanged("CurrentContent");
                }
            }
        }

        public string CurrentContent
        {
            //get
            //{
            //    var start = (currentPage - 1) * PageSize + 1;
            //    var end = (currentPage * PageSize) > Count ? Count : (currentPage * PageSize);
            //    return $"当前第{start}-{end}条数据";
            //}
            get => _currentContent;
            set
            {
                if (_currentContent != value)
                {
                    _currentContent = value;
                    base.RaisePropertyChanged("CurrentContent");
                }
            }
        }

        public int PageSize { get => pageSize; }
    }
}
