﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.OnlineProductControl
{
    /// <summary>
    /// OnlineProductUpdateResult.xaml 的交互逻辑
    /// </summary>
    public partial class OnlineProductUpdateResult : Window
    {
        AsyncObservableCollection<ChildSKU> itemsource = new AsyncObservableCollection<ChildSKU>();
        OnlineProductUpdateResultModel vm = new OnlineProductUpdateResultModel();
        private ShowOnLineProduct currentProduct;
        public OnlineProductUpdateResult(AsyncObservableCollection<ChildSKU> collection, string proUrl, ShowOnLineProduct product)
        {
            InitializeComponent();
            currentProduct = product;
            vm.Poriglink = proUrl;
            this.DataContext = vm;
            itemsource = collection;
        }

        private void CopyOtherSite_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var lc = new LazadaCore();
            vm.Ipbvalue = 0;
            bool isOK = true;
            string errorMsg = "";
            Task.Run(() =>
            {
                var loop = (itemsource.Count / 20) + ((itemsource.Count % 20) > 0 ? 1 : 0);
                var add = 100 / loop;
                for (int i = 0; i < loop; i++)
                {
                    var updates = itemsource.Skip(i * 20).Take(20).ToList<ChildSKU>();
                    //AsyncObservableCollection<ChildSKU> updates = itemsource.Skip(i * 20).Take(20) as AsyncObservableCollection<ChildSKU>;
                    for (int k = 0; k < loop; k++)
                    {
                        vm.Ipbvalue += add / 2;
                        Thread.Sleep(100);
                    }
                    var json = lc.UpdatePriceQuantity(updates);
                    for (int k = 0; k < loop; k++)
                    {
                        vm.Ipbvalue += add / 2;
                        Thread.Sleep(100);
                    }
                    while (vm.Ipbvalue < 100)
                    {
                        vm.Ipbvalue += 1;
                        Thread.Sleep(100);
                    }
                    var last = (i + 1) * 20 > itemsource.Count ? itemsource.Count : (i + 1) * 20;
                    var start = (i - 1) * 20 + 1;
                    if (json != null)
                    {
                        if (json["code"].ToString() != "0")
                        {
                            isOK = false;
                            errorMsg += json["message"].ToString();
                            break;
                        }
                    }
                    else
                    {
                        isOK = false;
                        break;
                    }

                }
                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    CopyOtherSite.IsEnabled = true;
                }));
                if (isOK)
                {
                    UpadteLocalInfo();
                    CMessageBox.Show("更新成功");
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        txt_link.Visibility = Visibility.Visible;
                    }));
                }
                else
                {
                    CMessageBox.Show("更新失败:" + errorMsg);
                }
            });
        }

        private void UpadteLocalInfo()
        {
            var json = JsonConvert.DeserializeObject<JObject>(currentProduct.JsonStr);
            JArray array = JsonConvert.DeserializeObject<JArray>(json["skus"].ToString());
            JObject obj = new JObject();
            obj["item_id"] = json["item_id"];
            obj["primary_category"] = json["primary_category"];
            obj["attributes"] = json["attributes"];
            JArray newSkuInfo = new JArray();
            foreach (var sku in array)
            {
                JObject skuObj = new JObject();
                foreach (var item in itemsource)
                {
                    var mySku = JsonConvert.DeserializeObject<JObject>(sku.ToString());
                    skuObj = mySku;
                    var sellerSku = mySku["SellerSku"].ToString();
                    if (item.SellerSku == sellerSku)
                    {
                        skuObj["price"] = item.Price;
                        skuObj["special_price"] = item.Special_price;
                        skuObj["special_from_time"] = item.Special_from_time;
                        skuObj["special_to_time"] = item.Special_to_time;
                        skuObj["quantity"] = item.Quantity;
                        break;
                    }
                }
                newSkuInfo.Add(skuObj);
            }
            obj["skus"] = newSkuInfo;
            currentProduct.JsonStr = JsonConvert.SerializeObject(obj);
            currentProduct.UpdateTime = DateTime.Now;
            new OnlineProductFunctionUpadteCore().SaveLocalOnlineProduct(currentProduct);
        }

        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            string olink = Convert.ToString(((TextBlock)sender).ToolTip);
            if (olink != "")
            {
                try
                {
                    System.Diagnostics.Process.Start(olink);
                }
                catch
                {

                }
            }
        }
    }


    public class OnlineProductUpdateResultModel : BaseViewModel
    {
        private int _Ipbvalue;
        private string _Poriglink;

        public int Ipbvalue
        {
            get => _Ipbvalue;
            set
            {
                if (_Ipbvalue != value)
                {
                    _Ipbvalue = value;
                    base.RaisePropertyChanged("Ipbvalue");
                }
            }
        }
        public string Poriglink
        {
            get => _Poriglink;
            set
            {
                if (_Poriglink != value)
                {
                    _Poriglink = value;
                    base.RaisePropertyChanged("Poriglink");
                }
            }
        }
    }
}
