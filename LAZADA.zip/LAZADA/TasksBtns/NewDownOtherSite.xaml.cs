﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Link;
using Logic.Login;
using Logic.Platform;
using Logic.PriceTemplate;
using Logic.SystemSole;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// NewDownOtherSite.xaml 的交互逻辑
    /// </summary>
    public partial class NewDownOtherSite : UserControl
    {
        bool isRun = false;
        PagingViewModel vm = new PagingViewModel() { PageSize = 50 };
        AsyncObservableCollection<SimpleProduct> products = new AsyncObservableCollection<SimpleProduct>();
        private string otherAccountToken = "";
        public NewDownOtherSite()
        {
            InitializeComponent();
            //vm = new OtherSitePagingViewModel();
            var action = new Action(() => Search());
            Paging pageinfo = new Paging(vm, action);
            gridpage.Children.Add(pageinfo);
            txt_imagePath.Text = new GetLinkCore().GetImageSavePath();
            GetPriceTemplates();
            cbo_Site.ItemsSource = new SiteCore().GetSiteList(" where id <> " + GlobalUserClass.SiteId);
            cbo_Site.DisplayMemberPath = "ZhName";
            cbo_Site.SelectedValuePath = "ID";
        }
        private void GetPriceTemplates()
        {
            var list = new PriceTemplateCore().GetPriceTemplateList();
            cbo_priceTemplate.Dispatcher.BeginInvoke(new Action(() =>
            {
                cbo_priceTemplate.ItemsSource = list;
                cbo_priceTemplate.DisplayMemberPath = "Jname";
                cbo_priceTemplate.SelectedValuePath = "Jnumber";
                cbo_priceTemplate.SelectedIndex = 0;
            }));
        }

        void OtherAccountChange(bool ischeck)
        {
            cbo_Site.IsEnabled = !ischeck;
            btn_search.IsEnabled = !ischeck;
            txt_account.IsEnabled = ischeck;
            pwd_pwd.IsEnabled = ischeck;
            btn_verify.IsEnabled = ischeck;
            if (!ischeck)
                otherAccountToken = "";

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            OtherAccountChange(chk_OtherUser.IsChecked ?? false);
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            OtherAccountChange(chk_OtherUser.IsChecked ?? false);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (txt_account.Text.Trim() != string.Empty && pwd_pwd.Password != string.Empty)
            {
                var jsondata = new UserLoginCore().DoUserLogin(txt_account.Text.Trim(), pwd_pwd.Password);
                if (jsondata["error_description"] != null)
                {
                    CMessageBox.Show("账号验证失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                    //CMessageBox.Show("账号验证失败");
                    otherAccountToken = "";
                    return;
                }
                CMessageBox.Show("账号验证成功,您可以同步该账号的产品数据");
                otherAccountToken = jsondata["access_token"].ToString();
                cbo_Site.ItemsSource = new SiteCore().GetSiteList();
                cbo_Site.DisplayMemberPath = "ZhName";
                cbo_Site.SelectedValuePath = "ID";
                cbo_Site.IsEnabled = true;
                btn_search.IsEnabled = true;
            }
        }

        internal void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Search();
        }

        public void Search()
        {
            products.Clear();
            if (!chk_OtherUser.IsChecked ?? false)
            {
                otherAccountToken = GlobalUserClass.Access_Token;
            }
            var siteid = Convert.ToInt32(cbo_Site.SelectedValue);
            var pc = new ProductCore();
            var json = new HummingbirdCore().GetUploadProduct(otherAccountToken, siteid, txt_pidprefix.Text.Trim(), txt_TitleKey.Text.Trim(), vm.PageSize, vm.CurrentPage);
            var isNeedRepeat = chkNeedRepeat.IsChecked ?? false;
            if (json["success"] != null && Convert.ToBoolean(json["success"]))
            {
                vm.CountNumber = Convert.ToInt32(json["result"]["totalCount"]);
                JArray arr = (JArray)json["result"]["items"];
                foreach (var item in arr)
                {
                    SimpleProduct product = new SimpleProduct()
                    {
                        From = Convert.ToString(item["from"]),
                        LinkUrl = Convert.ToString(item["linkUrl"]),
                        MainSku = Convert.ToString(item["mainSku"]),
                        Price = Convert.ToString(item["price"]),
                        Title = Convert.ToString(item["title"]),
                        Weight = Convert.ToString(item["weight"]),
                        IsChecked = false,
                        Id = Convert.ToString(item["id"]),
                        IsExists = !pc.CheckLinkExists(Convert.ToString(item["linkUrl"])),
                        MainPicture = Convert.ToString(item["mainPicture"]),
                        CreationTime = Convert.ToDateTime(item["creationTime"]).ToString("yyyy-MM-dd"),
                    };
                    if (isNeedRepeat && product.IsExists)
                    {
                        vm.CountNumber--;
                        continue;
                    }
                    products.Add(product);
                }
            }
            lvShowProduct.ItemsSource = products;
            lbl_count.Content = $"共{products.Count()}个";
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog fbd = new System.Windows.Forms.FolderBrowserDialog();
            if (System.Windows.Forms.DialogResult.OK == fbd.ShowDialog())
            {
                txt_imagePath.Text = fbd.SelectedPath;
                this.Dispatcher.BeginInvoke(new Action(() => new GetLinkCore().UpdateImageSavePath(fbd.SelectedPath)));
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            if (isRun)
            {
                CMessageBox.Show("正在同步中，请稍后再试");
                return;
            }
            var list = products.Where(p => p.IsChecked);
            lbl_bar.Content = "0/" + list.Count();
            var add = Convert.ToInt32(Math.Ceiling(((decimal)100) / list.Count()));
            prgCollect_1.Value = 0;
            int index = 1;
            var hbc = new HummingbirdCore();
            var pc = new ProductCore();
            bool isDownImg = chk_DownImage.IsChecked ?? false;
            var priceTemplate = (PriceTemplateEntity)cbo_priceTemplate.SelectedItem;
            var ptc = new PriceTemplateCore();
            var cc = new CategoryCore();
            var siteId = Convert.ToInt32(cbo_Site.SelectedValue);
            Task.Run(() =>
            {
                foreach (var item in list)
                {
                    var json = hbc.GetProductDetail(otherAccountToken, item.Id);
                    if (Convert.ToBoolean(json["success"]))
                    {
                        Product product = JsonConvert.DeserializeObject<Product>(json["result"]["spuData"].ToString());
                        product.SiteID = GlobalUserClass.SiteId;
                        product.IsChecked = false;
                        var num = product.Number;
                        var skuNum = product.SKUNumber;

                        product.Number = pc.GetNextProductNumber();

                        ptc.CalcProductCost(priceTemplate, product, Convert.ToDouble(product.Porigprice));
                        //product.SKUNumber = pc.GetNextSKUNumberByIdprefix(product.Pidprefix);
                        if (product.SKUDetail != "")
                        {
                            JArray array = JsonConvert.DeserializeObject<JArray>(product.SKUDetail);
                            JArray newarray = new JArray();
                            if (array != null && array.Count > 0)
                            {
                                foreach (var child in array)
                                {
                                    var sku = JsonConvert.DeserializeObject<JObject>(child.ToString());
                                    sku["price"] = product.Lazadaprice;
                                    sku["special_price"] = product.Lazadapromprice;
                                    newarray.Add(sku);
                                }
                                product.SKUDetail = JsonConvert.SerializeObject(newarray);
                            }
                        }
                        product.Padddate = DateTime.Now.ToString();
                        product.ChildSku = "";
                        product.ServerID = "";
                        product.Pstate = "";
                        product.Pstatetype = "10";
                        product.Pcancsv = "";
                        product.Pjisangongshi = priceTemplate.Jname;
                        product.Pkuchen = priceTemplate.Jkuchen;
                        product.PackageLength = priceTemplate.Jpkglength;
                        product.PackageHight = priceTemplate.Jpkghight;
                        product.PackageWidth = priceTemplate.Jpkgwidth;
                        product.Lazadacategoryid = cc.ChangeSiteCategory(product.LazadaCategoryTreePath);
                        if (product.Lazadacategoryid == string.Empty)
                        {
                            product.SPUEditError += "类目转换错误";
                        }
                        if (pc.SaveOtherSiteProduct(product))
                        {
                            SystemSoleEntity.GetProductList().Insert(0, product);
                        }
                        if (isDownImg)
                        {
                            new DownImageCore().DownProductImage(product);
                        }
                    }
                    Thread.Sleep(200);
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        lbl_bar.Content = index + "/" + list.Count();
                        prgCollect_1.Value += add;
                        index++;
                    }));
                }
                isRun = false;
            });
        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            CalcDownCount();
        }

        private void CalcDownCount()
        {
            var count = products.Where(p => p.IsChecked).Count();
            lbl_chooseCount.Content = $"已选{count}个";
            if (count > 0)
            {
                btn_Down.IsEnabled = true;
                btn_Down.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1F9EFF"));
            }
            else
            {
                btn_Down.IsEnabled = false;
                btn_Down.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AAAAAA"));
            }
        }

        private void CheckBox_Unchecked_1(object sender, RoutedEventArgs e)
        {
            CalcDownCount();
        }

        private void AllCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            foreach (var item in products)
            {
                item.IsChecked = true;
            }
            CalcDownCount();
        }

        private void AllCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (var item in products)
            {
                item.IsChecked = false;
            }
            CalcDownCount();
        }
    }
}
