﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Link;
using Logic.PriceTemplate;
using Logic.SystemSole;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// NewTasks.xaml 的交互逻辑
    /// </summary>
    public partial class NewTasks : Window
    {
        /// <summary>
        /// 是否有批量任正在执行，不让同时执行多个批量任务
        /// </summary>
        private bool isBulking = false;
        NewTaskViewModel ownVM = null;

        /// <summary>
        /// 可以开始采集的链接列表
        /// </summary>
        private List<Product> canCollectList = new List<Product>();

        public NewTasks()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            ownVM = new NewTaskViewModel();
            this.DataContext = ownVM;
        }

        private void BtnAddUrl_Click(object sender, RoutedEventArgs e)
        {
            //判断当前是否有链接
            if (ownVM.Msg.Trim() == string.Empty)
            {
                return;
            }
            ////判断当前是否有任务
            //if (isBulking)
            //{
            //    CMessageBox.Show("当前有批量任正在执行，请稍后");
            //    return;
            //}
            //判断当前图片保存路径是否存在
            if (txtImgPath.Text.Trim() == string.Empty)
            {
                CMessageBox.Show("图片保存路径不能为空");
                return;
            }
            else
            {
                var str = new IOHelp().CheckDirectory(txtImgPath.Text);
                if (str.Length > 0)
                {
                    CMessageBox.Show(str);
                    return;
                }
            }
            //获取当前链接数量
            int count = ownVM.Msg.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries).Length;
            //判断剩余添加数是否足够
            if (count > Convert.ToInt32(new AmountCore().GetRemainAmount()))
            {
                CMessageBox.Show("添加数不足,添加失败.", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            //异步委托，进行添加
            //this.Dispatcher.BeginInvoke(new Action(() =>
            //{
            canCollectList.Clear();
            //canCollectList.AddRange(new GetLinkCore().AddNewLinks(txtUrlBox, (PriceTemplateEntity)cmbValuateMde.SelectedItem, chkRemove.IsChecked ?? false, txtImgPath.Text, ownVM));
            txtUrlBox.Foreground = new SolidColorBrush(Colors.DimGray);
            //GetMyBlance();
            //lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    lblLinkCount.Content = 0;
            //}));
            //if (canCollectList.Count > 0)
            //{
            //    txtUrlBox.Dispatcher.BeginInvoke(new Action(() =>
            //    {
            //        txtUrlBox.AppendText($"\n检查完毕... 共{canCollectList.Count} 条数据可以采集");
            //        new AmountCore().ReduceAmount();
            //    }));
            //    btnAddUrl.Visibility = Visibility.Hidden;
            //    btnCollect.Visibility = Visibility.Visible;
            //}
            //}));
            var links = ownVM.Msg.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries).ToList();
            bool checkRepeat = chkRemove.IsChecked ?? false;
            var pc = new ProductCore();
            var ftc = new FromTypeCore();
            var ac = new AmountCore();
            var priceTemplate = (PriceTemplateEntity)cmbValuateMde.SelectedItem;
            var imagePath = txtImgPath.Text;

            List<string> addLinks = new List<string>();
            List<Task> tasks = new List<Task>();
            var add = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(100) / links.Count));
            ownVM.Msg = "开始检查链接";
            Task.Run(() =>
            {
                ownVM.BarValue += 0;
                Thread.Sleep(200);
                for (int i = links.Count - 1; i >= 0; i--)
                {
                    ownVM.BarValue += add;
                    ownVM.BarContent = (links.Count - i) + "/" + links.Count;
                    Thread.Sleep(200);
                    //检查链接
                    var linkInfo = ftc.GetFromTypeByLink(links[i]);
                    if (linkInfo == null)
                    {
                        ownVM.Msg += $"\n{links[i]}链接未匹配到平台";
                        continue;
                    }
                    if (addLinks.Contains(linkInfo[1]) && checkRepeat)
                    {
                        ownVM.Msg += $"\n{links[i]}链接重复存在,需要重复添加,请去掉下方去重勾选";
                        continue;
                    }
                    if (!pc.CheckLinkExists(linkInfo[2]) && checkRepeat)
                    {
                        ownVM.Msg += $"\n{links[i]}链接重复存在,需要重复添加,请去掉下方去重勾选";
                        continue;
                    }
                    addLinks.Add(links[i]);
                    //Task task = new Task(() =>
                    //{
                    Product product = new Product()
                    {
                        SiteID = GlobalUserClass.SiteId,
                        Number = pc.GetNextProductNumber(),
                        Pfromtype = linkInfo[0],
                        Ppid = linkInfo[1],
                        Poriglink = linkInfo[2],
                        Pidprefix = priceTemplate.Jprfix,
                        Pjisangongshi = priceTemplate.Jname.ToString(),
                        Padddate = DateTime.Now.ToString(),
                        Pusername = GlobalUserClass.uname,
                        Pstate = "未采集",
                        Pstatetype = "0",
                        Lazadaisparent = "1",
                        Plocalimgpath = string.Format(imagePath + "\\" + linkInfo[0] + linkInfo[1]),
                        SKUNumber = pc.GetNextSKUNumberByIdprefix(priceTemplate.Jprfix),
                        Pkuchen = priceTemplate.Jkuchen,
                        PackageLength = priceTemplate.Jpkglength,
                        PackageHight = priceTemplate.Jpkghight,
                        PackageWidth = priceTemplate.Jpkgwidth,
                        Peditdate = DateTime.Now.ToString()
                    };
                    if (pc.AddProduct(product))
                    {
                        canCollectList.Insert(0, product);
                        SystemSoleEntity.GetProductList().Insert(0, product);
                        new AmountCore().ReduceAmount();
                    }
                    //    //else
                    //    //{
                    //    //    ownVM.Msg += $"\n {links[i]} 添加失败";
                    //    //}
                    //});
                    //task.Start();
                    //tasks.Add(task);
                }
                GetMyBlance();
                lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
                {
                    lblLinkCount.Content = 0;
                }));
                if (canCollectList.Count > 0)
                {
                    btnAddUrl.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        btnAddUrl.Visibility = Visibility.Hidden;
                        btnCollect.Visibility = Visibility.Visible;
                    }));
                }
            });
            //Task.WaitAll(tasks.ToArray());
            //Thread.Sleep(300 * links.Count);
            //foreach (var item in canCollectList)
            //{
            //SystemSoleEntity.GetProductList().Insert(0, item);
            //}
            //GetMyBlance();
            //lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    lblLinkCount.Content = 0;
            //}));
            //if (canCollectList.Count > 0)
            //{
            //    txtUrlBox.Dispatcher.BeginInvoke(new Action(() =>
            //    {
            //        txtUrlBox.AppendText($"\n检查完毕... 共{canCollectList.Count} 条数据可以采集");
            //        new AmountCore().ReduceAmount();
            //    }));

            //}

        }

        private void BtnCollect_Click(object sender, RoutedEventArgs e)
        {
            if (canCollectList.Count == 0)
            {
                CMessageBox.Show("当前没有可以采集的链接");
                return;
            }
            btnCollect.IsEnabled = false;
            SystemSoleEntity.GetMainWinModel().InitModel("新增采集", canCollectList.Count);
            bool isDownImg = chkDownImg.IsChecked ?? false;
            GlobalUserClass globalUser = new GlobalUserClass();
            globalUser.RefreshAli1688Token();
            Task.Run(() =>
            {
                foreach (var product in canCollectList)
                {
                    try
                    {
                        new GetLinkCore().DownProductInfo(product, isDownImg);
                    }
                    catch (Exception ex)
                    {
                        SystemSoleEntity.GetMainWinModel().IbulkErrowCount++;
                        new LogOutput.LogTo().WriteErrorLine("采集出错：" + product.Porigimgsurl + "///" + ex.Message);
                    }
                    SystemSoleEntity.GetMainWinModel().Ipbvalue += SystemSoleEntity.GetMainWinModel().TaskAdd;
                    SystemSoleEntity.GetMainWinModel().TaskRunCount++;
                }
            });
        }

        private void TxtImgPath_MouseLeave(object sender, MouseEventArgs e)
        {
            txtImgPath.Text = txtImgPath.Text[txtImgPath.Text.Length - 1] == '\\' ? txtImgPath.Text : (txtImgPath.Text + "\\");
        }

        private void BtnPath_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog fbd = new System.Windows.Forms.FolderBrowserDialog();
            if (System.Windows.Forms.DialogResult.OK == fbd.ShowDialog())
            {
                txtImgPath.Text = fbd.SelectedPath[fbd.SelectedPath.Length-1]=='\\'? fbd.SelectedPath:(fbd.SelectedPath+"\\");
                this.Dispatcher.BeginInvoke(new Action(() => new GetLinkCore().UpdateImageSavePath(fbd.SelectedPath)));
            }
        }

        private void ChkDownImg_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void ChkDownImg_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InitWin();
        }

        /// <summary>
        /// 加载窗体事件
        /// </summary>
        private void InitWin()
        {
            Task getPriceTemplateTask = new Task(GetPriceTemplates);
            getPriceTemplateTask.Start();
            Task getLinkTask = new Task(GetNewLinks);
            getLinkTask.Start();
            Task getPathTask = new Task(GetImageSavePath);
            getPathTask.Start();
            Task getBlanceTask = new Task(GetMyBlance);
            getBlanceTask.Start();
            this.txtUserName.Text = GlobalUserClass.uname;
        }

        /// <summary>
        /// 进行用户额度剩余值获取
        /// </summary>
        private void GetMyBlance()
        {
            lblAdd.Dispatcher.BeginInvoke(new Action(() =>
            {
                lblAdd.Content = string.Format($"剩余可采集链接数：{new AmountCore().GetRemainAmount()}条。");
            }));

        }

        /// <summary>
        /// 获取计价模板下拉框
        /// </summary>
        private void GetPriceTemplates()
        {
            var list = new PriceTemplateCore().GetPriceTemplateList();
            cmbValuateMde.Dispatcher.BeginInvoke(new Action(() =>
            {
                cmbValuateMde.ItemsSource = list;
                cmbValuateMde.DisplayMemberPath = "Jname";
                cmbValuateMde.SelectedValuePath = "Jnumber";
                cmbValuateMde.SelectedIndex = 0;
            }));
        }

        /// <summary>
        /// 获取图片保存地址
        /// </summary>
        private void GetImageSavePath()
        {
            txtImgPath.Dispatcher.BeginInvoke(new Action(() =>
            {
                txtImgPath.Text = new GetLinkCore().GetImageSavePath();
            }));
        }

        /// <summary>
        /// 通过接口，获取新增的链接
        /// </summary>
        private void GetNewLinks()
        {
            //var glc = new GetLinkCore();
            //var getLinkRep = glc.GetNewLinks();
            //if (getLinkRep == null) return;
            //if (getLinkRep.raction != "succeed")
            //{
            //    CMessageBox.Show("获取链接失败");
            //    return;
            //}
            //else
            //{
            //    Task task = new Task(new Action(() => glc.SaveLinks(getLinkRep.links)));
            //    task.Start();
            //    if (getLinkRep.links.Count > 0)
            //    {
            //        var shd = glc.SetHaveDown(getLinkRep.endpos);
            //        if (getLinkRep.raction != "succeed")
            //        {
            //            new LogOutput.LogTo().WriteErrorLine("刷新链接失败");
            //        }
            //    }
            //}
            //lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    lblLinkCount.Content = getLinkRep.links.Count;
            //}));
            //txtUrlBox.Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    foreach (var item in getLinkRep.links)
            //        txtUrlBox.AppendText(item + "\n");
            //}));


        }
    }
}
