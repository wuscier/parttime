﻿using Logic.Author;
using Logic.SiteChange;
using LogOutput;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Author;
using PublicFunction.Entity.ResponseModel;
using PublicFunction.SiteImgRequestHelp;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static LAZADA.GlobalUserClass;

namespace LAZADA.ChangeSite
{
    
    /// <summary>
    /// ChioceSites.xaml 的交互逻辑
    /// </summary>
    public partial class ChioceSites : Window
    {
        /// <summary>
        /// 创建用户信息对象和站点授权对象
        /// </summary>
        private SiteAuthor SiteAuthor = new SiteAuthor();
        private GlobalUserClass GlobalUser = new GlobalUserClass();
        private MainWindow main = new MainWindow();
        /// <summary>
        /// 选择站点
        /// </summary>
        public ChioceSites()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            #region 初始显示该用户开通哪些站点(需完善)
            //账户站点信息集合
            List<int> reglist = OpenedRegionsItem.regions;
            //遍历用户的站点信息集合，判断哪个站点开通了
            foreach (var item in reglist)
            {
                switch (item)
                {
                    case 1:
                        SGICO.Visibility = Visibility.Visible;
                        break;
                    case 2:
                        THICO.Visibility = Visibility.Visible;
                        break;
                    case 3:
                        MYICO.Visibility = Visibility.Visible;
                        break;
                    case 4:
                        VNICO.Visibility = Visibility.Visible;
                        break;
                    case 5:
                        PHICO.Visibility = Visibility.Visible;
                        break;
                    case 6:
                        IDICO.Visibility = Visibility.Visible;
                        break;
                    case 9:
                        CRBICO.Visibility = Visibility.Visible;
                        THICO.Visibility = Visibility.Visible;
                        SGICO.Visibility = Visibility.Visible;
                        MYICO.Visibility = Visibility.Visible;
                        VNICO.Visibility = Visibility.Visible;
                        PHICO.Visibility = Visibility.Visible;
                        IDICO.Visibility = Visibility.Visible;
                        break;
                    default:
                        break;
                }
            }
            #endregion
            #region 显示初始站点使用期限是否过期
            //遍历用户个人信息中的站点使用期限
            string dt = GlobalUserClass.GetTime(Access_Token);
            DateTime now = Convert.ToDateTime(dt.Replace("\"", string.Empty));
            //foreach (var item in SiteExpriateTime)
            //{
            //    //指定lazada的
            //    if (OpenedRegionsItem.siteType == (int)WebSiteType.Lazada)
            //    {
            //        //匹配对应站点，判断该站点是否过期
            //        for (int i = 0; i < reglist.Count; i++)
            //        {
            //            switch (i)
            //            {
            //                case 1:
            //                    if (DateTime.Compare(now, item.Value) > 0)
            //                    {
            //                        lblSGIsAuth.Content = "已过期";//新加坡SG 1
            //                        lblSGIsAuth.Foreground = new SolidColorBrush(Colors.Red);
            //                    }
            //                    break;
            //                case 2:
            //                    if (DateTime.Compare(now, item.Value) > 0)
            //                    {
            //                        lblTHIsAuth.Content = "已过期";//泰国VN 2
            //                        lblTHIsAuth.Foreground = new SolidColorBrush(Colors.Red);
            //                    }
            //                    break;
            //                case 3:
            //                    if (DateTime.Compare(now, item.Value) > 0)
            //                    {
            //                        lblMYIsAuth.Content = "已过期";//马来西亚MY 3
            //                        lblMYIsAuth.Foreground = new SolidColorBrush(Colors.Red);
            //                    }
            //                    break;
            //                case 4:
            //                    if (DateTime.Compare(now, item.Value) > 0)
            //                    {
            //                        lblVNIsAuth.Content = "已过期";//越南VN 4
            //                        lblVNIsAuth.Foreground = new SolidColorBrush(Colors.Red);
            //                    }
            //                    break;
            //                case 5:
            //                    if (DateTime.Compare(now, item.Value) > 0)
            //                    {
            //                        lblPHIsAuth.Content = "已过期";//菲律宾PH 5
            //                        lblPHIsAuth.Foreground = new SolidColorBrush(Colors.Red);
            //                    }
            //                    break;
            //                case 6:
            //                    if (DateTime.Compare(now, item.Value) > 0)
            //                    {
            //                        lblIDIsAuth.Content = "已过期";//印尼ID 6
            //                        lblIDIsAuth.Foreground = new SolidColorBrush(Colors.Red);
            //                    }
            //                    break;
            //                case 9:
            //                    if (DateTime.Compare(now, item.Value) > 0)
            //                    {
            //                        lblCrbIsAuth.Content = "已过期";//六合一Crb 9
            //                        lblCrbIsAuth.Foreground = new SolidColorBrush(Colors.Red);
            //                    }
            //                    break;
            //                default:
            //                    break;
            //            }
            //        }
            //    }
            //}
            #endregion
            switch (SiteName)
            {
                case "马来西亚":
                    this.lblMY.Foreground = new SolidColorBrush(Color.FromRgb(255,255,255));
                    this.btnMYAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "泰国":
                    this.lblTH.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnTHAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "印度尼西亚":
                    this.lblID.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnIDAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "菲律宾":
                    this.lblPH.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnPHAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "新加坡":
                    this.lblSG.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnSGAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "越南":
                    this.lblVN.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnVNAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "六合一":
                    this.lblCrb.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnCrossAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                default:
                    break;
            }
        }
        My1688Collect my1688 = new My1688Collect();
        /// <summary>
        /// 获取网络日期时间
        /// </summary>
        /// <returns></returns>
        public static string GetNetDateTime()
        {
            WebRequest request = null;
            WebResponse response = null;
            WebHeaderCollection headerCollection = null;
            string datetime = string.Empty;
            try
            {
                request = WebRequest.Create("https://www.baidu.com");
                request.Timeout = 3000;
                request.Credentials = CredentialCache.DefaultCredentials;
                response = (WebResponse)request.GetResponse();
                headerCollection = response.Headers;
                foreach (var h in headerCollection.AllKeys)
                { if (h == "Date") { datetime = headerCollection[h]; } }
                return datetime;
            }
            catch (Exception) { return datetime; }
            finally
            {
                if (request != null)
                { request.Abort(); }
                if (response != null)
                { response.Close(); }
                if (headerCollection != null)
                { headerCollection.Clear(); }
            }
        }

        public static void GetThreadNum()
        {
            Process current = Process.GetCurrentProcess();
            ProcessThreadCollection allThreads = current.Threads;
            if (Thread.CurrentThread.ManagedThreadId > 2)
            {
                ChangeSta changeSta = new ChangeSta();
                changeSta.ShowDialog();
            }
        }

        /// <summary>
        /// 马来站点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnMYAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Malaysia;
            new LogTo().WriteLine("站点ID:" + GlobalUserClass.SiteId);
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Malaysia))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        this.Close();
                    }
                    else
                    {
                        //站点名称
                        GlobalUserClass.SiteName = lblMYName.Content.ToString();
                        new ChangeSites().CloseWindow(this);
                    }

                    #endregion
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                MessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件");
                Thread.Sleep(3000);
                Process.Start("http://91lazada.com/" + "download1");
                this.Close();
                #endregion
            }
            #endregion
        }

        /// <summary>
        /// 菲律宾站点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnPHAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Philippines;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(GlobalUserClass.Region.Philippines))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        this.Close();
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblPHImg.Content.ToString();
                        new ChangeSites().CloseWindow(this);
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion
            }
            else
            {
                #region 未开通联系客服开通
                MessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件");
                Thread.Sleep(3000);
                Process.Start("http://91lazada.com/" + "download1");
                this.Close();
                #endregion
            }
            #endregion
        }

        /// <summary>
        /// 泰国站点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnTHAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Thailand;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Thailand))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        this.Close();
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblTHImg.Content.ToString();
                        new ChangeSites().CloseWindow(this);

                    }
                    #endregion

                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                MessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件");
                Thread.Sleep(3000);
                Process.Start("http://91lazada.com/" + "download1");
                this.Close();
                #endregion
            }

            #endregion
        }

        /// <summary>
        /// 新加坡
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSGAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Singapore;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Singapore))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        this.Close();
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblSGImg.Content.ToString();

                        new ChangeSites().CloseWindow(this);
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                MessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件");
                Thread.Sleep(3000);
                Process.Start("http://91lazada.com/" + "download1");
                this.Close();
                #endregion
            }


            #endregion
        }

        /// <summary>
        /// 印尼
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnIDAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Indonesia;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Indonesia))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        this.Close();
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblIDImg.Content.ToString();

                        new ChangeSites().CloseWindow(this);
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {

                #region 未开通联系客服开通
                MessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件");
                Thread.Sleep(3000);
                Process.Start("http://91lazada.com/" + "download1");
                this.Close();
                #endregion
            }

            #endregion
        }

        /// <summary>
        /// 越南
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnVNAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Vietnam;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Vietnam)|| SiteAuthor.SiteAuthors(Region.CrossBorder))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        this.Close();
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblVNImg.Content.ToString();

                        new ChangeSites().CloseWindow(this);
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                MessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件");
                Thread.Sleep(3000);
                Process.Start("http://91lazada.com/" + "download1");
                this.Close();
                #endregion
            }
            #endregion
        }

        /// <summary>
        /// 六合一
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCrossAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.CrossBorder;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.CrossBorder)||
                ( SiteAuthor.SiteAuthors(Region.Vietnam)&& SiteAuthor.SiteAuthors(Region.Indonesia)
                && SiteAuthor.SiteAuthors(Region.Malaysia) && SiteAuthor.SiteAuthors(Region.Philippines) && SiteAuthor.SiteAuthors(Region.Singapore) && SiteAuthor.SiteAuthors(Region.Thailand)))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        this.Close();
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblCrbImg.Content.ToString();

                        new ChangeSites().CloseWindow(this);
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                MessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件");
                Thread.Sleep(3000);
                Process.Start("http://91lazada.com/" + "download1");
                this.Close();
                #endregion
            }
            #endregion
        }

        private void Btnsiteclose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Rectangle1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
