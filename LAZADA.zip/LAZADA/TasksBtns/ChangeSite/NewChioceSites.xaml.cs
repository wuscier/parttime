﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.Author;
using Logic.SiteChange;
using Logic.SystemSole;
using LogOutput;
using PublicFunction.Author;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static LAZADA.GlobalUserClass;

namespace LAZADA.TasksBtns.ChangeSite
{
    /// <summary>
    /// NewChioceSites.xaml 的交互逻辑
    /// </summary>
    public partial class NewChioceSites : UserControl
    {
        /// <summary>
        /// 创建用户信息对象和站点授权对象
        /// </summary>
        private SiteAuthor SiteAuthor = new SiteAuthor();
        private GlobalUserClass GlobalUser = new GlobalUserClass();
        private PagingViewModel vm = new PagingViewModel();
        My1688Collect my1688 = new My1688Collect();
        public NewChioceSites()
        {
            InitializeComponent();
            #region 初始显示该用户开通哪些站点(需完善)
            //账户站点信息集合
            List<int> reglist = OpenedRegionsItem.regions;
            //遍历用户的站点信息集合，判断哪个站点开通了

            #endregion
            #region 显示初始站点使用期限是否过期
            //遍历用户个人信息中的站点使用期限
            int a = 0;
            Dictionary<int, DateTime> keyValuePairs = new Dictionary<int, DateTime>();
            int i = 0;
            keyValuePairs = SiteExpriateTime;
            foreach (var item in keyValuePairs)
            {
                //指定lazada的

                if (item.Key == 9)
                {
                    CRBICO.Visibility = Visibility.Visible;
                    SGICO.Visibility = Visibility.Visible;
                    THICO.Visibility = Visibility.Visible;
                    MYICO.Visibility = Visibility.Visible;
                    VNICO.Visibility = Visibility.Visible;
                    PHICO.Visibility = Visibility.Visible;
                    IDICO.Visibility = Visibility.Visible;
                    break;
                }
                else
                {
                    //匹配对应站点，判断该站点是否过期
                    switch (item.Key)
                    {
                        case 1:
                            SGICO.Visibility = Visibility.Visible;
                            i++;
                            break;
                        case 2:
                            THICO.Visibility = Visibility.Visible;
                            i++;
                            break;
                        case 3:
                            MYICO.Visibility = Visibility.Visible;
                            i++;
                            break;
                        case 4:
                            VNICO.Visibility = Visibility.Visible;
                            i++;
                            break;
                        case 5:
                            PHICO.Visibility = Visibility.Visible;
                            i++;
                            break;
                        case 6:
                            IDICO.Visibility = Visibility.Visible;
                            i++;
                            break;
                    }
                }
            }
            if (i == 6)
            {
                CRBICO.Visibility = Visibility.Visible;
            }
            #endregion
            switch (SiteName)
            {
                case "马来西亚":
                    this.lblMY.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnMYAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "泰国":
                    this.lblTH.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnTHAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "印度尼西亚":
                    this.lblID.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnIDAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "菲律宾":
                    this.lblPH.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnPHAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "新加坡":
                    this.lblSG.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnSGAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "越南":
                    this.lblVN.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnVNAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                case "六合一":
                    this.lblCrb.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
                    this.btnCrossAuthor.Background = new SolidColorBrush(Color.FromRgb(52, 159, 252));
                    break;
                default:
                    break;
            }
        }
        /// <summary>
        /// 获取网络日期时间
        /// </summary>
        /// <returns></returns>
        public static string GetNetDateTime()
        {
            WebRequest request = null;
            WebResponse response = null;
            WebHeaderCollection headerCollection = null;
            string datetime = string.Empty;
            try
            {
                request = WebRequest.Create("https://www.baidu.com");
                request.Timeout = 3000;
                request.Credentials = CredentialCache.DefaultCredentials;
                response = (WebResponse)request.GetResponse();
                headerCollection = response.Headers;
                foreach (var h in headerCollection.AllKeys)
                { if (h == "Date") { datetime = headerCollection[h]; } }
                return datetime;
            }
            catch (Exception) { return datetime; }
            finally
            {
                if (request != null)
                { request.Abort(); }
                if (response != null)
                { response.Close(); }
                if (headerCollection != null)
                { headerCollection.Clear(); }
            }
        }

        public static void GetThreadNum()
        {
            Process current = Process.GetCurrentProcess();
            ProcessThreadCollection allThreads = current.Threads;
            if (Thread.CurrentThread.ManagedThreadId > 2)
            {
                ChangeSta changeSta = new ChangeSta();
                changeSta.ShowDialog();
            }
        }

        /// <summary>
        /// 马来站点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnMYAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Malaysia;
            new LogTo().WriteLine("站点ID:" + GlobalUserClass.SiteId);
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Malaysia))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        CMessageBox.Show("此站点已过期，请联系客服续费\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                    }
                    else
                    {
                        //站点名称
                        GlobalUserClass.SiteName = lblMYName.Content.ToString();
                        SystemSoleEntity.LoadProductList(vm);
                        Task.Run(() =>
                        {
                            GlobalUser.Ref_lazadaToken(SiteId);
                        });
                        
                        Window window = Window.GetWindow(this);
                        window.Close();
                    }

                    #endregion
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                CMessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                //Thread.Sleep(2000);
                //Process.Start("http://91lazada.com/" + "download1");

                #endregion
            }
            #endregion
        }

        /// <summary>
        /// 菲律宾站点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnPHAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Philippines;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(GlobalUserClass.Region.Philippines))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        CMessageBox.Show("此站点已过期，请联系客服续费\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblPHImg.Content.ToString();
                        SystemSoleEntity.LoadProductList(vm);
                        Task.Run(() =>
                        {
                            GlobalUser.Ref_lazadaToken(SiteId);
                        });
                        Window window = Window.GetWindow(this);
                        window.Close();
                    }
                    #endregion
                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion
            }
            else
            {
                #region 未开通联系客服开通
                CMessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                //Thread.Sleep(2000);
                //Process.Start("http://91lazada.com/" + "download1");

                #endregion
            }
            #endregion
        }

        /// <summary>
        /// 泰国站点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnTHAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Thailand;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Thailand))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        CMessageBox.Show("此站点已过期，请联系客服续费\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");

                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblTHImg.Content.ToString();
                        Task.Run(() =>
                        {
                            GlobalUser.Ref_lazadaToken(SiteId);
                        });
                        SystemSoleEntity.LoadProductList(vm);
                        Window window = Window.GetWindow(this);
                        window.Close();

                    }
                    #endregion

                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                CMessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                //Thread.Sleep(2000);
                //Process.Start("http://91lazada.com/" + "download1");
                #endregion
            }

            #endregion
        }

        /// <summary>
        /// 新加坡
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSGAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Singapore;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Singapore))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        CMessageBox.Show("此站点已过期，请联系客服续费\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblSGImg.Content.ToString();
                        Task.Run(() =>
                        {
                            GlobalUser.Ref_lazadaToken(SiteId);
                        });
                        SystemSoleEntity.LoadProductList(vm);
                        Window window = Window.GetWindow(this);
                        window.Close();
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                CMessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                //Thread.Sleep(2000);
                //Process.Start("http://91lazada.com/" + "download1");

                #endregion
            }


            #endregion
        }

        /// <summary>
        /// 印尼
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnIDAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Indonesia;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Indonesia))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        CMessageBox.Show("此站点已过期，请联系客服续费\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblIDImg.Content.ToString();
                        Task.Run(() =>
                        {
                            GlobalUser.Ref_lazadaToken(SiteId);
                        });
                        SystemSoleEntity.LoadProductList(vm);
                        Window window = Window.GetWindow(this);
                        window.Close();
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {

                #region 未开通联系客服开通
                CMessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                //Thread.Sleep(2000);
                //Process.Start("http://91lazada.com/" + "download1");

                #endregion
            }

            #endregion
        }

        /// <summary>
        /// 越南
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnVNAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.Vietnam;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.Vietnam))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SiteAuthor.Expriation(SiteId))
                    {
                        CMessageBox.Show("此站点已过期，请联系客服续费\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                    }
                    else
                    {
                        GlobalUserClass.SiteName = lblVNImg.Content.ToString();
                        Task.Run(() =>
                        {
                            GlobalUser.Ref_lazadaToken(SiteId);
                        });
                        SystemSoleEntity.LoadProductList(vm);
                        Window window = Window.GetWindow(this);
                        window.Close();
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                CMessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                //Thread.Sleep(2000);
                //Process.Start("http://91lazada.com/" + "download1");

                #endregion
            }
            #endregion
        }

        /// <summary>
        /// 六合一
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCrossAuthor_MouseDown(object sender, MouseButtonEventArgs e)
        {
            #region 确定选中的站点
            GlobalUserClass.SiteId = (int)Region.CrossBorder;
            #endregion
            #region 获取1688的access_token
            //GlobalUser.RefreshAli1688Token();
            #endregion
            #region 判断lazada的access_token是否过期，过期就提示重新去授权并重启软件

            #endregion
            #region 获取lazada授权的access_token
            GlobalUser.GETLAZADATOKEN(SiteId);
            #endregion
            #region 判断所选站点是否开通、过期
            if (SiteAuthor.SiteAuthors(Region.CrossBorder) ||
                (SiteAuthor.SiteAuthors(Region.Malaysia)
                && SiteAuthor.SiteAuthors(Region.Indonesia)
                && SiteAuthor.SiteAuthors(Region.Philippines)
                && SiteAuthor.SiteAuthors(Region.Thailand)
                && SiteAuthor.SiteAuthors(Region.Singapore)
                && SiteAuthor.SiteAuthors(Region.Vietnam)))
            {
                #region 已开通
                try
                {
                    #region 已激活
                    if (SGICO.Visibility == Visibility.Visible &&
                    THICO.Visibility == Visibility.Visible &&
                    MYICO.Visibility == Visibility.Visible &&
                    VNICO.Visibility == Visibility.Visible &&
                    PHICO.Visibility == Visibility.Visible &&
                    IDICO.Visibility == Visibility.Visible)
                    {
                        GlobalUserClass.SiteName = lblCrbImg.Content.ToString();
                        Task.Run(() =>
                        {
                            GlobalUser.Ref_lazadaToken(SiteId);
                        });
                        SystemSoleEntity.LoadProductList(vm);
                        Window window = Window.GetWindow(this);
                        window.Close();
                    }
                    else
                    {
                        if (SiteAuthor.Expriation(SiteId))
                        {
                            CMessageBox.Show("此站点已过期，请联系客服续费\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                        }
                        else
                        {
                            GlobalUserClass.SiteName = lblCrbImg.Content.ToString();
                            Task.Run(() =>
                            {
                                GlobalUser.Ref_lazadaToken(SiteId);
                            });
                            SystemSoleEntity.LoadProductList(vm);
                            Window window = Window.GetWindow(this);
                            window.Close();
                        }
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.Message);
                }
                #endregion

            }
            else
            {
                #region 未开通联系客服开通
                CMessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件\r\n客服QQ:\r        [蜂鸟安安：634076006]\r        [蜂鸟静静：630799166]");
                //MessageBox.Show("此站点未开通，请联系客服开通并在开通后重启软件");

                //Thread.Sleep(2000);
                //Process.Start("http://91lazada.com/" + "download1");
                #endregion
            }
            #endregion
        }


    }
}
