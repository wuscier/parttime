﻿using PublicFunction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// BaicWindow.xaml 的交互逻辑
    /// </summary>
    public partial class BaicWindow : Window
    {
        public BaicWindow()
        {
            InitializeComponent();
        }
        public BaicWindow(int Width, int Height,UserControl control,string WinName)
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            this.Width = Width;
            this.Height = Height;
            this.top.Width = Width - 2;
            this.ContentBody.Content = control;
            this.lbl.Content = WinName;
            this.Title = WinName;
        }
        public BaicWindow(int Width, int Height, Window control, string WinName)
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            this.Width = Width;
            this.Height = Height;
            this.top.Width = Width - 2;
            this.ContentBody.Content = control;
            this.lbl.Content = WinName;
        }
        private void CloseWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void Top_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }

    public class BaseWindow : BaicWindow
    {
        public BaseWindow() : base()
        {
            this.Closed += Window_Closed;
            this.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            this.ResizeMode = ResizeMode.NoResize;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Grid grid = this.Owner.Content as Grid;
            UIElement original = VisualTreeHelper.GetChild(grid, 0) as UIElement;
            grid.Children.Remove(original);
            this.Owner.Content = original;
        }
        /// <summary>
        /// 显示遮罩
        /// </summary>
        /// <param name="owner">遮罩的父容器</param>
        /// <param name="Width">窗体宽</param>
        /// <param name="Height">窗体高</param>
        /// <param name="control">base窗体的子容器</param>
        /// <param name="WinName">窗体标题</param>
        /// <returns></returns>
        public bool? Show(Window owner,int Width, int Height, UserControl control, string WinName)
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            this.Width = Width;
            this.Height = Height;
            this.top.Width = Width - 2;
            this.ContentBody.Content = control;
            this.lbl.Content = WinName;
            this.Title = WinName;
            Grid layer = new Grid() { Background = new SolidColorBrush(Color.FromArgb(128, 0, 0, 0)) };
            UIElement original = owner.Content as UIElement;
            owner.Content = null;
            Grid container = new Grid();
            container.Children.Add(original);
            container.Children.Add(layer);
            Image image = new Image();
            BitmapImage bitmap = new BitmapImage(new Uri("Images/加载.png", UriKind.RelativeOrAbsolute));
            image.Width = 50;
            image.Source = bitmap;
            Application.Current.Dispatcher.Invoke(new Action(() =>
            {
                PublicFunctions publicFunction = new PublicFunctions();
                TimeSpan ts1 = new TimeSpan(0, 0, 0, 30, 0);
                publicFunction.AngleEasingAnimationShow(image, 0, 360, 3, ts1);
            }));
            container.Children.Add(image);
            owner.Content = container;
            this.Owner = owner;
            return this.ShowDialog();
        }
        /// <summary>
        /// 显示遮罩
        /// </summary>
        /// <param name="owner">遮罩的父容器</param>
        public bool? Show(Window owner)
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            this.Width = Width;
            this.Height = Height;
            this.top.Width = Width - 2;
            Grid layer = new Grid() { Background = new SolidColorBrush(Color.FromArgb(128, 0, 0, 0)) };
            UIElement original = owner.Content as UIElement;
            owner.Content = null;
            Grid container = new Grid();
            container.Children.Add(original);
            container.Children.Add(layer);
            Image image = new Image();
            BitmapImage bitmap = new BitmapImage(new Uri("Images/加载.png", UriKind.RelativeOrAbsolute));
            image.Width = 50;
            image.Source = bitmap;
            Application.Current.Dispatcher.Invoke(new Action(() =>
            {
                PublicFunctions publicFunction = new PublicFunctions();
                TimeSpan ts1 = new TimeSpan(0, 0, 0, 30, 0);
                publicFunction.AngleEasingAnimationShow(image, 0, 360, 3, ts1);
            }));
            container.Children.Add(image);
            owner.Content = container;
            this.Owner = owner;
            return this.ShowDialog();
        }
        //private void SetWindowNoBorder()
        //{
        //    Window win = Window.GetWindow(this);
        //    // 获取窗体句柄 
        //    IntPtr hwnd = new System.Windows.Interop.WindowInteropHelper(win).Handle;

        //    // 获得窗体的 样式 
        //    long oldstyle = Win32.GetWindowLong(hwnd, Win32.GWL_STYLE);

        //    // 更改窗体的样式为无边框窗体 
        //   Win32.SetWindowLong(hwnd, Win32.GWL_STYLE, (int)(oldstyle & ~Win32.WS_CAPTION));
        //}
    }
    //public class Win32
    //{
    //    [StructLayout(LayoutKind.Sequential)]
    //    public struct POINT
    //    {
    //        public int X;
    //        public int Y;

    //        public POINT(int x, int y)
    //        {
    //            this.X = x;
    //            this.Y = y;
    //        }
    //    }


    //    /// <summary>  
    //    /// 带有外边框和标题的windows的样式  
    //    /// </summary>  
    //    public const long WS_CAPTION = 0X00C0000L;

    //    /// <summary>  
    //    /// window的基本样式  
    //    /// </summary>  
    //    public static int GWL_STYLE = -16;
    //    /// <summary>  
    //    /// window的扩展样式  
    //    /// </summary>  
    //    public static int GWL_EXSTYLE = -20;

    //    public static Int32 WS_EX_LAYERED = 0x00080000;
    //    public static Int32 WS_EX_TRANSPARENT = 0x00000020;

    //    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    //    public static extern bool GetCursorPos(out POINT pt);

    //    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    //    public static extern Int32 GetWindowLong(IntPtr hWnd, Int32 nIndex);

    //    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    //    public static extern Int32 SetWindowLong(IntPtr hWnd, Int32 nIndex, int newVal);

    //    [DllImport("gdi32")]
    //    public static extern int DeleteObject(IntPtr obj);
    //}
    public class CustomWindow : Window
    {
        public CustomWindow()
        {
            DefaultStyleKey = typeof(CustomWindow);
            CommandBindings.Add(new CommandBinding(SystemCommands.CloseWindowCommand, CloseWindow));
            CommandBindings.Add(new CommandBinding(SystemCommands.MaximizeWindowCommand, MaximizeWindow, CanResizeWindow));
            CommandBindings.Add(new CommandBinding(SystemCommands.MinimizeWindowCommand, MinimizeWindow, CanMinimizeWindow));
            CommandBindings.Add(new CommandBinding(SystemCommands.RestoreWindowCommand, RestoreWindow, CanResizeWindow));
            CommandBindings.Add(new CommandBinding(SystemCommands.ShowSystemMenuCommand, ShowSystemMenu));
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            if (e.ButtonState == MouseButtonState.Pressed)
                DragMove();
        }

        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);
            if (SizeToContent == SizeToContent.WidthAndHeight)
                InvalidateMeasure();
        }

        #region Window Commands

        private void CanResizeWindow(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ResizeMode == ResizeMode.CanResize || ResizeMode == ResizeMode.CanResizeWithGrip;
        }

        private void CanMinimizeWindow(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ResizeMode != ResizeMode.NoResize;
        }

        private void CloseWindow(object sender, ExecutedRoutedEventArgs e)
        {
            this.Close();
            //SystemCommands.CloseWindow(this);
        }

        private void MaximizeWindow(object sender, ExecutedRoutedEventArgs e)
        {
            SystemCommands.MaximizeWindow(this);
        }

        private void MinimizeWindow(object sender, ExecutedRoutedEventArgs e)
        {
            SystemCommands.MinimizeWindow(this);
        }

        private void RestoreWindow(object sender, ExecutedRoutedEventArgs e)
        {
            SystemCommands.RestoreWindow(this);
        }


        private void ShowSystemMenu(object sender, ExecutedRoutedEventArgs e)
        {
            var element = e.OriginalSource as FrameworkElement;
            if (element == null)
                return;

            var point = WindowState == WindowState.Maximized ? new Point(0, element.ActualHeight)
                : new Point(Left + BorderThickness.Left, element.ActualHeight + Top + BorderThickness.Top);
            point = element.TransformToAncestor(this).Transform(point);
            SystemCommands.ShowSystemMenu(this, point);
        }

        #endregion
    }
}
