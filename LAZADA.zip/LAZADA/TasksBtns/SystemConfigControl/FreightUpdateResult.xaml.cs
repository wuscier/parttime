﻿using Logic.BasicInfo;
using PublicFunction.Entity.BaseEntity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.SystemConfigControl
{
    /// <summary>
    /// FreightUpdateResult.xaml 的交互逻辑
    /// </summary>
    public partial class FreightUpdateResult : Window
    {
        public bool isFinish = false;
        FreightUpdateResultModel vm = new FreightUpdateResultModel();
        public FreightUpdateResult()
        {
            InitializeComponent();
            this.DataContext = vm;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Task.Run(() =>
            {
                try
                {
                    new SystemConfigCore().UpdateAllFreight();
                    isFinish = true;
                }
                catch
                {

                } while (vm.Ipbvalue < 100)
                {
                    vm.Ipbvalue += 1;
                    Thread.Sleep(100);
                }
                this.Dispatcher.BeginInvoke(new Action(() => this.Close()));
            });
        }


    }

    public class FreightUpdateResultModel : BaseViewModel
    {
        private int _Ipbvalue;

        public int Ipbvalue
        {
            get => _Ipbvalue;
            set
            {
                if (_Ipbvalue != value)
                {
                    _Ipbvalue = value;
                    base.RaisePropertyChanged("Ipbvalue");
                }
            }
        }
    }
}
