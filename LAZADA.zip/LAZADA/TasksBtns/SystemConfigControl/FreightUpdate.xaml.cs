﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.SystemConfigControl
{
    /// <summary>
    /// FreightUpdate.xaml 的交互逻辑
    /// </summary>
    public partial class FreightUpdate : Window
    {
        public FreightUpdate()
        {
            InitializeComponent();
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            if (isNoticedMe.IsChecked == true)
            {
                new SystemConfigCore().SetNoNoticedMe();
            }
            else
            {
                new SystemConfigCore().SetNeedNoticedMe();
            }
            this.Close();
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            FreightUpdateResult result = new FreightUpdateResult();
            result.ShowDialog();
            if(result.isFinish)
            {
                CMessageBox.Show("更新成功");
                this.Close();
            }
            else
            {
                CMessageBox.Show("更新失败,请联系客服");
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (!new SystemConfigCore().IsNeedToShow())
            {
                this.Close();
            }
        }
    }
}
