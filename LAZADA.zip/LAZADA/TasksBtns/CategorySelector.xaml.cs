﻿using Logic.BasicInfo;
using Logic.Platform;
using Logic.Translation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// CategorySelector.xaml 的交互逻辑
    /// </summary>
    public partial class CategorySelector : UserControl
    {
        private PublicFunctions publicFunctions = new PublicFunctions();
        #region 给用户控件注册类目变革时间，已通知主窗体

        public static readonly RoutedEvent CategoryChangedEvent = EventManager.RegisterRoutedEvent("CategoryChanged", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(CategorySelector));

        public event RoutedEventHandler CategoryChanged
        {
            add { AddHandler(CategoryChangedEvent, value); }
            remove { RemoveHandler(CategoryChangedEvent, value); }


        }

        #endregion

        #region 让SPU编辑控件调取的，当前所选择的类目信息

        public string leafId = "";
        public string idPath = "";
        public string namePath = "";
        public string treePath = "";

        #endregion


        List<LeafNode> nodeList = new List<LeafNode>();
        List<LeafNode> historyList = new List<LeafNode>();
        bool fyflag = false;
        JArray categoryArr = null;
        public CategorySelector()
        {
            InitializeComponent();
            //Task.Run(() => Init());
        }

        private void Init()
        {

            this.Dispatcher.BeginInvoke(new Action(() =>
            {
                try
                {
                    JObject jobject = new LazadaCore().GetCategoryTree();
                    categoryArr = (JArray)jobject["data"];
                    lstFirst.Items.Clear();
                    var cc = new CategoryCore();
                    for (int i = 0; i < categoryArr.Count; i++)
                    {
                        JObject aCateg = (JObject)categoryArr[i];
                        if (aCateg["name"] != null && aCateg["category_id"]  != null && !(!(bool)aCateg["leaf"] && !aCateg["children"].HasValues))
                        {
                            if (aCateg["pnamepath"] == null) aCateg["pnamepath"] = aCateg["name"].ToString();
                            if (aCateg["chinesename"] == null)
                            {
                                var ch_name = cc.GetChineseName(aCateg["name"].ToString());
                                aCateg["chinesename"] = ch_name == string.Empty ? cc.GetChineseName(aCateg["name"].ToString()) : ch_name;
                            }

                            if (aCateg["pchinesenamepath"] == null) aCateg["pchinesenamepath"] = aCateg["chinesename"].ToString();
                            if (aCateg["pidpath"] == null) aCateg["pidpath"] = aCateg["category_id"].ToString();

                            ListBoxItem oneItem = new ListBoxItem
                            {
                                DataContext = aCateg,
                                Content = (fyflag ? aCateg["chinesename"].ToString() : aCateg["name"].ToString())
                            };

                            if (aCateg["children"] != null && aCateg["children"].HasValues) oneItem.Content = (fyflag ? aCateg["chinesename"].ToString() : aCateg["name"].ToString()) + " >> ";

                            oneItem.MouseEnter += new MouseEventHandler(RoneItem_MouseEnter);
                            oneItem.MouseLeave += new MouseEventHandler(RoneItem_MouseLeave);
                            lstFirst.Items.Add(oneItem);
                        }
                        else
                        {
                            //无相关属性

                        }
                    }
                    nodeList.Clear();
                    //递归生成查询要用的集合
                    for (int k = 0; k < categoryArr.Count; k++)
                    {
                        JToken ajt = (JToken)categoryArr[k];
                        try
                        {
                            CreateCategoryQueryList(ajt, ajt["name"].ToString());
                        }
                        catch
                        {
                            continue;
                        }
                    }
                    ReadHistoryNodes();
                }
                catch
                {
                }
            }));
        }

        /// <summary>
        /// 读取选择的历史类目
        /// </summary>
        private void ReadHistoryNodes()
        {
            var historyStr = new IOHelp().ReadActFile(AppDomain.CurrentDomain.BaseDirectory + "sysdata\\historycategory.act");
            if (historyStr.Length > 0)
            {
                if (historyList == null) historyList = new List<LeafNode>();
                historyList.Clear();
                JArray jahs = (JArray)JsonConvert.DeserializeObject(historyStr);

                foreach (JToken jt in jahs)
                {
                    JToken id = jt["SiteId"];
                    if ((int)id == GlobalUserClass.SiteId)
                    {
                        historyList.Add(new LeafNode() { LeafId = jt["LeafId"].ToString(), LeafName = jt["LeafName"].ToString(), LeafPath = jt["LeafPath"].ToString() });

                    }
                }
            }
        }

        //递归生成查询类目用的集合
        public void CreateCategoryQueryList(JToken _oneNode, string _parentPath)
        {
            if (_oneNode == null)
            {
                return;
            }
            else
            {
                if (_oneNode["children"] != null && _oneNode["children"].HasValues && _oneNode["name"] != null)  //第一轮一定有
                {
                    JArray jactgD = (JArray)(_oneNode["children"]);

                    string tpath = _oneNode["name"].ToString();

                    string parentPathX = string.IsNullOrEmpty(_parentPath) ? tpath : (_parentPath + " >> " + tpath);

                    for (int i = 0; i < jactgD.Count; i++)
                    {
                        JToken aj = (JToken)jactgD[i];

                        CreateCategoryQueryList(aj, parentPathX);

                    }



                } //if  has not children
                else
                {
                    if ((bool)_oneNode["leaf"] && _oneNode["name"] != null && _oneNode["category_id"] != null)
                    {
                        string tpath = _oneNode["name"].ToString();

                        nodeList.Add(new LeafNode() { LeafId = _oneNode["category_id"].ToString(), LeafName = tpath.ToLower(), LeafPath = (_parentPath + " >> " + tpath) });
                    }
                }
            }
        }


        //选项鼠标划过时
        private void RoneItem_MouseEnter(object sender, RoutedEventArgs e)
        {
            ((ListBoxItem)sender).FontWeight = FontWeights.Bold;
        }
        //选项鼠标离开时
        private void RoneItem_MouseLeave(object sender, RoutedEventArgs e)
        {
            ((ListBoxItem)sender).FontWeight = FontWeights.Normal;
        }

        private void Border_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void SetChildMenu(ListBox lb_parent, ListBox lb_child)
        {
            lb_child.Items.Clear();
            if (lb_parent.SelectedItem == null) return;
            ListBoxItem oneCB = (ListBoxItem)(lb_parent.SelectedItem);
            if (oneCB.DataContext == null) return;
            JObject afirstcateg = (JObject)oneCB.DataContext;
            if (afirstcateg["children"] != null && afirstcateg["children"].HasValues)
            {
                SetNameAndId(fyflag ? afirstcateg["pchinesenamepath"].ToString() : afirstcateg["pnamepath"].ToString(), afirstcateg["pidpath"].ToString(), "");

                if (lb_child.Name != "listFourth" && lb_child.Name != "lstThird")
                    InitChildCategory(afirstcateg, lb_child);
                else
                    InitfourthCateg(afirstcateg);
            }
            else
            {
                SetNameAndId(fyflag ? afirstcateg["pchinesenamepath"].ToString() : afirstcateg["pnamepath"].ToString(), afirstcateg["pidpath"].ToString(), afirstcateg["category_id"].ToString());
            }
        }

        /// <summary>
        /// 设置第四层
        /// </summary>
        /// <param name="_jCategoryD"></param>
        private void InitfourthCateg(JObject _jCategoryD)
        {
            if (_jCategoryD == null)
            {
                return;
            }
            else
            {
                var cc = new CategoryCore();
                //if (((bool)_jCategoryD["leaf"] && !_jCategoryD["children"].HasValues))
                //{
                if (_jCategoryD["chinesename"] == null) _jCategoryD["chinesename"] = fyflag ? cc.GetChineseName(_jCategoryD["name"].ToString()) : _jCategoryD["name"].ToString();
                if (_jCategoryD["tname"] == null) _jCategoryD["tname"] = _jCategoryD["name"].ToString(); //只4级显示用
                if (_jCategoryD["tchinesename"] == null) _jCategoryD["tchinesename"] = _jCategoryD["chinesename"].ToString(); //只4级显示用
                if (_jCategoryD["children"] != null && _jCategoryD["children"].HasValues)  //第一轮一定有
                {
                    JArray jactgD = (JArray)(_jCategoryD["children"]);

                    for (int i = 0; i < jactgD.Count; i++)
                    {
                        JObject aj = (JObject)jactgD[i];
                        if (aj["chinesename"] == null) aj["chinesename"] = fyflag ? cc.GetChineseName(aj["name"].ToString()) : aj["name"].ToString();
                        if (aj["pnamepath"] == null) aj["pnamepath"] = _jCategoryD["pnamepath"].ToString() + " >> " + aj["name"].ToString();
                        if (aj["pchinesenamepath"] == null) aj["pchinesenamepath"] = _jCategoryD["pchinesenamepath"].ToString() + " >> " + aj["chinesename"].ToString();
                        if (aj["pidpath"] == null) aj["pidpath"] = _jCategoryD["pidpath"].ToString() + " >> " + aj["category_id"].ToString();

                        //只4级显示用
                        if (aj["tname"] == null)
                        {
                            aj["tname"] = _jCategoryD["tname"].ToString() + " >> " + aj["name"].ToString();
                            aj["tchinesename"] = _jCategoryD["tchinesename"].ToString() + " >> " + aj["chinesename"].ToString();
                        }

                        InitfourthCateg(aj);

                    }



                } //if  has children
                else
                {
                    if (_jCategoryD["name"] != null && _jCategoryD["category_id"] != null)
                    {
                        ListBoxItem oneItem = new ListBoxItem();

                        oneItem.DataContext = _jCategoryD;
                        oneItem.Content = fyflag ? _jCategoryD["tchinesename"].ToString() : _jCategoryD["tname"].ToString();
                        oneItem.MouseEnter += new MouseEventHandler(RoneItem_MouseEnter);
                        oneItem.MouseLeave += new MouseEventHandler(RoneItem_MouseLeave);
                        listFourth.Items.Add(oneItem);
                    }
                }
                //}
            }
        }


        private void SetNameAndId(string _namepath, string _idpath, string _leafid)
        {
            txtResult.Text = _namepath;
            idPath = _idpath;
            namePath = _namepath;
            leafId = _leafid;
            lblId.Content = _leafid;
            btnConfirm.IsEnabled = _leafid == string.Empty ? false : true;

        }

        /// <summary>
        /// 设置子类目（1，2，3）
        /// </summary>
        /// <param name="_jcb"></param>
        /// <param name="lb"></param>
        private void InitChildCategory(JObject _jcb, ListBox lb)
        {
            var jCategoryB = (JArray)(_jcb["children"]);

            if (jCategoryB == null)
            {
                return;
            }
            else
            {
                if (jCategoryB.Count > 0)
                {
                    var cc = new CategoryCore();
                    try
                    {
                        for (int i = 0; i < jCategoryB.Count; i++)
                        {
                            JObject aCateg = (JObject)jCategoryB[i];
                            if (aCateg["name"] != null && aCateg["category_id"] != null && !(!(bool)aCateg["leaf"] && !aCateg["children"].HasValues))
                            {
                                if (aCateg["chinesename"] == null)
                                {
                                    string name = cc.GetChineseName(aCateg["name"].ToString());
                                    aCateg["chinesename"] = fyflag ? name : aCateg["name"].ToString();
                                }
                                if (aCateg["pnamepath"] == null) aCateg["pnamepath"] = _jcb["pnamepath"].ToString() + " >> " + aCateg["name"].ToString();
                                if (aCateg["pchinesenamepath"] == null) aCateg["pchinesenamepath"] = _jcb["pchinesenamepath"].ToString() + " >> " + aCateg["chinesename"].ToString();
                                if (aCateg["pidpath"] == null) aCateg["pidpath"] = _jcb["pidpath"].ToString() + " >> " + aCateg["category_id"].ToString();


                                ListBoxItem oneItem = new ListBoxItem
                                {
                                    DataContext = aCateg,
                                    Content = fyflag ? aCateg["chinesename"].ToString() : aCateg["name"].ToString()
                                };

                                if (aCateg["children"] != null && aCateg["children"].HasValues) oneItem.Content = (fyflag ? aCateg["chinesename"].ToString() : aCateg["name"].ToString()) + " >> ";

                                oneItem.MouseEnter += new MouseEventHandler(RoneItem_MouseEnter);
                                oneItem.MouseLeave += new MouseEventHandler(RoneItem_MouseLeave);
                                lb.Items.Add(oneItem);

                            }
                        }
                    }
                    catch
                    {

                    }


                } //if
            }

        }

        //一级类目
        private void LstFirst_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //SetChildMenu(lstFirst, lstSecond);
            lstSecond.Items.Clear();
            if (lstFirst.SelectedItem == null) return;
            ListBoxItem oneCB = (ListBoxItem)(lstFirst.SelectedItem);
            if (oneCB.DataContext == null) return;
            JObject afirstcateg = (JObject)oneCB.DataContext;
            if (afirstcateg["children"] != null && afirstcateg["children"].HasValues)
            {
                SetNameAndId(fyflag ? afirstcateg["pchinesenamepath"].ToString() : afirstcateg["pnamepath"].ToString(), afirstcateg["pidpath"].ToString(), "");

                InitSecondCateg(afirstcateg);
            }
            else
            {
                SetNameAndId(fyflag ? afirstcateg["pchinesenamepath"].ToString() : afirstcateg["pnamepath"].ToString(), afirstcateg["pidpath"].ToString(), afirstcateg["category_id"].ToString());
            }
        }

        private void InitSecondCateg(JObject _jcb)
        {
            var jCategoryB = (JArray)(_jcb["children"]);
            if (jCategoryB == null)
            {
                return;
            }
            else
            {
                if (jCategoryB.Count > 0)
                {
                    var cc = new CategoryCore();
                    try
                    {
                        for (int i = 0; i < jCategoryB.Count; i++)
                        {
                            JObject aCateg = (JObject)jCategoryB[i];
                            if (aCateg["name"] != null && aCateg["category_id"] != null)
                            {
                                if (aCateg["chinesename"] == null) aCateg["chinesename"] = fyflag ? cc.GetChineseName(aCateg["name"].ToString()) : aCateg["name"].ToString();
                                if (aCateg["pnamepath"] == null) aCateg["pnamepath"] = _jcb["pnamepath"].ToString() + " >> " + aCateg["name"].ToString();
                                if (aCateg["pchinesenamepath"] == null) aCateg["pchinesenamepath"] = _jcb["pchinesenamepath"].ToString() + " >> " + aCateg["chinesename"].ToString();
                                if (aCateg["pidpath"] == null) aCateg["pidpath"] = _jcb["pidpath"].ToString() + " >> " + aCateg["category_id"].ToString();


                                ListBoxItem oneItem = new ListBoxItem();

                                oneItem.DataContext = aCateg;
                                oneItem.Content = fyflag ? aCateg["chinesename"].ToString() : aCateg["name"].ToString();

                                if (aCateg["children"] != null && aCateg["children"].HasValues) oneItem.Content = (fyflag ? aCateg["chinesename"].ToString() : aCateg["name"].ToString()) + " >> ";

                                oneItem.MouseEnter += new MouseEventHandler(RoneItem_MouseEnter);
                                oneItem.MouseLeave += new MouseEventHandler(RoneItem_MouseLeave);
                                lstSecond.Items.Add(oneItem);

                            }
                        }
                    }
                    catch
                    {
                    }
                } //if
            }
        }

        //二级类目
        private void LstSecond_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //SetChildMenu(lstSecond, lstThird);
            lstThird.Items.Clear();

            if (lstSecond.SelectedItem == null) return;

            ListBoxItem oneCB = (ListBoxItem)(lstSecond.SelectedItem);
            if (oneCB.DataContext == null) return;



            JObject asecondcateg = (JObject)oneCB.DataContext;

            if (asecondcateg["children"] != null && asecondcateg["children"].HasValues)
            {
                SetNameAndId(fyflag ? asecondcateg["pchinesenamepath"].ToString() : asecondcateg["pnamepath"].ToString(), asecondcateg["pidpath"].ToString(), "");

                InitThirdCateg(asecondcateg);
            }
            else
            {
                SetNameAndId(fyflag ? asecondcateg["pchinesenamepath"].ToString() : asecondcateg["pnamepath"].ToString(), asecondcateg["pidpath"].ToString(), asecondcateg["category_id"].ToString());
            }
        }


        private void InitThirdCateg(JObject _jcb)
        {
            var jCategoryC = (JArray)(_jcb["children"]);

            if (jCategoryC == null)
            {
                return;
            }
            else
            {
                if (jCategoryC.Count > 0)
                {
                    var cc = new CategoryCore();
                    try
                    {
                        for (int i = 0; i < jCategoryC.Count; i++)
                        {
                            JObject aCateg = (JObject)jCategoryC[i];
                            if (aCateg["name"] != null && aCateg["category_id"] != null)
                            {
                                if (aCateg["chinesename"] == null) aCateg["chinesename"] = fyflag ? cc.GetChineseName(aCateg["name"].ToString()) : aCateg["name"].ToString();
                                if (aCateg["pnamepath"] == null) aCateg["pnamepath"] = _jcb["pnamepath"].ToString() + " >> " + aCateg["name"].ToString();
                                if (aCateg["pchinesenamepath"] == null) aCateg["pchinesenamepath"] = _jcb["pchinesenamepath"].ToString() + " >> " + aCateg["chinesename"].ToString();
                                if (aCateg["pidpath"] == null) aCateg["pidpath"] = _jcb["pidpath"].ToString() + " >> " + aCateg["category_id"].ToString();

                                ListBoxItem oneItem = new ListBoxItem();

                                oneItem.DataContext = aCateg;
                                oneItem.Content = fyflag ? aCateg["chinesename"].ToString() : aCateg["name"].ToString();
                                if (aCateg["children"] != null && aCateg["children"].HasValues) oneItem.Content = (fyflag ? aCateg["chinesename"].ToString() : aCateg["name"].ToString()) + " >> ";

                                oneItem.MouseEnter += new MouseEventHandler(RoneItem_MouseEnter);
                                oneItem.MouseLeave += new MouseEventHandler(RoneItem_MouseLeave);
                                lstThird.Items.Add(oneItem);
                            }
                        }
                    }
                    catch
                    {
                    }
                } //if
            }
        }


        //三级类目
        private void LstThird_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //SetChildMenu(lstThird, listFourth);
            listFourth.Items.Clear();

            if (lstThird.SelectedItem == null) return;

            ListBoxItem oneCB = (ListBoxItem)(lstThird.SelectedItem);
            if (oneCB.DataContext == null) return;

            JObject athirdcateg = (JObject)oneCB.DataContext;

            if (athirdcateg["children"] != null && athirdcateg["children"].HasValues)
            {
                SetNameAndId(fyflag ? athirdcateg["pchinesenamepath"].ToString() : athirdcateg["pnamepath"].ToString(), athirdcateg["pidpath"].ToString(), "");

                InitfourthCateg(athirdcateg);
            }
            else
            {
                SetNameAndId(fyflag ? athirdcateg["pchinesenamepath"].ToString() : athirdcateg["pnamepath"].ToString(), athirdcateg["pidpath"].ToString(), athirdcateg["category_id"].ToString());
            }
        }
        //四级类目
        private void ListFourth_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //SetChildMenu(listFourth, listFourth);
            if (listFourth.SelectedItem == null) return;

            ListBoxItem oneCB = (ListBoxItem)(listFourth.SelectedItem);
            if (oneCB.DataContext == null) return;

            JObject a4thcateg = (JObject)(oneCB.DataContext);
            SetNameAndId(fyflag ? a4thcateg["pchinesenamepath"].ToString() : a4thcateg["pnamepath"].ToString(), a4thcateg["pidpath"].ToString(), a4thcateg["category_id"].ToString());
        }
        //刷新
        private void LblRefresh_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Init();
            TimeSpan ts1 = new TimeSpan(0, 0, 0, 0, 300);
            publicFunctions.AngleEasingAnimationShow(Img, 0, 180, 3, ts1);
        }

        //搜索
        private void TxtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyboardDevice.IsKeyDown(Key.Enter))
            {
                SearchCategory();
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchCategory();
        }

        private void SearchCategory()
        {
            if (txtSearch.Text.Trim() == string.Empty) return;
            if (PART_PopupSearch.IsOpen)
                PART_PopupSearch.IsOpen = false;
            if (PART_PopupHistory.IsOpen)
                PART_PopupHistory.IsOpen = false;
            lstSearch.Items.Clear();
            Regex reg = new Regex(@"\b" + txtSearch.Text.Trim() + @"(s|es)?\b", RegexOptions.IgnoreCase);
            if (nodeList != null && nodeList.Count > 0)
            {
                var query = nodeList.Where(P => (reg.IsMatch(P.LeafName)));
                foreach (var item in query)
                {
                    ListBoxItem lstitm = new ListBoxItem
                    {
                        Content = item.LeafPath
                    };
                    if (item.LeafPath.Length > 110) lstitm.ToolTip = item.LeafPath;

                    lstSearch.Items.Add(lstitm);

                    lstitm.Tag = item;
                }

                var query2 = nodeList.Where(P => ((reg.Matches(P.LeafPath)).Count > 1));
                foreach (var item in query2)
                {
                    if (lstSearch.Items.Contains(item)) continue;
                    ListBoxItem lstitm = new ListBoxItem
                    {
                        Content = item.LeafPath
                    };
                    if (item.LeafPath.Length > 110) lstitm.ToolTip = item.LeafPath;

                    lstSearch.Items.Add(lstitm);

                    lstitm.Tag = item;
                }
            }
            if (lstSearch.Items.Count > 0)
                PART_PopupSearch.IsOpen = true;
        }


        void GetTreePath()
        {
            treePath = "";
            var m1 = (ListBoxItem)lstFirst.SelectedItem;
            if (m1 != null)
            {
                if (m1.DataContext != null)
                {
                    JObject obj1 = (JObject)(m1.DataContext);
                    treePath = obj1["pnamepath"].ToString();
                }
            }
            var m2 = (ListBoxItem)lstSecond.SelectedItem;
            if (m2 != null)
            {

                if (m2.DataContext != null)
                {
                    JObject obj1 = (JObject)(m2.DataContext);
                    treePath = obj1["pnamepath"].ToString();
                }
            }
            var m3 = (ListBoxItem)lstThird.SelectedItem;
            if (m3 != null)
            {

                if (m3.DataContext != null)
                {
                    JObject obj1 = (JObject)(m3.DataContext);
                    treePath = obj1["pnamepath"].ToString();
                }
            }
            var m4 = (ListBoxItem)listFourth.SelectedItem;
            if (m4 != null)
            {

                if (m4.DataContext != null)
                {
                    JObject obj1 = (JObject)(m4.DataContext);
                    treePath = obj1["pnamepath"].ToString();
                }
            }
        }

        //确定
        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            GetTreePath();
            SaveHistoryCategory();
            RoutedEventArgs arg = new RoutedEventArgs(CategoryChangedEvent, this);
            this.RaiseEvent(arg);
        }

        /// <summary>
        /// 保存历史类目
        /// </summary>
        private void SaveHistoryCategory()
        {
            JArray ja = new JArray();
            if (historyList.Count > 0)
            {
                var query3 = historyList.Where(P => (P.LeafId != leafId && historyList.IndexOf(P) < 25));

                List<LeafNode> newList = new List<LeafNode>();

                foreach (var item in query3)
                {
                    JObject jb = new JObject
                    {
                        { "LeafId", item.LeafId },
                        { "LeafName", item.LeafName },
                        { "LeafPath", item.LeafPath },
                        {"SiteId",GlobalUserClass.SiteId }
                    };
                    ja.Add(jb);
                }
                historyList = newList;
            }
            JObject obj = new JObject
            {
                { "LeafId", leafId },
                { "LeafName", "" },
                { "LeafPath", namePath },
                {"SiteId",GlobalUserClass.SiteId }
            };
            ja.Insert(0, obj);
            var historyStr = JsonConvert.SerializeObject(ja);
            new IOHelp().SaveActFile(AppDomain.CurrentDomain.BaseDirectory + Constants.ACTFILE_HISTORY, historyStr);
        }

        //翻译
        private void BtnTranslate_Click(object sender, RoutedEventArgs e)
        {
            fyflag = btnTranslate.Content.ToString() == "翻译" ? true : false;
            var cc = new CategoryCore();
            var ali = new ALiCore();
            string tname = "";
            string cateName = "";
            if (lstFirst.Items.Count > 0)
            {
                foreach (ListBoxItem item in lstFirst.Items)
                {
                    cateName = ((JObject)item.DataContext)["name"].ToString();
                    if (fyflag)
                    {
                        tname = cc.GetChineseName(cateName);
                    }
                    item.Content = (fyflag ? tname : cateName) + (item.Content.ToString().Contains(">>") ? " >> " : "");

                }
            }

            if (lstSecond.Items.Count > 0)
            {
                foreach (ListBoxItem item in lstSecond.Items)
                {
                    cateName = ((JObject)item.DataContext)["name"].ToString();
                    if (fyflag)
                    {
                        tname = cc.GetChineseName(cateName);
                    }
                    item.Content = (fyflag ? tname : cateName) + (item.Content.ToString().Contains(">>") ? " >> " : "");
                }
            }

            if (lstThird.Items.Count > 0)
            {
                foreach (ListBoxItem item in lstThird.Items)
                {
                    cateName = ((JObject)item.DataContext)["name"].ToString();
                    if (fyflag)
                    {
                        tname = cc.GetChineseName(cateName);
                    }
                    item.Content = (fyflag ? tname : cateName) + (item.Content.ToString().Contains(">>") ? " >> " : "");
                }
            }

            if (listFourth.Items.Count > 0)
            {
                foreach (ListBoxItem item in listFourth.Items)
                {
                    cateName = ((JObject)item.DataContext)["tname"].ToString();
                    if (fyflag)
                    {
                        tname = cc.GetChineseName(cateName);
                    }
                    item.Content = (fyflag ? tname : cateName);
                }
            }
            btnTranslate.Content = btnTranslate.Content.ToString() == "翻译" ? "取消翻译" : "翻译";
        }

        private void BtnHistory_Click(object sender, RoutedEventArgs e)
        {
            if (PART_PopupSearch.IsOpen)
                PART_PopupSearch.IsOpen = false;
            lstHistory.Items.Clear();
            if (historyList.Count == 0)
                ReadHistoryNodes();
            foreach (var item in historyList)
            {
                ListBoxItem lstitm = new ListBoxItem
                {
                    Content = item.LeafPath
                };
                if (item.LeafPath.Length > 110) lstitm.ToolTip = item.LeafPath;

                lstHistory.Items.Add(lstitm);

                lstitm.Tag = item;
            }
            PART_PopupHistory.IsOpen = true;
        }

        private void PART_PopupSearch_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChooseSearchOneItem();
        }

        /// <summary>
        /// 选择检索窗体中的一项
        /// </summary>
        private void ChooseSearchOneItem()
        {
            if (lstSearch.SelectedItem == null) return;
            ListBoxItem oneCB = (ListBoxItem)(lstSearch.SelectedItem);
            if (oneCB.Tag == null) return;
            LeafNode lfnd = (LeafNode)(oneCB.Tag);
            SetNameAndId(lfnd.LeafPath, lfnd.LeafId, lfnd.LeafId);
        }

        private void PART_PopupHistory_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void LstHistory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (lstHistory.SelectedItem == null) return;

            ListBoxItem oneCB = (ListBoxItem)(lstHistory.SelectedItem);
            if (oneCB.Tag == null) return;

            LeafNode lfnd = (LeafNode)(oneCB.Tag);

            SetNameAndId(lfnd.LeafPath, lfnd.LeafId, lfnd.LeafId);

            //SaveHistoryCategory();
            //RoutedEventArgs arg = new RoutedEventArgs(CategoryChangedEvent, this);
            //this.RaiseEvent(arg);
        }

        private void LstSearch_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ChooseSearchOneItem();
        }

        private void Rootgrid_Loaded(object sender, RoutedEventArgs e)
        {
            Task.Run(() => Init());
        }
    }

    public class LeafNode
    {
        public string LeafId { get; set; }
        public string LeafName { get; set; }
        public string LeafChineseName { get; set; }
        public string LeafPath { get; set; }
    }
}
