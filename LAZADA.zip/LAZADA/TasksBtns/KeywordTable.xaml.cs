﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// KeywordTable.xaml 的交互逻辑
    /// </summary>
    public partial class KeywordTable : Window
    {
        public KeywordTable()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
        }

        private void TxtKWDVal_GotFocus(object sender, RoutedEventArgs e)
        {

        }

        private void TxtKWDVal_MouseLeave(object sender, MouseEventArgs e)
        {

        }

        private void TxtKWDVal_LostFocus(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAffirm_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnDel_Click(object sender, RoutedEventArgs e)
        {

        }

        private void KWDSaveBtn_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
