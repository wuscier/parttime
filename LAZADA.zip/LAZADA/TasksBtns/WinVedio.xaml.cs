﻿using Logic.BasicInfo;
using PublicFunction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// WinVedio.xaml 的交互逻辑
    /// </summary>
    public partial class WinVedio : Window
    {
        DispatcherTimer timer = null;
        public WinVedio()
        {
            InitializeComponent();
            var uri = Constants.VEDIOURI;
            sliderPosition.Maximum = 883;
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += new EventHandler(timer_tick);
            meShow.Source = new Uri(Constants.VEDIOURI);
            timer.Start();
        }

        private void timer_tick(object sender, EventArgs e)
        {
            sliderPosition.Value = meShow.Position.TotalSeconds;
        }

        private void MediaPlayer_MediaOpened(object sender, RoutedEventArgs e)
        {
            int duration = meShow.NaturalDuration.TimeSpan.Seconds;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            new SystemConfigCore().UpdateIsShowVedio(chkNeedShow.IsChecked ?? false);
            this.Close();
        }

        private void sliderPosition_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            meShow.Position = TimeSpan.FromSeconds(sliderPosition.Value);
        }
    }
}
