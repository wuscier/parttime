﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// FigureReleased.xaml 的交互逻辑
    /// </summary>
    public partial class FigureReleased : Window
    {
        public FigureReleased()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
        }
        //开始上传图片
        private void BtnUploadImg_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnUPtest_Click(object sender, RoutedEventArgs e)
        {

        }
        //开始发布产品
        private void BtnRelease_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
