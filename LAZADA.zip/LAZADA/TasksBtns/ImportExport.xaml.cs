﻿using PublicFunction;
using PublicFunction.ControlHelp;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// ImportExport.xaml 的交互逻辑
    /// </summary>
    public partial class ImportExport : Window
    {
        private string SavePath = "";//导出保存的路径
        List<DataRow> dataRows = new List<DataRow>();//导出的行数
        private int ExportNum = 0;//统计导出的数量
        private int countInGroup = 2000;
        private string CurrentDataXlsxName = "";//数据表Name
        private string CurrentSkuXlsxName = "";//货源表Name
        private string CurrentLinkXlsxName = "";//链接表Name
        public ImportExport()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
        }

        //选择导出路径
        private void BtnExportPath_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog m_Dialog = new FolderBrowserDialog();//选择文件
            m_Dialog.ShowNewFolderButton = true;
            DialogResult result = m_Dialog.ShowDialog();//弹窗

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                SavePath = m_Dialog.SelectedPath.Trim();
                txtExportPath.Text = SavePath;//保存路径
                txtExportPath.BorderBrush = Brushes.Gray;
            }
        }
        
        //开始导出
        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            if (dataRows==null)
            {
                return;
            }
            if (dataRows.Count<1)
            {
                return;
            }
            if (String.IsNullOrEmpty(SavePath))
            {
                txtExportPath.BorderBrush = Brushes.Red;
                txtExportPath.Text = "请选择";
                return;
            }
            progressBarOut.Value = 0;
            if (progressBarOut.Value>0)
            {
                lblExportSult.Content = "正在导出。。。";
                btnExport.IsEnabled = false;

                //开始导出
                Thread thread = new Thread(new ThreadStart(BeginExport));
                thread.IsBackground = true;
                thread.Start();
            }
        }
        /// <summary>
        /// 导出
        /// </summary>
        private void BeginExport()
        {
            ExportNum = dataRows.Count;//导出数量
            try
            {
                for (int i = 0; i < ExportNum; i++)
                {
                    DataRow dataRow = dataRows[i];//数据源
                    string timestr = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");//导出的当前时间
                    if ((i % countInGroup) == 0)
                    {
                        try
                        {
                            string num = (((dataRows.Count - countInGroup) > i) ? (i + countInGroup) : dataRows.Count).ToString("000#");
                            string numb = DateTime.Now.ToString("yyyyMMddHHmmss") + "-" + (i + 1).ToString("000#") + "-" + num;


                            CurrentDataXlsxName = SavePath + "\\" + numb + "-数据记录表" + ".xlsx";

                            CurrentSkuXlsxName = SavePath + "\\" + numb + "-货源记录表" + ".xlsx";

                            CurrentLinkXlsxName = SavePath + "\\" + numb + "-链接记录表" + ".xlsx";

                        }
                        catch(Exception ex)
                        {
                            this.Dispatcher.BeginInvoke(new Action(() => { lblExportSult.Content = "写文件出错，已停止导出"; }));
                            new LogOutput.LogTo().WriteErrorLine(ex.InnerException.Message);
                            return;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.InnerException.Message);
                return;
            }
        }


        /// <summary>
        /// 选择图片路径
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnImgPath_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog fbd = new System.Windows.Forms.FolderBrowserDialog();
            fbd.ShowNewFolderButton = true;
            fbd.ShowDialog();
            if (fbd.SelectedPath != string.Empty)
            {
                this.txtImgPath.Text = fbd.SelectedPath;
                this.txtImgPath.ToolTip = this.txtImgPath.Text;
                txtImgPath.BorderBrush = Brushes.Gray;
                writeSaveFolder(this.txtImgPath.Text);
            }
        }

        #region //读写保存地址
        private void writeSaveFolder(string _path)
        {
            FileStream fileStream = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\initdata.act", FileMode.OpenOrCreate);
            StreamWriter streamWriter = new StreamWriter(fileStream, System.Text.Encoding.Default);
            //清空后再写
            fileStream.Seek(0, SeekOrigin.Begin);
            fileStream.SetLength(0); //清空txt文件
            streamWriter.Write(_path);
            streamWriter.Close();
            fileStream.Close();
        }
        private string readSaveFolder()
        {
            if (System.IO.File.Exists(AppDomain.CurrentDomain.BaseDirectory + "\\initdata.act"))
            {
                string appPath = AppDomain.CurrentDomain.BaseDirectory;
                //读一个文本 ,作为环境变量
                FileStream fst = new FileStream(appPath + "\\initdata.act", FileMode.OpenOrCreate);
                //读数据到txt
                StreamReader sr = new StreamReader(fst, System.Text.Encoding.Default);
                //读取
                string initdataStr = sr.ReadToEnd().Trim();
                sr.Close();
                fst.Close();
                return initdataStr;
            }
            else
            {
                return "";

            }

        }
        #endregion

        //选择表格位置
        private void BtnTblImportPath_Click(object sender, RoutedEventArgs e)
        {

        }

        //导入
        private void BtnImport_Click(object sender, RoutedEventArgs e)
        {
            bool imgpath = new ControlCheckHelp().CheckTextBox(txtImgPath);
            if (imgpath || !System.IO.Directory.Exists(txtImgPath.Text.Trim()))
            {
                txtImgPath.Text = "无效路径";
                return;
            }
            bool tabpath= new ControlCheckHelp().CheckTextBox(txtTablePath);
            if (tabpath || !File.Exists(txtTablePath.Text.Trim()))
            {
                txtTablePath.Text = "无效路径";
                return;
            }
        }

        private void TxtImgPath_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {

        }
    }
}
