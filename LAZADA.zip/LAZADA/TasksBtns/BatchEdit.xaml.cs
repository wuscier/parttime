﻿using Logic.BasicInfo;
using Logic.PriceTemplate;
using Logic.SystemSole;
using Logic.Translation;
using Newtonsoft.Json.Linq;
using PublicFunction.AlertHelp;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// BatchEdit.xaml 的交互逻辑
    /// </summary>
    public partial class BatchEdit : Window
    {
        public BatchEdit()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            txtAffectRow.Text = "选中" + SystemSoleEntity.SelectedProductNumberList.Count + "行";
        }

        /// <summary>
        /// 未设置的按指定时间设置，已设置过的按下面方式处理Checked事件
        /// </summary>
        private void RdoTimePart_Checked(object sender, RoutedEventArgs e)
        {
            //if (rdoTimePart.IsChecked == true)
            //{
            //    rdoTimePartIgnor.IsEnabled = true;
            //    rdoTimePartReset.IsEnabled = true;
            //}
            //else
            //{
            //    rdoTimePartIgnor.IsEnabled = false;
            //    rdoTimePartReset.IsEnabled = false;
            //}
        }
        /// <summary>
        /// 未设置的按指定时间设置，已设置过的按下面方式处理Unloaded事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RdoTimePart_Unloaded(object sender, RoutedEventArgs e)
        {
            //if (rdoTimePart.IsChecked == true)
            //{
            //    rdoTimePartIgnor.IsEnabled = true;
            //    rdoTimePartReset.IsEnabled = true;
            //}
            //else
            //{
            //    rdoTimePartIgnor.IsEnabled = false;
            //    rdoTimePartReset.IsEnabled = false;
            //}
        }


        private void SaveChangeLabel(string labelName)
        {
            foreach (Canvas item in EditMode.Children)
            {
                if (Convert.ToString(item.Tag) == labelName)
                {
                    return;
                }
            }
            Canvas acanvas = new Canvas();
            acanvas.Tag = labelName;
            acanvas.Height = 26;
            acanvas.Width = 116;
            acanvas.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(200, 197, 140));
            acanvas.Background = brsA;
            acanvas.Margin = new Thickness(1);

            Label alabel = new Label();
            alabel.Content = labelName;
            alabel.Width = 96;
            acanvas.Children.Add(alabel);

            Label alabel2 = new Label();
            alabel2.VerticalContentAlignment = System.Windows.VerticalAlignment.Center;
            alabel2.Content = "X";
            alabel2.Width = 20;
            alabel2.Margin = new Thickness(96, 0, 0, 0);
            System.Windows.Media.Brush brsB = new SolidColorBrush(System.Windows.Media.Color.FromRgb(220, 210, 160));
            alabel2.Background = brsB;
            // alabel2.Style = this.FindResource("LableMouseOver") as Style;
            alabel2.MouseEnter += new MouseEventHandler(alabel2_MouseEnter);
            alabel2.MouseLeave += new MouseEventHandler(alabel2_MouseLeave);
            alabel2.MouseLeftButtonDown += new MouseButtonEventHandler(alabel2_MouseLeftButtonDown);


            acanvas.Children.Add(alabel2);

            EditMode.Children.Add(acanvas);
        }

        private void alabel2_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            EditMode.Children.Remove((Canvas)(((Label)sender).Parent));
        }

        private void alabel2_MouseEnter(object sender, MouseEventArgs e)
        {
            System.Windows.Media.Brush brsBx = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
            ((Label)sender).Background = brsBx;


        }
        private void alabel2_MouseLeave(object sender, MouseEventArgs e)
        {
            System.Windows.Media.Brush brsBx = new SolidColorBrush(System.Windows.Media.Color.FromRgb(220, 210, 160));
            ((Label)sender).Background = brsBx;


        }

        /// <summary>
        /// 切换label背景
        /// </summary>
        /// <param name="label"></param>
        private void ChangeLabelBgColor(Label label)
        {
            System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(209, 209, 209));
            lblTitle.Background = brsA;
            lblDescribe.Background = brsA;
            lblSelling.Background = brsA;
            //lblKword.Background = brsA;
            //lblImg.Background = brsA;
            //lblSundry.Background = brsA;
            lblValua.Background = brsA;

            System.Windows.Media.Brush brsB = new SolidColorBrush(System.Windows.Media.Color.FromRgb(100, 200, 200));
            label.Background = brsB;
            CvTitle.Visibility = System.Windows.Visibility.Collapsed;
            CanvasDesc.Visibility = System.Windows.Visibility.Collapsed;
            CanvasSelling.Visibility = System.Windows.Visibility.Collapsed;
            CanvasKword.Visibility = System.Windows.Visibility.Collapsed;
            CanvasImg.Visibility = System.Windows.Visibility.Collapsed;
            CanvasSundry.Visibility = System.Windows.Visibility.Collapsed;
            CanvasValuaMode.Visibility = System.Windows.Visibility.Collapsed;
        }
        private void BtnExecute_Click(object sender, RoutedEventArgs e)
        {
            if (EditMode.Children.Count == 0) return;
            var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            SystemSoleEntity.GetMainWinModel().InitModel("批量编辑", list.Count);
            Task.Run(() =>
            {
                foreach (var product in list)
                {
                    try
                    {
                        this.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            foreach (Canvas control in EditMode.Children)
                            {
                                switch (Convert.ToString(control.Tag))
                                {
                                    case "标题变更":
                                        TileChange(product);
                                        break;
                                    case "描述头变更":
                                        DescChange(product);
                                        break;
                                    case "卖点变更":
                                        SalePointChange(product);
                                        break;
                                    case "计价模板变更":
                                        PriceTemplateChange(product);
                                        break;
                                }
                            }
                            new ProductCore().UpdateBatchEdit(product);
                        }));
                    }
                    catch (Exception ex)
                    {
                        SystemSoleEntity.GetMainWinModel().IbulkErrowCount++;
                        new LogOutput.LogTo().WriteErrorLine("批量编辑出错：" + product.Porigimgsurl + "///" + ex.Message);
                    }
                    SystemSoleEntity.GetMainWinModel().Ipbvalue += SystemSoleEntity.GetMainWinModel().TaskAdd;
                    SystemSoleEntity.GetMainWinModel().TaskRunCount++;
                }
                //EditMode.Children.Clear();
                this.Dispatcher.BeginInvoke(new Action(() => {
                    this.Close();
                }));
            });
            //this.Close();
        }


        /// <summary>
        /// 标题变更
        /// 控件事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnTitleAdd_Click(object sender, RoutedEventArgs e)
        {
            if (txtTitleEditVal.Text != string.Empty || txtTitleAddFrVal.Text != string.Empty || txtTitleAddBeVal.Text != string.Empty
                || (txtTitleReplyValA.Text != string.Empty && txtTitleAsValA.Text != string.Empty)
                || (txtTitleReplyValB.Text != string.Empty && txtTitleAsValB.Text != string.Empty)
                || (txtTitleReplyValC.Text != string.Empty && txtTitleAsValC.Text != string.Empty)
                || (txtTitleReplyValD.Text != string.Empty && txtTitleAsValD.Text != string.Empty)
                //|| (chkAdjustOrder.IsChecked ?? false && txtReferWordVal.Text != string.Empty)
                )
                SaveChangeLabel("标题变更");
        }


        /// <summary>
        /// 标题变更
        /// </summary>
        /// <param name="product"></param>
        private void TileChange(Product product)
        {
            if (txtTitleEditVal.Text != string.Empty)
                product.Pnewtitle = txtTitleEditVal.Text;
            else
            {
                if (txtTitleAddFrVal.Text != string.Empty)
                {
                    product.Pnewtitle = txtTitleAddFrVal.Text + " " + product.Pnewtitle;
                }
                if (txtTitleAddBeVal.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle + " " + txtTitleAddBeVal.Text;
                }
                if (txtTitleReplyValA.Text != string.Empty && txtTitleAsValA.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle.Replace(txtTitleReplyValA.Text, txtTitleAsValA.Text);
                }
                if (txtTitleReplyValB.Text != string.Empty && txtTitleAsValB.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle.Replace(txtTitleReplyValB.Text, txtTitleAsValB.Text);
                }
                if (txtTitleReplyValC.Text != string.Empty && txtTitleAsValC.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle.Replace(txtTitleReplyValC.Text, txtTitleAsValC.Text);
                }
                if (txtTitleReplyValD.Text != string.Empty && txtTitleAsValD.Text != string.Empty)
                {
                    product.Pnewtitle = product.Pnewtitle.Replace(txtTitleReplyValD.Text, txtTitleAsValD.Text);
                }
            }
        }

        /// <summary>
        /// 卖点变更
        /// 控件事件
        /// </summary>
        /// <param name="product"></param>
        private void BtnSellAdd_Click(object sender, RoutedEventArgs e)
        {
            if (Convert.ToString(HtmlEditorHLight.Content) != string.Empty || txtSellForntAdd.Text != string.Empty || txtSellBehindAdd.Text != string.Empty
                || (txtSellReplayA.Text != string.Empty && txtSellAsA.Text != string.Empty) || (txtSellReplayB.Text != string.Empty && txtSellAsB.Text != string.Empty))
                SaveChangeLabel("卖点变更");
        }

        /// <summary>
        /// 卖点变更
        /// </summary>
        /// <param name="product"></param>
        private void SalePointChange(Product product)
        {
            if (Convert.ToString(HtmlEditorHLight.BindingContent) != string.Empty)
                product.Lazadahighlight = Convert.ToString(HtmlEditorHLight.BindingContent);
            else
            {
                if (txtSellForntAdd.Text != string.Empty)
                {
                    product.Lazadahighlight = "<P>" + txtSellForntAdd.Text + "</P>" + product.Lazadahighlight;
                }
                if (txtSellBehindAdd.Text != string.Empty)
                {
                    product.Lazadahighlight = product.Lazadahighlight + "<P>" + txtSellBehindAdd.Text + "</P>";
                }
            }
        }


        /// <summary>
        /// 描述头变更
        /// 控件事件
        /// </summary>
        /// <param name="product"></param>
        private void BtnDescAdd_Click(object sender, RoutedEventArgs e)
        {
            if (chkDescTranslate.IsChecked ?? false || Convert.ToString(HtmlEditorDesc.Content) != string.Empty || txtDescAddFrontVal.Text != string.Empty || txtDescAddBehindVal.Text != string.Empty
                || (txtDescReplayA.Text != string.Empty && txtDescAsA.Text != string.Empty) || (txtDescReplayB.Text != string.Empty && txtDescAsB.Text != string.Empty))
                SaveChangeLabel("描述头变更");
        }

        /// <summary>
        /// 描述头变更
        /// </summary>
        /// <param name="product"></param>
        private void DescChange(Product product)
        {
            if (Convert.ToString(HtmlEditorDesc.BindingContent) != string.Empty)
                product.Lazadadescription = Convert.ToString(HtmlEditorDesc.BindingContent);
            else
            {
                if (txtDescAddFrontVal.Text != string.Empty)
                    product.Lazadadescription = "<P>" + txtDescAddFrontVal.Text + "</P>" + product.Lazadadescription;
                if (txtDescAddBehindVal.Text != string.Empty)
                    product.Lazadadescription = "<P>" + txtDescAddBehindVal.Text + "</P>" + product.Lazadadescription;
            }
            if (chkDescTranslate.IsChecked ?? false)
            {
                product.Lazadadescription = product.Lazadadescription.Replace("\t", "-#").Replace("\r\n", "♂").Replace("\n\n", "♂").Replace("\r", "♂").Replace("\n", "♂");
                Regex reg = new Regex("[\u4e00-\u9fa5]+");
                string restr1 = !reg.IsMatch(product.Lazadadescription, 0) ? product.Lazadadescription : new ALiCore().ChangeZhToEn(product.Lazadadescription).Replace("♂", "\n").Replace("^", " ").Replace("-#", "\t").Trim();
            }
        }

        /// <summary>
        /// 添加计价模板
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnValua_Click(object sender, RoutedEventArgs e)
        {
            //if ((cmbValua.Text != string.Empty && cmbValua.Text != "不更改") || (chkStock.IsChecked ?? false) || (chkMeasure.IsChecked ?? false) || (chkBoxWeight.IsChecked ?? false)
            //   || (BoxWeightCK.IsChecked ?? false && cmboBoxCondition.Text != string.Empty && comboBoxAction.Text != string.Empty)
            //   || (chkHotTime.IsChecked ?? false && StartDate.PickedDateTime != string.Empty && EndDate.PickedDateTime != string.Empty))
            //    SaveChangeLabel("计价模板变更");
        }

        /// <summary>
        /// 计价模板变更
        /// </summary>
        /// <param name="product"></param>
        private void PriceTemplateChange(Product product)
        {
            bool needReCalc = false;
            var ptc = new PriceTemplateCore();
            var jname = cmbValua.Text;
            if (jname == string.Empty)
                jname = product.Pjisangongshi;
            var template = ptc.GetPriceTemplate(jname);
            if (chkBoxWeight.IsChecked ?? false)
            {
                product.Lazadapackageweight = Convert.ToString(PkgWight.Value);
                needReCalc = true;
            }
            if ((BoxWeightCK.IsChecked ?? false && cmboBoxCondition.Text != string.Empty && comboBoxAction.Text != string.Empty))
            {
                var weight = Convert.ToDecimal(product.Lazadapackageweight);
                var condition1 = NumericUpDownConditionWeight.Value;
                var condition2 = NumericUpDownConditionWeight.Value;

                if (Convert.ToString(cmboBoxCondition.Text) == "小于" && weight < condition1)
                {
                    if (Convert.ToString(comboBoxAction.Text) == "增加")
                    {
                        weight += condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "减少" && weight > condition2)
                    {
                        weight -= condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "改为" && condition2 > 0)
                    {
                        weight = condition2;
                        needReCalc = true;
                    }
                }
                else if (Convert.ToString(cmboBoxCondition.Text) == "等于" && weight == condition1)
                {
                    if (Convert.ToString(comboBoxAction.Text) == "增加")
                    {
                        weight += condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "减少" && weight > condition2)
                    {
                        weight -= condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "改为" && condition2 > 0)
                    {
                        weight = condition2;
                        needReCalc = true;
                    }
                }
                else if (Convert.ToString(cmboBoxCondition.Text) == "大于" && weight > condition1)
                {
                    if (Convert.ToString(comboBoxAction.Text) == "增加")
                    {
                        weight += condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "减少" && weight > condition2)
                    {
                        weight -= condition2;
                        needReCalc = true;
                    }
                    else if (Convert.ToString(comboBoxAction.Text) == "改为" && condition2 > 0)
                    {
                        weight = condition2;
                        needReCalc = true;
                    }
                }

            }

            if ((cmbValua.Text != string.Empty && cmbValua.Text != "不更改"))
            {
                product.Pjisangongshi = template.Jname;
                needReCalc = true;
            }
            if (chkStock.IsChecked ?? false)
            {
                product.Pkuchen = NumericUpDownKuchen.ToString();
            }
            if (chkMeasure.IsChecked ?? false)
            {
                product.PackageLength = NumericUpDownPkgLength.ToString();
                product.PackageWidth = NumericUpDownPkgWidth.ToString();
                product.PackageHight = NumericUpDownPkgHight.ToString();
            }
            //if ((chkHotTime.IsChecked ?? false && StartDate.PickedDateTime != string.Empty && EndDate.PickedDateTime != string.Empty))
            //{
            //    if (rdoTimeAlll.IsChecked ?? false)
            //    {
            //        product.Lazadapromstart = StartDate.PickedDateTime;
            //        product.Lazadapromend = EndDate.PickedDateTime;
            //    }
            //    else
            //    {
            //        if (product.Lazadapromstart != string.Empty && product.Lazadapromend != string.Empty)
            //        {
            //            if (rdoTimePartReset.IsChecked ?? false)
            //            {
            //                var start = Convert.ToDateTime(product.Lazadapromstart);
            //                var end = Convert.ToDateTime(product.Lazadapromend);
            //                if (start < DateTime.Now)
            //                {
            //                    product.Lazadapromstart = StartDate.PickedDateTime;
            //                    product.Lazadapromend = Convert.ToDateTime(EndDate.PickedDateTime).AddDays((end - start).Days).AddHours((end - start).Hours).ToString();
            //                }
            //            }
            //        }
            //        if (product.Lazadapromstart == string.Empty)
            //            product.Lazadapromstart = StartDate.PickedDateTime;
            //        if (product.Lazadapromend == string.Empty)
            //            product.Lazadapromend = EndDate.PickedDateTime;
            //    }
            //}
            if (needReCalc)
            {
                ptc.CalcProductCost(template, product, Convert.ToDouble(product.Porigprice));
            }
        }

        /// <summary>
        /// 标题
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblTitle_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            CvTitle.Visibility = System.Windows.Visibility.Visible;
        }
        /// <summary>
        /// 描述头
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblDescribe_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            CanvasDesc.Visibility = System.Windows.Visibility.Visible;
        }
        /// <summary>
        /// 卖点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblSelling_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            CanvasSelling.Visibility = System.Windows.Visibility.Visible;
        }
        /// <summary>
        /// 关键词
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblKword_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            CanvasKword.Visibility = System.Windows.Visibility.Visible;
        }
        /// <summary>
        /// 图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblImg_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            CanvasImg.Visibility = System.Windows.Visibility.Visible;
        }
        /// <summary>
        /// 杂项
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblSundry_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            CanvasSundry.Visibility = System.Windows.Visibility.Visible;
        }
        /// <summary>
        /// 计价模板
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblValua_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ChangeLabelBgColor((Label)sender);
            CanvasValuaMode.Visibility = System.Windows.Visibility.Visible;
        }

        private void BtnKwdAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TxtKwdAsVal_LostFocus(object sender, RoutedEventArgs e)
        {

        }

        private void CmbKwdToVal_DropDownOpened(object sender, EventArgs e)
        {

        }

        private void BtnImgAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnImgChoice_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnImgChoiceB_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSundryAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CmbBrandVal_DropDownOpened(object sender, EventArgs e)
        {

        }

        private void BtnTranslat_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnNum_Click(object sender, RoutedEventArgs e)
        {

        }

        /// <summary>
        /// 下拉选择计价模板
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CmbValua_DropDownOpened(object sender, EventArgs e)
        {
            if (cmbValua.Items.Count < 1)
            {
                AddValuaModel();
            }
        }
        /// <summary>
        /// 添加计价模板
        /// </summary>
        private void AddValuaModel()
        {
            try
            {
                List<PriceTemplateEntity> ValuaName = new PriceTemplateCore().GetPriceTemplateList();
                if (ValuaName.Count > 0)
                {
                    ComboBoxItem firstValuaName = new ComboBoxItem();
                    firstValuaName.Content = "不更改";
                    cmbValua.Items.Add(firstValuaName);

                    for (int i = 0; i < ValuaName.Count; i++)
                    {
                        ComboBoxItem onejm = new ComboBoxItem
                        {
                            Content = ValuaName[i].Jname
                        };
                        cmbValua.Items.Add(onejm);
                    }
                }
            }
            catch
            {
            }

        }
        /// <summary>
        /// 包裹重量设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkBoxWeight_Checked(object sender, RoutedEventArgs e)
        {
            if (chkBoxWeight.IsChecked == true)
            {
                PkgWight.IsEnabled = true;
                BoxWeightCK.IsChecked = false;
            }
            else
            {
                PkgWight.IsEnabled = false;
            }
        }
        /// <summary>
        /// 包裹大小设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkMeasure_Checked(object sender, RoutedEventArgs e)
        {
            if (chkMeasure.IsChecked == true)
            {
                NumericUpDownPkgLength.IsEnabled = true;
                NumericUpDownPkgWidth.IsEnabled = true;
                NumericUpDownPkgHight.IsEnabled = true;
            }
            else
            {
                NumericUpDownPkgLength.IsEnabled = false;
                NumericUpDownPkgWidth.IsEnabled = false;
                NumericUpDownPkgHight.IsEnabled = false;
            }
        }
        /// <summary>
        /// 库存设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkStock_Checked(object sender, RoutedEventArgs e)
        {
            if (chkStock.IsChecked == true)
            {
                NumericUpDownKuchen.IsEnabled = true;
            }
            else
            {
                NumericUpDownKuchen.IsEnabled = false;
            }
        }
        /// <summary>
        /// 促销时间设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkHotTime_Checked(object sender, RoutedEventArgs e)
        {
            //if (chkHotTime.IsChecked == true)
            //{
            //    CanvasHotTime.IsEnabled = true;
            //}
        }
        /// <summary>
        /// 促销时间未设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChkHotTime_Unchecked(object sender, RoutedEventArgs e)
        {
            //if (chkHotTime.IsChecked == false)
            //{
            //    CanvasHotTime.IsEnabled = false;
            //}
        }

        /// <summary>
        /// 调整促销时间
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAdjustTime_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(StartDate.PickedDateTime) || string.IsNullOrEmpty(EndDate.PickedDateTime))
            {
                //设置调整的时间范围
                DateTime dt0 = DateTime.Now.AddHours(1);
                StartDate.PickedDateTime = dt0.ToString("yyyy-MM-dd HH:00:00");
                EndDate.PickedDateTime = dt0.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");

            }
            else
            {
                try
                {
                    //调整时间
                    DateTime[] tms = adjustTimes(DateTime.Parse(StartDate.PickedDateTime), DateTime.Parse(EndDate.PickedDateTime));

                    StartDate.PickedDateTime = tms[0].AddHours(1).ToString("yyyy-MM-dd HH:00:00");
                    EndDate.PickedDateTime = tms[1].AddHours(1).ToString("yyyy-MM-dd HH:00:00");
                }
                catch
                {
                }
            }
        }
        //调整时间差 ，当开始时间早于电脑时间时  ，开始时间改为当前时间并 按以前设定的时间差设置结束时间
        public static DateTime[] adjustTimes(DateTime BeginTime, DateTime Endtime)
        {
            if (BeginTime == null || Endtime == null)
            {
                return new DateTime[] { BeginTime, Endtime };
            }
            if (BeginTime.CompareTo(Endtime) > 0)
            {
                return new DateTime[] { BeginTime, Endtime };
            }

            TimeSpan Timeinterval = Endtime.Subtract(BeginTime);

            DateTime now = DateTime.Now;

            if (now.CompareTo(BeginTime) > 0)  //早于开始时间
            {
                return new DateTime[] { now, now.AddTicks(Timeinterval.Ticks) };
            }
            else
            {
                return new DateTime[] { BeginTime, Endtime };
            }

        }

        /// <summary>
        /// 包裹重量范围设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BoxWeightCK_Checked(object sender, RoutedEventArgs e)
        {
            NumericUpDownConditionWeight.IsEnabled = true;
            NumericUpDownActionWeight.IsEnabled = true;
            cmboBoxCondition.IsEnabled = true;
            comboBoxAction.IsEnabled = true;
            chkBoxWeight.IsChecked = false;
        }
        /// <summary>
        /// 包裹重量范围
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BoxWeightCK_Unchecked(object sender, RoutedEventArgs e)
        {
            NumericUpDownConditionWeight.IsEnabled = false;
            NumericUpDownActionWeight.IsEnabled = false;
            cmboBoxCondition.IsEnabled = false;
            comboBoxAction.IsEnabled = false;
        }
        /// <summary>
        /// 促销时间设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartDate_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {
            if (StartDate.PickedDateTime == null || EndDate.PickedDateTime == null) return;

            try
            {
                DateTime now = DateTime.Now;
                DateTime BeginTime = DateTime.Parse(StartDate.PickedDateTime);

                DateTime EndTime = BeginTime.AddMonths(1);

                if (string.IsNullOrEmpty(EndDate.PickedDateTime))
                {
                    EndDate.PickedDateTime = EndTime.ToString("yyyy-MM-dd HH:00:00");
                }

                EndTime = DateTime.Parse(EndDate.PickedDateTime);
                //时间间隔
                TimeInterval(BeginTime, EndTime);


                if (now.CompareTo(BeginTime) > 0)//设置的开始时间晚于当前时间
                {
                    StartDate.BorderBrush = new SolidColorBrush(Color.FromRgb(255, 0, 0));
                }
                else
                {
                    StartDate.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }


                if (BeginTime.CompareTo(EndTime) > 0)//设置的开始时间晚于结束时间
                {
                    EndDate.BorderBrush = new SolidColorBrush(Color.FromRgb(255, 0, 0));
                }
                else
                {
                    EndDate.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }


            }
            catch
            {
                MessageBox.Show("时间设置错误");
                return;
            }
        }
        //显示时间间隔
        private void TimeInterval(DateTime _BeginTime, DateTime _EndTime)
        {
            int hours = (_EndTime - _BeginTime).Hours;
            int days = (_EndTime - _BeginTime).Days;

            lblTimelength.Content = string.Format("{0}D{1}H", days, hours);
        }

        private void viblM1hkeC(object sender, RoutedEventArgs e)
        {

        }

        private void KxGl3D9EJU(object sender, SelectionChangedEventArgs e)
        {

        }

        private void UdklvHhQRn(object sender, RoutedEventArgs e)
        {

        }

        private void ruNlSIpe3Q(object sender, EventArgs e)
        {

        }

        private void BtnSelect_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {

        }

        private void LblCategoryTi_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

        }
        private void CloseWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void Top_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
