﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// WaittingImg.xaml 的交互逻辑
    /// </summary>
    public partial class WaittingImg : UserControl
    {
        private Storyboard story;

        public WaittingImg()
        {
            InitializeComponent();
            this.story = (base.Resources["waiting"] as Storyboard);
        }
        public WaittingImg(string _str)
        {
            InitializeComponent();
            this.story = (base.Resources["waiting"] as Storyboard);
            tips.Content = _str;
        }

        public void setTips(string _str)
        {
            tips.Content = _str;
        }

        public void startWaitting()
        {
            this.story.Begin(this.waittingImage, true);
            this.waittingImage.Visibility = Visibility.Visible;
        }

        public void pauseWaitting()
        {
            this.story.Pause(this.waittingImage);
            //this.waittingImage.Visibility = Visibility.Hidden;
        }

        public void hideWaitting()
        {
            this.story.Pause(this.waittingImage);
            this.waittingImage.Visibility = Visibility.Collapsed;
        }

        public override string ToString()
        {
            return "";
        }


    }
}
