﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Logic.SystemSole;
using Logic.Translation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.AlertHelp;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// ChoiceCategory.xaml 的交互逻辑
    /// </summary>
    public partial class ChoiceCategory : Window
    {
        private CategorySelector selector = null;
        #region 过滤掉已经有的属性
        List<string> attrlist = new List<string>
            {
                "name",
                "short_description",
                "description",
                "video",
                "size",
                "SellerSku",
                "barcode_ean",
                //"product_warranty",
                "quantity",
                "name_ms",
                "product_warranty_en",
                "price",
                "special_price",
                "special_from_date",
                "special_to_date",
                "description_ms",
                "seller_promotion",
                "package_content",
                "package_weight",
                "package_length",
                "package_width",
                "package_height",
                "__images__",
                //"tax_class",
                "published_date",
                "external_url",
                "std_search_keywords"
            };

        #endregion
        List<Aattribute> categoryOtherAttrs = new List<Aattribute>();
        string oldSreachContect = "";

        public ChoiceCategory()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            txtChecked.Text = "选中" + SystemSoleEntity.SelectedProductNumberList.Count + "行";
        }

        //确定按钮
        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            string leafid = Convert.ToString(lblCategoryResult.Tag);
            string namePath = Convert.ToString(lblCategoryResult.Content);
            string tax = "";
            JArray jarray2 = new JArray();
            foreach (var item in categoryOtherAttrs)
            {
                if (item.Avalue != string.Empty && item.Aname != string.Empty)
                {
                    if (item.Aname == "tax_class")
                    {
                        tax = item.Avalue;
                    }
                    JObject jobject = new JObject();
                    jobject.Add("name", item.Aname);
                    jobject.Add("value", item.Avalue);
                    jarray2.Add(jobject);

                }
            }
            var attr = JsonConvert.SerializeObject(jarray2);
            List<Product> products = new List<Product>();
            var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            foreach (var product in list)
            {
                //var product = SystemSoleEntity.GetProductList().Where(p => p.Number == item).First();
                if (product.Pstatetype == "1") continue;
                product.LazadaCategoryTreePath = selector.treePath;
                product.Lazadacategoryid = leafid;
                product.Lazadacategorynamepath = namePath;
                product.Lazadaattributs = attr;
                product.Lazadatax = tax;
                //new ProductCore().UpdateSKUEdit(product);
                products.Add(product);
            }
            if (products.Count > 0)
            {
                if (new ProductCore().UpdateChoiceCategory(products))
                {
                    CMessageBox.Show("更改成功");
                }
                else
                {
                    CMessageBox.Show("保存失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                }
            }
        }

        //选择
        private void BtnSelect_Click(object sender, RoutedEventArgs e)
        {
            this.Pop_category.IsOpen = true;
            bool flag = this.selector == null;
            if (flag)
            {
                this.selector = new CategorySelector();
                this.selector.CategoryChanged += this.CategroyChange;
            }
            this.contentControlCategory.Content = this.selector;
        }

        private void CategroyChange(object sender, RoutedEventArgs e)
        {
            var selector = (CategorySelector)sender;
            string text = selector.namePath.Trim();
            bool flag = string.IsNullOrEmpty(text);
            if (flag)
            {
                this.lblCategoryResult.Content = "无效类目，请重新选择";
            }
            else
            {
                this.lblCategoryResult.Content = text;
                this.lblCategoryResult.Tag = selector.leafId;
            }
            if (selector.leafId.Trim() != string.Empty)
            {
                this.Pop_category.IsOpen = false;
                btnConfirm.IsEnabled = true;
                LoadCategoryDetail(selector.leafId);
            }
        }

        private void LoadCategoryDetail(string leafId)
        {
            JObject jsondata = new LazadaCore().GetCategoryAttr(leafId);
            //Product product = (Product)this.DataContext;
            if (jsondata["data"] == null) return;
            var list = ((JArray)jsondata["data"]).ToList();
            categoryOtherAttrs.Clear();
            WrpPnlProRequired.Children.Clear();
            WrpPnlProChoosable.Children.Clear();
            //SKU 必要属性
            list.Where(p => Convert.ToString(p["attribute_type"]) == "sku").ToList().ForEach(item =>
            {
                if (item["input_type"].ToString() == "singleSelect" && item["is_mandatory"].ToString() == "1" && item["options"].HasValues)
                {
                    //税种
                    if (item["name"].ToString() == "tax_class")
                    {
                        if (item["options"] != null && item["options"].HasValues)
                        {
                            Aattribute aattribute6 = new Aattribute();
                            aattribute6.Aname = item["name"].ToString();
                            aattribute6.IsSku = true;
                            categoryOtherAttrs.Add(aattribute6);
                            caMlKHhf7i(this.WrpPnlProChoosable, (JObject)item, aattribute6);
                        }
                    }
                }
                else
                {
                    if (((item["input_type"].ToString() == "multiSelect" || item["input_type"].ToString() == "multiEnumInput" || item["input_type"].ToString() == "enumInput")
                    && item["is_mandatory"].ToString() == "1" && item["options"].HasValues) ||
                    item["name"].ToString() == "type_screen_guard" || item["name"].ToString() == "material_screen_guard" || item["name"].ToString() == "eyewear_size")
                    {
                        return;
                    }
                    else
                    {
                        Aattribute aattribute5 = new Aattribute();
                        aattribute5.Aname = item["name"].ToString();
                        aattribute5.IsSku = true;
                        if (!attrlist.Contains(aattribute5.Aname))
                            categoryOtherAttrs.Add(aattribute5);
                        if (attrlist.Contains(aattribute5.Aname)) return;
                        if ((int)item["is_mandatory"] == 1)

                        {
                            bool flag43 = !item["label"].ToString().StartsWith("*");
                            if (flag43)
                            {
                                item["label"] = "*" + item["label"].ToString();
                            }
                            caMlKHhf7i(this.WrpPnlProRequired, (JObject)item, aattribute5);
                        }
                        else

                        {
                            caMlKHhf7i(this.WrpPnlProChoosable, (JObject)item, aattribute5);
                        }
                    }
                }
            });
            //sku 非必要属性
            list.Where(p => Convert.ToString(p["attribute_type"]) != "sku").ToList().ForEach(item =>
            {
                if (attrlist.Contains(item["name"].ToString())) return;
                Aattribute aattribute5 = new Aattribute();
                aattribute5.Aname = item["name"].ToString();
                aattribute5.IsSku = (int)item["is_mandatory"] == 1;
                if (!attrlist.Contains(aattribute5.Aname))
                    categoryOtherAttrs.Add(aattribute5);
                bool flag42 = (int)item["is_mandatory"] == 1;
                if (flag42)

                {
                    bool flag43 = !item["label"].ToString().StartsWith("*");
                    if (flag43)
                    {
                        item["label"] = "*" + item["label"].ToString();
                    }
                    this.caMlKHhf7i(this.WrpPnlProRequired, (JObject)item, aattribute5);
                }
                else

                {
                    this.caMlKHhf7i(this.WrpPnlProChoosable, (JObject)item, aattribute5);
                }

            });
        }


        private void caMlKHhf7i(WrapPanel wp, JObject att, Aattribute od)
        {
            int num = 0;
            Canvas canvas = new Canvas();
            canvas.Height = 25.0;
            canvas.Width = 250;
            if (att["label"].ToString().StartsWith("*") || att["attribute_type"].ToString() == "sku")
            {
                canvas.Background = new SolidColorBrush(Color.FromArgb(170, byte.MaxValue, 204, 153));
            }
            else
            {
                canvas.Background = new SolidColorBrush(Color.FromRgb(210, 225, 210));
            }
            canvas.Margin = new Thickness(4.0, 0.0, 0.0, 2.0);
            canvas.DataContext = od;
            Label label = new Label();
            bool flag2 = att["CHlabel"] == null;
            if (flag2)
            {
                label.Content = att["label"].ToString();
            }
            else
            {
                label.Content = att["CHlabel"].ToString();
                label.ToolTip = att["label"].ToString();
            }
            bool flag3 = att["label"].ToString().Length > 15;
            if (flag3)
            {
                label.ToolTip = att["label"].ToString();
                num = 50;
            }
            label.HorizontalAlignment = HorizontalAlignment.Left;
            canvas.Children.Add(label);
            label.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
            //label.MouseEnter += this.aaQlO13fOX;

            //label.MouseLeave += this.LArlUJbNoF;

            label.MouseDoubleClick += this.AttributeDoubleClick;

            string a = att["input_type"].ToString();
            if (!(a == "numeric") && !(a == "text"))

            {
                if (!(a == "multiSelect"))
                {
                    if (!(a == "singleSelect"))
                    {
                        TextBox textBox = new TextBox();
                        textBox.Height = 22.0;
                        textBox.Width = (double)(120);
                        textBox.Margin = new Thickness((double)(130), 2.0, 0.0, 0.0);
                        //textBox.LostFocus += this.NFAl5Wf0JS;
                        Binding binding = new Binding("Avalue");
                        binding.Mode = BindingMode.TwoWay;
                        binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                        textBox.SetBinding(TextBox.TextProperty, binding);
                        canvas.Children.Add(textBox);
                    }
                    else
                    {
                        ComboBox comboBox = new ComboBox();
                        comboBox.Height = 22.0;
                        comboBox.Width = (double)(120);
                        comboBox.Margin = new Thickness((double)(130), 2.0, 0.0, 0.0);
                        comboBox.Tag = od;
                        JArray jarray = (JArray)att["options"];
                        bool flag4 = jarray.Count > 0;
                        if (flag4)

                        {
                            label.Tag = new FyLabel("", label, comboBox, att);
                            ObservableCollection<OptionItem> observableCollection = new ObservableCollection<OptionItem>();
                            observableCollection.Add(new OptionItem
                            {
                                EnName = " ",
                                ChName = " "
                            });
                            int num2 = -1;
                            for (int i = 0; i < jarray.Count; i++)
                            {
                                string text = ((JObject)jarray[i])["name"].ToString();
                                string chName = text;
                                bool flag5 = ((JObject)jarray[i])["CHname"] != null;
                                if (flag5)
                                {
                                    bool flag6 = !string.IsNullOrEmpty(((JObject)jarray[i])["CHname"].ToString());
                                    if (flag6)
                                    {
                                        chName = ((JObject)jarray[i])["CHname"].ToString();
                                    }
                                }
                                OptionItem item = new OptionItem
                                {
                                    EnName = text,
                                    ChName = chName
                                };
                                observableCollection.Add(item);
                                bool flag7 = od.Avalue == text;
                                if (flag7)
                                {
                                    num2 = observableCollection.IndexOf(item);
                                }
                            }
                            comboBox.ItemsSource = observableCollection;
                            comboBox.DisplayMemberPath = "ChName";
                            comboBox.SelectedValuePath = "EnName";
                            comboBox.SelectionChanged += this.i36lhTIgPS;
                            bool flag8 = num2 >= 0 && comboBox.Items.Count > num2;
                            if (flag8)
                            {
                                comboBox.SelectedIndex = num2;
                            }
                        }
                        else

                        {
                            Binding binding2 = new Binding("Avalue");
                            binding2.Mode = BindingMode.TwoWay;
                            comboBox.SetBinding(ComboBox.TextProperty, binding2);
                            comboBox.IsEditable = true;
                            comboBox.IsTextSearchEnabled = false;
                            bool flag9 = att["name"].ToString() == "brand";
                            if (flag9)

                            {
                                TextBox textBox2 = new TextBox();
                                textBox2.Height = 22.0;
                                textBox2.Width = (double)(215 - num);
                                textBox2.KeyDown += this.auClNmcSBP;
                                comboBox.Items.Add(textBox2);
                                //comboBox.GotFocus += this.akgl7QsrYW;
                                WaittingImg waittingImg = new WaittingImg("Enter后开搜索");
                                waittingImg.pauseWaitting();
                                textBox2.Tag = waittingImg;
                            }
                        }
                        canvas.Children.Add(comboBox);
                    }
                }
                else
                {
                    MutiAttrSelector mutiAttrSelector = new MutiAttrSelector();
                    mutiAttrSelector.Height = 22.0;
                    mutiAttrSelector.Width = (double)(120);
                    mutiAttrSelector.Margin = new Thickness((double)(130), 2.0, 0.0, 0.0);
                    mutiAttrSelector.Tag = od;
                    Binding binding3 = new Binding("Avalue");
                    binding3.Mode = BindingMode.TwoWay;
                    mutiAttrSelector.SetBinding(MutiAttrSelector.AttributValueProperty, binding3);
                    mutiAttrSelector.SetBinding(FrameworkElement.ToolTipProperty, binding3);
                    JArray jarray2 = (JArray)att["options"];
                    bool flag10 = jarray2.Count > 0;
                    if (flag10)
                    {
                        label.Tag = new FyLabel("", label, mutiAttrSelector, att);
                        bool flag11 = !string.IsNullOrEmpty(od.Avalue);
                        if (flag11)
                        {
                            List<string> list = new List<string>();
                            string[] array = od.Avalue.Split(new char[]
                                                        {
                                ','
                                                        }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string text2 in array)
                            {
                                bool flag12 = !list.Contains(text2.Trim());
                                if (flag12)
                                {
                                    list.Add(text2.Trim());
                                }
                            }
                            mutiAttrSelector.oldvalues = list;
                        }
                        List<OptionItem> list2 = new List<OptionItem>();
                        for (int k = 0; k < jarray2.Count; k++)
                        {
                            string text3 = ((JObject)jarray2[k])["name"].ToString().Trim();
                            string chName2 = text3;
                            bool flag13 = ((JObject)jarray2[k])["CHname"] != null;
                            if (flag13)
                            {
                                bool flag14 = !string.IsNullOrEmpty(((JObject)jarray2[k])["CHname"].ToString());
                                if (flag14)
                                {
                                    chName2 = ((JObject)jarray2[k])["CHname"].ToString();
                                }
                            }
                            OptionItem item2 = new OptionItem
                            {
                                EnName = text3,
                                ChName = chName2
                            };
                            list2.Add(item2);
                        }
                        mutiAttrSelector.AddOpints(list2);
                    }
                    canvas.Children.Add(mutiAttrSelector);
                }
            }
            else
            {
                TextBox textBox3 = new TextBox();
                textBox3.Height = 22.0;
                textBox3.Width = (double)(120);
                textBox3.Margin = new Thickness((double)(130), 2.0, 0.0, 0.0);
                //textBox3.LostFocus += this.NFAl5Wf0JS;

                Binding binding4 = new Binding("Avalue");

                binding4.Mode = BindingMode.TwoWay;

                binding4.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;

                textBox3.SetBinding(TextBox.TextProperty, binding4);
                canvas.Children.Add(textBox3);
            }
            wp.Children.Add(canvas);
        }


        #region 属性双击翻译
        private void AttributeDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Label label = (Label)sender;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(label.Content.ToString() + "\r\n");
            bool flag = label.Tag != null;
            if (flag)
            {
                FyLabel fyLabel = (FyLabel)label.Tag;
                JArray jarray = (JArray)fyLabel.FYary["options"];
                foreach (JToken jtoken in jarray)
                {
                    stringBuilder.Append(jtoken["name"].ToString() + "\r\n");
                }
                fyLabel.FYstr = stringBuilder.ToString();
                new Thread(new ParameterizedThreadStart(this.AttributeTranslation)).Start(fyLabel);
            }
        }

        public void AttributeTranslation(object d)
        {
            string text = new ALiCore().ChangeEnToZh(((FyLabel)d).FYstr);
            base.Dispatcher.BeginInvoke(new Action<FyLabel, string>(delegate (FyLabel b, string c)
            {
                try
                {
                    bool flag = string.IsNullOrEmpty(c);
                    if (!flag)
                    {
                        Dictionary<string, string> dictionary = new Dictionary<string, string>();
                        string[] strZH = c.Replace("\n", "●").Split('●');
                        string[] strEN = ((FyLabel)b).FYstr.Replace("\n", "●").Split('●');
                        for (int i = 0; i < strEN.Length; i++)
                        {
                            string key = strEN[i].ToString().Trim();
                            string value = strZH.Length > i ? strZH[i].ToString().Trim() : null;
                            bool flag3 = !dictionary.ContainsKey(key);
                            if (flag3)
                            {
                                dictionary.Add(key, value);
                            }
                        }
                        Label fylb = b.FYlb;
                        bool flag4 = dictionary.ContainsKey(fylb.Content.ToString());
                        if (flag4)
                        {
                            fylb.ToolTip = fylb.Content.ToString();
                            fylb.Content = dictionary[fylb.Content.ToString()];
                        }
                        string key2 = b.FYary["label"].ToString();
                        bool flag5 = dictionary.ContainsKey(key2);
                        if (flag5)
                        {
                            b.FYary["CHlabel"] = dictionary[key2];
                        }
                        JArray jarray = (JArray)b.FYary["options"];
                        foreach (JToken jtoken in jarray)
                        {
                            bool flag6 = dictionary.ContainsKey(jtoken["name"].ToString());
                            if (flag6)
                            {
                                jtoken["CHname"] = jtoken["name"].ToString() + "(" + dictionary[jtoken["name"].ToString()] + ")";
                            }
                        }
                        bool flag7 = b.FYcbx != null;
                        if (flag7)
                        {
                            bool flag8 = b.FYcbx is ComboBox;
                            if (flag8)
                            {
                                ComboBox comboBox = (ComboBox)b.FYcbx;
                                foreach (object obj in ((IEnumerable)comboBox.Items))
                                {
                                    OptionItem optionItem = (OptionItem)obj;
                                    bool flag9 = dictionary.ContainsKey(optionItem.EnName);
                                    if (flag9)
                                    {
                                        optionItem.ChName = optionItem.EnName + "(" + dictionary[optionItem.EnName] + ")";
                                    }
                                }
                                comboBox.Items.Refresh();
                                bool flag10 = comboBox.SelectedIndex > 0;
                                if (flag10)
                                {
                                    int selectedIndex = comboBox.SelectedIndex;
                                    comboBox.SelectedIndex = 0;
                                    comboBox.SelectedIndex = selectedIndex;
                                }
                            }
                            else
                            {
                                bool flag11 = b.FYcbx is MutiAttrSelector;
                                if (flag11)
                                {
                                    ((MutiAttrSelector)b.FYcbx).RefreshOpints(dictionary);
                                }
                            }
                        }
                    }
                }
                catch
                {
                }
            }), new object[]
            {
                (FyLabel)d,
                text
            });
        }
        #endregion


        private void i36lhTIgPS(object w, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)w;
            try
            {
                ((Aattribute)comboBox.Tag).Avalue = comboBox.SelectedValue.ToString();
            }
            catch
            {
            }
        }


        private void auClNmcSBP(object d, KeyEventArgs e)
        {
            bool flag = e.KeyboardDevice.IsKeyDown(Key.Return);
            if (flag)
            {
                e.Handled = true;
                TextBox textBox = (TextBox)d;
                bool flag2 = string.IsNullOrEmpty(textBox.Text.Trim());
                if (!flag2)
                {
                    WaittingImg waittingImg = (WaittingImg)textBox.Tag;
                    waittingImg.setTips("搜索中......");
                    waittingImg.startWaitting();
                    if (oldSreachContect == textBox.Text || textBox.Text.Trim() == string.Empty)
                        return;
                    oldSreachContect = textBox.Text;
                    ComboBox comboBox = (ComboBox)textBox.Parent;
                    comboBox.Items.Clear();
                    comboBox.Items.Add(textBox);
                    comboBox.Items.Add(textBox.Tag);
                    textBox.Focus();
                    Task.Run(() =>
                    {
                        var jsondata = new LazadaCore().GetBrands();
                        if (jsondata == null)
                        {
                            this.Dispatcher.BeginInvoke(new Action<TextBox>(delegate (TextBox b)
                            {
                                ((WaittingImg)b.Tag).setTips("查无结果");
                                ((WaittingImg)b.Tag).pauseWaitting();
                            }), new object[] { d });
                        }
                        else
                        {
                            base.Dispatcher.BeginInvoke(new Action<TextBox, JObject>(delegate (TextBox b, JObject c)
                            {
                                ((WaittingImg)b.Tag).setTips("继续请按Enter");
                                ((WaittingImg)b.Tag).pauseWaitting();
                                try
                                {
                                    string value = b.Text.Trim().ToLower();
                                    JArray jarray = (JArray)c["data"];
                                    foreach (JToken jtoken in jarray)
                                    {
                                        if (jtoken["name"].ToString().ToLower().StartsWith(value))
                                        {
                                            comboBox.Items.Insert(2, jtoken["name"].ToString());
                                        }
                                    }
                                }
                                catch
                                {
                                }
                            }), new object[] { d, jsondata });
                        }
                    });

                }
            }
        }


    }
}
