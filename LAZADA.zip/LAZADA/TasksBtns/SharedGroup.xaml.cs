﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// SharedGroup.xaml 的交互逻辑
    /// </summary>
    public partial class SharedGroup : Window
    {
        public SharedGroup()
        {
            InitializeComponent();
        }

        private void TxtFilePath_MouseLeave(object sender, MouseEventArgs e)
        {

        }

        private void BtnSavePath_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnBegin_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
