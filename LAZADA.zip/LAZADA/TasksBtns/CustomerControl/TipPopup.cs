﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.CustomerControl
{
    static class Extensions
    {

        public static void ShowTipPopup(this FrameworkElement _ui, params object[] _objs)
        {
            if (_ui == null) return;
            TipPopup.Show(_ui, _objs);
        }

    }


    class TipPopup
    {
        //单实例
        private static Popup mypupop;

        private static StackPanel stp;

        private static Path myPath;

        private TipPopup() { }

        public static void Show(FrameworkElement _ui, params object[] _objs)
        {
            if (mypupop == null)
            {
                mypupop = new Popup();
                Grid grd = new Grid();
                mypupop.Child = grd;

                Border bder = new Border();
                bder.Margin = new Thickness(0, 9, 0, 0);
                bder.BorderThickness = new System.Windows.Thickness(1);
                bder.BorderBrush = new SolidColorBrush(Color.FromArgb(0xFF, 0x98, 0x9c, 0x48));
                bder.CornerRadius = new CornerRadius(5);
                bder.Background = new SolidColorBrush(Color.FromArgb(0xFF, 0xE5, 0xED, 0xBA));
                bder.Padding = new Thickness(15, 10, 15, 20);
                grd.Children.Add(bder);


                stp = new StackPanel();
                stp.Orientation = Orientation.Vertical;
                bder.Child = stp;


                PathFigure myPathFigure0 = new PathFigure();
                myPathFigure0.IsClosed = true;
                myPathFigure0.StartPoint = new Point(20, 10);
                PathSegmentCollection myPathSegmentCollection0 = new PathSegmentCollection();
                myPathSegmentCollection0.Add(new LineSegment(new Point(30, 0), true));
                myPathSegmentCollection0.Add(new LineSegment(new Point(40, 10), true));
                myPathSegmentCollection0.Add(new LineSegment(new Point(20, 10), false));  //画个闭合三角形
                myPathFigure0.Segments = myPathSegmentCollection0;

                PathFigureCollection myPathFigureCollection = new PathFigureCollection();
                myPathFigureCollection.Add(myPathFigure0);

                PathGeometry myPathGeometry = new PathGeometry();
                myPathGeometry.Figures = myPathFigureCollection;

                myPath = new Path();
                myPath.Stroke = new SolidColorBrush(Color.FromArgb(0xFF, 0x98, 0x9c, 0x48));
                myPath.StrokeThickness = 1;
                myPath.Fill = new SolidColorBrush(Color.FromArgb(0xFF, 0xE5, 0xED, 0xBA));
                myPath.Data = myPathGeometry;

                // Add path shape to the UI.
                //myPath.Margin = new Thickness(10, 0, 0, 0);
                myPath.VerticalAlignment = VerticalAlignment.Top;
                myPath.HorizontalAlignment = HorizontalAlignment.Left;
                grd.Children.Add(myPath);

                // mypupop.PlacementTarget = ui;
                mypupop.Placement = PlacementMode.Bottom;
                mypupop.PopupAnimation = PopupAnimation.Fade;
                mypupop.StaysOpen = false;
                mypupop.AllowsTransparency = true;
                mypupop.MouseLeave += (s, e) => { ((Popup)s).IsOpen = false; };
            }




            mypupop.PlacementTarget = _ui;

            stp.Children.Clear();
            foreach (var str in _objs)
            {
                if (str is string)
                {
                    string[] lstr = ((string)str).Split('\n');
                    foreach (var sstr in lstr)
                    {
                        Label lb = new Label();
                        lb.Content = sstr;
                        stp.Children.Add(lb);
                    }
                }

                if (str is FrameworkElement)
                {
                    stp.Children.Add((FrameworkElement)str);
                }
            }

            int boffset = _ui.Width > 300 ? (int)_ui.Width / 4 : 0;

            myPath.Margin = new Thickness(boffset, 0, 0, 0);


            mypupop.IsOpen = false;
            mypupop.IsOpen = true;


        }




    }
}
