﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.CustomerControl
{
    /// <summary>
    /// SkuImgListBox.xaml 的交互逻辑
    /// </summary>
    public partial class SkuImgListBox : UserControl
    {
        //选中时，外部控件要给件响应
        // public delegate void SelecedmeDelegate( object _obj);
        //创建一个委托实例 
        // public SelecedmeDelegate myDel;
        //声明一个事件
        //   public event SelecedmeDelegate EventSelecedme;
        //事件触发机制(必须和事件在同一个类中) 外界无法直接用EventSelecedme()来触发事件
        public static readonly RoutedEvent DeleteAllImgSkuImgListBoxEvent = EventManager.RegisterRoutedEvent("DeleteAllImgSkuImgListBox", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(SkuImgListBox));
        public static readonly RoutedEvent CopyOneSkuImgListBoxEvent = EventManager.RegisterRoutedEvent("CopyOneSkuImgListBox", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(SkuImgListBox));
        public static readonly RoutedEvent CopyAllSkuImgListBoxEvent = EventManager.RegisterRoutedEvent("CopyAllSkuImgListBox", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(SkuImgListBox));
        //为事件加个包装
        public event RoutedEventHandler DeleteAllImgSkuImgListBox
        {
            add { AddHandler(DeleteAllImgSkuImgListBoxEvent, value); }
            remove { RemoveHandler(DeleteAllImgSkuImgListBoxEvent, value); }
        }

        public event RoutedEventHandler CopyOneSkuImgListBox
        {
            add { AddHandler(CopyOneSkuImgListBoxEvent, value); }
            remove { RemoveHandler(CopyOneSkuImgListBoxEvent, value); }
        }

        public event RoutedEventHandler CopyAllSkuImgListBox
        {
            add { AddHandler(CopyAllSkuImgListBoxEvent, value); }
            remove { RemoveHandler(CopyAllSkuImgListBoxEvent, value); }
        }


        private System.Windows.Shapes.Rectangle selectRect0 = null;
        private bool needMove0 = false;

        public int maximgcount = 8;

        int[] mainimgsize = new int[] { 0, 0 };

        public int imgcount = 0;




        public string id = "";

        private string _lazadaSkuZuohe = string.Empty;

        public string LazadaSkuZuohe
        {
            get
            {
                return _lazadaSkuZuohe;
            }
            set
            {
                if (value != null)
                {
                    _lazadaSkuZuohe = value;
                    skuImgListSpTips.Text = value;
                }

            }
        }

        public string ChColor = "";

        public JObject skuimginfo = new JObject();

        public string skuConbinName = string.Empty;



        private bool isChecked = false;
        public bool IsChecked
        {
            get { return isChecked; }
            set
            {

                if (value)
                {
                    checkedThisImgList();
                }
                else
                {
                    unCheckedThisImgList();
                }


                isChecked = value;

            }

        }


        public SkuImgListBox()
        {
            InitializeComponent();
        }

        public SkuImgListBox(JObject _skuimginfo)
        {
            InitializeComponent();

            if (_skuimginfo["sku"] == null) return;
            if (!_skuimginfo["sku"].HasValues) return;

            if (((JArray)_skuimginfo["sku"]).Count < 1) return;

            skuimginfo = _skuimginfo;

            List<string> tempname = new List<string>();

            foreach (JToken jt in ((JArray)_skuimginfo["sku"]))
            {
                tempname.Add(jt["value"].ToString());

            }

            if (tempname.Count > 0)
            {
                LazadaSkuZuohe = "[" + string.Join(" ◆ ", tempname.ToArray()) + "]";
            }
            else
            {
                return;
            }

            if (_skuimginfo["leftimages"] != null && _skuimginfo["leftimages"].HasValues)
            {
                List<string> limg = new List<string>();
                foreach (string jtx in (JArray)_skuimginfo["leftimages"])
                {
                    limg.Add(jtx);
                }

                addImgLeft(limg.ToArray());
            }


        }







        //一个委托响应
        public void isChoosedMe(string _col)
        {


        }


        public int getImgCount()
        {
            return skuImgListStackpanel.Children.Count;
        }



        //异步图片加载完成时
        private void BitmapImage_DownloadCompleted(object sender, EventArgs e)
        {
            refeshCountAndSizeFirst(((BitmapImage)sender).UriSource.AbsolutePath);

        }

        //只异步加载完成 用
        public void refeshCountAndSizeFirst(string _url)
        {
            imgcount = getImgCount();
            if (imgcount > 0)
            {
                for (int i = 0; i < imgcount; i++)
                {
                    System.Windows.Controls.Image aimgblock = ConvertImage.GetChildObject<Image>((Canvas)(skuImgListStackpanel.Children[i]), null);
                    if (i == 0)
                    {
                        if (aimgblock != null)
                        {
                            mainimgsize[0] = (int)(((BitmapImage)(aimgblock.Source)).Width);
                            mainimgsize[1] = (int)(((BitmapImage)(aimgblock.Source)).Height);
                        }
                        else
                        {
                            mainimgsize[0] = 0;
                            mainimgsize[1] = 0;
                        }

                        //  skuImgListImgcountTips.Text = string.Format("[{0}]", imgcount);
                        skuImgListSizeTips.Text = string.Format(" {0}x{1} ", mainimgsize[0], mainimgsize[1]);

                        if (mainimgsize[0] != mainimgsize[1] || mainimgsize[0] < 800 || mainimgsize[1] < 800)
                        {
                            Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255, 255, 0, 0));
                            skuImgListSizeTips.Background = brs;
                        }
                        else
                        {
                            // Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255, 255, 255, 255));
                            skuImgListSizeTips.Background = null;
                        }


                    }

                    if (aimgblock.Tag.ToString().Contains(_url))  //有同地址的对象   不分开处理了
                    {
                        aimgblock.ToolTip = aimgblock.Source.Width.ToString("#") + "X" + aimgblock.Source.Height.ToString("#") + " , " + System.IO.Path.GetFileNameWithoutExtension(_url);


                    }



                }

            }







        }


        //增 删时用
        public void refeshCountAndSize()
        {
            imgcount = getImgCount();
            if (imgcount > 0)
            {
                System.Windows.Controls.Image aimgblock = ConvertImage.GetChildObject<System.Windows.Controls.Image>((Canvas)(skuImgListStackpanel.Children[0]), null);

                // aimgblock.

                if (aimgblock != null)
                {
                    mainimgsize[0] = (int)(((BitmapImage)(aimgblock.Source)).Width);
                    mainimgsize[1] = (int)(((BitmapImage)(aimgblock.Source)).Height);
                }
                else
                {
                    mainimgsize[0] = 0;
                    mainimgsize[1] = 0;
                }
            }
            else
            {
                mainimgsize[0] = 0;
                mainimgsize[1] = 0;
            }


            imgcount = getImgCount();
            skuImgListImgcountTips.Text = string.Format("[{0}]", imgcount);

            //  skuImgListImgcountTips.Text = string.Format("[{0}]", imgcount);
            skuImgListSizeTips.Text = string.Format(" {0}x{1} ", mainimgsize[0], mainimgsize[1]);

            if ((mainimgsize[0] < 500 || mainimgsize[0] > 2000 || mainimgsize[1] < 500 || mainimgsize[1] > 2000) && imgcount > 0)
            {
                Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255, 255, 0, 0));
                skuImgListSizeTips.Background = brs;
            }
            else
            {
                // Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromArgb(255, 255, 255, 255));
                skuImgListSizeTips.Background = null;
            }
        }


        //自已刷新下  内部是本地图的 重新加载下
        public void refeshLocalImg()
        {
            if (skuImgListStackpanel.Children.Count > 0)
            {
                foreach (BorderImageX bdimg in skuImgListStackpanel.Children)
                {
                    bdimg.Refresh();

                }

            }

        }


        //
        public void addColorTips()
        {


        }


        //改变底色
        private void checkedThisImgList()
        {
            Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xff, 0x64, 0xaa, 0xdd));
            skuImgListCanvas.Background = brs;

        }

        private void unCheckedThisImgList()  //FFaaaaaa
        {
            Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xff, 0xaa, 0xaa, 0xaa));
            skuImgListCanvas.Background = brs;

        }

        //向外抛传一个点击事件
        private void UserControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //if (IsChecked) return;
            //  RoutedEventArgs arg = new RoutedEventArgs(MainWindow.SkuImgListSelcetChangedEvent, this);
            //  this.RaiseEvent(arg);


        }



        //清除一行的图片
        public void clearImg()
        {
            if (skuImgListStackpanel.Children.Count > 0)
            {
                foreach (BorderImageX bdimg in skuImgListStackpanel.Children)
                {
                    bdimg.SourceBitmapImage100 = null;
                }
            }

            skuImgListStackpanel.Children.Clear();

            //  refeshCountAndSize();
        }

        public void clearAndAddimgLeft(string[] imgPaths)
        {
            clearImg();
            addImgLeft(imgPaths);

        }

        //添加图片 
        public void addImgLeft(string[] imgPaths)
        {
            addImg(imgPaths, "Left");
        }

        public void addImgRight(string[] imgPaths)
        {
            //  addImg(imgPaths, "Right");
        }

        public void addImg(string[] imgPaths, string _LorR)
        {
            if (imgPaths == null) return;
            if (imgPaths.Length < 1) return;

            for (int i = 0; i < imgPaths.Length && i < 8; i++)
            {
                if (!String.IsNullOrEmpty(imgPaths[i].Trim())) addImg(imgPaths[i].Trim(), _LorR);
            }

        }


        public void addImg(string imgPath, string _LorR)
        {
            if (_LorR != "Left") return;

            if (imgPath.StartsWith("http"))
            {
                // BitmapImage _imgsource = new BitmapImage(new Uri(imgPath, UriKind.Absolute));
                // addImg( _imgsource, imgPath , _LorR);
                //_imgsource.DownloadCompleted += BitmapImage_DownloadCompleted;
                addImgX(imgPath);
            }
            else
            {
                if (System.IO.File.Exists(imgPath))
                {
                    // BitmapImage _imgsource = ConvertImage.FileToBitmapImage(imgPath);
                    // addImg(_imgsource, imgPath , _LorR);
                    addImgX(imgPath);
                }
            }


        }

        public void addImgX(string _imgPath)
        {
            if (skuImgListStackpanel.Children.Count >= maximgcount) return;

            List<string> toldimgs = GetLeftImgPaths();
            if (toldimgs != null && toldimgs.Contains(_imgPath.Trim())) return;


            BorderImageX bdimg = new BorderImageX();
            bdimg.Width = 86;
            bdimg.Height = 86;
            bdimg.IsUsed = false;
            bdimg.SourcePath = _imgPath;

            skuImgListStackpanel.Children.Add(bdimg);

            //  bdimg.MouseLeftButtonDown += Bdimg_MouseLeftButtonDown;
            bdimg.MouseLeftButtonUp += Bdimg_MouseLeftButtonDown;

            bdimg.Deleted += Bdimg_Deleted;


        }

        private void Bdimg_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // e.Handled = true;
            BorderImageX t = (BorderImageX)sender;

            if (t.IsSelected)
            {
                t.IsSelected = false;
                skuImgListStackpanel.Tag = null;
                return;
            }

            if (skuImgListStackpanel.Tag != null)
            {
                if (skuImgListStackpanel.Tag is BorderImageX)
                {
                    BorderImageX tFrom = (BorderImageX)(skuImgListStackpanel.Tag);
                    int tindex = skuImgListStackpanel.Children.IndexOf(t);
                    int tFromIndex = skuImgListStackpanel.Children.IndexOf(tFrom);

                    tFrom.IsSelected = false;

                    if (tindex == 0 && (tFrom.SizeWidth < 800 || tFrom.SizeHeight < 800))
                    {
                        if (!tFrom.SourcePath.StartsWith("http"))
                        {
                            tFrom.ShowTipPopup("主图应大于800x800，此图为" + tFrom.SizeInfo);
                            skuImgListStackpanel.Tag = null;
                            return;
                        }
                    }

                    else if (tFromIndex == 0 && tindex > 0)
                    {
                        BorderImageX tSecond = (BorderImageX)skuImgListStackpanel.Children[1];
                        if (!tSecond.SourcePath.StartsWith("http"))
                        {

                            if (tSecond.SizeWidth < 800 || tSecond.SizeHeight < 800)
                            {
                                // new TipPopup(tSecond, "主图应大于800x800，此图为" + tSecond.SizeInfo).Show();
                                tSecond.ShowTipPopup("主图应大于800x800，此图为" + tSecond.SizeInfo);
                                skuImgListStackpanel.Tag = null;
                                return;
                            }

                        }
                    }


                    skuImgListStackpanel.Children.Remove(tFrom);
                    skuImgListStackpanel.Children.Insert(tindex, tFrom);

                }

                skuImgListStackpanel.Tag = null;

            }
            else
            {
                t.IsSelected = true;
                skuImgListStackpanel.Tag = t;
            }
        }

        private void Bdimg_Deleted(object Sender, RoutedEventArgs e)
        {
            BorderImageX delbix = (BorderImageX)Sender;
            try
            {
                skuImgListStackpanel.Children.Remove(delbix);
            }
            catch
            {

            }
        }

        //弃用
        public void addImg(BitmapImage bitmapImage, String imgPath, string _LorR)
        {
            if (skuImgListStackpanel.Children.Count >= maximgcount) return;

            if (bitmapImage == null) return;
            //放置图和边框
            Canvas acanvas = new Canvas();
            acanvas.Height = 86;
            acanvas.Width = 86;
            acanvas.HorizontalAlignment = HorizontalAlignment.Left;
            acanvas.VerticalAlignment = VerticalAlignment.Top;
            System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(210, 225, 210));
            acanvas.Background = brsA;
            acanvas.Margin = new Thickness(2);
            acanvas.MouseLeftButtonDown += new MouseButtonEventHandler(askuimgCanvas_MouseLeftButtonDown);

            acanvas.MouseEnter += new MouseEventHandler(acanvas_MouseEnter);
            acanvas.MouseLeave += new MouseEventHandler(acanvas_MouseLeave);


            //加图
            System.Windows.Controls.Image aimgblock = new System.Windows.Controls.Image();
            aimgblock.Width = 80;
            aimgblock.Height = 80;
            aimgblock.Margin = new Thickness(2);
            aimgblock.Tag = imgPath;
            aimgblock.ToolTip = bitmapImage.Width.ToString("#") + "X" + bitmapImage.Height.ToString("#") + " , " + System.IO.Path.GetFileNameWithoutExtension(imgPath);

            aimgblock.Source = bitmapImage;
            acanvas.Children.Add(aimgblock);

            acanvas.ToolTip = aimgblock.ToolTip;






            //加图片边框
            System.Windows.Shapes.Rectangle rect = new System.Windows.Shapes.Rectangle();
            rect.Width = 82;
            rect.Height = 82;
            System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(170, 170, 140));
            if (imgPath.StartsWith("http")) brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(240, 140, 30));
            rect.Stroke = brs;
            rect.StrokeThickness = 1;
            rect.Margin = new Thickness(2);
            acanvas.Children.Add(rect);

            //加删除按钮
            Button delBt = new Button();
            //   delBt.Tag = imgPath;
            delBt.Width = 23;
            delBt.Height = 22;
            // delBt.Content = "X";
            delBt.Margin = new Thickness(60, 60, 0, 0);
            // delBt.Visibility = Visibility.Hidden;
            delBt.Background = null;
            delBt.SetResourceReference(Button.StyleProperty, "btnStyle1");
            delBt.Visibility = Visibility.Hidden;
            delBt.Click += new RoutedEventHandler(delBt0_Click);
            acanvas.Children.Add(delBt);

            if (_LorR == "Left")
            {
                skuImgListStackpanel.Children.Add(acanvas);

                imgcount = getImgCount();
                skuImgListImgcountTips.Text = string.Format("[{0}]", imgcount);

                if (imgcount < 2)
                {
                    refeshCountAndSize();
                }

            }
            else
            {
                // skuImgListStackpanel2.Children.Add(acanvas);
            }

            //  if() skuImgListSizeTips = 
            // if(imgcount == 1)
            //     refeshCountAndSize();

        }






        //替换一个图  用本地图片
        public void changeImg(string _oldimgPaht, string _newimgPath)
        {
            if (skuImgListStackpanel.Children.Count > 0)
            {
                List<BorderImageX> cavanlist = new List<BorderImageX>();
                foreach (BorderImageX bdimg in skuImgListStackpanel.Children)
                {

                    if (bdimg.SourcePath.Trim() == _oldimgPaht.Trim())
                    {
                        if (String.IsNullOrEmpty(_newimgPath))
                        {
                            cavanlist.Add(bdimg);  //新路径为空时可以删掉
                        }
                        else
                        {
                            if (System.IO.File.Exists(_newimgPath))
                            {
                                bdimg.Refresh();
                            }
                            else
                            {

                                cavanlist.Add(bdimg);  //新路径图片不存在时可以删掉
                            }
                        }


                    }
                }

                if (cavanlist.Count > 0)
                {
                    foreach (BorderImageX bdimg2 in cavanlist)
                    {
                        bdimg2.SourceBitmapImage100 = null;
                        skuImgListStackpanel.Children.Remove(bdimg2);
                    }

                    cavanlist.Clear();
                    cavanlist = null;
                }

            }

            //  refeshCountAndSize();
        }

        // 图片删一个
        private void delBt0_Click(object sender, RoutedEventArgs e)
        {
            Button delBt = (Button)sender;
            // string filePath = delBt.Tag.ToString();
            // ()(((Canvas)(delBt.Parent)).Parent)

            //  skuImgListStackpanel.Children.Remove((Canvas)(delBt.Parent));

            //  refeshCountAndSize();
            try
            {
                if (((Canvas)delBt.Parent).Parent != null)
                {
                    (((StackPanel)((Canvas)delBt.Parent).Parent)).Children.Remove((Canvas)(delBt.Parent));

                }
            }
            catch
            {

            }

            refeshCountAndSize();
        }

        //返回图片地址
        public List<string> GetLeftImgPaths()
        {
            return GetImgPaths("Left");

        }

        public List<string> GetRightImgPaths()
        {
            //  return GetImgPaths("Right");
            return null;
        }

        public List<string> GetImgPaths(string _LorR)
        {
            if (_LorR == "Left")
            {
                if (skuImgListStackpanel.Children.Count > 0)
                {
                    List<string> pathlist = new List<string>();
                    for (int i = 0; i < skuImgListStackpanel.Children.Count; i++)
                    {
                        if (skuImgListStackpanel.Children[i] is BorderImageX)
                        {
                            string tspath = ((BorderImageX)(skuImgListStackpanel.Children[i])).SourcePath.Trim();
                            if (tspath.Length > 3 && !pathlist.Contains(tspath))
                            {
                                pathlist.Add(tspath);
                            }

                        }
                    }

                    if (pathlist.Count > 0) return pathlist;

                }

            }
            else
            {
                if (skuImgListStackpanel2.Children.Count > 0)
                {
                    List<string> pathlist = new List<string>();
                    for (int i = 0; i < skuImgListStackpanel2.Children.Count; i++)
                    {
                        Image aimgblock = ConvertImage.GetChildObject<Image>((Canvas)(skuImgListStackpanel2.Children[i]), null);
                        if (aimgblock != null)
                        {
                            if (aimgblock.Tag != null && aimgblock.Tag.ToString() != "")
                            {
                                pathlist.Add(aimgblock.Tag.ToString());
                            }

                        }
                    }

                    if (pathlist.Count > 0) return pathlist;

                }

            }

            return null;
        }


        //返回json object 
        public JObject getJsonInfo()
        {
            //   JObject jbs = new JObject();

            // skuimginfo

            List<string> alist = GetImgPaths("Left");
            if (alist == null)
            {
                skuimginfo["leftimages"] = new JArray();
            }
            else
            {
                JArray t = new JArray();
                foreach (string p in alist)
                {
                    t.Add(p);

                }

                skuimginfo["leftimages"] = t;
            }

            skuimginfo["rightimages"] = new JArray();

            return skuimginfo;
        }






        public void acanvas_MouseEnter(object sender, MouseEventArgs e)
        {
            Button delBt = ConvertImage.GetChildObject<Button>(((Canvas)sender), null);
            delBt.Visibility = Visibility.Visible;
        }
        public void acanvas_MouseLeave(object sender, MouseEventArgs e)
        {
            Button delBt = ConvertImage.GetChildObject<Button>(((Canvas)sender), null);
            delBt.Visibility = Visibility.Hidden;
        }


        //点图片，移动位置用
        public void askuimgCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (needMove0 == true)
            {
                needMove0 = false;

                if (selectRect0 != null)
                {
                    try
                    {
                        Canvas ccanvas = (Canvas)(selectRect0.Parent);
                        if (skuImgListStackpanel.Children.Contains(ccanvas))  //???
                        {
                            if (ccanvas != ((Canvas)sender))
                            {
                                skuImgListStackpanel.Children.Remove(ccanvas);
                                skuImgListStackpanel.Children.Insert(skuImgListStackpanel.Children.IndexOf((Canvas)sender), ccanvas);
                            }

                            ccanvas.Children.Remove(selectRect0);
                            selectRect0 = null;



                        }
                        else
                        {

                            ccanvas.Children.Remove(selectRect0);
                            ((Canvas)sender).Children.Add(selectRect0);
                            needMove0 = true;
                        }
                    }
                    catch
                    {
                        selectRect0 = null;
                    }

                    refeshCountAndSize();

                }



            }
            else
            {
                if (selectRect0 == null)
                {
                    selectRect0 = new System.Windows.Shapes.Rectangle();
                    selectRect0.Width = 86;
                    selectRect0.Height = 86;
                    System.Windows.Media.Brush brs0x = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 0, 255));
                    selectRect0.Stroke = brs0x;
                    selectRect0.StrokeThickness = 2;
                    ((Canvas)sender).Children.Add(selectRect0);

                }
                else
                {
                    // ((Canvas)(selectRect2.Parent)).Children.Remove(selectRect2);
                    //  ((Canvas)(((System.Windows.Controls.Image)sender).Parent)).Children.Add(selectRect2);

                }

                needMove0 = true;

            }


        }

        //工具横条 改变背景色
        private void skuImgListCanvas_MouseEnter(object sender, MouseEventArgs e)
        {
            PART_toolbarpanel.Background = new SolidColorBrush(Color.FromRgb(255, 255, 255));
        }

        private void skuImgListCanvas_MouseLeave(object sender, MouseEventArgs e)
        {
            PART_toolbarpanel.Background = new SolidColorBrush(Color.FromArgb(102, 238, 238, 238));
        }

        //移出自己
        private void skuImgListDelete_MouseUp(object sender, MouseButtonEventArgs e)
        {
            //   RoutedEventArgs arg = new RoutedEventArgs(DeleteSkuImgListBoxEvent, this);
            //  this.RaiseEvent(arg);
        }
        //清自己的图片
        private void skuImgDelete_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            clearImg();
        }

        //复制上一行的图片
        private void ButtonCopyOne_Click(object sender, RoutedEventArgs e)
        {
            //SkuImgListBox _self = (SkuImgListBox)sender;  
            RoutedEventArgs arg = new RoutedEventArgs(CopyOneSkuImgListBoxEvent, this);
            this.RaiseEvent(arg);

        }
        //复制图片到下面的所有行
        private void ButtonCopyAll_Click(object sender, RoutedEventArgs e)
        {
            RoutedEventArgs arg = new RoutedEventArgs(CopyAllSkuImgListBoxEvent, this);
            this.RaiseEvent(arg);
        }
        //复制上一行的图片
        private void Label_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            RoutedEventArgs arg = new RoutedEventArgs(CopyOneSkuImgListBoxEvent, this);
            this.RaiseEvent(arg);
        }
        //复制图片到下面的所有行
        private void Label_MouseDoubleClick_1(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            RoutedEventArgs arg = new RoutedEventArgs(CopyAllSkuImgListBoxEvent, this);
            this.RaiseEvent(arg);

        }
        //清除其下面行的图片
        private void Label_MouseDoubleClick_2(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            RoutedEventArgs arg = new RoutedEventArgs(DeleteAllImgSkuImgListBoxEvent, this);
            this.RaiseEvent(arg);
        }


    }
}
