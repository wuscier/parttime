﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns.CustomerControl
{
    /// <summary>
    /// 按照步骤 1a 或 1b 操作，然后执行步骤 2 以在 XAML 文件中使用此自定义控件。
    ///
    /// 步骤 1a) 在当前项目中存在的 XAML 文件中使用该自定义控件。
    /// 将此 XmlNamespace 特性添加到要使用该特性的标记文件的根 
    /// 元素中: 
    ///
    ///     xmlns:MyNamespace="clr-namespace:LAZADA.TasksBtns.CustomerControl"
    ///
    ///
    /// 步骤 1b) 在其他项目中存在的 XAML 文件中使用该自定义控件。
    /// 将此 XmlNamespace 特性添加到要使用该特性的标记文件的根 
    /// 元素中: 
    ///
    ///     xmlns:MyNamespace="clr-namespace:LAZADA.TasksBtns.CustomerControl;assembly=LAZADA.TasksBtns.CustomerControl"
    ///
    /// 您还需要添加一个从 XAML 文件所在的项目到此项目的项目引用，
    /// 并重新生成以避免编译错误: 
    ///
    ///     在解决方案资源管理器中右击目标项目，然后依次单击
    ///     “添加引用”->“项目”->[浏览查找并选择此项目]
    ///
    ///
    /// 步骤 2)
    /// 继续操作并在 XAML 文件中使用控件。
    ///
    ///     <MyNamespace:BorderImage/>
    ///
    /// </summary>
    public class BorderImageX : ContentControl
    {
        static BorderImageX()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(BorderImageX), new FrameworkPropertyMetadata(typeof(BorderImageX)));
        }

        public delegate void UsedEventHandler(object Sender, RoutedEventArgs e);
        public static readonly RoutedEvent UsedEvent = EventManager.RegisterRoutedEvent("UsedEvent", RoutingStrategy.Bubble, typeof(UsedEventHandler), typeof(BorderImageX));
        public event UsedEventHandler Used
        {
            add
            {
                AddHandler(UsedEvent, value);
            }
            remove
            {
                RemoveHandler(UsedEvent, value);
            }
        }

        public delegate void UnUsedEventHandler(object Sender, RoutedEventArgs e);
        public static readonly RoutedEvent UnUsedEvent = EventManager.RegisterRoutedEvent("UnUsedEvent", RoutingStrategy.Bubble, typeof(UnUsedEventHandler), typeof(BorderImageX));
        public event UnUsedEventHandler UnUsed
        {
            add
            {
                AddHandler(UnUsedEvent, value);
            }
            remove
            {
                RemoveHandler(UnUsedEvent, value);
            }
        }

        public delegate void DeletedEventHandler(object Sender, RoutedEventArgs e);
        public static readonly RoutedEvent DeletedEvent = EventManager.RegisterRoutedEvent("DeletedEvent", RoutingStrategy.Bubble, typeof(DeletedEventHandler), typeof(BorderImageX));
        public event DeletedEventHandler Deleted
        {
            add
            {
                AddHandler(DeletedEvent, value);
            }
            remove
            {
                RemoveHandler(DeletedEvent, value);
            }
        }

        #region  //几个属性
        public static readonly DependencyProperty SourcePathProperty = DependencyProperty.Register("SourcePath", typeof(string), typeof(BorderImageX), new PropertyMetadata(string.Empty));
        public string SourcePath
        {
            get { return (string)GetValue(SourcePathProperty); }
            set { SetValue(SourcePathProperty, value.Trim()); Refresh(); }
        }

        public static readonly DependencyProperty SourceBitmapImage100Property = DependencyProperty.Register("SourceBitmapImage100", typeof(BitmapImage), typeof(BorderImageX), new PropertyMetadata(null));
        public BitmapImage SourceBitmapImage100
        {
            get { return (BitmapImage)GetValue(SourceBitmapImage100Property); }
            set { SetValue(SourceBitmapImage100Property, value); }
        }

        public static readonly DependencyProperty IsNetImgProperty = DependencyProperty.Register("IsNetImg", typeof(bool), typeof(BorderImageX), new PropertyMetadata(false));
        public bool IsNetImg
        {
            get { return (bool)GetValue(IsNetImgProperty); }
            set { SetValue(IsNetImgProperty, value); }
        }


        public static readonly DependencyProperty IsSelectedProperty = DependencyProperty.Register("IsSelected", typeof(bool), typeof(BorderImageX), new PropertyMetadata(false));
        public bool IsSelected
        {
            get { return (bool)GetValue(IsSelectedProperty); }
            set { SetValue(IsSelectedProperty, value); }
        }


        public static readonly DependencyProperty IsUsedProperty = DependencyProperty.Register("IsUsed", typeof(bool), typeof(BorderImageX), new PropertyMetadata(false));
        public bool IsUsed
        {
            get { return (bool)GetValue(IsUsedProperty); }
            set { SetValue(IsUsedProperty, value); }
        }


        public static readonly DependencyProperty IsErrowSizeProperty = DependencyProperty.Register("IsErrowSize", typeof(bool), typeof(BorderImageX), new PropertyMetadata(false));
        public bool IsErrowSize
        {
            get { return (bool)GetValue(IsErrowSizeProperty); }
            set { SetValue(IsErrowSizeProperty, value); }
        }

        public static readonly DependencyProperty SizeInfoProperty = DependencyProperty.Register("SizeInfo", typeof(string), typeof(BorderImageX), new PropertyMetadata(string.Empty));
        public string SizeInfo
        {
            get { return (string)GetValue(SizeInfoProperty); }
            set { SetValue(SizeInfoProperty, value); }
        }

        public int SizeWidth = 0;
        public int SizeHeight = 0;


        #endregion
        // System.Windows.Controls.Image Imgblock;

        public void Refresh()
        {
            if (!string.IsNullOrEmpty(SourcePath))
            {
                if (SourcePath.StartsWith("http"))
                {
                    this.IsNetImg = true;
                    SourceBitmapImage100 = new BitmapImage(new Uri(SourcePath, UriKind.Absolute));
                    // SourceBitmapImage100.DownloadCompleted += SourceBitmapImage_DownloadCompleted;
                }
                else if (File.Exists(SourcePath))
                {
                    this.IsNetImg = false;
                    ConvertImage.FileToBitmapImage100(this);
                }

            }

        }



        #region OnApplyTemplate
        private Label DeleteLabel;
        private CheckBox UsedCheckBox;

        public bool ShowCheck = false;

        public sealed override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            DeleteLabel = GetPartFormTemplate<Label>("PART_DeleteLabel");
            UsedCheckBox = GetPartFormTemplate<CheckBox>("PART_UsedCheckBox");

            if (ShowCheck) UsedCheckBox.Visibility = Visibility.Visible;

            this.MouseEnter += BorderImageX_MouseEnter;
            this.MouseLeave += BorderImageX_MouseLeave;

            DeleteLabel.MouseDoubleClick += DeleteLabel_MouseDoubleClick;
            DeleteLabel.MouseLeftButtonDown += DeleteLabel_MouseLeftButtonDown;
            UsedCheckBox.Checked += UsedCheckBox_Checked;
            UsedCheckBox.Unchecked += UsedCheckBox_Unchecked;
        }

        private void BorderImageX_MouseLeave(object sender, MouseEventArgs e)
        {
            if (DeleteLabel != null) DeleteLabel.Visibility = Visibility.Collapsed;
        }

        private void BorderImageX_MouseEnter(object sender, MouseEventArgs e)
        {
            if (DeleteLabel != null) DeleteLabel.Visibility = Visibility.Visible;
        }

        private void DeleteLabel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
        }

        private void UsedCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
            RaiseEvent(new RoutedEventArgs(UnUsedEvent));
        }

        private void UsedCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
            RaiseEvent(new RoutedEventArgs(UsedEvent));
        }

        private void DeleteLabel_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            RaiseEvent(new RoutedEventArgs(DeletedEvent));
        }

        private T GetPartFormTemplate<T>(string name)
        {
            return (T)Template.FindName(name, this);
        }


        #endregion









    }
}
