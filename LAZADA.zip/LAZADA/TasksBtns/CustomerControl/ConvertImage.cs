﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace LAZADA.TasksBtns.CustomerControl
{
    class ConvertImage
    {

        public static int _sycavW = 25;
        public static int _sycavH = 20;

        public static int _textpt = 0;
        public static int _fbcolor = 0;
        public static int _tpos = 0;



        public static BitmapImage FileToBitmapImageLess(string _filePath)
        {
            try
            {
                BitmapImage bitmapImage = new BitmapImage(); //初始化BitmapImage类的一个新实例
                bitmapImage.BeginInit(); //表示BitmapImage初始化开始
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.UriSource = new Uri(_filePath);//获取或设置BitmapImage的Uri源
                bitmapImage.EndInit();//表示BitmapImage初始化结束

                return bitmapImage;
            }
            catch
            {
                return null;
            }
        }


        public static BitmapImage FileToBitmapImage(string _filePath)
        {
            try
            {
                System.IO.FileStream fs = new System.IO.FileStream(_filePath, System.IO.FileMode.Open, System.IO.FileAccess.Read);
                byte[] buffer = new byte[fs.Length];
                fs.Read(buffer, 0, buffer.Length);
                fs.Close();
                fs.Dispose();

                System.IO.MemoryStream ms = new System.IO.MemoryStream(buffer);
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = ms;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();
                ms.Dispose();
                return bitmapImage;
            }
            catch
            {
                return null;
            }
        }


        public static Bitmap BitmapSourceToBitmap(BitmapSource source)
        {
            using (var stream = new MemoryStream())
            {
                var e = new BmpBitmapEncoder();
                e.Frames.Add(BitmapFrame.Create(source));
                e.Save(stream);

                var bmp = new Bitmap(stream);

                return bmp;
            }
        }


        public static BitmapImage BitmapToBitmapImage(System.Drawing.Bitmap bitmap)
        {
            if (bitmap == null) return null;
            try
            {
                BitmapImage bitmapImage = new BitmapImage();

                using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                {
                    bitmap.Save(ms, ImageFormat.Bmp);
                    bitmapImage.BeginInit();
                    bitmapImage.StreamSource = ms;
                    bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapImage.EndInit();
                    bitmapImage.Freeze();
                }

                return bitmapImage;
            }
            catch
            {
                return null;
            }
        }

        public static BitmapImage BitmapPNGToBitmapImage(System.Drawing.Bitmap bitmap)
        {
            if (bitmap == null) return null;
            try
            {
                BitmapImage bitmapImage = new BitmapImage();

                using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                {
                    bitmap.Save(ms, ImageFormat.Png);
                    bitmapImage.BeginInit();
                    bitmapImage.StreamSource = ms;
                    bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapImage.EndInit();
                    bitmapImage.Freeze();
                }

                return bitmapImage;
            }
            catch
            {
                return null;
            }
        }

        public static BitmapImage BitmapJPGToBitmapImage(System.Drawing.Bitmap bitmap)
        {
            if (bitmap == null) return null;
            try
            {
                BitmapImage bitmapImage = new BitmapImage();

                using (System.IO.MemoryStream ms = new System.IO.MemoryStream())
                {
                    bitmap.Save(ms, ImageFormat.Jpeg);
                    bitmapImage.BeginInit();
                    bitmapImage.StreamSource = ms;
                    bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapImage.EndInit();
                    bitmapImage.Freeze();
                }

                return bitmapImage;
            }
            catch
            {
                return null;
            }
        }

        public static Bitmap loadCloneBitmap(string _filePath)
        {
            Image image = Image.FromFile(_filePath);
            Bitmap cloneImage = new Bitmap(image);
            image.Dispose();
            return cloneImage;
        }

        public static BitmapImage FileToBitmapImage100(string _filePath)
        {
            Image image = Image.FromFile(_filePath);
            //Bitmap cloneImage = new Bitmap(image);
            int newWidth = 100;
            int newHight = 100;
            if (image.Width >= image.Height)
            {
                newHight = newWidth * image.Height / image.Width;

            }
            else
            {
                newWidth = newHight * image.Width / image.Height;
            }


            Bitmap bmpOut = new Bitmap(newWidth, newHight);
            Graphics g = Graphics.FromImage(bmpOut);
            g.DrawImage(image, new System.Drawing.Rectangle(0, 0, newWidth, newHight), new System.Drawing.Rectangle(0, 0, image.Width, image.Height), GraphicsUnit.Pixel);
            g.Dispose();

            image.Dispose();

            BitmapImage newBtimg = BitmapToBitmapImage(bmpOut);

            bmpOut.Dispose();

            return newBtimg;

        }

        public static void FileToBitmapImage100(BorderImageX _bdimg)
        {
            try
            {
                Image image = Image.FromFile(_bdimg.SourcePath);
                _bdimg.SizeInfo = string.Format("{0}x{1}", image.Width, image.Height);
                _bdimg.SizeWidth = image.Width;
                _bdimg.SizeHeight = image.Height;


                _bdimg.ToolTip = _bdimg.SizeInfo;
                try
                {
                    _bdimg.ToolTip = _bdimg.SizeInfo + " , " + System.IO.Path.GetFileNameWithoutExtension(_bdimg.SourcePath);
                }
                catch
                { }


                //Bitmap cloneImage = new Bitmap(image);
                int newWidth = 100;
                int newHight = 100;
                if (image.Width >= image.Height)
                {
                    newHight = newWidth * image.Height / image.Width;

                    if (image.Width > 2000 || image.Height < 500)
                    {
                        _bdimg.IsErrowSize = true;
                    }
                    else
                    {
                        _bdimg.IsErrowSize = false;
                    }
                }
                else
                {
                    newWidth = newHight * image.Width / image.Height;

                    if (image.Height > 2000 || image.Width < 500)
                    {
                        _bdimg.IsErrowSize = true;
                    }
                    else
                    {
                        _bdimg.IsErrowSize = false;
                    }
                }


                // _bdimg.SourceBitmapImage100 =  FileToBitmapImageLess(_bdimg.SourcePath);

                // return;

                Bitmap bmpOut = new Bitmap(newWidth, newHight);
                Graphics g = Graphics.FromImage(bmpOut);
                g.DrawImage(image, new System.Drawing.Rectangle(0, 0, newWidth, newHight), new System.Drawing.Rectangle(0, 0, image.Width, image.Height), GraphicsUnit.Pixel);
                g.Dispose();

                image.Dispose();

                _bdimg.SourceBitmapImage100 = BitmapToBitmapImage(bmpOut);

                bmpOut.Dispose();

            }
            catch
            {

            }

        }

        public static void PngToJpeg(string _pngpath, string _jpegpath)
        {
            try
            {
                if (!File.Exists(_pngpath)) return;
                Image img = Image.FromFile(_pngpath);
                // Assumes myImage is the PNG you are converting
                using (var b = new Bitmap(img.Width, img.Height))
                {
                    b.SetResolution(img.HorizontalResolution, img.VerticalResolution);

                    using (var g = Graphics.FromImage(b))
                    {
                        g.Clear(System.Drawing.Color.White);
                        g.DrawImageUnscaled(img, 0, 0);
                    }

                    // Now save b as a JPEG like you normally would
                    b.Save(_jpegpath, System.Drawing.Imaging.ImageFormat.Jpeg);
                }
            }
            catch
            {

            }
        }


        //参数类型是Image对象，返回Byte[] 类型: 
        public static byte[] ImageTobyteArray(Bitmap imgPhoto)
        {
            //将Image转换成流数据，并保存为byte[] 
            MemoryStream mstream = new MemoryStream();
            imgPhoto.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg);
            byte[] byData = new Byte[mstream.Length];
            mstream.Position = 0;
            mstream.Read(byData, 0, byData.Length);
            mstream.Close();
            return byData;
        }


        public static string upedImgID(byte[] _imgData)
        {

            return null;

        }
        public static Bitmap drawRactang(Bitmap _img, int _sposx, int _sposy, int _w, int _h)
        {
            Graphics gp = Graphics.FromImage(_img);    // 绑定画板 

            Image blankimg = new Bitmap(_w, _h);
            Graphics g = Graphics.FromImage(blankimg);
            g.Clear(System.Drawing.Color.White); //清除画布,背景设置为白色
            g.Dispose();

            Rectangle oldRect1 = new System.Drawing.Rectangle(0, 0, _w, _h);

            Rectangle newRect1 = new System.Drawing.Rectangle(_sposx, _sposy, _w, _h);

            gp.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Default;
            gp.DrawImage(blankimg, newRect1, oldRect1, GraphicsUnit.Pixel);

            gp.Dispose();

            return _img;



        }


        public static Bitmap drawText(string _text, Bitmap _oldimg)
        {
            if (_oldimg == null || _text.Trim() == "" || _text.Trim() == "-") return null;
            Bitmap _img = new Bitmap(_oldimg);
            string text = _text;
            System.Drawing.Color frontColor;
            System.Drawing.Color backColor;
            System.Drawing.Point tpos;
            int textpt = 50;

            switch (_textpt)
            { //自动 加大 缩小
                case 0:
                    textpt = _img.Width / 12;
                    break;
                case 1:
                    textpt = _img.Width / 10;
                    break;
                case 2:
                    textpt = _img.Width / 14;
                    break;
                default:
                    textpt = 50;
                    break;
            }

            if (textpt < 5) textpt = 5;
            switch (_fbcolor)
            { //黄色 黑色 白色 蓝色 红色 绿色
                case 0:
                    frontColor = System.Drawing.Color.Yellow;
                    backColor = System.Drawing.Color.Blue;
                    break;
                case 1:
                    frontColor = System.Drawing.Color.Black;
                    backColor = System.Drawing.Color.White;
                    break;
                case 2:
                    frontColor = System.Drawing.Color.White;
                    backColor = System.Drawing.Color.Black;
                    break;
                case 3:
                    frontColor = System.Drawing.Color.Blue;
                    backColor = System.Drawing.Color.Red;
                    break;
                case 4:
                    frontColor = System.Drawing.Color.Red;
                    backColor = System.Drawing.Color.Blue;
                    break;
                case 5:
                    frontColor = System.Drawing.Color.Green;
                    backColor = System.Drawing.Color.Blue;
                    break;

                default:
                    frontColor = System.Drawing.Color.Yellow;
                    backColor = System.Drawing.Color.Blue;
                    break;

            }
            switch (_tpos)
            { //左上 右上 左下 右下
                case 0:
                    tpos = new System.Drawing.Point(1, 1);
                    break;
                case 1:
                    //   MessageBox.Show(pictureBox4.Image.Width.ToString());
                    tpos = new System.Drawing.Point(_img.Width - (textpt * text.Length), 1);
                    break;
                case 2:
                    tpos = new System.Drawing.Point(1, _img.Height - textpt * 2);
                    break;
                case 3:
                    tpos = new System.Drawing.Point(_img.Width - (textpt * text.Length), _img.Height - textpt * 2);
                    break;
                default:
                    tpos = new System.Drawing.Point(1, 1);
                    break;

            }



            //  Bitmap timg = new Bitmap(pictureBox4.Image);
            Graphics gp = Graphics.FromImage(_img);    // 绑定画板 
            gp.DrawString(text, new System.Drawing.Font("Verdana", textpt), new SolidBrush(backColor),
            new System.Drawing.Point(tpos.X + 2, tpos.Y + 2));
            gp.DrawString(text, new System.Drawing.Font("Verdana", textpt), new SolidBrush(frontColor), tpos);
            //pictureBox4.Image = timg;
            gp.Dispose();

            return _img;

        }

        //在白底上叠图片
        public static Bitmap HeapBitMap(Bitmap[] _imgs)
        {
            if (_imgs.Length < 1) return null;
            try
            {
                int _w = _imgs.Select(n => n.Width).Max();
                int _h = _imgs.Select(n => n.Height).Max();

                System.Drawing.Image blankimg = new Bitmap(_w, _h);
                Graphics g = Graphics.FromImage(blankimg);
                g.Clear(System.Drawing.Color.White); //清除画布,背景设置为白色

                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Default;

                for (int i = 0; i < _imgs.Length; i++)
                {
                    g.DrawImage(_imgs[i], new System.Drawing.Point(0, 0));
                }

                g.Dispose();

                return (Bitmap)blankimg;
            }
            catch
            {
                return null;
            }


        }

        //保存图片
        public static Bitmap HeapWhiteBitMap(Bitmap _imgs)
        {
            try
            {
                int _w = _imgs.Width;
                int _h = _imgs.Height;

                System.Drawing.Image blankimg = new Bitmap(_w, _h);
                Graphics g = Graphics.FromImage(blankimg);
                g.Clear(System.Drawing.Color.White); //清除画布,背景设置为白色

                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Default;

                g.DrawImage(_imgs, new System.Drawing.Point(0, 0));

                g.Dispose();

                return (Bitmap)blankimg;
            }
            catch
            {
                return null;
            }


        }


        /// <summary>
        /// 有偏移的剪切
        /// </summary>
        /// <param name="oldBp">内容来源图</param>
        /// <param name="bgStartX">从画布的哪个点开始画</param>
        /// <param name="bgStartY">从画布的哪个点开始画</param>
        /// <param name="bgWidth">画布宽</param>
        /// <param name="bgHeight">画布高</param>
        /// <param name="imgStartX">从来源图片的哪个点开始取内容</param>
        /// <param name="imgStartY">从来源图片的哪个点开始取内容</param>
        /// <param name="imgIWidth">所取内容宽</param>
        /// <param name="imgIHight">所取内容高/param>
        /// <returns></returns>

        public static Bitmap KiCutX(Bitmap oldBp, int bgWidth, int bgHeight, int bgStartX, int bgStartY, int imgStartX, int imgStartY, int imgIWidth, int imgIHight)
        {
            if (oldBp == null)
            {
                return null;
            }

            try
            {
                Bitmap bmpOut = new Bitmap(bgWidth, bgHeight);
                Graphics g = Graphics.FromImage(bmpOut);
                g.FillRectangle(System.Drawing.Brushes.White, new Rectangle(0, 0, bgWidth, bgHeight)); //加白底

                g.DrawImage(oldBp, new Rectangle(bgStartX, bgStartY, imgIWidth, imgIHight), new Rectangle(imgStartX, imgStartY, imgIWidth, imgIHight), GraphicsUnit.Pixel);
                g.Dispose();
                return bmpOut;
            }
            catch
            {
                return oldBp;
            }
        }

        /// <summary>
        /// 剪裁 -- 用GDI+
        /// </summary>
        /// <param name="b">原始Bitmap</param>
        /// <param name="StartX">开始坐标X</param>
        /// <param name="StartY">开始坐标Y</param>
        /// <param name="iWidth">宽度</param>
        /// <param name="iHeight">高度</param>
        /// <returns>剪裁后的Bitmap</returns>

        public static Bitmap KiCut(Bitmap oldBp, int StartX, int StartY, int iWidth, int iHeight)
        {
            if (oldBp == null)
            {
                return null;
            }
            if (StartX < 0 || StartY < 0 || iWidth < 1 || iHeight < 1)
            {
                return oldBp;
            }
            if (StartX >= oldBp.Width || StartY >= oldBp.Height)
            {
                return oldBp;
            }

            if (StartX + iWidth > oldBp.Width)
            {
                iWidth = oldBp.Width - StartX;
            }
            if (StartY + iHeight > oldBp.Height)
            {
                iHeight = oldBp.Height - StartY;
            }
            try
            {
                //ConsoleManager.Write(string.Format("01KiCut 剪切背景区 =====bpWidth:{0},bpHeight:{1},\n", iWidth, iHeight));
                //ConsoleManager.Write(string.Format("02KiCut 剪切前景区 =====bpWidth:{0},bpHeight:{1},内部偏移 X:{2}, Y:{3}\n", oldBp.Width , oldBp.Height, StartX, StartY));
                Bitmap bmpOut = new Bitmap(iWidth, iHeight);
                Graphics g = Graphics.FromImage(bmpOut);
                g.DrawImage(oldBp, new System.Drawing.Rectangle(0, 0, iWidth, iHeight), new System.Drawing.Rectangle(StartX, StartY, iWidth, iHeight), GraphicsUnit.Pixel);
                g.Dispose();

                //ConsoleManager.Write(string.Format("03KiCut 剪切后的背景区 =====bmpOutW:{0},bmpOutH:{1},\n", bmpOut.Width, bmpOut.Height));

                return bmpOut;
            }
            catch
            {
                //ConsoleManager.Write(string.Format("04KiCut 出错！！！！！ \n"));
                return oldBp;
            }
        }

        //等比放大/缩小图片

        public static Bitmap KiCut(Bitmap oldBp, int _newWidth, int _newHeight)
        {
            try
            {
                if (oldBp == null)
                {
                    return null;
                }



                /*
                if (_newWidth < _newHeight && _newWidth < 500)
                {
                    _newWidth = 600;
                    _newHeight = (int)(_newWidth * oldBp.Height / oldBp.Width);

                }

                if (_newWidth > _newHeight && _newHeight < 500)
                {
                    _newHeight = 600;

                    _newWidth = (int)(_newHeight * oldBp.Width / oldBp.Height);
                }

    */

                Bitmap bmpOut = new Bitmap(_newWidth, _newHeight);
                Graphics g = Graphics.FromImage(bmpOut);
                g.DrawImage(oldBp, new System.Drawing.Rectangle(0, 0, _newWidth, _newHeight), new System.Drawing.Rectangle(0, 0, oldBp.Width, oldBp.Height), GraphicsUnit.Pixel);
                g.Dispose();
                return bmpOut;
            }
            catch
            {
                return oldBp;
            }
        }




        //自动组合来合并图片  PictureBox
        public static Bitmap AutoMergerImg(int _outwidth, int _rows, int _colums, ArrayList _pblist)
        {
            if (_pblist.Count < 2) return null;

            System.Drawing.Image[] curzhupb = new System.Drawing.Image[_pblist.Count];

            for (int i = 0; i < _pblist.Count; i++)
            {
                curzhupb[i] = (System.Drawing.Image)_pblist[i];

            }

            return AutoMergerImg(_outwidth, _rows, _colums, curzhupb);



        }


        public static Bitmap AutoMergerImg(int _outwidth, int _rows, int _colums, params Image[] pbs)
        {

            if (pbs.Length == 0) return null;
            foreach (Image img in pbs)
            {
                if (img == null) return null;

            }


            if (pbs.Length == 1) return new Bitmap(pbs[0]);
            if ((_rows * _colums) <= pbs.Length) return MergerImg(_outwidth, _rows, _colums, pbs);
            Bitmap retImg;
            switch (pbs.Length)
            {
                case 2:
                    if (((pbs[0].Width * pbs[1].Height) + (pbs[1].Width * pbs[0].Height)) > (1.2 * pbs[0].Height * pbs[1].Height))  //太宽（(w1/h1) +(w2/h2)）>1.2
                    { retImg = MergerImg(_outwidth, 2, 1, pbs); } //排成一列
                    else
                    { retImg = MergerImg(_outwidth, 1, 2, pbs); }
                    break;
                case 3:
                    //  if (((pbs[0].Width * pbs[1].Height * pbs[2].Height) + (pbs[1].Width * pbs[0].Height * pbs[2].Height) + (pbs[2].Width * pbs[1].Height * pbs[0].Height)) > (1.3 * pbs[1].Height*pbs[1].Height * pbs[0].Height))//太宽（(w1/h1) +(w2/h2)+(w3/h3)）>1.3
                    //      { retImg = MergerImg(3, 1, pbs); }
                    //      else
                    //      { retImg = MergerImg(1, 3, pbs); }     
                    retImg = MergerImg(_outwidth, 2, 2, appendImg(4, pbs));
                    break;
                case 4:
                    retImg = MergerImg(_outwidth, 2, 2, pbs);
                    break;
                case 5:
                    retImg = MergerImg(_outwidth, 3, 2, appendImg(6, pbs));
                    break;
                case 6:
                    retImg = MergerImg(_outwidth, 3, 2, pbs);
                    break;
                case 7:
                    retImg = MergerImg(_outwidth, 3, 3, appendImg(9, pbs));
                    break;
                case 8:
                    retImg = MergerImg(_outwidth, 3, 3, appendImg(9, pbs));
                    break;
                case 9:
                    retImg = MergerImg(_outwidth, 3, 3, pbs);
                    break;
                case 10:
                    retImg = MergerImg(_outwidth, 4, 3, appendImg(12, pbs));
                    break;
                case 11:
                    retImg = MergerImg(_outwidth, 4, 3, appendImg(12, pbs));
                    break;
                case 12:
                    retImg = MergerImg(_outwidth, 4, 3, pbs);
                    break;
                default:
                    retImg = MergerImg(_outwidth, _rows, _colums, appendImg(_rows * _colums, pbs));
                    break;


            }
            return retImg;


        }



        /// 合并图片 
        public static Bitmap MergerImg(int _outwidth, int _rows, int _colums, params Image[] pbs) //行，列
        {
            if (pbs.Length == 0) return null;
            if (pbs.Length == 1 || (_rows * _colums) > pbs.Length) return new Bitmap(pbs[0]);

            int[] lineheights = new int[_rows];
            //创建要显示的图片对象,根据参数的个数设置宽度
            for (int rx = 0; rx < _rows; rx++)  //确定行高
            {
                if (_colums == 2)
                {
                    if (pbs[(rx * _colums)].Height > 1000 && pbs[(rx * _colums) + 1].Height > 1000)
                    {
                        lineheights[rx] = (int)(_outwidth * pbs[(rx * _colums)].Height * ((Double)(pbs[(rx * _colums) + 1].Height) / ((pbs[(rx * _colums)].Height * pbs[(rx * _colums) + 1].Width) + (pbs[(rx * _colums) + 1].Height * pbs[(rx * _colums)].Width))));
                        // MessageBox.Show("ph0:" + pbs[(rx * _colums)].Height.ToString() + "\r\n" + "ph1:" + pbs[(rx * _colums) + 1].Height.ToString() + "\r\n" + "pW0:" + pbs[(rx * _colums)].Width.ToString() + "\r\n" + "pw1:" + pbs[(rx * _colums) + 1].Width.ToString() + "\r\n" + lineheights[rx].ToString());
                        //  MessageBox.Show(((Double)(pbs[(rx * _colums) + 1].Height) / ((pbs[(rx * _colums)].Height * pbs[(rx * _colums) + 1].Width) + (pbs[(rx * _colums) + 1].Height * pbs[(rx * _colums)].Width))).ToString());
                        // MessageBox.Show(((pbs[(rx * _colums)].Height * pbs[(rx * _colums) + 1].Width) + (pbs[(rx * _colums) + 1].Height * pbs[(rx * _colums)].Width)).ToString());
                    }
                    else
                    {
                        lineheights[rx] = (_outwidth * pbs[(rx * _colums)].Height * pbs[(rx * _colums) + 1].Height) / ((pbs[(rx * _colums)].Height * pbs[(rx * _colums) + 1].Width) + (pbs[(rx * _colums) + 1].Height * pbs[(rx * _colums)].Width));

                    }


                }
                else
                {
                    // lineheights[rx] = 500;
                    lineheights[rx] = (_outwidth * pbs[(rx * _colums)].Height) / (_colums * (pbs[(rx * _colums)].Width));
                    for (int cx = 0; cx < _colums; cx++)
                    {
                        int clineheight = (_outwidth * pbs[(rx * _colums) + cx].Height) / (_colums * pbs[(rx * _colums) + cx].Width);
                        if (lineheights[rx] > clineheight) lineheights[rx] = clineheight;
                    }
                }
            }


            int cpy = 0;
            Bitmap backgroudImg = new Bitmap(_outwidth, lineheights.Sum());
            Graphics g = Graphics.FromImage(backgroudImg);
            g.Clear(System.Drawing.Color.White); //清除画布,背景设置为白色
            for (int r = 0; r < _rows; r++)
            {
                if (r == 0)
                {
                    cpy = 0;
                }
                else
                {
                    cpy += lineheights[r - 1];
                }


                for (int c = 0; c < _colums; c++)
                {
                    int cwidth = lineheights[r] * (pbs[(r * _colums) + c].Width) / (pbs[(r * _colums) + c].Height) + 1;
                    if (_colums == 2)
                    {
                        g.DrawImage(pbs[(r * _colums) + c], (c * (lineheights[r] * (pbs[(r * _colums)].Width) / (pbs[(r * _colums)].Height))) - 1, cpy - 1, cwidth + 1, lineheights[r] + 1);
                    }
                    else
                    {
                        g.DrawImage(pbs[(r * _colums) + c], (_outwidth / _colums) * c + (((_outwidth / _colums) - cwidth) / 2), cpy, cwidth, lineheights[r]);
                    }
                }
            }
            g.Dispose();
            return backgroudImg;
        }
        //补空白图
        public static Image[] appendImg(int _count, params Image[] pbs)
        {
            if (_count <= pbs.Length) return pbs;
            Image[] newpbs = new Image[_count];
            Image blankimg = new Bitmap(100, 100);
            Graphics g = Graphics.FromImage(blankimg);
            g.Clear(System.Drawing.Color.White); //清除画布,背景设置为白色
            g.Dispose();
            for (int i = 0; i < pbs.Length; i++)
            {
                newpbs[i] = pbs[i];
            }
            for (int j = pbs.Length; j < _count; j++)
            {
                newpbs[j] = blankimg;
            }
            return newpbs;

        }



        public static string CreateRandomCode()//验证码生成函数
        {
            string allChar = "0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z";
            string[] allCharArray = allChar.Split(',');
            string randomNum = "";
            int temp = -1;
            Random rand = new Random();
            for (int i = 0; i < 4; i++)
            {
                if (temp != -1)
                {
                    rand = new Random(i * temp * ((int)DateTime.Now.Ticks));
                }
                int t = rand.Next(62);//不要数字的去掉，然后这里做相应修改
                randomNum += allCharArray[t];
            }
            return randomNum;
        }


        /// 获得指定元素的父元素
        /// </summary>
        /// <typeparam name="T">指定页面元素</typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static T GetParentObject<T>(DependencyObject obj) where T : FrameworkElement
        {
            DependencyObject parent = VisualTreeHelper.GetParent(obj);

            while (parent != null)
            {
                if (parent is T)
                {
                    return (T)parent;
                }

                parent = VisualTreeHelper.GetParent(parent);
            }

            return null;
        }

        /// <summary>
        /// 获得指定元素的所有子元素
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static List<T> GetChildObjects<T>(DependencyObject obj) where T : FrameworkElement
        {
            DependencyObject child = null;
            List<T> childList = new List<T>();

            for (int i = 0; i <= VisualTreeHelper.GetChildrenCount(obj) - 1; i++)
            {
                child = VisualTreeHelper.GetChild(obj, i);

                if (child is T)
                {
                    childList.Add((T)child);
                }
                childList.AddRange(GetChildObjects<T>(child));
            }
            return childList;
        }

        /// <summary>
        /// 查找子元素
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static T GetChildObject<T>(DependencyObject obj, string name) where T : FrameworkElement
        {
            DependencyObject child = null;
            T grandChild = null;


            for (int i = 0; i <= VisualTreeHelper.GetChildrenCount(obj) - 1; i++)
            {
                child = VisualTreeHelper.GetChild(obj, i);


                if (child is T && (((T)child).Name == name | string.IsNullOrEmpty(name)))
                {
                    return (T)child;
                }
                else
                {
                    grandChild = GetChildObject<T>(child, name);
                    if (grandChild != null)
                        return grandChild;
                }
            }
            return null;
        }

        public static string convertToZaitu(string cutPath)
        {
            //调窄
            string newimgpathname = System.IO.Path.GetDirectoryName(cutPath) + "\\" + System.IO.Path.GetFileNameWithoutExtension(cutPath) + CreateRandomCode() + ".jpg";//  cutPath.Replace(".jpg" , CreateRandomCode() + ".jpg");
                                                                                                                                                                        //MessageBox.Show(newimgpathname);
            Image bigImg = Image.FromFile(cutPath);
            if (bigImg.Width > 1024)
            {

                Bitmap bmp800 = new Bitmap(800, 800 * bigImg.Height / bigImg.Width);
                Graphics gp800 = Graphics.FromImage(bmp800); // 绑定画板 
                // 原图片的开始绘制位置,及宽和高 (控制Rectangle的组成参数,便可实现对图片的剪切)
                System.Drawing.Rectangle oldRect1 = new System.Drawing.Rectangle(0, 0, bigImg.Width, bigImg.Height);
                // 绘制在新画板中的位置,及宽和高 (在这里是完全填充)  
                System.Drawing.Rectangle newRect1 = new System.Drawing.Rectangle(0, 0, 800, bmp800.Height);
                // 指定新图片的画面质量
                gp800.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Default;
                // 把原图片指定位置的图像绘制到新画板中
                gp800.DrawImage(bigImg, newRect1, oldRect1, GraphicsUnit.Pixel);
                bigImg.Dispose();
                bmp800.Save(newimgpathname, System.Drawing.Imaging.ImageFormat.Jpeg);
                bmp800.Dispose();

                return newimgpathname;
            }

            return cutPath;
        }


        public static void AdjustToLarger(string cutPath)
        {
            string[] Imgs = Directory.GetFiles(cutPath, "*.jpg");
            if (Imgs.Length < 1) { return; }
            foreach (string Img in Imgs)
            {

                Image bigImg;
                try
                {
                    bigImg = Image.FromFile(Img);

                    if (bigImg.Width < 360 || bigImg.Height < 360)
                    {
                        bigImg.Dispose();
                        continue;
                    }


                    if ((bigImg.Width < 500 && bigImg.Height < 900) || (bigImg.Height < 500 && bigImg.Width < 900))
                    {


                        Bitmap bmpOut = new Bitmap((int)(bigImg.Width * 1.6), (int)(bigImg.Height * 1.6));
                        Graphics g = Graphics.FromImage(bmpOut);
                        g.DrawImage(bigImg, new Rectangle(0, 0, bmpOut.Width, bmpOut.Height), new Rectangle(0, 0, bigImg.Width, bigImg.Height), GraphicsUnit.Pixel);
                        g.Dispose();
                        bigImg.Dispose();

                        bmpOut.Save(Img, ImageFormat.Jpeg);
                        bmpOut.Dispose();



                    }

                }
                catch
                {

                    continue;
                }


            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cutPath"></param>
        /// <param name="_forceCut"></param>

        public static void cutImg(string cutPath, bool _forceCut, bool vCut)
        {
            int scanStarPos = 400;
            int scanEndPosToBottom = 160;
            int jumpPixAfterWhite = 40;
            int markOffsetPixAfterWhite = 8;
            int scanStep = 4;
            if (_forceCut)
            {
                scanStarPos = 1;
                scanEndPosToBottom = 4;
                jumpPixAfterWhite = 0;
                markOffsetPixAfterWhite = 0;
                scanStep = 2;

            }



            string _path = cutPath;
            string preImgName = "XSAXX";
            string[] Imgs = Directory.GetFiles(_path, "*.jpg");
            if (Imgs.Length < 1) { return; }

            int ImgsPosi = 0;
            int bigImgs = 0;
            foreach (string Img in Imgs)
            {
                FileInfo fileInfo = new FileInfo(Img);
                //  MessageBox.Show( fileInfo.Length.ToString()); //1字节单位
                if (fileInfo.Length < 1024 * 2)
                {
                    try
                    {
                        File.Delete(Img);
                    }
                    catch
                    {
                        continue;
                    }

                }

                if (System.IO.Path.GetFileNameWithoutExtension(Img).Contains("zt") || System.IO.Path.GetFileNameWithoutExtension(Img).Contains("ys")) continue;


                Image bigImg;
                try
                {
                    bigImg = Image.FromFile(Img);
                }
                catch
                {

                    continue;
                }
                //宽度底于360PIX的图片就删了
                if ((bigImg.Width < 360 || bigImg.Height < 200))
                {
                    bigImg.Dispose();
                    try
                    {
                        File.Delete(Img);
                    }
                    catch
                    {
                        continue;
                    }
                }
                else
                {
                    ImgsPosi++;



                    //调窄
                    if (bigImg.Width > 1200 && bigImg.Width != bigImg.Height)
                    {
                        Bitmap bmp950 = new Bitmap(950, 950 * bigImg.Height / bigImg.Width);
                        Graphics gp950 = Graphics.FromImage(bmp950); // 绑定画板 
                        // 原图片的开始绘制位置,及宽和高 (控制Rectangle的组成参数,便可实现对图片的剪切)
                        System.Drawing.Rectangle oldRect1 = new System.Drawing.Rectangle(0, 0, bigImg.Width, bigImg.Height);
                        // 绘制在新画板中的位置,及宽和高 (在这里是完全填充)  
                        System.Drawing.Rectangle newRect1 = new System.Drawing.Rectangle(0, 0, 950, bmp950.Height);
                        // 指定新图片的画面质量
                        gp950.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Default;
                        // 把原图片指定位置的图像绘制到新画板中
                        gp950.DrawImage(bigImg, newRect1, oldRect1, GraphicsUnit.Pixel);
                        bigImg.Dispose();
                        bmp950.Save(Img, System.Drawing.Imaging.ImageFormat.Jpeg);
                        bmp950.Dispose();
                        bigImg = Image.FromFile(Img);

                    }

                    if (bigImg.Height < 1812 && (!_forceCut))
                    {
                        preImgName = Path.GetFileNameWithoutExtension(Img);
                        bigImg.Dispose();
                    }
                    else
                    {

                        bigImgs++;
                        bool whiteBefore = false;  //上一次是白线吗
                        int whiteBeforePos = 0; //上一次是白线的位置
                        ArrayList marks = new ArrayList();
                        marks.Add(0);



                        Bitmap bp = new Bitmap(bigImg.Width, bigImg.Height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                        Graphics gh = Graphics.FromImage(bp);
                        gh.DrawImage(bigImg, 0, 0, bigImg.Width, bigImg.Height);

                        if (vCut == true)
                        {

                            bp.RotateFlip(RotateFlipType.Rotate90FlipNone);

                            //  bp.Save(_path + "\\" + Path.GetFileNameWithoutExtension(Img) + "-90.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                        }

                        //   MessageBox.Show("bpW:" + bp.Width.ToString() + "---------" + "bpH:" + bp.Height.ToString());

                        //顺时针旋转90度     RotateFlipType.Rotate90FlipNone
                        //逆时针旋转90度     RotateFlipType.Rotate270FlipNone
                        //水平翻转    RotateFlipType.Rotate180FlipY
                        //垂直翻转    RotateFlipType.Rotate180FlipX

                        for (int hpix = scanStarPos; hpix < bp.Height - scanEndPosToBottom; hpix += scanStep)
                        {
                            bool isWhiteLeft = true;
                            bool isWhiteRight = true;
                            bool mark = true;
                            Random ran = new Random();
                            int ran1 = 1;
                            int ran2 = 2;
                            try
                            {
                                ran1 = ran.Next(10, bp.Width / 2);  //水平线上取点
                                ran2 = ran.Next(bp.Width / 2, bp.Width - 10);

                            }
                            catch
                            {
                                continue;
                            }
                            //左边点检查
                            for (int i = ran1; i < ran1 + 4; i++)
                            {
                                bool canEixt4X4 = false;
                                for (int k = hpix; k < hpix + scanStep; k++)
                                {
                                    System.Drawing.Color pixelColor = bp.GetPixel(i, k);
                                    // MessageBox.Show(pixelColor.R.ToString());
                                    if (pixelColor.R < 240 || pixelColor.G < 240 || pixelColor.B < 240)
                                    {
                                        canEixt4X4 = true;
                                        isWhiteLeft = false;
                                        mark = false;
                                        break;
                                    }
                                }
                                if (canEixt4X4 == true) break;
                            }
                            //右边点检查
                            if (isWhiteLeft == true)
                            {
                                for (int j = ran2; j < ran2 + 4; j++)
                                {
                                    bool canEixt4X4 = false;
                                    for (int k = hpix; k < hpix + scanStep; k++)
                                    {
                                        System.Drawing.Color pixelColor = bp.GetPixel(j, k);
                                        // MessageBox.Show(pixelColor.R.ToString());
                                        if (pixelColor.R < 240 || pixelColor.G < 240 || pixelColor.B < 240)
                                        {
                                            canEixt4X4 = true;
                                            isWhiteRight = false;
                                            mark = false;
                                            break;
                                        }
                                    }
                                    if (canEixt4X4 == true) break;
                                }
                            }

                            if (isWhiteLeft == true && isWhiteRight == true)
                            {
                                for (int m = 10; m < bp.Width - 10; m += 2)
                                {
                                    bool canEixt4W = false;
                                    //  for (int n = hpix; n < hpix + 4; n++)
                                    for (int n = hpix; n < hpix + scanStep; n++)
                                    {
                                        System.Drawing.Color pixelColor = bp.GetPixel(m, n);
                                        // MessageBox.Show(pixelColor.R.ToString());
                                        if (pixelColor.R < 240 || pixelColor.G < 240 || pixelColor.B < 240)
                                        {
                                            canEixt4W = true;
                                            mark = false;
                                            break;
                                        }
                                    }
                                    if (canEixt4W == true) break;

                                }

                            }



                            if (mark == false && whiteBefore == false)
                            {
                                if ((hpix - whiteBeforePos) > 1300)
                                {
                                    whiteBeforePos += 800;
                                    marks.Add(whiteBeforePos);
                                    marks.Add(whiteBeforePos + 1);
                                }
                                continue;
                            }
                            if (mark == true && whiteBefore == true)
                            {
                                hpix += jumpPixAfterWhite;
                            }
                            if (mark == true && whiteBefore == false)
                            {
                                //MessageBox.Show("mark:" + mark.ToString() + "\t" + "whiteBefore:" + whiteBefore.ToString());
                                //   gh.DrawLine(new Pen(Color.Green), 0, hpix + 8, bp.Width, hpix + 8);
                                whiteBefore = true;
                                if ((hpix + markOffsetPixAfterWhite + scanStep) < bp.Height - scanEndPosToBottom)
                                {
                                    // marks.Add(hpix + markOffsetPixAfterWhite + scanStep);
                                    marks.Add(hpix + markOffsetPixAfterWhite);
                                }
                                else
                                {
                                    marks.Add(hpix + markOffsetPixAfterWhite);
                                }
                                whiteBeforePos = hpix;
                                hpix += jumpPixAfterWhite;
                                continue;
                            }

                            if (mark == false && whiteBefore == true)
                            {

                                whiteBefore = false;
                                //    gh.DrawLine(new Pen(Color.Red), 0, hpix - 20, bp.Width, hpix - 20);
                                marks.Add(hpix - jumpPixAfterWhite);
                                whiteBeforePos = hpix - jumpPixAfterWhite;
                                hpix += jumpPixAfterWhite;
                                continue;
                            }
                        }

                        //string filename = _path + "\\" + Path.GetFileNameWithoutExtension(Img) + "-X" + ".jpg";
                        //  bp.Save(filename, System.Drawing.Imaging.ImageFormat.Jpeg);
                        // string maks = "";
                        marks.Add(bp.Height);
                        for (int i = 0; i < marks.Count / 2; i++)
                        {
                            // maks += marks[i * 2].ToString() + "---" + marks[i * 2 + 1].ToString() + "\n"; 

                            //宽度底于360PIX的图片就删了
                            if ((Convert.ToInt32(marks[i * 2 + 1]) - Convert.ToInt32(marks[i * 2])) < 150)
                            {
                                continue;
                            }


                            System.Drawing.Rectangle oldRect = new System.Drawing.Rectangle(0, Convert.ToInt32(marks[i * 2]), bp.Width, Convert.ToInt32(marks[i * 2 + 1]) - Convert.ToInt32(marks[i * 2]));
                            // 绘制在新画板中的位置,及宽和高 (在这里是完全填充)  
                            System.Drawing.Rectangle newRect = new System.Drawing.Rectangle(0, 0, bp.Width, Convert.ToInt32(marks[i * 2 + 1]) - Convert.ToInt32(marks[i * 2]));
                            // 指定新图片的画面质量


                            // Bitmap bmSmall = new Bitmap(bp.Width, Convert.ToInt32(marks[i * 2 + 1]) - Convert.ToInt32(marks[i * 2]), System.Drawing.Imaging.PixelFormat.Format24bppRgb);

                            Bitmap bmSmall = new Bitmap(newRect.Width, newRect.Height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

                            Graphics ghSmall = Graphics.FromImage(bmSmall);
                            // 原图片的开始绘制位置,及宽和高 (控制Rectangle的组成参数,便可实现对图片的剪切)

                            ghSmall.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                            // 把原图片指定位置的图像绘制到新画板中
                            ghSmall.DrawImage((Image)bp, newRect, oldRect, GraphicsUnit.Pixel);

                            if (vCut == true)
                            {

                                bmSmall.RotateFlip(RotateFlipType.Rotate270FlipNone);

                            }
                            //  bp.RotateFlip(RotateFlipType.Rotate90FlipNone);

                            //分割后的小图的序号，小于10的序号要补前缀0.
                            string srialNO = (i + 1).ToString("0#");
                            //保存图片到当前文件夹
                            string smallFilename;
                            if (_forceCut)
                            {
                                if (Path.GetFileNameWithoutExtension(Img).Split('_').Length < 6)
                                {
                                    smallFilename = _path + "\\" + Path.GetFileNameWithoutExtension(Img) + "_" + srialNO + ".jpg";
                                }
                                else
                                {
                                    smallFilename = _path + "\\D" + ImgsPosi.ToString("0#") + srialNO + "-" + DateTime.Now.ToString("mmss") + ".jpg";
                                }
                            }
                            else
                            {
                                smallFilename = _path + "\\" + Path.GetFileNameWithoutExtension(Img) + "-" + srialNO + ".jpg";

                            }

                            bmSmall.Save(smallFilename, System.Drawing.Imaging.ImageFormat.Jpeg);
                            ghSmall.Dispose();
                            bmSmall.Dispose();


                        }

                        // dscImgshtml.Append("<br height=12 />");
                        // Clipboard.SetDataObject(maks);
                        // MessageBox.Show(maks);
                        bigImg.Dispose();
                        gh.Dispose();
                        bp.Dispose();


                        try
                        {
                            //当前文件夹下新建  HigImg 文件夹，并移动大图到此文件下
                            if (!Directory.Exists(_path + "\\原图CI"))
                            {
                                Directory.CreateDirectory(_path + "\\原图CI");
                            }
                            File.Delete(_path + "\\原图CI\\" + Path.GetFileName(Img));
                            File.Move(Img, _path + "\\原图CI\\" + Path.GetFileName(Img));
                        }
                        catch
                        {


                        }

                    }//(bigImg.Height > 1210)



                }


            } //foreach



        }


    }
}
