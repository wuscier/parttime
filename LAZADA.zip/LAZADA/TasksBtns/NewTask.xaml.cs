﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Link;
using Logic.Platform;
using Logic.PriceTemplate;
using Logic.SystemSole;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// NewTask.xaml 的交互逻辑
    /// </summary>
    public partial class NewTask : Window
    {
        /// <summary>
        /// 是否有批量任正在执行，不让同时执行多个批量任务
        /// </summary>
        private bool isBulking = false;
        NewTaskViewModel ownVM = null;
        List<string> collectList = new List<string>();

        /// <summary>
        /// 可以开始采集的链接列表
        /// </summary>
        private List<Product> canCollectList = new List<Product>();
        public NewTask()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            cmbSynchronic.SelectedIndex = 0;
            ownVM = new NewTaskViewModel();
            this.DataContext = ownVM;
        }

        private void Top_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void CloseWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
        private void BtnAddUrl_Click(object sender, RoutedEventArgs e)
        {
            //判断当前是否有链接
            if (txtUrlBox.Text.Trim() == string.Empty)
            {
                return;
            }
            ////判断当前是否有任务
            //if (isBulking)
            //{
            //    CMessageBox.Show("当前有批量任正在执行，请稍后");
            //    return;
            //}
            //判断当前图片保存路径是否存在
            if (txtImgPath.Text.Trim() == string.Empty)
            {
                CMessageBox.Show("图片保存路径不能为空");
                return;
            }
            else
            {
                var str = new IOHelp().CheckDirectory(txtImgPath.Text);
                if (str.Length > 0)
                {
                    CMessageBox.Show(str);
                    return;
                }
            }
            //获取当前链接数量
            int count = txtUrlBox.Text.Trim().Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries).Length;
            //判断剩余添加数是否足够
            //if (count > Convert.ToInt32(new AmountCore().GetRemainAmount()))
            //{
            //    CMessageBox.Show("添加数不足,添加失败.", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
            //    //CMessageBox.Show("添加数不足,添加失败.");
            //    return;
            //}
            //异步委托，进行添加
            //this.Dispatcher.BeginInvoke(new Action(() =>
            //{
            canCollectList.Clear();
            //canCollectList.AddRange(new GetLinkCore().AddNewLinks(txtUrlBox, (PriceTemplateEntity)cmbValuateMde.SelectedItem, chkRemove.IsChecked ?? false, txtImgPath.Text, ownVM));
            txtUrlBox.Foreground = new SolidColorBrush(Colors.DimGray);
            //GetMyBlance();
            //lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    lblLinkCount.Content = 0;
            //}));
            //if (canCollectList.Count > 0)
            //{
            //    txtUrlBox.Dispatcher.BeginInvoke(new Action(() =>
            //    {
            //        txtUrlBox.AppendText($"\n检查完毕... 共{canCollectList.Count} 条数据可以采集");
            //        new AmountCore().ReduceAmount();
            //    }));
            //    btnAddUrl.Visibility = Visibility.Hidden;
            //    btnCollect.Visibility = Visibility.Visible;
            //}
            //}));
            var links = txtUrlBox.Text.Trim().Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries).ToList();
            bool checkRepeat = chkRemove.IsChecked ?? false;
            var pc = new ProductCore();
            var ftc = new FromTypeCore();
            var hbc = new HummingbirdCore();
            var priceTemplate = (PriceTemplateEntity)cmbValuateMde.SelectedItem;
            var imagePath = txtImgPath.Text;

            List<string> addLinks = new List<string>();
            List<Task> tasks = new List<Task>();
            var add = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(100) / links.Count));
            ownVM.Msg = "开始检查链接";
            Task.Run(() =>
            {
                ownVM.BarValue += 0;
                Thread.Sleep(200);
                for (int i = links.Count - 1; i >= 0; i--)
                {
                    ownVM.BarValue += add;
                    ownVM.Counts = links.Count;
                    ownVM.BarContent = (links.Count - i) + "/" + links.Count;
                    Thread.Sleep(200);
                    //检查链接
                    var linkInfo = ftc.GetFromTypeByLink(links[i]);
                    if (linkInfo == null)
                    {
                        ownVM.Msg += $"\n{links[i]}链接未匹配到平台";
                        continue;
                    }
                    if (addLinks.Contains(linkInfo[1]) && checkRepeat)
                    {
                        ownVM.Msg += $"\n{links[i]}链接重复存在,需要重复添加,请去掉下方去重勾选";
                        continue;
                    }
                    if (!pc.CheckLinkExists(linkInfo[2]) && checkRepeat)
                    {
                        ownVM.Msg += $"\n{links[i]}链接重复存在,需要重复添加,请去掉下方去重勾选";
                        continue;
                    }
                    if (!collectList.Contains(links[i]))
                    {
                        if (!hbc.CheckPoint(links[i], linkInfo[0]))
                        {
                            ownVM.Msg += $"\n{links[i]}用户积分不足,手动添加的采集链接新增失败";
                            continue;
                        }
                    }
                    addLinks.Add(links[i]);
                    //Task task = new Task(() =>
                    //{
                    Product product = new Product()
                    {
                        SiteID = GlobalUserClass.SiteId,
                        Number = pc.GetNextProductNumber(),
                        Pfromtype = linkInfo[0],
                        Ppid = linkInfo[1],
                        Poriglink = linkInfo[2],
                        Pidprefix = priceTemplate.Jprfix,
                        Pjisangongshi = priceTemplate.Jname.ToString(),
                        Padddate = DateTime.Now.ToString(),
                        Pusername = GlobalUserClass.uname,
                        Pstate = "未采集",
                        Pstatetype = "0",
                        Lazadaisparent = "1",
                        Plocalimgpath = string.Format(imagePath + "\\" + linkInfo[0] + linkInfo[1]),
                        SKUNumber = pc.GetNextSKUNumberByIdprefix(priceTemplate.Jprfix),
                        Pkuchen = priceTemplate.Jkuchen,
                        PackageLength = priceTemplate.Jpkglength,
                        PackageHight = priceTemplate.Jpkghight,
                        PackageWidth = priceTemplate.Jpkgwidth,
                        Peditdate = DateTime.Now.ToString()
                    };
                    if (pc.AddProduct(product))
                    {
                        canCollectList.Insert(0, product);
                        lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            lblLinkCount.Content = canCollectList.Count;
                        }));
                        SystemSoleEntity.GetProductList().Insert(0, product);
                        //new AmountCore().ReduceAmount();
                    }
                    //    //else
                    //    //{
                    //    //    ownVM.Msg += $"\n {links[i]} 添加失败";
                    //    //}
                    //});
                    //task.Start();
                    //tasks.Add(task);
                }
                GetMyBlance();

                if (canCollectList.Count > 0)
                {
                    btnAddUrl.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        btnAddUrl.Visibility = Visibility.Hidden;
                        btnCollect.Visibility = Visibility.Visible;
                    }));
                }
            });
            //Task.WaitAll(tasks.ToArray());
            //Thread.Sleep(300 * links.Count);
            //foreach (var item in canCollectList)
            //{
            //SystemSoleEntity.GetProductList().Insert(0, item);
            //}
            //GetMyBlance();
            //lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    lblLinkCount.Content = 0;
            //}));
            //if (canCollectList.Count > 0)
            //{
            //    txtUrlBox.Dispatcher.BeginInvoke(new Action(() =>
            //    {
            //        txtUrlBox.AppendText($"\n检查完毕... 共{canCollectList.Count} 条数据可以采集");
            //        new AmountCore().ReduceAmount();
            //    }));

            //}

        }

        private void BtnCollect_Click(object sender, RoutedEventArgs e)
        {
            new LogOutput.LogTo().WriteLine(Constants.Ali1688_ACCESSTOKEN);
            if (canCollectList.Count == 0)
            {
                CMessageBox.Show("当前没有可以采集的链接");
                return;
            }
            btnCollect.IsEnabled = false;
            SystemSoleEntity.GetMainWinModel().InitModel("新增采集", canCollectList.Count);
            bool isDownImg = chkDownImg.IsChecked ?? false;
            GlobalUserClass globalUser = new GlobalUserClass();
            globalUser.RefreshAli1688Token();
            Task.Run(() =>
            {
                Parallel.ForEach(canCollectList, new Action<Product>((product) => {
                    try
                    {
                        //new LogOutput.LogTo().WriteLine(Constants.Ali1688_ACCESSTOKEN);
                        //GlobalUserClass globalUser = new GlobalUserClass();
                        //globalUser.Ref_Sav_AliToken();
                        //new LogOutput.LogTo().WriteLine(Constants.Ali1688_ACCESSTOKEN);
                        new GetLinkCore().DownProductInfo(product, isDownImg);
                        Thread.Sleep(200);
                    }
                    catch (Exception ex)
                    {
                        SystemSoleEntity.GetMainWinModel().IbulkErrowCount++;
                        new LogOutput.LogTo().WriteErrorLine("采集出错：" + product.Porigimgsurl + "///" + ex.Message);
                    }
                    SystemSoleEntity.GetMainWinModel().Ipbvalue += SystemSoleEntity.GetMainWinModel().TaskAdd;
                    SystemSoleEntity.GetMainWinModel().TaskRunCount++;
                }));
                //foreach (var product in canCollectList)
                //{
                    
                //}
            });
        }

        private void TxtImgPath_MouseLeave(object sender, MouseEventArgs e)
        {
            txtImgPath.Text = txtImgPath.Text[txtImgPath.Text.Length - 1] == '\\' ? txtImgPath.Text : (txtImgPath.Text + "\\");
            this.Dispatcher.BeginInvoke(new Action(() => new GetLinkCore().UpdateImageSavePath(txtImgPath.Text)));
        }

        private void BtnPath_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.FolderBrowserDialog fbd = new System.Windows.Forms.FolderBrowserDialog();
            if (System.Windows.Forms.DialogResult.OK == fbd.ShowDialog())
            {
                txtImgPath.Text = fbd.SelectedPath[fbd.SelectedPath.Length - 1] == '\\' ? fbd.SelectedPath : (fbd.SelectedPath + "\\");
                this.Dispatcher.BeginInvoke(new Action(() => new GetLinkCore().UpdateImageSavePath(txtImgPath.Text)));
            }
        }

        private void ChkDownImg_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void ChkDownImg_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InitWin();
        }

        /// <summary>
        /// 加载窗体事件
        /// </summary>
        private void InitWin()
        {
            Task getPriceTemplateTask = new Task(GetPriceTemplates);
            getPriceTemplateTask.Start();
            Task getLinkTask = new Task(GetNewLinks);
            getLinkTask.Start();
            Task getPathTask = new Task(GetImageSavePath);
            getPathTask.Start();
            Task getBlanceTask = new Task(GetMyBlance);
            getBlanceTask.Start();
            this.txtUserName.Text = GlobalUserClass.uname;
        }

        /// <summary>
        /// 进行用户额度剩余值获取
        /// </summary>
        private void GetMyBlance()
        {
            var json = new HummingbirdCore().GetPoints();
            var point = json == null ? "0" : json["result"].ToString();
            lblAdd.Dispatcher.BeginInvoke(new Action(() =>
            {
                //lblAdd.Content = string.Format($"剩余可采集链接数：{new AmountCore().GetRemainAmount()}条。");
                lblAdd.Content = string.Format($"剩余可采集链接数：{point}条。");
            }));

        }

        /// <summary>
        /// 获取计价模板下拉框
        /// </summary>
        private void GetPriceTemplates()
        {
            var list = new PriceTemplateCore().GetPriceTemplateList();
            cmbValuateMde.Dispatcher.BeginInvoke(new Action(() =>
            {
                cmbValuateMde.ItemsSource = list;
                cmbValuateMde.DisplayMemberPath = "Jname";
                cmbValuateMde.SelectedValuePath = "Jnumber";
                cmbValuateMde.SelectedIndex = 0;
            }));
        }

        /// <summary>
        /// 获取图片保存地址
        /// </summary>
        private void GetImageSavePath()
        {
            txtImgPath.Dispatcher.BeginInvoke(new Action(() =>
            {
                txtImgPath.Text = new GetLinkCore().GetImageSavePath();
            }));
        }

        /// <summary>
        /// 通过接口，获取新增的链接
        /// </summary>
        private void GetNewLinks()
        {
            var json = new HummingbirdCore().GetNewLinks();
            if (json == null)
            {
                CMessageBox.Show("获取链接失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            collectList.Clear();

            JArray array = JsonConvert.DeserializeObject<JArray>(json["result"].ToString());


            lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
            {
                lblLinkCount.Content = array == null ? 0 : array.Count;
            }));
            if (array == null) return;
            foreach (var item in array)
            {
                var link = item["linkUrl"].ToString();
                collectList.Add(link);
                txtUrlBox.Dispatcher.BeginInvoke(new Action(() =>
                {
                    txtUrlBox.AppendText(link + "\n");
                }));
            }

            //var glc = new GetLinkCore();
            //var getLinkRep = glc.GetNewLinks();
            ////if (getLinkRep == null) return;
            //if (Convert.ToString(getLinkRep["raction"]) != "succeed")
            //{
            //    CMessageBox.Show("获取链接失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
            //    //CMessageBox.Show("获取链接失败");
            //    return;
            //}
            //var links = (JArray)getLinkRep["links"];
            //Task task = new Task(new Action(() => glc.SaveLinks(links)));
            //task.Start();
            //if (links.Count > 0)
            //{
            //    var shd = glc.SetHaveDown(Convert.ToInt32(getLinkRep["endpos"]));
            //    if (Convert.ToString(getLinkRep["raction"]) != "succeed")
            //    {
            //        new LogOutput.LogTo().WriteErrorLine("刷新链接失败");
            //    }
            //}
            //lblLinkCount.Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    lblLinkCount.Content = links.Count;
            //}));
            //txtUrlBox.Dispatcher.BeginInvoke(new Action(() =>
            //{
            //    foreach (var item in links)
            //        txtUrlBox.AppendText(item + "\n");
            //}));


        }

        private void BtnSynchronizate_Click(object sender, RoutedEventArgs e)
        {
            if (txtUserName.Text.Trim().Length < 4) return;
            collectList.Clear();
            ownVM.BarValue = 0;
            int max = Convert.ToInt32(cmbSynchronic.Text);
            JObject jObject = new JObject()
            {
                { "downloaded", rdoSynchronic.IsChecked ?? false }
            };
            if (rdoSynchronic.IsChecked ?? false)
            {
                jObject.Add("pageIndex", 1);
                jObject.Add("pageSize", max);
            }
            var json = new HummingbirdCore().GetHistoryLinks(jObject);
            ownVM.Msg = "开始同步连接";
            if (json == null)
            {
                ownVM.Msg = "同步失败";
                return;
            }
            if (!Convert.ToBoolean(json["success"]))
            {
                ownVM.Msg = "同步失败:" + json["success"]["message"].ToString();
                return;
            }
            JArray array = JsonConvert.DeserializeObject<JArray>(json["result"]["items"].ToString());
            if (array.Count == 0)
            {
                ownVM.Msg += "\n没有可同步的链接";
                return;
            }
            Task.Run(() =>
            {
                var allCount = Convert.ToInt32(json["result"]["totalCount"]);
                ownVM.Counts = allCount;
                ownVM.BarContent = $"0/{ownVM.Counts}";
                var add = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(100) / array.Count));
                int downCount = 0;
                ownVM.Msg = "";
                foreach (var item in array)
                {
                    downCount += 1;
                    ownVM.BarContent = $"{downCount}/{ownVM.Counts}";
                    ownVM.Msg += item["linkUrl"].ToString() + "\n";
                    ownVM.BarValue += add;
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        lblLinkCount.Content = downCount;
                    }));
                    Thread.Sleep(100);
                }
            });
            //var glc = new GetLinkCore();
            //if (rdoSynchronic.IsChecked ?? false)//同步部分条数
            //{
            //    ownVM.Msg = "开始同步连接";
            //    ownVM.BarValue = 0;
            //    int max = Convert.ToInt32(cmbSynchronic.Text);
            //    Task.Run(() =>
            //    {
            //        try
            //        {
            //            var allCount = glc.GetAllCount();
            //            int newCount = Convert.ToInt32(allCount["count"]);
            //            if (newCount < 1)
            //            {
            //                ownVM.Msg += "\n没有可同步的链接";
            //                return;
            //            }
            //            ownVM.Counts = max > newCount ? newCount : max;
            //            ownVM.BarContent = $"0/{ownVM.Counts}";
            //            var add = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(100) / ownVM.Counts));
            //            int downCount = 0;
            //            int mark = newCount;
            //            ownVM.Msg = "";
            //            while (mark > 0 && downCount < ownVM.Counts)
            //            {
            //                var getLinkRep = glc.GetAllLinks();
            //                var links = (JArray)getLinkRep["links"];
            //                mark = links.Count;
            //                if (mark > 0)
            //                {
            //                    foreach (var item in links)
            //                    {
            //                        downCount += 1;
            //                        ownVM.BarContent = $"{downCount}/{ownVM.Counts}";
            //                        ownVM.Msg += item + "\n";
            //                        ownVM.BarValue += add;
            //                        this.Dispatcher.BeginInvoke(new Action(() =>
            //                        {
            //                            lblLinkCount.Content = downCount;
            //                        }));
            //                        Thread.Sleep(100);
            //                    }
            //                }
            //            }
            //        }
            //        catch
            //        {
            //            CMessageBox.Show("同步失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
            //        }
            //    });
            //}
            //else if (rdoGetAll.IsChecked ?? false)//同步所有条数
            //{
            //    ownVM.Msg = "开始同步连接";
            //    ownVM.BarValue = 0;
            //    Task.Run(() =>
            //    {
            //        try
            //        {
            //            var jsondata = glc.GetNewCount();
            //            int newCount = Convert.ToInt32(jsondata["count"]);
            //            if (newCount < 1)
            //            {
            //                ownVM.Msg += "\n没有可同步的链接";
            //                return;
            //            }
            //        }
            //        catch
            //        {
            //            CMessageBox.Show("同步失败");
            //        }
            //    });
            //}
        }

        private void RdoGetAll_Click(object sender, RoutedEventArgs e)
        {
            var glc = new GetLinkCore();
            Task.Run(() =>
            {
                try
                {
                    var allCount = glc.GetAllCount();
                    var newCount = glc.GetNewCount();
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        this.lblSearchResult.Content = $"全部:{Convert.ToString(allCount["count"])}  未同步:{newCount["count"]}";
                    }));
                }
                catch
                {
                    CMessageBox.Show("查询失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                }
            });
        }
    }
}
