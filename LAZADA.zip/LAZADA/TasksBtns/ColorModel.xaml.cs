﻿using PublicFunction;
using PublicFunction.SaveHelp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// ColorModel.xaml 的交互逻辑
    /// </summary>
    public partial class ColorModel : UserControl
    {
        public ColorModel()
        {
            InitializeComponent();
            RightColorsInit();
        }

        //返回所有颜色
        public string[] getAllColors()
        {
            List<string> allColors = new List<string>();
            foreach (CheckBox oneItem in listBox1.Items)
            {
                string[] tstr = oneItem.Content.ToString().Split(new char[2] { '(', ')' });
                allColors.Add(tstr[0]);
            }
            return allColors.ToArray();

        }

        public List<string> getAllColors2()
        {
            List<string> allColors = new List<string>();
            foreach (CheckBox oneItem in listBox1.Items)
            {
                string[] tstr = oneItem.Content.ToString().Split(new char[2] { '(', ')' });
                allColors.Add(tstr[0]);
            }
            return allColors;

        }

        //返回勾选的要用的颜色
        public string[] getUseColors()
        {
            List<string> UseColors = new List<string>();
            foreach (CheckBox oneItem in listBox1.Items)
            {
                if (oneItem.IsChecked == true)
                {
                    string[] tstr = oneItem.Content.ToString().Split(new char[2] { '(', ')' });

                    UseColors.Add(tstr[0]);
                }

            }

            return UseColors.ToArray();

        }


        //返回重复值
        public string getRepeadColor(string[] _colors)
        {
            if (_colors.Length < 3) return "";
            Array.Sort(_colors);
            for (int i = 0; i < _colors.Length - 1; i++)
            {
                if (_colors[i] == _colors[i + 1])
                {
                    return _colors[i];

                }

            }
            return "";


        }

        public bool checkRepeadColor()
        {
            string[] useColors = getUseColors();
            string repeadColor = getRepeadColor(useColors);
            if (repeadColor.Length > 0)
            {
                foreach (CheckBox oneItem in listBox1.Items)
                {
                    if (oneItem.IsChecked == true)
                    {
                        string[] tstr = oneItem.Content.ToString().Split(new char[2] { '(', ')' });
                        if (tstr[0] == repeadColor)
                        {
                            oneItem.FontWeight = FontWeights.Bold;
                        }
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 初始化邮编的颜色列表
        /// </summary>
        private void RightColorsInit()
        {
            if (ColorMatch.wishcolors == null) return;
            for (int i = 0; i < ColorMatch.wishcolors.Length; i++)
            {
                ListBoxItem oneItem = new ListBoxItem();
                oneItem.Content = ColorMatch.wishcolors[i];
                oneItem.MouseEnter += new MouseEventHandler(roneItem_MouseEnter);
                oneItem.MouseLeave += new MouseEventHandler(roneItem_MouseLeave);
                listBox2.Items.Add(oneItem);

            }

        }

        //左边颜色列表中添加一项
        public void leftAddOne(string _srt, string _tips)
        {
            // ListBoxItem oneItem = new
            _srt = _srt.Replace(",", " ").Replace("\'", " ").Replace("=", " ").Replace("|", "").Replace("(", "").Replace(")", "");
            // _srt = Regex.Replace(_srt, @"[^\u4E00-\u9FFFA-Za-z&\s]+", "").Trim();
            CheckBox oneItem = new CheckBox();
            oneItem.IsChecked = true;
            oneItem.Click += new RoutedEventHandler(oneItem_Click);
            oneItem.Checked += new RoutedEventHandler(oneItem_Checked);
            oneItem.MouseEnter += new MouseEventHandler(oneItem_MouseEnter);
            oneItem.MouseLeave += new MouseEventHandler(oneItem_MouseLeave);
            oneItem.Content = _srt;
            if (_tips != "") oneItem.ToolTip = _tips;
            if (ColorMatch.wishcolors != null)
            {
                if (!ColorMatch.IsWishColor(_srt))
                {
                    oneItem.ToolTip = "要手动匹配";
                    System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
                    oneItem.Foreground = brs;
                }
            }
            listBox1.Items.Add(oneItem);

            //  listBox1.SelectedItem = oneItem;

        }
        //左边列表中有一项被点击时
        private void oneItem_Click(object sender, RoutedEventArgs e)
        {
            // listBox1.SelectedItem = (CheckBox)sender ;
            // MessageBox.Show(listBox1.Items.CurrentPosition.ToString());
        }
        //左边列表中有一项被选中时
        private void oneItem_Checked(object sender, RoutedEventArgs e)
        {
            listBox1.SelectedItem = (CheckBox)sender;
        }

        //左边选项鼠标划过时
        private void oneItem_MouseEnter(object sender, RoutedEventArgs e)
        {
            ((CheckBox)sender).FontWeight = FontWeights.Bold;
        }
        //左边选项鼠标离开时
        private void oneItem_MouseLeave(object sender, RoutedEventArgs e)
        {
            ((CheckBox)sender).FontWeight = FontWeights.Normal;
        }

        //右边选项鼠标划过时
        private void roneItem_MouseEnter(object sender, RoutedEventArgs e)
        {
            ((ListBoxItem)sender).FontWeight = FontWeights.Bold;
        }
        //右边选项鼠标离开时
        private void roneItem_MouseLeave(object sender, RoutedEventArgs e)
        {
            ((ListBoxItem)sender).FontWeight = FontWeights.Normal;
        }

        private void listBox1_MouseEnter(object sender, MouseEventArgs e)
        {
            listBox1.Focus();
        }

        private void listBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listBox1.SelectedItem == null) return;

            CheckBox oneCB = (CheckBox)(listBox1.SelectedItem);
            if (oneCB.Content == null) return;
            if (String.IsNullOrEmpty(oneCB.Content.ToString())) return;
            string[] tstr = oneCB.Content.ToString().Split(new char[2] { '(', ')' });

            textBox1.Text = tstr[0];
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            textBox1.Text = Regex.Replace(textBox1.Text, @"[^\u4E00-\u9FFFA-Za-z&\s]+", "").Trim();
            if (textBox1.Text.Trim() == "") return;
            addnewColor(textBox1.Text.Trim());
        }

        private void comboBox1_GotFocus(object sender, RoutedEventArgs e)
        {

        }

        private void comboBox1_DropDownOpened(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string seachText = comboBox1.Text.Trim();
            if (seachText.Length < 2) return;

            foreach (ListBoxItem obj in listBox2.Items)
            {
                if (obj.Content.ToString().ToLower().Contains(seachText.ToLower()))
                {
                    comboBox1.Items.Add(obj.Content.ToString());
                }
            }
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comboBox1.SelectedItem == null) return;
            foreach (ListBoxItem item in listBox2.Items)
            {
                if (item.Content.ToString() == comboBox1.SelectedItem.ToString())
                {
                    listBox2.SelectedItem = item;
                    listBox2.Focus();
                    listBox2.ScrollIntoView(item);
                    comboBox1.Items.Clear();
                    break;
                }

            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            //要两边都有选中
            if (listBox1.SelectedItem == null || listBox2.SelectedItem == null) return;

            string rcolor = ((ListBoxItem)(listBox2.SelectedItem)).Content.ToString().Trim();
            if (listBox2.SelectedItems.Count > 1)
            {
                List<string> alist = new List<string>();
                for (int i = 0; i < listBox2.SelectedItems.Count; i++)
                {
                    alist.Add(((ListBoxItem)(listBox2.SelectedItems[i])).Content.ToString().Trim());
                }

                rcolor = String.Join(" & ", alist.ToArray());
            }

            string[] lcolors = ((CheckBox)listBox1.SelectedItem).Content.ToString().Split(new char[2] { '(', ')' });
            if (lcolors.Length == 1)
            {
                if (ColorMatch.wishcolors != null && ColorMatch.IsWishColor(lcolors[0]))
                {
                    return;
                }
                else
                {
                    ((CheckBox)listBox1.SelectedItem).Content = rcolor + "(" + lcolors[0] + ")";
                    System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 0, 0));
                    ((CheckBox)listBox1.SelectedItem).Foreground = brs;
                    ((CheckBox)listBox1.SelectedItem).ToolTip = lcolors[0];
                    reWriteMatchedColor(rcolor, lcolors[0]);
                    ColorMatch.SysColor = null;
                }
            }
            else
            {
                if (lcolors.Length > 1)
                {
                    ((CheckBox)listBox1.SelectedItem).Content = rcolor + "(" + lcolors[1] + ")";
                    System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 0, 0));
                    ((CheckBox)listBox1.SelectedItem).Foreground = brs;
                    ((CheckBox)listBox1.SelectedItem).ToolTip = lcolors[1];
                    reWriteMatchedColor(rcolor, lcolors[1]);
                    ColorMatch.SysColor = null;
                }
            }
        }

        private void reWriteMatchedColor(string _encolor, string _chcolor)
        {
            _chcolor = _chcolor.Replace("色", "").Replace("的", "");
            if (ColorMatch.SysColor.Contains(_encolor + "=" + _chcolor)) return;
            new IOHelp().SaveActFile(AppDomain.CurrentDomain.BaseDirectory + Constants.ACTFILE_MACHEDCOLOR, _encolor + "=" + _chcolor);
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            if (listBox2.SelectedItem == null) return;
            string rcolor = ((ListBoxItem)(listBox2.SelectedItem)).Content.ToString().Trim();
            if (listBox2.SelectedItems.Count > 1)
            {
                List<string> alist = new List<string>();
                for (int i = 0; i < listBox2.SelectedItems.Count; i++)
                {
                    alist.Add(((ListBoxItem)(listBox2.SelectedItems[i])).Content.ToString().Trim());
                }

                rcolor = String.Join(" & ", alist.ToArray());
            }


            if (rcolor != "") //leftAddOne(rcolor, rcolor);
            {
                string[] havedColors = getAllColors();
                if (havedColors.Contains(rcolor))
                {
                    foreach (CheckBox oneItem in listBox1.Items)
                    {

                        string[] tstr = oneItem.Content.ToString().Split(new char[2] { '(', ')' });
                        if (tstr[0] == rcolor)
                        {
                            oneItem.IsChecked = true;
                            listBox1.SelectedItem = oneItem;
                            break;
                        }

                    }

                }
                else
                {
                    leftAddOne(rcolor, rcolor);

                }
            }
        }

        private void listBox2_MouseEnter(object sender, MouseEventArgs e)
        {
            listBox2.Focus();
        }

        public void addnewColor(string _newcolor)
        {
            string tips = _newcolor.Trim();

            List<string> havedColors2 = getAllColors2();
            string newcolor = ColorMatch.GetENcolor3(_newcolor.Trim(), havedColors2);

            if (newcolor.Length < 1)
            {
                newcolor = _newcolor.Trim();
                tips = "要手动匹配";
            }
            // string[] havedColors = getAllColors();
            if (havedColors2.Contains(newcolor))
            {
                foreach (CheckBox oneItem in listBox1.Items)
                {

                    string[] tstr = oneItem.Content.ToString().Split(new char[2] { '(', ')' });
                    if (tstr[0] == newcolor)
                    {
                        oneItem.IsChecked = true;
                        listBox1.SelectedItem = oneItem;
                        break;
                    }
                }
            }
            else
            {
                leftAddOne(newcolor, tips);
            }
        }
    }
}
