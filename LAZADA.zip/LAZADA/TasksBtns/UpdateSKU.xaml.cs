﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.SystemSole;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// UpdateSKU.xaml 的交互逻辑
    /// </summary>
    public partial class UpdateSKU : Window
    {

        public UpdateSKU()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            var pidprefix = textBox.Text.Trim();
            var startNumber = textBox_Copy.Text.Trim();
            var pc = new ProductCore();
            if (pidprefix != string.Empty && startNumber != string.Empty)
            {
                var finalstartNumber = pc.GetNextSKUNumberByIdprefix(pidprefix);
                if (Convert.ToInt32(startNumber) > finalstartNumber)
                    finalstartNumber = Convert.ToInt32(startNumber);
                foreach (var item in SystemSoleEntity.SelectedProductNumberList)
                {
                    Product product = SystemSoleEntity.GetProductList().Where(p => p.Number == item).FirstOrDefault();
                    try
                    {
                        JArray array = JsonConvert.DeserializeObject<JArray>(product.SKUDetail);
                        if (array != null && array.Count > 0)
                        {
                            JArray newarray = new JArray();
                            foreach (var arr in array)
                            {
                                var json = JsonConvert.DeserializeObject<JObject>(arr.ToString());
                                json["SellerSku"]= json["SellerSku"].ToString().Replace(product.Pidprefix+product.SKUNumber, pidprefix+ finalstartNumber);
                                newarray.Add(json);
                            }
                            product.SKUDetail = JsonConvert.SerializeObject(newarray);
                        }
                    }
                    catch { }
                    product.Pidprefix = pidprefix;
                    product.SKUNumber = finalstartNumber;
                    product.Peditdate = DateTime.Now.ToString();
                    if (pc.UpdateSKUNumber(product))
                        finalstartNumber++;
                }
                CMessageBox.Show("更新成功");
                this.Close();
            }
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Tb_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            Regex re = new Regex("[^0-9]+");
            e.Handled = re.IsMatch(e.Text);
        }

        private void Label_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
