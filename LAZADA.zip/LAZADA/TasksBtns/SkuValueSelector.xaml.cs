﻿using Newtonsoft.Json.Linq;
using PublicFunction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA.TasksBtns
{
    /// <summary>
    /// SkuValueSelector.xaml 的交互逻辑
    /// </summary>
    public partial class SkuValueSelector : UserControl
    {
        Regex reg = new Regex("[\u4e00-\u9fa5]+");
        private List<string> oldsizeslist = new List<string>();
        public JObject skuJsonItem = null;
        public bool CanCustomEdit = false;

        private bool _isNumeric = false;
        public bool IsNumeric
        {
            get { return _isNumeric; }
            set
            {
                if (_isNumeric != value)
                {
                    _isNumeric = value;
                }
            }
        }

        private bool _CanEdit = false;
        public bool CanEdit
        {
            get { return _CanEdit; }
            set
            {
                if (_CanEdit != value)
                {
                    _CanEdit = value;
                    if (_CanEdit)
                    {
                        PART_Value2.Visibility = Visibility.Visible;
                        PART_Value.Visibility = Visibility.Collapsed;
                    }
                    else
                    {
                        PART_Value.Visibility = Visibility.Visible;
                        PART_Value2.Visibility = Visibility.Collapsed;

                    }
                }
            }
        }

        private string _zh;
        public string zhongwencolor
        {
            get { return _zh; }
            set
            {
                _zh = reg.Replace(value, "");

            }
        }

        //register 最后一个参数（可选的回调函数 ）可做属性值验证，倒数第2个参数（一个类）的其中一个属性可以做属性值改变时的处理函数
        public static readonly DependencyProperty SelectSkuValueProperty = DependencyProperty.Register("SelectSkuValue", typeof(string), typeof(SkuValueSelector));


        public string SelectSkuValue  //不在此作验证
        {
            get { return (string)GetValue(SelectSkuValueProperty); }
            set
            {

                string t = reg.Replace(value, "");

                SetValue(SelectSkuValueProperty, t);

            }
        }

        public SkuValueSelector(JObject _skuJsonItem, string _title)
        {
            InitializeComponent();

            skuJsonItem = _skuJsonItem;

            setSkuTitle(_title);
        }

        public void setSkuTitle(string _str)
        {
            PART_Name.Text = _str;
            PART_Name.ToolTip = _str;
        }


        //打开选择项
        private void PART_Button_Click(object sender, RoutedEventArgs e)
        {
            if (skuJsonItem == null) return;
            PART_Popwd.IsOpen = true;
            if (psizeWrapPanel.Children.Count > 0 && !CanEdit && SelectSkuValue.Trim().Length > 0)
            {
                return;
            }
            oldsizeslist.Clear();

            if (SelectSkuValue.Trim().Length > 0)
            {
                string[] oldsizes = SelectSkuValue.Split(new char[] { ',', '，' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string a in oldsizes)
                {
                    if (!oldsizeslist.Contains(a.Trim()))
                        oldsizeslist.Add(a.Trim());
                }
            }
            else if (!string.IsNullOrEmpty(zhongwencolor) && CanEdit == CanCustomEdit)
            {

                string[] oldsizes = zhongwencolor.Split(new char[] { ',', '，' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string a in oldsizes)
                {
                    if (!oldsizeslist.Contains(a.Trim()))
                        oldsizeslist.Add(a.Trim());
                }

            }

            List<string> sizeoptionsList = new List<string>();
            List<string> rightsizes = new List<string>();


            if (CanEdit && !CanCustomEdit)
            {
                oldsizeslist.OrderBy(h => h).ToList<string>();

                List<string> sizeoptions = ((JArray)skuJsonItem["options"]).Select(o => o["name"].ToString()).OrderBy(h => h).ToList<string>();
                sizeoptionsList = sizeoptions;
                psizeWrapPanel.Children.Clear();
                foreach (var str in sizeoptions)
                {
                    Label alb = new Label();
                    alb.Background = Brushes.Wheat;
                    alb.MinWidth = 90;
                    alb.Content = "+ " + str;
                    alb.Margin = new Thickness(2);
                    psizeWrapPanel.Children.Add(alb);
                    alb.MouseLeftButtonDown += Alb_MouseLeftButtonDown;
                }

                TextBlock tlb = new TextBlock();
                tlb.Width = 560;
                tlb.TextWrapping = TextWrapping.Wrap;
                tlb.Foreground = Brushes.Gray;
                tlb.Text = "点击上面色系标签可添加色系并自动生成自定义颜色名称，如(Red)Red01  ，名称括号内的字样不要改动，括号外的可以改，如可改为(Red)Red01x";
                psizeWrapPanel.Children.Add(tlb);

                foreach (string str in oldsizeslist)
                {
                    CheckBox acb = new CheckBox();
                    string asize = str.Replace(" ", "");
                    acb.Content = asize;
                    acb.MinWidth = 90;
                    acb.Margin = new Thickness(4);

                    acb.IsChecked = true;
                    psizeWrapPanel.Children.Add(acb);
                    acb.Checked += Acb_Checked;
                    acb.Unchecked += Acb_Unchecked;
                }

                if (oldsizeslist.Count > 0)
                {
                    previewlabel.Content = string.Join(" , ", oldsizeslist.ToArray());
                }
                else
                {
                    previewlabel.Content = "----";
                }
                PART_Popwd.IsOpen = true;
            }
            else
            {
                List<string> sizeoptions = new List<string>();

                if (oldsizeslist.Count > 0 && CanEdit && CanCustomEdit)
                {
                    sizeoptions.AddRange(oldsizeslist);
                }
                if (skuJsonItem["options"].HasValues)
                {

                    List<string> toptions = ((JArray)skuJsonItem["options"]).Select(o => o["name"].ToString()).ToList<string>();
                    if (skuJsonItem["name"].ToString() == "color_family" || skuJsonItem["name"].ToString() == "compatibility_by_model")
                        toptions = toptions.OrderBy(h => h).ToList<string>();
                    toptions.ForEach(item =>
                    {
                        bool needAdd = true;
                        foreach (var op in sizeoptions)
                        {
                            if (op.ToUpper() == item.ToUpper())
                            {
                                needAdd = false;
                                break;
                            }
                        }
                        if (needAdd)
                        {
                            sizeoptions.Add(item);
                        }
                    });
                    //sizeoptions.AddRange(toptions);
                }

                sizeoptions = sizeoptions.Distinct().ToList();

                int s = sizeoptions.Count;

                if (s > 0)
                {
                    List<string> oldsizeslistUpper = oldsizeslist.Select(a => a.ToUpper()).ToList();

                    oldsizeslist.Clear();

                    psizeWrapPanel.Children.Clear();
                    for (int i = 0; i < s; i++)
                    {
                        CheckBox acb = new CheckBox();
                        string asize = sizeoptions[i];
                        acb.Content = asize;
                        acb.MinWidth = 90;
                        acb.Margin = new Thickness(2);

                        sizeoptionsList.Add(asize);

                        string tasize = asize;
                        if (asize.Contains(":"))
                        {
                            string[] partsizestr = asize.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                            if (partsizestr.Length > 0) tasize = partsizestr.Last();
                        }
                        if (oldsizeslistUpper.Contains(tasize.ToUpper()) || oldsizeslistUpper.Contains(asize.ToUpper()))
                        {
                            if (!oldsizeslist.Contains(asize))
                            {
                                oldsizeslist.Add(asize);
                            }
                            acb.IsChecked = true;
                        }
                        psizeWrapPanel.Children.Add(acb);
                        acb.Checked += Acb_Checked;
                        acb.Unchecked += Acb_Unchecked;
                    }
                }
                if (oldsizeslist.Count > 0)
                {
                    foreach (string str in oldsizeslist)
                    {
                        if (sizeoptionsList.Contains(str.Trim()))
                        {
                            rightsizes.Add(str.Trim());
                        }
                    }
                    oldsizeslist = rightsizes;

                    if (oldsizeslist.Count > 0)
                    {
                        previewlabel.Content = string.Join(" , ", oldsizeslist.ToArray());
                    }
                    else
                    {
                        previewlabel.Content = "----";
                    }
                }
                else
                {
                    previewlabel.Content = "----";
                }
                PART_Popwd.IsOpen = true;
            }
        }

        private void Alb_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //throw new NotImplementedException();
            Label cb = (Label)sender;
            if (cb.Content == null) return;
            if (cb.Content.ToString().Length > 0)
            {
                string stb = cb.Content.ToString().Replace("+", "").Trim();
                int ins = oldsizeslist.Where(o => o.StartsWith("(" + stb + ")")).Count() + 1;

                CheckBox acb = new CheckBox();
                string asize = "(" + stb + ")" + stb + ins.ToString("0#");
                acb.Content = asize;
                acb.MinWidth = 90;
                acb.Margin = new Thickness(4);

                psizeWrapPanel.Children.Add(acb);

                acb.Checked += Acb_Checked;
                acb.Unchecked += Acb_Unchecked;

                acb.IsChecked = true;
            }
        }

        //确认选择
        private void OKbt_Click(object sender, RoutedEventArgs e)
        {
            SelectSkuValue = string.Join(" , ", oldsizeslist.ToArray());

            PART_Popwd.IsOpen = false;
        }

        //取消勾上一个SKU值
        private void Acb_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = (CheckBox)sender;
            if (cb.Content == null) return;
            if (cb.Content.ToString().Length > 0)
            {
                if (oldsizeslist.Contains(cb.Content.ToString()))
                {
                    oldsizeslist.Remove(cb.Content.ToString());
                    previewlabel.Content = String.Join(" , ", oldsizeslist.ToArray());
                }

            }
        }

        //勾上一个SKU值
        private void Acb_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = (CheckBox)sender;
            if (cb.Content == null) return;
            if (cb.Content.ToString().Length > 0)
            {
                if (!oldsizeslist.Contains(cb.Content.ToString()))
                {
                    oldsizeslist.Add(cb.Content.ToString());
                    previewlabel.Content = String.Join(" , ", oldsizeslist.ToArray());
                }

            }

        }

        //label转给button的点击事件
        private void PART_Value_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (e.Source != sender) return;

            MouseButtonEventArgs args = new MouseButtonEventArgs(Mouse.PrimaryDevice, 0, MouseButton.Left);
            args.RoutedEvent = Button.ClickEvent;

            PART_Button.RaiseEvent(args);
        }

        //颜色值 单个词首字母大写并去重
        private void PART_Value2_LostFocus(object sender, RoutedEventArgs e)
        {
            if (skuJsonItem != null && skuJsonItem["name"] != null && skuJsonItem["name"].ToString() == "color_family")
            {
                string t = ((TextBox)sender).Text;
                if (t.Length > 0)
                {
                    ((TextBox)sender).Text = PublicFunctions.upFirstCharWithSpaceWithSplitor(t.Replace("，", ","), ',');
                }

            }
            if (IsNumeric)
            {
                string t = ((TextBox)sender).Text;
                var arr = t.Replace("，", ",").Split(',');
                List<string> list = new List<string>();
                string numberPattern = @"^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$";
                Regex reg = new Regex(numberPattern);
                foreach (var item in arr)
                {
                    if (reg.IsMatch(item))
                    {
                        list.Add(item);
                    }
                }
                (sender as TextBox).Text = string.Join(",", list);


            }
        }

        private void PART_Value2_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (reg.IsMatch((sender as TextBox).Text))
            {
                //int s = (sender as TextBox).SelectionStart;
                string t = reg.Replace((sender as TextBox).Text, "");

                (sender as TextBox).Text = t;
                (sender as TextBox).SelectionStart = t.Length;
            }
        }
    }
}
