﻿using Logic.Platform;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// CrbPublishPro.xaml 的交互逻辑
    /// </summary>
    public partial class CrbPublishPro : UserControl
    {
        public CrbPublishPro()
        {
            InitializeComponent();
            ALL.IsChecked = true;
        }

        private void ChbAll_Checked(object sender, RoutedEventArgs e)
        {
            chbMY.IsChecked = true;
            chbID.IsChecked = true;
            chbPH.IsChecked = true;
            chbSG.IsChecked = true;
            chbTH.IsChecked = true;
            chbVN.IsChecked = true;
        }

        private void ChbAll_Unchecked(object sender, RoutedEventArgs e)
        {
            chbID.IsChecked = false;
            chbPH.IsChecked = false;
            chbSG.IsChecked = false;
            chbTH.IsChecked = false;
            chbVN.IsChecked = false;
            chbMY.IsChecked = false;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            GlobalUserClass.PublishingSite = "";
            if (chbID.IsChecked == true && chbSG.IsChecked == true && chbPH.IsChecked == true && chbTH.IsChecked == true && chbVN.IsChecked == true && chbMY.IsChecked == true || ALL.IsChecked == true)
                GlobalUserClass.PublishingSite = "all";
            else
            {
                if (chbMY.IsChecked == true)
                    GlobalUserClass.PublishingSite = "MY";
                if (chbID.IsChecked == true)
                    GlobalUserClass.PublishingSite += ",ID";
                if (chbSG.IsChecked == true)
                    GlobalUserClass.PublishingSite += ",SG";
                if (chbPH.IsChecked == true)
                    GlobalUserClass.PublishingSite += ",PH";
                if (chbTH.IsChecked == true)
                    GlobalUserClass.PublishingSite += ",TH";
                if (chbVN.IsChecked == true)
                    GlobalUserClass.PublishingSite += ",VN";
            }
            new LazadaCore().LazadaPublish_Six();
            ((Window)this.Parent).Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (ALL.IsChecked == true)
            {
                ALL.IsChecked = false;
                chbMY.IsChecked = false;
                chbID.IsChecked = false;
                chbSG.IsChecked = false;
                chbPH.IsChecked = false;
                chbTH.IsChecked = false;
                chbVN.IsChecked = false;
            }
            else
            {
                if (chbMY.IsChecked == true)
                    chbMY.IsChecked = false;
                if (chbID.IsChecked == true)
                    chbID.IsChecked = false;
                if (chbSG.IsChecked == true)
                    chbSG.IsChecked = false;
                if (chbPH.IsChecked == true)
                    chbPH.IsChecked = false;
                if (chbTH.IsChecked == true)
                    chbTH.IsChecked = false;
                if (chbVN.IsChecked == true)
                    chbVN.IsChecked = false;
            }
        }

        private void ChbMY_Unchecked(object sender, RoutedEventArgs e)
        {
                if (((CheckBox)sender).IsChecked == false)
                {
                    ALL.IsChecked = false;
                }
        }
    }
}
