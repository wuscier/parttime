﻿using Logic.BasicInfo;
using PublicFunction;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// ChooseStore.xaml 的交互逻辑
    /// </summary>
    public partial class ChooseStore : UserControl
    {
        public ChooseStore()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string str = "0";
            if (chbStore0.IsChecked == true) str += "," + chbStore0.Tag.ToString().Split(',')[0];
            if (chbStore1.IsChecked == true) str += "," + chbStore1.Tag.ToString().Split(',')[0];
            if (chbStore2.IsChecked == true) str += "," + chbStore2.Tag.ToString().Split(',')[0];
            if (chbStore3.IsChecked == true) str += "," + chbStore3.Tag.ToString().Split(',')[0];
            if (chbStore4.IsChecked == true) str += "," + chbStore4.Tag.ToString().Split(',')[0];
            if (chbStore5.IsChecked == true) str += "," + chbStore5.Tag.ToString().Split(',')[0];
            if (chbStore6.IsChecked == true) str += "," + chbStore6.Tag.ToString().Split(',')[0];
            if (chbStore7.IsChecked == true) str += "," + chbStore7.Tag.ToString().Split(',')[0];
            if (chbStore8.IsChecked == true) str += "," + chbStore8.Tag.ToString().Split(',')[0];
            if (chbStore9.IsChecked == true) str += "," + chbStore9.Tag.ToString().Split(',')[0];
            if (chbStore10.IsChecked == true) str += "," + chbStore10.Tag.ToString().Split(',')[0];
            if (chbStore11.IsChecked == true) str += "," + chbStore11.Tag.ToString().Split(',')[0];
            if (chbStore12.IsChecked == true) str += "," + chbStore12.Tag.ToString().Split(',')[0];
            if (chbStore13.IsChecked == true) str += "," + chbStore13.Tag.ToString().Split(',')[0];
            if (chbStore14.IsChecked == true) str += "," + chbStore14.Tag.ToString().Split(',')[0];
            if (chbStore15.IsChecked == true) str += "," + chbStore15.Tag.ToString().Split(',')[0];
            if (chbStore16.IsChecked == true) str += "," + chbStore16.Tag.ToString().Split(',')[0];
            if (chbStore17.IsChecked == true) str += "," + chbStore17.Tag.ToString().Split(',')[0];
            if (chbStore18.IsChecked == true) str += "," + chbStore18.Tag.ToString().Split(',')[0];
            if (chbStore19.IsChecked == true) str += "," + chbStore19.Tag.ToString().Split(',')[0];
            new SqlAuthorization().Edit("UPDATE Store SET IsDefault='0' where user='" + GlobalUserClass.uname + "' and region=" + GlobalUserClass.SiteId);
            new SqlAuthorization().Edit("UPDATE Store SET IsDefault='0' where user='" + GlobalUserClass.uname + "' and region=" + GlobalUserClass.SiteId);
            MessageBox.Show("设置成功！", "提示", MessageBoxButton.OK);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if ( MessageBoxResult.Yes==MessageBox.Show("是否确定发布产品到选定的店铺", "提示", MessageBoxButton.YesNo))
            {
                Constants.ReleaseStore = new Dictionary<string, string>();
                if (chbStore0.IsChecked == true) Constants.ReleaseStore.Add(chbStore0.Content.ToString(), chbStore0.Tag.ToString());
                if (chbStore1.IsChecked == true) Constants.ReleaseStore.Add(chbStore1.Content.ToString(), chbStore1.Tag.ToString());
                if (chbStore2.IsChecked == true) Constants.ReleaseStore.Add(chbStore2.Content.ToString(), chbStore2.Tag.ToString());
                if (chbStore3.IsChecked == true) Constants.ReleaseStore.Add(chbStore3.Content.ToString(), chbStore3.Tag.ToString());
                if (chbStore4.IsChecked == true) Constants.ReleaseStore.Add(chbStore4.Content.ToString(), chbStore4.Tag.ToString());
                if (chbStore5.IsChecked == true) Constants.ReleaseStore.Add(chbStore5.Content.ToString(), chbStore5.Tag.ToString());
                if (chbStore6.IsChecked == true) Constants.ReleaseStore.Add(chbStore6.Content.ToString(), chbStore6.Tag.ToString());
                if (chbStore7.IsChecked == true) Constants.ReleaseStore.Add(chbStore7.Content.ToString(), chbStore7.Tag.ToString());
                if (chbStore8.IsChecked == true) Constants.ReleaseStore.Add(chbStore8.Content.ToString(), chbStore8.Tag.ToString());
                if (chbStore9.IsChecked == true) Constants.ReleaseStore.Add(chbStore9.Content.ToString(), chbStore9.Tag.ToString());
                if (chbStore10.IsChecked == true) Constants.ReleaseStore.Add(chbStore10.Content.ToString(), chbStore10.Tag.ToString());
                if (chbStore11.IsChecked == true) Constants.ReleaseStore.Add(chbStore11.Content.ToString(), chbStore11.Tag.ToString());
                if (chbStore12.IsChecked == true) Constants.ReleaseStore.Add(chbStore12.Content.ToString(), chbStore12.Tag.ToString());
                if (chbStore13.IsChecked == true) Constants.ReleaseStore.Add(chbStore13.Content.ToString(), chbStore13.Tag.ToString());
                if (chbStore14.IsChecked == true) Constants.ReleaseStore.Add(chbStore14.Content.ToString(), chbStore14.Tag.ToString());
                if (chbStore15.IsChecked == true) Constants.ReleaseStore.Add(chbStore15.Content.ToString(), chbStore15.Tag.ToString());
                if (chbStore16.IsChecked == true) Constants.ReleaseStore.Add(chbStore16.Content.ToString(), chbStore16.Tag.ToString());
                if (chbStore17.IsChecked == true) Constants.ReleaseStore.Add(chbStore17.Content.ToString(), chbStore17.Tag.ToString());
                if (chbStore18.IsChecked == true) Constants.ReleaseStore.Add(chbStore18.Content.ToString(), chbStore18.Tag.ToString());
                if (chbStore19.IsChecked == true) Constants.ReleaseStore.Add(chbStore19.Content.ToString(), chbStore19.Tag.ToString());
                Window.GetWindow(this).Close();
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            List<Store> lStore = new SqlAuthorization().GetStoreList(" and account<>'' and expirationTime>'" + GlobalUserClass.GetTime(GlobalUserClass.Access_Token).Replace("\"","").Replace("T", " ") + "' and user='" + GlobalUserClass.uname + "' and region=" + GlobalUserClass.SiteId);
            int i = 0;
            foreach(var item in lStore)
            {
                switch (i)
                {
                    case 0:
                        chbStore0.Visibility = Visibility.Visible;
                        chbStore0.Content = item.Name == "" ? item.account : item.Name;
                        chbStore0.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore0.IsChecked = item.IsDefault == "true";
                        break;  
                    case 1:     
                        chbStore1.Visibility = Visibility.Visible;
                        chbStore1.Content = item.Name == "" ? item.account : item.Name;
                        chbStore1.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore1.IsChecked = item.IsDefault == "true";
                        break;  
                    case 2:     
                        chbStore2.Visibility = Visibility.Visible;
                        chbStore2.Content = item.Name == "" ? item.account : item.Name;
                        chbStore2.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore2.IsChecked = item.IsDefault == "true";
                        break;  
                    case 3:     
                        chbStore3.Visibility = Visibility.Visible;
                        chbStore3.Content = item.Name == "" ? item.account : item.Name;
                        chbStore3.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore3.IsChecked = item.IsDefault == "true";
                        break;  
                    case 4:     
                        chbStore4.Visibility = Visibility.Visible;
                        chbStore4.Content = item.Name == "" ? item.account : item.Name;
                        chbStore4.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore4.IsChecked = item.IsDefault == "true";
                        break;  
                    case 5:     
                        chbStore5.Visibility = Visibility.Visible;
                        chbStore5.Content = item.Name == "" ? item.account : item.Name;
                        chbStore5.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore5.IsChecked = item.IsDefault == "true";
                        break;  
                    case 6:     
                        chbStore6.Visibility = Visibility.Visible;
                        chbStore6.Content = item.Name == "" ? item.account : item.Name;
                        chbStore6.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore6.IsChecked = item.IsDefault == "true";
                        break;  
                    case 7:     
                        chbStore7.Visibility = Visibility.Visible;
                        chbStore7.Content = item.Name == "" ? item.account : item.Name;
                        chbStore7.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore7.IsChecked = item.IsDefault == "true";
                        break;  
                    case 8:     
                        chbStore8.Visibility = Visibility.Visible;
                        chbStore8.Content = item.Name == "" ? item.account : item.Name;
                        chbStore8.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore8.IsChecked = item.IsDefault == "true";
                        break;  
                    case 9:     
                        chbStore9.Visibility = Visibility.Visible;
                        chbStore9.Content = item.Name == "" ? item.account : item.Name;
                        chbStore9.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore9.IsChecked = item.IsDefault == "true";
                        break;  
                    case 10:    
                        chbStore10.Visibility = Visibility.Visible;
                        chbStore10.Content = item.Name == "" ? item.account : item.Name;
                        chbStore10.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore10.IsChecked = item.IsDefault == "true";
                        break;  
                    case 11:    
                        chbStore11.Visibility = Visibility.Visible;
                        chbStore11.Content = item.Name == "" ? item.account : item.Name;
                        chbStore11.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore11.IsChecked = item.IsDefault == "true";
                        break;  
                    case 12:    
                        chbStore12.Visibility = Visibility.Visible;
                        chbStore12.Content = item.Name == "" ? item.account : item.Name;
                        chbStore12.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore12.IsChecked = item.IsDefault == "true";
                        break;  
                    case 13:    
                        chbStore13.Visibility = Visibility.Visible;
                        chbStore13.Content = item.Name == "" ? item.account : item.Name;
                        chbStore13.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore13.IsChecked = item.IsDefault == "true";
                        break;  
                    case 14:    
                        chbStore14.Visibility = Visibility.Visible;
                        chbStore14.Content = item.Name == "" ? item.account : item.Name;
                        chbStore14.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore14.IsChecked = item.IsDefault == "true";
                        break;  
                    case 15:    
                        chbStore15.Visibility = Visibility.Visible;
                        chbStore15.Content = item.Name == "" ? item.account : item.Name;
                        chbStore15.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore15.IsChecked = item.IsDefault == "true";
                        break;  
                    case 16:    
                        chbStore16.Visibility = Visibility.Visible;
                        chbStore16.Content = item.Name == "" ? item.account : item.Name;
                        chbStore16.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore16.IsChecked = item.IsDefault == "true";
                        break;  
                    case 17:    
                        chbStore17.Visibility = Visibility.Visible;
                        chbStore17.Content = item.Name == "" ? item.account : item.Name;
                        chbStore17.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore17.IsChecked = item.IsDefault == "true";
                        break;  
                    case 18:    
                        chbStore18.Visibility = Visibility.Visible;
                        chbStore18.Content = item.Name == "" ? item.account : item.Name;
                        chbStore18.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore18.IsChecked = item.IsDefault == "true";
                        break;  
                    case 19:    
                        chbStore19.Visibility = Visibility.Visible;
                        chbStore19.Content = item.Name == "" ? item.account : item.Name;
                        chbStore19.Tag = item.id.ToString() + "," + item.accessToken;
                        chbStore19.IsChecked = item.IsDefault == "true";
                        break;
                }
                i++;
            }
        }

        private void checkBox_Checked(object sender, RoutedEventArgs e)
        {
            chbStore0.IsChecked = chbStore0.IsVisible;
            chbStore1.IsChecked = chbStore1.IsVisible;
            chbStore2.IsChecked = chbStore2.IsVisible;
            chbStore3.IsChecked = chbStore3.IsVisible;
            chbStore4.IsChecked = chbStore4.IsVisible;
            chbStore5.IsChecked = chbStore5.IsVisible;
            chbStore6.IsChecked = chbStore6.IsVisible;
            chbStore7.IsChecked = chbStore7.IsVisible;
            chbStore8.IsChecked = chbStore8.IsVisible;
            chbStore9.IsChecked = chbStore9.IsVisible;
            chbStore10.IsChecked = chbStore10.IsVisible;
            chbStore11.IsChecked = chbStore11.IsVisible;
            chbStore12.IsChecked = chbStore12.IsVisible;
            chbStore13.IsChecked = chbStore13.IsVisible;
            chbStore14.IsChecked = chbStore14.IsVisible;
            chbStore15.IsChecked = chbStore15.IsVisible;
            chbStore16.IsChecked = chbStore16.IsVisible;
            chbStore17.IsChecked = chbStore17.IsVisible;
            chbStore18.IsChecked = chbStore18.IsVisible;
            chbStore19.IsChecked = chbStore19.IsVisible;
        }

        private void checkBox_Unchecked(object sender, RoutedEventArgs e)
        {
            chbStore0.IsChecked = false;
            chbStore1.IsChecked = false;
            chbStore2.IsChecked = false;
            chbStore3.IsChecked = false;
            chbStore4.IsChecked = false;
            chbStore5.IsChecked = false;
            chbStore6.IsChecked = false;
            chbStore7.IsChecked = false;
            chbStore8.IsChecked = false;
            chbStore9.IsChecked = false;
            chbStore10.IsChecked = false;
            chbStore11.IsChecked = false;
            chbStore12.IsChecked = false;
            chbStore13.IsChecked = false;
            chbStore14.IsChecked = false;
            chbStore15.IsChecked = false;
            chbStore16.IsChecked = false;
            chbStore17.IsChecked = false;
            chbStore18.IsChecked = false;
            chbStore19.IsChecked = false;
        }
    }
}
