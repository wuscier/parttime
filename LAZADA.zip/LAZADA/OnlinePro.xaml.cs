﻿using LAZADA.HaiWang;
using LAZADA.OnlineProductControls;
using LAZADA.TasksBtns;
using LAZADA.TasksBtns.CustomerControl;
using LAZADA.TasksBtns.OnlineProductControl;
using Lazop.Api;
using Logic.BasicInfo;
using Logic.Platform;
using Logic.SystemSole;
using Logic.Translation;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static LAZADA.GlobalUserClass;

namespace LAZADA
{
    /// <summary>
    /// OnlinePro.xaml 的交互逻辑
    /// </summary>
    public partial class OnlinePro : UserControl
    {
        public PagingViewModel vm = new PagingViewModel() { PageSize = 10 };
        private GlobalUserClass global = new GlobalUserClass();
        AsyncObservableCollection<ShowOnLineProduct> onlineProductList = new AsyncObservableCollection<ShowOnLineProduct>();
        List<char> numberList = new List<char>() { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
        Dictionary<string, string> searchDic = new Dictionary<string, string>();
        string SQLWHERE = "";

        MainWindow mainWindow = null;


        public OnlinePro(MainWindow window)
        {
            //SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.ShowSKU);
            mainWindow = window;
            vm.CurrentPage = 1;
            InitializeComponent();
            //cmbValuateMde.SelectedIndex = 0;
            //SystemSoleEntity.SelectedProductNumberList.Clear();

            var listStore = new SqlAuthorization().GetStoreList(" and account<>'' and expirationTime>'" + GlobalUserClass.GetTime(GlobalUserClass.Access_Token).Replace("\"", "").Replace("T", " ") + "' and user='" + GlobalUserClass.uname + "' and region=" + GlobalUserClass.SiteId);
            cmbStore.Dispatcher.BeginInvoke(new Action(() =>
            {
                cmbStore.ItemsSource = listStore;
                cmbStore.DisplayMemberPath = "account";
                cmbStore.SelectedValuePath = "accessToken";
                cmbStore.SelectedIndex = 0;
            }));
            Paging pageinfo = new Paging(vm, new Action(() => LoadLocalOnlineProduct()));
            gridpage.Children.Add(pageinfo);
            LoadLocalOnlineProduct();
            //GetOnLineProducts();
            //onlineProductList = GETALL_OnlinePro();
            //Application.Current.Dispatcher.Invoke(new Action(() =>
            //{
            //    this.lvShowProduct.ItemsSource = GetOnlineProducts();
            //}));
        }

        public void LoadLocalOnlineProduct()
        {
            var list = new OnlineProductFunctionUpadteCore().GetLocalOnlineProduct(vm, SQLWHERE, searchDic);
            live.Content = $"全部产品（{vm.CountNumber}）";
            onlineProductList.Clear();
            foreach (var item in list)
            {
                if (item[2].ToString().Length < 30)
                    continue;
                var obj = JsonConvert.DeserializeObject<JObject>(item[2]);
                ShowOnLineProduct product = new ShowOnLineProduct()
                {
                    Title = obj["attributes"]["name"].ToString(),
                    Itemid = obj["item_id"].ToString(),
                    JsonStr = item[2].ToString(),
                    Categoryid = obj["primary_category"].ToString(),
                    UpdateTime = Convert.ToDateTime(item[1]),
                    LocalTime = Convert.ToDateTime(item[0]),
                };
                var skus = JsonConvert.DeserializeObject<JArray>(obj["skus"].ToString());
                product.SkuaAttrs = new List<string>();
                if (skus.Count > 0)
                {
                    bool isFirst = true;
                    foreach (var sku in skus)
                    {
                        var mySku = JsonConvert.DeserializeObject<JObject>(sku.ToString());
                        var sellerSku = mySku["SellerSku"].ToString();
                        var attrs = sellerSku.Split('-');
                        ///加载主SKU属性
                        if (isFirst)
                        {
                            var name = attrs[0];
                            product.MainSku = name;
                            //product.Title = mySku["name"].ToString();
                            //product.special_from_time = mySku["special_from_time"].ToString();
                            //product.Lazadapromend = mySku["special_to_time"].ToString();
                            //product.Lazadaprice = mySku["price"].ToString();
                            //product.Lazadapromprice = mySku["special_price"].ToString();
                            var imgs = JsonConvert.DeserializeObject<JArray>(mySku["Images"].ToString());
                            if (imgs != null && imgs.Count > 0)
                            {
                                product.Img = imgs[0].ToString();
                            }

                            isFirst = false;
                            product.SKUS = new AsyncObservableCollection<ChildSKU>();
                            product.Url = mySku["Url"].ToString();
                        }
                        ChildSKU child = new ChildSKU();
                        child.SellerSku = mySku["SellerSku"].ToString();
                        try
                        {
                            child.Special_to_time = mySku["special_to_time"].ToString();
                            child.Special_from_time = mySku["special_from_time"].ToString();
                        }
                        catch { }
                        child.Price = mySku["price"].ToString();
                        child.Special_price = mySku["special_price"].ToString();
                        child.Quantity = mySku["quantity"].ToString();
                        product.SKUS.Add(child);
                        for (int i = 1; i < attrs.Length; i++)
                        {
                            if (!product.SkuaAttrs.Contains(attrs[i]))
                            {
                                product.SkuaAttrs.Add(attrs[i]);
                            }
                        }
                    }
                }
                onlineProductList.Add(product);
            }
            lvShowProduct.ItemsSource = onlineProductList;
        }
        private void GetOnLineProductsToLocal(Dictionary<string, string> dic)
        {
            OnlineProductLoad win = new OnlineProductLoad(dic, this);
            win.ShowDialog();
            LoadLocalOnlineProduct();
        }
        //private void GetOnLineProducts(Dictionary<string, string> dic)
        //{
        //    onlineProductList.Clear();
        //    //OnlineProductLoad win = new OnlineProductLoad();
        //    //win.viewModel = new OnlineProductLoadModel();
        //    //win.DataContext = win.viewModel;
        //    //Task.Run(() =>
        //    //{
        //    //    this.Dispatcher.BeginInvoke(new Action(() => { win.ShowDialog(); }));
        //    //});
        //    var jsondata = new LazadaCore().GetOnLineProduct(dic);

        //    if (jsondata["code"].ToString() == "0" && jsondata["data"].HasValues)
        //    {
        //        vm.CountNumber = Convert.ToInt32(jsondata["data"]["total_products"]);
        //        live.Content = cmbValuateMde.Text + "( " + vm.CountNumber + " )";
        //        var jarry = JsonConvert.DeserializeObject<JArray>(jsondata["data"]["products"].ToString());
        //        //while (win.viewModel.Ipbvalue < 30)
        //        //{
        //        //    Thread.Sleep(100);
        //        //}
        //        //Task.Run(() =>
        //        //{
        //        //    while (win.viewModel.Ipbvalue < 90)
        //        //    {
        //        //        win.viewModel.Ipbvalue++;
        //        //        win.viewModel.Ipbvalue++;
        //        //        Thread.Sleep(300);
        //        //    }
        //        //});
        //        foreach (var item in jarry)
        //        {
        //            var obj = JsonConvert.DeserializeObject<JObject>(item.ToString());
        //            ShowOnLineProduct product = new ShowOnLineProduct()
        //            {
        //                Title = obj["attributes"]["name"].ToString(),
        //                Itemid = obj["item_id"].ToString(),
        //                JsonStr = item.ToString(),
        //                IsUpdate = false
        //            };
        //            var skus = JsonConvert.DeserializeObject<JArray>(obj["skus"].ToString());
        //            product.SkuaAttrs = new List<string>();
        //            if (skus.Count > 0)
        //            {
        //                bool isFirst = true;
        //                foreach (var sku in skus)
        //                {
        //                    var mySku = JsonConvert.DeserializeObject<JObject>(sku.ToString());
        //                    var sellerSku = mySku["SellerSku"].ToString();
        //                    var attrs = sellerSku.Split('-');
        //                    ///加载主SKU属性
        //                    if (isFirst)
        //                    {
        //                        var name = attrs[0];
        //                        product.MainSku = name;
        //                        //product.Title = mySku["name"].ToString();
        //                        //product.special_from_time = mySku["special_from_time"].ToString();
        //                        //product.Lazadapromend = mySku["special_to_time"].ToString();
        //                        //product.Lazadaprice = mySku["price"].ToString();
        //                        //product.Lazadapromprice = mySku["special_price"].ToString();
        //                        var imgs = JsonConvert.DeserializeObject<JArray>(mySku["Images"].ToString());
        //                        product.Img = imgs[0].ToString();
        //                        isFirst = false;
        //                        product.SKUS = new AsyncObservableCollection<ChildSKU>();
        //                        product.Url = mySku["Url"].ToString();
        //                    }
        //                    ChildSKU child = new ChildSKU();
        //                    child.SellerSku = mySku["SellerSku"].ToString();
        //                    child.Special_to_time = mySku["special_to_time"].ToString();
        //                    child.Special_from_time = mySku["special_from_time"].ToString();
        //                    child.Price = mySku["price"].ToString();
        //                    child.Special_price = mySku["special_price"].ToString();
        //                    child.Quantity = mySku["quantity"].ToString();
        //                    product.SKUS.Add(child);
        //                    for (int i = 1; i < attrs.Length; i++)
        //                    {
        //                        if (!product.SkuaAttrs.Contains(attrs[i]))
        //                        {
        //                            product.SkuaAttrs.Add(attrs[i]);
        //                        }
        //                    }
        //                    //product.ChildSku += sellerSku + ",";
        //                }

        //                //product.ChildSku = product.ChildSku.Substring(0, product.ChildSku.Length - 1);
        //            }
        //            onlineProductList.Add(product);
        //        }
        //        //Task.Run(() =>
        //        //{
        //        //    while (win.viewModel.Ipbvalue < 100)
        //        //    {
        //        //        win.viewModel.Ipbvalue++;
        //        //        Thread.Sleep(200);
        //        //    }
        //        //    this.Dispatcher.BeginInvoke(new Action(() =>
        //        //    {
        //        //        lvShowProduct.ItemsSource = onlineProductList;
        //        //        win.Close();
        //        //    }));
        //        //});
        //    }
        //    else
        //    {
        //        //this.Dispatcher.BeginInvoke(new Action(() => { win.Close(); }));
        //    }
        //}

        /// <summary>
        /// 获取所有在线产品
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public AsyncObservableCollection<OnlineProduct> GETALL_OnlinePro()
        {
            try
            {
                JObject data = GetOnlineData(GlobalUserClass.SiteId);
                int sum = data["data"]["products"].Count();
                vm.CountNumber = sum;
                live.Content = "在线（" + sum + "）";

                AsyncObservableCollection<OnlineProduct> listPro = new AsyncObservableCollection<OnlineProduct>();
                AsyncObservableCollection<JToken> skuarry = new AsyncObservableCollection<JToken>();
                AsyncObservableCollection<JToken> title = new AsyncObservableCollection<JToken>();
                AsyncObservableCollection<JToken> num = new AsyncObservableCollection<JToken>();
                AsyncObservableCollection<JToken> skunum = new AsyncObservableCollection<JToken>();
                foreach (var item in data["data"]["products"])
                {
                    OnlineProduct product = new OnlineProduct();
                    skuarry.Add(item["skus"]);
                    title.Add(item["attributes"]);
                    num.Add((long)item["item_id"]);
                    skunum.Add((long)item["primary_category"]);
                    foreach (var sk in skuarry)
                    {
                        foreach (var item1 in sk)
                        {
                            product.Pimgurl = Convert.ToString(item1["Images"].First);
                            product.SKUDetail = Convert.ToString(item1["ShopSku"]);
                            product.Lazadaprice = Convert.ToString(item1["price"]);
                            product.Lazadapromprice = Convert.ToString(item1["special_price"]);
                            product.Pkuchen = Convert.ToString(item1["sellableStock"]);
                            product.Padddate = Convert.ToString(item1["special_from_date"]);
                            product.Lazadapromstart = Convert.ToDateTime(item1["special_from_date"]).ToString("yyyy-MM-dd HH:mm");
                            product.Lazadapromend = Convert.ToDateTime(item1["special_to_date"]).ToString("yyyy-MM-dd HH:mm");
                            product.PackageHight = Convert.ToString(item1["package_height"]);
                            product.PackageLength = Convert.ToString(item1["package_length"]);
                            product.PackageWidth = Convert.ToString(item1["package_width"]);
                            product.Lazadapackageweight = Convert.ToString(item1["package_weight"]);
                            product.Pcolors = Convert.ToString(item1["color_family"]);
                            product.Lazadapackageincluding = Convert.ToString(item1["package_content"]);
                        }
                    }
                    foreach (var ti in title)
                    {
                        product.Porigtitle = Convert.ToString(ti["name"]);
                        product.Pbrand = Convert.ToString(ti["brand"]);
                        product.Pidprefix = product.Pbrand;
                        product.Video = Convert.ToString(ti["video"]);
                    }
                    foreach (var nm in num)
                    {
                        product.Number = (long)nm;
                    }
                    foreach (var snm in skunum)
                    {
                        product.SKUNumber = (long)snm;
                    }
                    listPro.Add(product);

                }
                return listPro;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        /// <summary>
        /// 获取在线产品
        /// </summary>
        /// <returns></returns>
        public JObject GetOnlineData(int siteId)
        {
            string AccessToken = GETLazada();
            //Constants.GETLAZADA_APPSECRET();
            ILazopClient client = new LazopClient("https://api.lazada.com.my/rest", Constants.LAZADA_APPKEY, Constants.LAZADA_APPSECRET);
            LazopRequest request = new LazopRequest();
            request.SetApiName("/products/get");
            request.SetHttpMethod("GET");
            request.AddApiParameter("filter", "live");
            //request.AddApiParameter("search", "Sleeve Was Thin T-shirt Female Pullover Short Striped Bottoming Shirt Loose Bell-sleeve");
            request.AddApiParameter("offset", "0");
            request.AddApiParameter("limit", "10");
            request.AddApiParameter("options", "1");
            //request.AddApiParameter("sku_seller_list", " [\"ZCJ11-White-IntXL\", \"ZCJ11-White-IntM\"]");
            LazopResponse response = client.Execute(request, AccessToken);
            var result = response.Body;
            JObject data = (JObject)JsonConvert.DeserializeObject(result);
            return data;
        }
        /// <summary>
        /// 获取lazada新的token
        /// </summary>
        /// <returns></returns>
        public string GETLazada()
        {
            try
            {
                string accesstoken = Access_Token;
                string authorMsg = GetSiteProfile(accesstoken);
                int siteId = SiteId;
                string REFERSHTOKEN = "";
                JObject result = (JObject)JsonConvert.DeserializeObject(authorMsg);

                JArray arryresult = (JArray)result["result"];
                foreach (var item in arryresult)
                {
                    if ((int)item["siteType"] == (int)WebSiteType.Lazada)
                    {

                        if ((int)item["region"] == siteId)
                        {
                            switch (siteId)
                            {
                                case 1:
                                    REFERSHTOKEN = Convert.ToString(item["refreshToken"]);
                                    break;
                                case 2:
                                    REFERSHTOKEN = Convert.ToString(item["refreshToken"]);
                                    break;
                                case 3:
                                    REFERSHTOKEN = Convert.ToString(item["refreshToken"]);
                                    break;
                                case 4:
                                    REFERSHTOKEN = Convert.ToString(item["refreshToken"]);
                                    break;
                                case 5:
                                    REFERSHTOKEN = Convert.ToString(item["refreshToken"]);
                                    break;
                                case 6:
                                    REFERSHTOKEN = Convert.ToString(item["refreshToken"]);
                                    break;
                                case 9:
                                    REFERSHTOKEN = Convert.ToString(item["refreshToken"]);
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }


                LazopClient client1 = new LazopClient("https://auth.lazada.com/rest", Constants.LAZADA_APPKEY, Constants.LAZADA_APPSECRET);
                LazopRequest request1 = new LazopRequest("/auth/token/refresh");
                request1.AddApiParameter("refresh_token", "50001101934e5tatuHdDhqCO02jFdLiVdxS9j4FSrFOxww1296ec9bQPdpsAo");
                LazopResponse responses = client1.Execute(request1);
                var str = responses.Body;
                var jsondata = (JObject)JsonConvert.DeserializeObject(str);
                string ACCESSTOKEN = Convert.ToString(jsondata["access_token"]);
                return ACCESSTOKEN;
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteLine(ex.Message);
                return "";
            }
        }

        private void AllCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            //foreach (var item in SystemSoleEntity.GetProductList())
            //{
            //    item.IsChecked = true;
            //    if (!SystemSoleEntity.SelectedProductNumberList.Contains(item.Number))
            //    {
            //        SystemSoleEntity.SelectedProductNumberList.Add(item.Number);
            //    }
            //}
            foreach (var item in onlineProductList)
            {
                item.IsChecked = true;
            }
        }

        private void AllCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            //foreach (var item in SystemSoleEntity.GetProductList())
            //{
            //    item.IsChecked = false;
            //    if (SystemSoleEntity.SelectedProductNumberList.Contains(item.Number))
            //    {
            //        SystemSoleEntity.SelectedProductNumberList.Remove(item.Number);
            //    }
            //}
            foreach (var item in onlineProductList)
            {
                item.IsChecked = false;
            }
        }

        private void Menu_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox combo = (ComboBox)sender;
            if (combo.SelectedIndex == 0) return;
            long number = Convert.ToInt64(combo.Tag);
            OnlineProduct product = new OnlineProduct();
            try
            {
                //product = GetOnlineProducts().Where(p => p.Number == number).First();
            }
            catch (Exception ex)
            {

                throw;
            }
            switch (combo.SelectedIndex)
            {
                case 1:
                    mainWindow.myContain.Children.Clear();
                    OnlineProSPUEdit spu = new OnlineProSPUEdit(product, mainWindow, vm.CurrentPage);
                    mainWindow.myContain.Children.Add(spu);
                    break;
                    //case 2:
                    //    mainWindow.myContain.Children.Clear();
                    //    DetailsEditor editor = new DetailsEditor(product, mainWindow, vm.CurrentPage);
                    //    mainWindow.myContain.Children.Add(editor);
                    //    break;
                    //case 3:
                    //    mainWindow.myContain.Children.Clear();
                    //    ChooseImg img = new ChooseImg(product, mainWindow, vm.CurrentPage);
                    //    mainWindow.myContain.Children.Add(img);
                    //    break;
                    //case 4:
                    //    mainWindow.myContain.Children.Clear();
                    //    AdditionalSKU add = new AdditionalSKU(product, mainWindow, vm.CurrentPage);
                    //    mainWindow.myContain.Children.Add(add);
                    //    break;
                    //case 5:
                    //    break;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            var itemid = Convert.ToString(btn.Tag);
            ShowOnLineProduct product = onlineProductList.Where(p => p.Itemid == itemid).First();

            OnlineProductDetails detail = new OnlineProductDetails(product);
            BaseWindow baseWindow = new BaseWindow();
            baseWindow.Show(mainWindow, 700, 400, detail, "修改产品明细（单次最多20条）");
            LoadLocalOnlineProduct();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            var id = btn.Tag.ToString();
            ShowOnLineProduct product = onlineProductList.Where(p => p.Itemid == id).First();
            mainWindow.ChangeChildControl_OnlineProduct(product, mainWindow, "Detail");

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            popLoacl.IsOpen = false;
            Dictionary<string, string> dic = new Dictionary<string, string>();
            var filter = "all";
            //switch (cmbValuateMde.Text)
            //{
            //    case "在线产品":
            //        filter = "live";
            //        break;
            //    case "疑似下线":
            //        filter = "inactive";
            //        break;
            //    case "已删除":
            //        filter = "deleted";
            //        break;
            //    case "图像丢失":
            //        filter = "image-missing";
            //        break;
            //    case "待处理":
            //        filter = "pending";
            //        break;
            //    case "已拒绝":
            //        filter = "rejected";
            //        break;
            //    case "已售罄":
            //        filter = "sold-out";
            //        break;
            //    case "强制性":
            //        filter = "Mandatory";
            //        break;
            //}
            dic.Add("filter", filter);
            //var offset = (vm.CurrentPage - 1) * vm.PageSize;
            //dic.Add("offset", offset.ToString());
            ////dic.Add("limit", vm.PageSize.ToString());
            //dic.Add("limit", "100");
            //var search = txtsearch.Text.Trim();
            //if (search.Length > 0)
            //    dic.Add("search", search);
            //if (dtp_create_after.PickedDateTime != null && dtp_create_after.PickedDateTime != string.Empty)
            //{
            //    DateTime dt = Convert.ToDateTime(dtp_create_after.PickedDateTime);
            //    var t = dt.ToString("yyyy-MM-dd'T'HH:mm:ss");
            //    dic.Add("create_after", t.ToString());
            //}
            //if (dtp_create_before.PickedDateTime != null && dtp_create_before.PickedDateTime != string.Empty)
            //{
            //    DateTime dt = Convert.ToDateTime(dtp_create_before.PickedDateTime);
            //    dic.Add("create_before", dt.ToString("yyyy-MM-dd'T'HH:mm:ss"));
            //}
            //if (dtp_update_after.PickedDateTime != null && dtp_create_before.PickedDateTime != string.Empty)
            //{
            //    DateTime dt = Convert.ToDateTime(dtp_update_after.PickedDateTime);
            //    dic.Add("update_after", dt.ToString("yyyy-MM-dd'T'HH:mm:ss"));
            //}
            //if (dtp_update_before.PickedDateTime != null && dtp_create_before.PickedDateTime != string.Empty)
            //{
            //    DateTime dt = Convert.ToDateTime(dtp_update_before.PickedDateTime);
            //    dic.Add("update_before", dt.ToString("yyyy-MM-dd'T'HH:mm:ss"));
            //}
            GetOnLineProductsToLocal(dic);
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            string olink = Convert.ToString(((TextBlock)sender).ToolTip);
            if (olink != "")
            {
                try
                {
                    System.Diagnostics.Process.Start(olink);
                }
                catch
                {

                }
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            popLoacl.IsOpen = false;
            List<string> list = new List<string>();
            foreach (var item in onlineProductList)
            {
                if (item.IsChecked)
                {
                    list.Add(item.Itemid);
                }
            }
            if (list.Count > 0)
            {
                OnlineProductItemUpdate update = new OnlineProductItemUpdate(list);
                update.ShowDialog();
                LoadLocalOnlineProduct();
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            popLoacl.IsOpen = true;
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            CheckBox chk = (CheckBox)sender;
            ShowOnLineProduct product = (ShowOnLineProduct)chk.DataContext;
            product.IsChecked = true;
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox chk = (CheckBox)sender;
            ShowOnLineProduct product = (ShowOnLineProduct)chk.DataContext;
            product.IsChecked = false;
        }

        private void BtnOpertaing_Click(object sender, RoutedEventArgs e)
        {
            var list = onlineProductList.Where(p => p.IsChecked).ToList();
            if (list.Count > 0)
            {
                OnlineProductBatch detail = new OnlineProductBatch(list);
                BaseWindow baseWindow = new BaseWindow();
                baseWindow.Show(mainWindow, 950, 500, detail, "批量编辑");
                LoadLocalOnlineProduct();
            }
            else
            {
                CMessageBox.Show("请勾选需要批量编辑的产品");
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            searchDic.Clear();
            SQLWHERE = "";
            if (dtp_create_after.PickedDateTime != string.Empty && dtp_create_after.PickedDateTime != null)
            {
                SQLWHERE += " and  localTime > '" + dtp_create_after.PickedDateTime + "' ";
                searchDic.Add("localTime", dtp_create_after.PickedDateTime);
            }
            if (dtp_create_before.PickedDateTime != string.Empty && dtp_create_before.PickedDateTime != null)
            {
                SQLWHERE += " and  localTime < '" + dtp_create_after.PickedDateTime + "' ";
                searchDic.Add("localTime", dtp_create_after.PickedDateTime);
            }
            if (dtp_update_after.PickedDateTime != string.Empty && dtp_update_after.PickedDateTime != null)
            {
                SQLWHERE += " and  updateTime > '" + dtp_update_after.PickedDateTime + "' ";
                searchDic.Add("updateTime", dtp_update_after.PickedDateTime);
            }
            if (dtp_update_before.PickedDateTime != string.Empty && dtp_update_before.PickedDateTime != null)
            {
                SQLWHERE += " and  updateTime < '" + dtp_update_before.PickedDateTime + "' ";
                searchDic.Add("updateTime", dtp_update_before.PickedDateTime);
            }
            if (txtsearch.Text.Trim() != string.Empty && txtsearch.Text != null)
            {
                SQLWHERE += " and  (title like '%" + txtsearch.Text + "%' or mainSku ='" + txtsearch.Text + "' or sellersku like '%" + txtsearch.Text + "%' ) ";
                searchDic.Add("title", txtsearch.Text);
                searchDic.Add("mainSku", txtsearch.Text);
                searchDic.Add("sellersku", txtsearch.Text);
            }
            LoadLocalOnlineProduct();
        }

        private void BtnPerson_Click(object sender, RoutedEventArgs e)
        {
            string url = GlobalUserClass.GetHaiWangModel().CreateURL(Constants.HAIWANG_FUN_PERSONAL_URL);
            WinMyWebBrowser win = new WinMyWebBrowser("阿里翻译智能翻译定制", url);
            win.ShowDialog();
        }

        private void BtnClearTime_Click(object sender, RoutedEventArgs e)
        {
            dtp_create_after.PickedDateTime = null;
            dtp_create_before.PickedDateTime = null;
            dtp_update_after.PickedDateTime = null;
            dtp_update_before.PickedDateTime = null;
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            string url = GlobalUserClass.GetHaiWangModel().CreateURL(Constants.HAIWANG_FUN_DIAGNOSE_URL);
            WinMyWebBrowser win = new WinMyWebBrowser("阿里翻译店铺诊断", url);
            win.ShowDialog();
        }

        private void btnOpertaing_Copy_Click(object sender, RoutedEventArgs e)
        {
            var list = onlineProductList.Where(p => p.IsChecked).ToList();
            if (list.Count > 0)
            {
                BatchTitleOptimization detail = new BatchTitleOptimization(list, mainWindow);
                BaseWindow baseWindow = new BaseWindow();
                baseWindow.Show(mainWindow, 810, 490, detail, "批量标题优化");
                LoadLocalOnlineProduct();
            }
            else
            {
                CMessageBox.Show("请勾选需要批量标题优化的产品");
            }
        }

        private void cmbStore_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbStore.SelectedValue != null)
            {
                Constants.OnlineLAZADA_ACCESSTOKEN = cmbStore.SelectedValue.ToString();
                Constants.OnlineLAZADA_ACCOUNT = ((Store)cmbStore.SelectedItem).Name.ToString();
                LoadLocalOnlineProduct();
            }
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            label.Visibility = Visibility.Visible;
            popLoacl.IsOpen = false;
            string ItemidList = "";
            string sellerSku = "[";
            foreach (var item in onlineProductList)
            {
                if (item.IsChecked)
                {
                    //string[] strList = item.Sellersku.Split(',');
                    foreach(var str in item.SKUS)
                    {
                        sellerSku +=sellerSku=="["?("\"" + str.SellerSku + "\"") :( ",\"" + str.SellerSku + "\"");
                    }
                    ItemidList += ItemidList == "" ? item.Itemid : ("," + item.Itemid);
                }
            }
            sellerSku += "]";
            if (sellerSku != "[]")
            {
                LazadaRequestClient client = new LazadaRequestClient();
                JObject jObject = client.RemoveProduct(sellerSku);
                if (jObject != null && jObject["code"].ToString() == "0")
                {
                    new SqlAuthorization().Edit("delete from OnlineProduct where itemid in (" + ItemidList + ")");
                    MessageBox.Show("删除成功！", "提示", MessageBoxButton.OK, MessageBoxImage.None);
                    LoadLocalOnlineProduct();
                }
                else if (jObject == null)
                {
                    MessageBox.Show("操作超时！", "提示", MessageBoxButton.OK, MessageBoxImage.None);
                }
                else
                {
                    MessageBox.Show("删除失败："+ jObject["message"].ToString(), "提示", MessageBoxButton.OK, MessageBoxImage.None);
                }
            }
            else
            {
                MessageBox.Show("请选择要删除的产品！", "提示", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            }
            label.Visibility = Visibility.Collapsed;
        }
    }
}
