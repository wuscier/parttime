﻿using LAZADA.TasksBtns;
using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Logic.PriceTemplate;
using Logic.SystemSole;
using Logic.Translation;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// SPUEditor.xaml 的交互逻辑
    /// </summary>
    public partial class SPUEditor : UserControl
    {
        List<string> dgColunms = new List<string>() {
            "选择","SKU","包裹重","源价","价格","促销价","库存","计价模板"
        };
        private DataTable dtSource = null;
        private CategorySelector selector = null;
        private ColorModel colorModel = null;
        MainWindow mainWin = null;

        #region 过滤掉已经有的属性
        List<string> attrlist = new List<string>
            {
                "name",
                "short_description",
                "description",
                "video",
                "SellerSku",
                "barcode_ean",
                //"product_warranty",
                "quantity",
                "name_ms",
                "product_warranty_en",
                "price",
                "special_price",
                "special_from_date",
                "special_to_date",
                "description_ms",
                "seller_promotion",
                "package_content",
                "package_weight",
                "package_length",
                "package_width",
                "package_height",
                "__images__",
                //"tax_class",
                "published_date",
                "external_url",
                "std_search_keywords"
            };

        #endregion
        private int parentCurrentPage = 1;
        List<Aattribute> categoryAttrs = new List<Aattribute>();
        List<Aattribute> categoryOtherAttrs = new List<Aattribute>();
        Dictionary<string, string> categoryAttrDic = null;
        private bool isLoad = true;
        string oldSreachContect = "";
        public SPUEditor(Product product, MainWindow _mainWin)
        {
            SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.EditSpu);
            InitializeComponent();
            dgShow.AutoGenerateColumns = false;
            mainWin = _mainWin;
            var currency = new SiteChangeHelp().GetCurrency();
            lbl_price.Content = "价格" + currency;
            lbl_discountPrice.Content = "促销价" + currency;

            GetPriceTemplates();
            this.DataContext = product;
            if (product.Lazadacategoryid != null && product.Lazadacategoryid != string.Empty)
                LoadCategoryDetailNew(product.Lazadacategoryid);

            CreateDataGridFromSku();
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void cmbTemplate_DropDownOpened(object sender, EventArgs e)
        {

        }

        private void cmbTemplate_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void nudPromotionPrice_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void chbAuto_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void chbAuto_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void btnAdjust_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnRecalculate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void SourceColor_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnMatching_Click(object sender, RoutedEventArgs e)
        {

        }

        private void bdCategory_MouseUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void btnCategory_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSize_Click(object sender, RoutedEventArgs e)
        {

        }

        private void lblTaxes_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void lblTaxes_Leave(object sender, MouseEventArgs e)
        {

        }

        private void lblTaxes_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void cmbWhatBox_DropDownOpened(object sender, EventArgs e)
        {

        }

        private void cmbWhatBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Translation_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnNumber_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSaveNext_Click(object sender, RoutedEventArgs e)
        {
            if (!SaveProduct())
            {
                CMessageBox.Show("保存失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            //mainWin.RdoDetails_Click(null, null);
            //mainWin.myContain.Children.Clear();
            //DetailsEditor userControl = new DetailsEditor((Product)this.DataContext, mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);
            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "Detail");
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (SaveProduct())
                CMessageBox.Show("已保存");
            else
                CMessageBox.Show("保存失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
        }

        public bool SaveProduct(bool isAuto = false)
        {
            Product product = (Product)this.DataContext;
            if (product.Pstatetype != "1")
                product.Pstatetype = "10";
            product.SPUEditError = "";
            if (product.Lazadacategoryid == string.Empty || product.Lazadacategoryid == null)
            {
                product.SPUEditError += "类目未选择 \n";
            }
            if (product.Lazadapromstart != null && product.Lazadapromstart != string.Empty)
            {
                if (Convert.ToDateTime(product.Lazadapromstart) < DateTime.Now)
                {
                    product.SPUEditError += "促销开始时间错误 \n";
                }
            }
            else
            {
                product.SPUEditError += "没有促销开始时间 \n";
            }
            if (product.Lazadapromend != null && product.Lazadapromend != string.Empty)
            {
                if (Convert.ToDateTime(product.Lazadapromend) < DateTime.Now)
                {
                    product.SPUEditError += "促销结束时间错误 \n";
                }
            }
            else
            {
                product.SPUEditError += "没有促销结束时间 \n";
            }
            if (product.Lazadapromstart != string.Empty && product.Lazadapromend != string.Empty && product.Lazadapromstart != null && product.Lazadapromend != null)
            {
                if (Convert.ToDateTime(product.Lazadapromstart) >= Convert.ToDateTime(product.Lazadapromend))
                {
                    product.SPUEditError += "促销时间段错误 \n";
                }
            }
            if (product.Lazadapackageweight == string.Empty)
            {
                product.SPUEditError += "包裹重不能为空 \n";
            }

            JArray jarray = new JArray();
            foreach (var item in categoryAttrs)
            {
                if (item.Avalue != string.Empty && item.Aname != string.Empty)
                {
                    JObject jobject = new JObject();
                    jobject.Add("name", item.Aname);
                    jobject.Add("value", item.Avalue);
                    jarray.Add(jobject);
                }
                else
                {
                    if (!attrlist.Contains(item.Aname))
                        product.SPUEditError += "属性[" + item.Aname + "]为空 \n";
                }
            }
            if (jarray.Count > 0)
            {
                product.Lazadaskux = JsonConvert.SerializeObject(jarray);
            }
            else
            {
                JObject jobject2 = new JObject();
                jobject2.Add("name", "DEFAULT");
                jobject2.Add("value", "OnlyOne");
                jarray.Add(jobject2);
                var result = JsonConvert.SerializeObject(jarray);
                product.Lazadaskux = result;
            }

            JArray jarray2 = new JArray();
            foreach (var item in categoryOtherAttrs)
            {
                if (item.Avalue != string.Empty && item.Aname != string.Empty)
                {
                    if (item.Aname == "tax_class")
                    {
                        product.Lazadatax = item.Avalue;
                    }
                    JObject jobject = new JObject();
                    jobject.Add("name", item.Aname);
                    jobject.Add("value", item.Avalue);
                    jarray2.Add(jobject);

                }
                else if (item.IsSku)
                {
                    if (!attrlist.Contains(item.Aname))
                        product.SPUEditError += "属性[" + item.Aname + "]为空 \n";
                }
            }
            if (jarray2.Count > 0)
            {
                product.Lazadaattributs = JsonConvert.SerializeObject(jarray2);
            }

            if (product.Lazadapromprice == string.Empty || product.Lazadapromprice == null)
            {
                product.Lazadapromprice = "0";
                product.SPUEditError += "促销价 不能为0 \n";
            }

            if (product.Lazadaprice == string.Empty || product.Lazadaprice == null)
            {
                product.Lazadaprice = "0";
                product.SPUEditError += "价格 不能为0 \n";
            }
            if (product.Lazadapromprice != "0" && product.Lazadaprice != "0")
            {
                var result = Convert.ToDouble(product.Lazadapromprice) / Convert.ToDouble(product.Lazadaprice) * 100;
                var percent = new SiteChangeHelp().GetPricePercent();
                if (result < percent)
                {
                    product.SPUEditError += "促销价 不能低于价格的 " + percent.ToString() + "% \n";
                }
            }
            if (dtSource == null || dtSource.Rows.Count == 0)
            {
                CreateDataGridForCategory();
            }
            JArray array = new JArray();
            for (int i = 0; i < dtSource.Rows.Count; i++)
            {
                JObject sku = new JObject();
                for (int k = 1; k < dtSource.Columns.Count; k++)
                {
                    sku[dtSource.Columns[k].ColumnName] = dtSource.Rows[i][k].ToString();
                }
                array.Add(JsonConvert.SerializeObject(sku));
                if (Convert.ToString(dtSource.Rows[i]["special_price"]) == string.Empty)
                {
                    dtSource.Rows[i]["special_price"] = "0";
                    product.SPUEditError += dtSource.Rows[i]["SellerSku"].ToString() + " 促销价 不能为0 \n";
                }

                if (Convert.ToString(dtSource.Rows[i]["price"]) == string.Empty)
                {
                    dtSource.Rows[i]["price"] = "0";
                    product.SPUEditError += dtSource.Rows[i]["SellerSku"].ToString() + " 价格 不能为0 \n";
                }
                if (Convert.ToString(dtSource.Rows[i]["price"]) != "0" && Convert.ToString(dtSource.Rows[i]["special_price"]) != "0")
                {
                    var price = Convert.ToDouble(dtSource.Rows[i]["price"]);
                    var sprice = Convert.ToDouble(dtSource.Rows[i]["special_price"]);
                    var result = sprice / price * 100;
                    var percent = new SiteChangeHelp().GetPricePercent();
                    if (result < percent)
                    {
                        product.SPUEditError += dtSource.Rows[i]["SellerSku"].ToString() + " 促销价 不能低于价格的 " + percent.ToString() + "% \n";
                    }
                }
            }
            product.SKUDetail = JsonConvert.SerializeObject(array);
            //if (product.Lazadatax == string.Empty)
            //{
            //    product.SPUEditError += "税种为空 \n";
            //}
            //if (product.Lazadawarrantytype == string.Empty)
            //{
            //    product.SPUEditError += "保修类型为空 \n";
            //}
            return new ProductCore().UpdateSPUEditor(product);
        }

        private void btnRefresh_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSureColor_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSureSize_Click(object sender, RoutedEventArgs e)
        {

        }

        private void F75lxpxTmO(object sender, SelectionChangedEventArgs e)
        {
            if (isLoad)
            {
                isLoad = false;
                return;
            }
            UpdatePriceTemplateChange();
        }

        private void UpdatePriceTemplateChange()
        {
            ///根据计价模板变更，改变对应的价格
            var ptc = new PriceTemplateCore();
            //计价模板可能更改，需要实时更新
            var pt = ptc.GetPriceTemplate(((PriceTemplateEntity)cmbValuateMde.SelectedItem).Jname);
            var product = (Product)this.DataContext;
            var pc = new ProductCore();
            product.Pjisangongshi = pt.Jname;
            product.PackageLength = pt.Jpkglength;
            product.PackageWidth = pt.Jpkgwidth;
            product.PackageHight = pt.Jpkghight;
            ptc.CalcProductCost(pt, product, Convert.ToDouble(product.Porigprice));
            pc.UpdateChangePriceTemplate(product);
        }

        private void lHwllOTpUY(object sender, RoutedEventArgs e)
        {
            UpdatePriceTemplateChange();
        }

        private void lbLlIuK5s2(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void dj0xntc6bF(object sender, RoutedEventArgs e)
        {
            ///如果有一个为空，开始时间为当前+1小时，结束时间为一个月后
            if (string.IsNullOrEmpty(this.endTimePicker.PickedDateTime) || string.IsNullOrEmpty(this.startTimePicker.PickedDateTime))
            {
                DateTime dateTime = DateTime.Now.AddHours(2.0);
                this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
            }
            else
            {
                try
                {   //时间格式正确，一起往后顺延一小时
                    if (Convert.ToDateTime(this.endTimePicker.PickedDateTime) > Convert.ToDateTime(startTimePicker.PickedDateTime))
                    {
                        this.endTimePicker.PickedDateTime = Convert.ToDateTime(this.endTimePicker.PickedDateTime).AddHours(1.0).ToString("yyyy-MM-dd HH:00:00");
                        this.startTimePicker.PickedDateTime = DateTime.Now.AddHours(1.0).ToString("yyyy-MM-dd HH:00:00");
                    }
                    else //结束时间>开始时间，开始时间为当前+1小时，结束时间为一个月后
                    {
                        DateTime dateTime = DateTime.Now.AddHours(1.0);
                        this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                        this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
                    }
                }
                catch
                {
                    DateTime dateTime = DateTime.Now.AddHours(1.0);
                    this.startTimePicker.PickedDateTime = dateTime.ToString("yyyy-MM-dd HH:00:00");
                    this.endTimePicker.PickedDateTime = dateTime.AddMonths(1).ToString("yyyy-MM-dd HH:00:00");
                }
            }
        }

        private void tSblrcsZRe(object sender, MouseButtonEventArgs e)
        {

        }

        private void Fkflmvunvs(object sender, RoutedEventArgs e)
        {
            //this.Pop_xiangji.IsOpen = true;
            //if (colorModel == null)
            //{
            //    colorModel = new ColorModel();
            //    if (this.textBox11.Text.Trim() != "")
            //    {
            //        this.textBox11.Text = ColorMatch.ColorsUpFirstchar2(this.textBox11.Text.Replace("，", ","));
            //        string[] array = this.textBox11.Text.Split(new char[]
            //        {
            //            ','
            //        });
            //        for (int i = 0; i < array.Length; i++)
            //        {
            //            bool flag3 = array[i].Trim() != "";
            //            if (flag3)
            //            {
            //                string tips = this.pimlf7L8NO(array[i].Trim());
            //                this.colorModel.leftAddOne(array[i].Trim(), tips);
            //            }
            //        }
            //    }
            //}
            //this.contentControl1.Content = this.colorModel;
        }

        private string pimlf7L8NO(string b)
        {
            Product product = (Product)this.DataContext;
            string result;
            if (product.Pcolormatch != null && product.Pcolormatch != string.Empty)
            {
                string u = product.Pcolormatch;
                string text = ColorMatch.GetCHcolor(b, u);
                result = text;
            }
            else
            {
                result = "";
            }
            return result;
        }

        private void PIil6fSQDn(object sender, TextChangedEventArgs e)
        {
            LywltNunYD();
        }


        private void LywltNunYD()
        {
            string text = this.textBox11.Text.Trim();
            bool flag = text.Length > 0;
            if (flag)
            {
                Regex reg = new Regex("[\u4e00-\u9fa5]+");
                bool flag2 = !reg.IsMatch(text);
                if (flag2)
                {
                    Brush foreground = new SolidColorBrush(Color.FromRgb(0, 0, 0));
                    this.textBox11.Foreground = foreground;
                }
                else
                {
                    Brush foreground2 = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                    this.textBox11.Foreground = foreground2;
                }
            }
            else
            {
                Brush foreground3 = new SolidColorBrush(Color.FromRgb(0, 0, 0));
                this.textBox11.Foreground = foreground3;
            }
        }


        private void a2gljhwPPO(object sender, RoutedEventArgs e)
        {
            this.Pop_category.IsOpen = true;
            bool flag = this.selector == null;
            if (flag)
            {
                this.selector = new CategorySelector();
                this.selector.CategoryChanged += this.CategroyChange;
            }
            this.contentControl2X.Content = this.selector;
        }

        private void CategroyChange(object sender, RoutedEventArgs e)
        {
            var selector = (CategorySelector)sender;
            string text = selector.namePath.Trim();
            bool flag = string.IsNullOrEmpty(text);
            if (flag)
            {
                this.label15L.Text = "无效类目，请重新选择";
            }
            else
            {
                this.label15L.Text = text;
            }
            string text2 = selector.leafId.Trim();
            bool flag2 = string.IsNullOrEmpty(text2);
            if (!flag2)
            {
                var product = (Product)this.DataContext;
                product.Lazadacategoryid = text2;
                product.Lazadacategoryidpath = selector.idPath;
                product.LazadaCategoryTreePath = selector.treePath;
                this.Pop_category.IsOpen = false;
                //Task.Run(() => 
                LoadCategoryDetailNew(text2);
                //);
                //this.zLgl8aX7MI(this.a13lZS8LZg);
            }
        }
        //加载类目属性
        private void LoadCategoryDetailNew(string leafId)
        {
            JObject jsondata = new LazadaCore().GetCategoryAttr(leafId);
            Product product = (Product)this.DataContext;
            if (jsondata["data"] == null) return;
            var list = ((JArray)jsondata["data"]).ToList();
            categoryAttrs.Clear();
            categoryOtherAttrs.Clear();
            categoryAttrDic = InitDictionary(product.Lazadaskux, product.Lazadaattributs);
            WrapPanelX01.Children.Clear();
            WrapPanelX02.Children.Clear();
            skulistpanel.Children.Clear();
            list.ForEach(item =>
            {
                var name = item["name"].ToString();
                ///去除系统自带属性
                if (attrlist.Contains(name))
                    return;
                ///是否是销售属性,(用于判断是否是上方的辩题属性)
                bool isSaleProp = Convert.ToBoolean(item["is_sale_prop"]);
                if ((isSaleProp && item["name"].ToString()!= "brand")|| item["name"].ToString() == "color_hb" )//|| item["name"].ToString() == "Type_of_Material")
                {
                    Aattribute aattribute = new Aattribute();
                    aattribute.Aname = item["name"].ToString();
                    if (categoryAttrDic.ContainsKey(aattribute.Aname))
                    {
                        aattribute.Avalue = categoryAttrDic[aattribute.Aname];
                    }
                    categoryAttrs.Add(aattribute);
                    SkuValueSelector skuValueSelector = new SkuValueSelector((JObject)item, item["label"].ToString());
                    if (aattribute.Aname == "size" && (product.Psizes==null || product.Psizes.Length > 0))
                    {
                        string text2 = product.Psizes == null?"":Regex.Replace(product.Psizes, "[^0-9a-zA-Z\\s\\.-:,]", "");
                        if (text2.Length > 0)
                        {
                            if (product.Lazadaskux == "" || product.Lazadaskux == null || product.Lazadaskux == "[{\"name\":\"DEFAULT\",\"value\":\"OnlyOne\"}]")
                                aattribute.Avalue = PublicFunctions.upFirstCharWithSpaceWithSplitor(("," + text2).Replace("，", ",").Replace(",3XL", ",Int:3XL").Replace(",XXXL", ",Int:3XL").Replace(",2XS", ",Int:XXS").Replace(",2XL", ",Int:XXL").Replace(",XL", ",Int:XL")
                                .Replace(",S", ",Int:S").Replace(",M", ",Int:M").Replace(",L", ",Int:L").Replace(",32", ",EU:32").Replace(",32.5", ",EU:32.5").Replace(",33", ",EU:33").Replace(",34", ",EU:34").Replace(",33.5", ",EU:33.5").Replace(",34.5", ",EU:34.5")
                                .Replace(",35", ",EU:35").Replace(",35.5", ",EU:35.5").Replace(",36", ",EU:36").Replace(",36.5", ",EU:36.5").Replace(",37", ",EU:37").Replace(",37.5", ",EU:37.5").Replace(",38", ",EU:38").Replace(",38.5", ",EU:38.5").Replace(",39", ",EU:39")
                                .Replace(",39.5", ",EU:39.5").Replace(",40", ",EU:40").Replace(",40.5", ",EU:40.5").Replace(",41", ",EU:41").Replace(",41.5", ",EU:41.5").Replace(",42", ",EU:42").Replace(",42.5", ",EU:42.5").Replace(",43", ",EU:43").Replace(",43.5", ",EU:43.5")
                                .Replace(",44", ",EU:44").Replace(",44.5", ",EU:44.5").Replace(",45", ",EU:45").Replace(",45.5", ",EU:45.5").Replace(",46", ",EU:46").Replace(",47", ",EU:47").Replace(",46.5", ",EU:46.5").Replace(",47.5", ",EU:47.5").Replace(",48", ",EU:48")
                                .Replace(",48.5", ",EU:48.5").Replace(",49", ",EU:49").Replace(",49.5", ",EU:49.5").Replace(",50", ",EU:50").Remove(0, 1), ',', false); 
                            skuValueSelector.zhongwencolor = text2;
                        }
                    }
                    else if (aattribute.Aname == "color_family" && (product.Pcolors==null || product.Pcolors.Length > 0))
                    {
                        string text2 = product.Pcolors==null?"": Regex.Replace(product.Pcolors, "[^0-9a-zA-Z\\s\\.-:,]", "");
                        if (text2.Length > 0)
                        {
                            if (product.Lazadaskux == "" || product.Lazadaskux == null)
                                aattribute.Avalue = PublicFunctions.upFirstCharWithSpaceWithSplitor(text2.Replace("，", ","), ',');
                            skuValueSelector.zhongwencolor = text2;
                        }
                    }
                    if (item["input_type"].ToString().IndexOf("Input") != -1 || !item["options"].HasValues)
                    {
                        skuValueSelector.CanEdit = true;
                        skuValueSelector.CanCustomEdit = true;
                    }
                    if (item["input_type"].ToString() == "numeric")
                    {
                        skuValueSelector.IsNumeric = true;
                    }
                    skuValueSelector.DataContext = aattribute;
                    Binding binding = new Binding("Avalue");
                    binding.Mode = BindingMode.TwoWay;
                    binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                    skuValueSelector.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding);

                    this.skulistpanel.Children.Add(skuValueSelector);
                    skuValueSelector.Margin = new Thickness(0.0, 3.0, 0.0, 5.0);
                }
                else
                {
                    bool isMandatory = Convert.ToBoolean(item["is_mandatory"]);
                    if (isMandatory)
                    {
                        Aattribute aattribute = new Aattribute();
                        aattribute.Aname = item["name"].ToString();
                        aattribute.IsSku = true;
                        if (categoryAttrDic.ContainsKey(aattribute.Aname))
                        {
                            aattribute.Avalue = categoryAttrDic[aattribute.Aname];
                        }
                        categoryOtherAttrs.Add(aattribute);
                        caMlKHhf7i(this.WrapPanelX01, (JObject)item, aattribute);
                    }
                    else
                    {
                        Aattribute aattribute = new Aattribute();
                        aattribute.Aname = item["name"].ToString();
                        aattribute.IsSku = false;
                        if (categoryAttrDic.ContainsKey(aattribute.Aname))
                        {
                            aattribute.Avalue = categoryAttrDic[aattribute.Aname];
                        }
                        categoryOtherAttrs.Add(aattribute);
                        caMlKHhf7i(this.WrapPanelX02, (JObject)item, aattribute);
                    }

                }
            });
        }

        private void LoadCategoryDetail(string leafId)
        {
            JObject jsondata = new LazadaCore().GetCategoryAttr(leafId);
            Product product = (Product)this.DataContext;
            if (jsondata["data"] == null) return;
            var list = ((JArray)jsondata["data"]).ToList();
            categoryAttrs.Clear();
            categoryOtherAttrs.Clear();
            categoryAttrDic = InitDictionary(product.Lazadaskux, product.Lazadaattributs);
            WrapPanelX01.Children.Clear();
            WrapPanelX02.Children.Clear();
            skulistpanel.Children.Clear();
            //SKU 必要属性
            list.Where(p => Convert.ToString(p["attribute_type"]) == "sku").ToList().ForEach(item =>
            {
                var t = item["input_type"].ToString();
                if (item["input_type"].ToString() == "singleSelect" && item["is_mandatory"].ToString() == "1" && item["options"].HasValues)
                {
                    //税种
                    if (item["name"].ToString() == "tax_class")
                    {
                        if (item["options"] != null && item["options"].HasValues)
                        {
                            //JArray jarray2 = (JArray)item["options"];
                            //if (jarray2.Count > 0)
                            //{
                            //    this.labelTaxes.Tag = new FyLabel("", this.labelTaxes, this.comboBoxTaxes, (JObject)item);
                            //    ObservableCollection<OptionItem> observableCollection = new ObservableCollection<OptionItem>();
                            //    int num = -1;
                            //    string b = "default";
                            //    if (product.Lazadatax != null)
                            //    {
                            //        b = product.Lazadatax;
                            //    }
                            //    for (int j = 0; j < jarray2.Count; j++)
                            //    {
                            //        string text = ((JObject)jarray2[j])["name"].ToString().Trim();
                            //        string chName = text;
                            //        if (((JObject)jarray2[j])["CHname"] != null)
                            //        {
                            //            if (!string.IsNullOrEmpty(((JObject)jarray2[j])["CHname"].ToString()))
                            //            {
                            //                chName = ((JObject)jarray2[j])["CHname"].ToString();
                            //            }
                            //        }
                            //        observableCollection.Add(new OptionItem
                            //        {
                            //            EnName = text,
                            //            ChName = chName
                            //        });
                            //        if (text == b)
                            //        {
                            //            num = j;
                            //        }
                            //    }
                            //    this.comboBoxTaxes.ItemsSource = observableCollection;
                            //    this.comboBoxTaxes.DisplayMemberPath = "ChName";
                            //    this.comboBoxTaxes.SelectedValuePath = "EnName";
                            //}
                            Aattribute aattribute6 = new Aattribute();
                            aattribute6.Aname = item["name"].ToString();
                            aattribute6.IsSku = true;
                            if (categoryAttrDic.ContainsKey(aattribute6.Aname))
                            {
                                aattribute6.Avalue = categoryAttrDic[aattribute6.Aname];
                            }
                            categoryOtherAttrs.Add(aattribute6);
                            //caMlKHhf7i(this.WrapPanelX02, (JObject)item, aattribute6);
                            if ((int)item["is_mandatory"] == 1)
                            {
                                caMlKHhf7i(this.WrapPanelX01, (JObject)item, aattribute6);
                            }
                            else
                            {
                                caMlKHhf7i(this.WrapPanelX02, (JObject)item, aattribute6);
                            }
                        }
                    }
                    else
                    {
                        Aattribute aattribute = new Aattribute();
                        aattribute.Aname = item["name"].ToString();
                        if (categoryAttrDic.ContainsKey(aattribute.Aname))
                        {
                            aattribute.Avalue = categoryAttrDic[aattribute.Aname];
                        }
                        categoryAttrs.Add(aattribute);
                        SkuValueSelector skuValueSelector = new SkuValueSelector((JObject)item, item["label"].ToString());
                        if (aattribute.Aname == "size" && product.Psizes.Length > 0)
                        {
                            string text2 = Regex.Replace(product.Psizes, "[^0-9a-zA-Z\\s\\.-:,]", "");
                            if (text2.Length > 0)
                            {
                                    skuValueSelector.zhongwencolor = text2;
                            }
                        }
                        skuValueSelector.DataContext = aattribute;
                        Binding binding = new Binding("Avalue");
                        binding.Mode = BindingMode.TwoWay;
                        binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                        skuValueSelector.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding);

                        this.skulistpanel.Children.Add(skuValueSelector);
                        skuValueSelector.Margin = new Thickness(0.0, 3.0, 0.0, 5.0);
                    }
                }
                else
                {
                    if (((item["input_type"].ToString() == "multiSelect" || item["input_type"].ToString() == "multiEnumInput" || item["input_type"].ToString() == "enumInput")
                    && item["is_mandatory"].ToString() == "1" && item["options"].HasValues) ||
                    item["name"].ToString() == "type_screen_guard" || item["name"].ToString() == "material_screen_guard" || item["name"].ToString() == "eyewear_size")
                    {
                        if ((item["name"].ToString() == "color_family" || item["name"].ToString() == "watch_strap_color" || item["name"].ToString() == "type_screen_guard"))
                        {
                            #region color_family
                            Aattribute aattribute2 = new Aattribute();
                            aattribute2.Aname = item["name"].ToString();
                            if (categoryAttrDic.ContainsKey(aattribute2.Aname))
                            {
                                aattribute2.Avalue = categoryAttrDic[aattribute2.Aname];
                            }
                            categoryAttrs.Add(aattribute2);
                            SkuValueSelector skuValueSelector2 = new SkuValueSelector((JObject)item, item["label"].ToString());
                            bool flag17 = item["input_type"].ToString().IndexOf("Input") != -1;
                            if (flag17)
                            {
                                skuValueSelector2.CanEdit = true;
                                skuValueSelector2.CanCustomEdit = true;
                            }
                            if (product.Pcolors.Length > 0)
                            {
                                string text3 = Regex.Replace(product.Pcolors, "[^0-9a-zA-Z\\s\\.-:,]", "");
                                bool flag19 = text3.Length > 0;
                                if (flag19)
                                {
                                        skuValueSelector2.zhongwencolor = IDfWwoYj3X(text3, ',');
                                }
                            }
                            skuValueSelector2.DataContext = aattribute2;
                            Binding binding2 = new Binding("Avalue");
                            binding2.Mode = BindingMode.TwoWay;
                            binding2.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                            skuValueSelector2.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding2);

                            this.skulistpanel.Children.Add(skuValueSelector2);
                            skuValueSelector2.Margin = new Thickness(0.0, 3.0, 0.0, 5.0);
                            #endregion
                        }
                        else
                        {
                            if (item["name"].ToString() == "color_hb")
                            {
                                #region color_hb
                                Aattribute aattribute3 = new Aattribute();
                                aattribute3.Aname = item["name"].ToString();
                                if (categoryAttrDic.ContainsKey(aattribute3.Aname))
                                {
                                    aattribute3.Avalue = categoryAttrDic[aattribute3.Aname];
                                }
                                categoryAttrs.Add(aattribute3);
                                SkuValueSelector skuValueSelector3 = new SkuValueSelector((JObject)item, "Color text");
                                skuValueSelector3.CanEdit = true;
                                skuValueSelector3.DataContext = aattribute3;
                                Binding binding3 = new Binding("Avalue");
                                binding3.Mode = BindingMode.TwoWay;
                                binding3.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                                skuValueSelector3.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding3);

                                this.skulistpanel.Children.Add(skuValueSelector3);
                                skuValueSelector3.Margin = new Thickness(0.0, 3.0, 0.0, 5.0);
                                #endregion
                            }
                            else
                            {
                                #region 其他
                                Aattribute aattribute4 = new Aattribute();
                                aattribute4.Aname = item["name"].ToString();
                                if (categoryAttrDic.ContainsKey(aattribute4.Aname))
                                {
                                    aattribute4.Avalue = categoryAttrDic[aattribute4.Aname];
                                }
                                categoryAttrs.Add(aattribute4);
                                SkuValueSelector skuValueSelector4 = new SkuValueSelector((JObject)item, item["label"].ToString());
                                bool flag23 = item["input_type"].ToString() == "multiEnumInput";
                                if (flag23)
                                {
                                    skuValueSelector4.CanEdit = true;
                                    skuValueSelector4.CanCustomEdit = true;
                                }
                                skuValueSelector4.DataContext = aattribute4;
                                Binding binding4 = new Binding("Avalue");
                                binding4.Mode = BindingMode.TwoWay;
                                binding4.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                                skuValueSelector4.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding4);

                                this.skulistpanel.Children.Add(skuValueSelector4);
                                skuValueSelector4.Margin = new Thickness(0.0, 0.0, 0.0, 5.0);
                                #endregion}
                            }
                        }
                    }
                    else if (item["name"].ToString() == "color_family" && !item["options"].HasValues)
                    {
                        Aattribute aattribute = new Aattribute();
                        aattribute.Aname = item["name"].ToString();
                        if (categoryAttrDic.ContainsKey(aattribute.Aname))
                        {
                            aattribute.Avalue = categoryAttrDic[aattribute.Aname];
                        }
                        categoryAttrs.Add(aattribute);
                        SkuValueSelector skuValueSelector = new SkuValueSelector((JObject)item, item["label"].ToString());
                        skuValueSelector.CanEdit = true;
                        skuValueSelector.CanCustomEdit = true;
                        skuValueSelector.DataContext = aattribute;
                        Binding binding = new Binding("Avalue");
                        binding.Mode = BindingMode.TwoWay;
                        binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                        skuValueSelector.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding);

                        this.skulistpanel.Children.Add(skuValueSelector);
                        skuValueSelector.Margin = new Thickness(0.0, 3.0, 0.0, 5.0);
                    }
                    else if (item["name"].ToString() == "cable_connection" || item["name"].ToString() == "cable_length" || item["name"].ToString() == "smartwatch_dial_size" || item["name"].ToString() == "wear_acc_connectivity" || item["name"].ToString() == "smartwear_size" || item["name"].ToString() == "power_tool_accessory_size")
                    {
                        Aattribute aattribute = new Aattribute();
                        aattribute.Aname = item["name"].ToString();
                        if (categoryAttrDic.ContainsKey(aattribute.Aname))
                        {
                            aattribute.Avalue = categoryAttrDic[aattribute.Aname];
                        }
                        categoryAttrs.Add(aattribute);
                        SkuValueSelector skuValueSelector = new SkuValueSelector((JObject)item, item["label"].ToString());
                        skuValueSelector.CanEdit = true;
                        skuValueSelector.CanCustomEdit = true;
                        skuValueSelector.DataContext = aattribute;
                        Binding binding = new Binding("Avalue");
                        binding.Mode = BindingMode.TwoWay;
                        binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                        skuValueSelector.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding);

                        this.skulistpanel.Children.Add(skuValueSelector);
                        skuValueSelector.Margin = new Thickness(0.0, 3.0, 0.0, 5.0);
                    }
                    else
                    {
                        Aattribute aattribute5 = new Aattribute();
                        aattribute5.Aname = item["name"].ToString();
                        aattribute5.IsSku = true;
                        if (categoryAttrDic.ContainsKey(aattribute5.Aname))
                        {
                            aattribute5.Avalue = categoryAttrDic[aattribute5.Aname];
                        }
                        if (!attrlist.Contains(aattribute5.Aname))
                            categoryOtherAttrs.Add(aattribute5);
                        if (attrlist.Contains(aattribute5.Aname)) return;
                        if ((int)item["is_mandatory"] == 1)

                        {
                            bool flag43 = !item["label"].ToString().StartsWith("*");
                            if (flag43)
                            {
                                item["label"] = "*" + item["label"].ToString();
                            }
                            caMlKHhf7i(this.WrapPanelX01, (JObject)item, aattribute5);
                        }
                        else

                        {
                            caMlKHhf7i(this.WrapPanelX02, (JObject)item, aattribute5);
                        }
                    }
                }
            });
            //sku 非必要属性
            list.Where(p => Convert.ToString(p["attribute_type"]) != "sku").ToList().ForEach(item =>
            {
                if (attrlist.Contains(item["name"].ToString())) return;
                //if (item["name"].ToString() == "warranty_type")
                //{
                //    if (item["options"] != null && item["options"].HasValues)
                //    {
                //        JArray jarray3 = (JArray)item["options"];
                //        if (jarray3.Count > 0)
                //        {
                //            this.labelWTX.Tag = new FyLabel("", this.labelWTX, this.comboBox1wt, (JObject)item);
                //            ObservableCollection<OptionItem> observableCollection2 = new ObservableCollection<OptionItem>();
                //            int num2 = -1;
                //            string b2 = "No Warranty";
                //            if (product.Lazadawarrantytype != null)
                //            {
                //                b2 = product.Lazadawarrantytype;
                //            }
                //            for (int k = 0; k < jarray3.Count; k++)

                //            {
                //                string text4 = ((JObject)jarray3[k])["name"].ToString().Trim();
                //                string chName2 = text4;
                //                bool flag29 = ((JObject)jarray3[k])["CHname"] != null;
                //                if (flag29)
                //                {
                //                    bool flag30 = !string.IsNullOrEmpty(((JObject)jarray3[k])["CHname"].ToString());
                //                    if (flag30)
                //                    {
                //                        chName2 = ((JObject)jarray3[k])["CHname"].ToString();
                //                    }
                //                }
                //                observableCollection2.Add(new OptionItem
                //                {
                //                    EnName = text4,
                //                    ChName = chName2
                //                });
                //                bool flag31 = text4 == b2;
                //                if (flag31)
                //                {
                //                    num2 = k;
                //                }
                //            }
                //            this.comboBox1wt.ItemsSource = observableCollection2;
                //            this.comboBox1wt.DisplayMemberPath = "ChName";
                //            this.comboBox1wt.SelectedValuePath = "EnName";
                //            //this.comboBox1wt.SelectionChanged += this.VoalqjrLl1;
                //            //bool flag32 = num2 >= 0 && this.comboBox1wt.Items.Count > num2;
                //            //if (flag32)

                //            //{
                //            //    this.comboBox1wt.SelectedIndex = num2;
                //            //}
                //        }
                //    }
                //}
                //else
                {
                    //if (item["name"].ToString() == "warranty")
                    //{
                    //    if (item["options"] != null && item["options"].HasValues)
                    //    {
                    //        JArray jarray4 = (JArray)item["options"];
                    //        if (jarray4.Count > 0)
                    //        {
                    //            this.labelWTX.Tag = new FyLabel("", this.labelWTX, this.comboBox1wp, (JObject)item);
                    //            ObservableCollection<OptionItem> observableCollection3 = new ObservableCollection<OptionItem>();
                    //            int num3 = -1;
                    //            string text5 = "";
                    //            if (product.Lazadawarrantyperiod != null)
                    //            {
                    //                text5 = product.Lazadawarrantyperiod;
                    //            }
                    //            for (int l = 0; l < jarray4.Count; l++)
                    //            {
                    //                string text6 = ((JObject)jarray4[l])["name"].ToString().Trim();
                    //                string chName3 = text6;
                    //                bool flag37 = ((JObject)jarray4[l])["CHname"] != null;
                    //                if (flag37)
                    //                {
                    //                    bool flag38 = !string.IsNullOrEmpty(((JObject)jarray4[l])["CHname"].ToString());
                    //                    if (flag38)
                    //                    {
                    //                        chName3 = ((JObject)jarray4[l])["CHname"].ToString();
                    //                    }
                    //                }
                    //                observableCollection3.Add(new OptionItem
                    //                {
                    //                    EnName = text6,
                    //                    ChName = chName3
                    //                });
                    //                bool flag39 = text5.Length > 0 && text6 == text5;
                    //                if (flag39)
                    //                {
                    //                    num3 = l;
                    //                }
                    //            }
                    //            this.comboBox1wp.ItemsSource = observableCollection3;
                    //            this.comboBox1wp.DisplayMemberPath = "ChName";
                    //            this.comboBox1wp.SelectedValuePath = "EnName";
                    //            //this.comboBox1wp.SelectionChanged += this.obalAQay33;
                    //            //bool flag40 = num3 >= 0 && this.comboBox1wp.Items.Count > num3;
                    //            //if (flag40)
                    //            //{
                    //            //    this.comboBox1wp.SelectedIndex = num3;
                    //            //}
                    //        }
                    //    }
                    //}
                    //if (item["name"].ToString() == "color_family")
                    //{
                    //    Aattribute aattribute = new Aattribute();
                    //    aattribute.Aname = item["name"].ToString();
                    //    if (categoryAttrDic.ContainsKey(aattribute.Aname))
                    //    {
                    //        aattribute.Avalue = categoryAttrDic[aattribute.Aname];
                    //    }
                    //    categoryAttrs.Add(aattribute);
                    //    SkuValueSelector skuValueSelector = new SkuValueSelector((JObject)item, item["label"].ToString());
                    //    skuValueSelector.CanEdit = true;
                    //    skuValueSelector.CanCustomEdit = true;
                    //    skuValueSelector.DataContext = aattribute;
                    //    Binding binding = new Binding("Avalue");
                    //    binding.Mode = BindingMode.TwoWay;
                    //    binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                    //    skuValueSelector.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding);

                    //    this.skulistpanel.Children.Add(skuValueSelector);
                    //    skuValueSelector.Margin = new Thickness(0.0, 3.0, 0.0, 5.0);
                    //}
                    //else
                    {
                        Aattribute aattribute5 = new Aattribute();
                        aattribute5.Aname = item["name"].ToString();
                        aattribute5.IsSku = (int)item["is_mandatory"] == 1;
                        if (categoryAttrDic.ContainsKey(aattribute5.Aname))
                        {
                            aattribute5.Avalue = categoryAttrDic[aattribute5.Aname];
                        }
                        if (!attrlist.Contains(aattribute5.Aname))
                            categoryOtherAttrs.Add(aattribute5);
                        bool flag42 = (int)item["is_mandatory"] == 1;
                        if (flag42)

                        {
                            bool flag43 = !item["label"].ToString().StartsWith("*");
                            if (flag43)
                            {
                                item["label"] = "*" + item["label"].ToString();
                            }
                            this.caMlKHhf7i(this.WrapPanelX01, (JObject)item, aattribute5);
                        }
                        else

                        {
                            this.caMlKHhf7i(this.WrapPanelX02, (JObject)item, aattribute5);
                        }
                    }
                }
            });
        }

        private Dictionary<string, string> InitDictionary(string skux, string attrs)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            if (skux != null && skux != string.Empty)
            {
                JArray jarray = (JArray)JsonConvert.DeserializeObject(skux);
                foreach (JToken jtoken in jarray)
                {
                    JObject jobject = (JObject)jtoken;
                    dic.Add(jobject["name"].ToString(), jobject["value"].ToString());
                }
            }
            if (attrs != null && attrs != string.Empty)
            {
                JArray jarray2 = (JArray)JsonConvert.DeserializeObject(attrs);
                foreach (JToken jtoken in jarray2)
                {
                    JObject jobject = (JObject)jtoken;
                    dic.Add(jobject["name"].ToString(), jobject["value"].ToString());
                }
            }
            return dic;
        }
        //加载属性
        private void caMlKHhf7i(WrapPanel wp, JObject att, Aattribute od)
        {
            int num = 0;
            Canvas canvas = new Canvas();
            canvas.Height = 25.0;
            canvas.Width = 340;
            if (att["label"].ToString().StartsWith("*") || att["is_mandatory"].ToString() == "1")
            {
                canvas.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFB43F"));
                //canvas.Background = new SolidColorBrush(Color.FromArgb(170, byte.MaxValue, 204, 153));
            }
            else
            {
                canvas.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#9DAAC1"));
                //canvas.Background = new SolidColorBrush(Color.FromRgb(210, 225, 210));
            }
            canvas.Margin = new Thickness(4.0, 0.0, 0.0, 2.0);
            canvas.DataContext = od;
            Label label = new Label();
            bool flag2 = att["CHlabel"] == null;
            if (flag2)
            {
                label.Content = att["label"].ToString();
            }
            else
            {
                label.Content = att["CHlabel"].ToString();
                label.ToolTip = att["label"].ToString();
            }
            bool flag3 = att["label"].ToString().Length > 15;
            if (flag3)
            {
                label.ToolTip = att["label"].ToString();
                num = 50;
            }
            label.HorizontalAlignment = HorizontalAlignment.Left;
            canvas.Children.Add(label);
            label.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
            label.MouseEnter += this.aaQlO13fOX;

            label.MouseLeave += this.LArlUJbNoF;

            label.MouseDoubleClick += this.AttributeDoubleClick;

            string a = att["input_type"].ToString();
            if (!(a == "numeric") && !(a == "text"))

            {
                if (!(a == "multiSelect"))
                {
                    if (!(a == "singleSelect"|| a == "multiEnumInput" || a == "enumInput"))
                    {
                        TextBox textBox = new TextBox();
                        textBox.Height = 22.0;
                        textBox.Width = (double)(170);
                        textBox.Margin = new Thickness((double)(170), 2.0, 0.0, 0.0);
                        //textBox.LostFocus += this.NFAl5Wf0JS;
                        Binding binding = new Binding("Avalue");
                        binding.Mode = BindingMode.TwoWay;
                        binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                        textBox.SetBinding(TextBox.TextProperty, binding);
                        canvas.Children.Add(textBox);
                    }
                    else
                    {
                        ComboBox comboBox = new ComboBox();
                        comboBox.Height = 22.0;
                        comboBox.Width = (double)(170);
                        comboBox.Margin = new Thickness((double)(170), 2.0, 0.0, 0.0);
                        comboBox.Tag = od;
                        JArray jarray = (JArray)att["options"];
                        bool flag4 = jarray.Count > 0;
                        if (flag4)

                        {
                            label.Tag = new FyLabel("", label, comboBox, att);
                            ObservableCollection<OptionItem> observableCollection = new ObservableCollection<OptionItem>();
                            observableCollection.Add(new OptionItem
                            {
                                EnName = " ",
                                ChName = " "
                            });
                            int num2 = -1;
                            for (int i = 0; i < jarray.Count; i++)
                            {
                                string text = ((JObject)jarray[i])["name"].ToString();
                                string chName = text;
                                bool flag5 = ((JObject)jarray[i])["CHname"] != null;
                                if (flag5)
                                {
                                    bool flag6 = !string.IsNullOrEmpty(((JObject)jarray[i])["CHname"].ToString());
                                    if (flag6)
                                    {
                                        chName = ((JObject)jarray[i])["CHname"].ToString();
                                    }
                                }
                                OptionItem item = new OptionItem
                                {
                                    EnName = text,
                                    ChName = chName
                                };
                                observableCollection.Add(item);
                                bool flag7 = od.Avalue == text;
                                if (flag7)
                                {
                                    num2 = observableCollection.IndexOf(item);
                                }
                            }
                            comboBox.ItemsSource = observableCollection;
                            comboBox.DisplayMemberPath = "ChName";
                            comboBox.SelectedValuePath = "EnName";
                            comboBox.SelectionChanged += this.i36lhTIgPS;
                            bool flag8 = num2 >= 0 && comboBox.Items.Count > num2;
                            if (flag8)
                            {
                                comboBox.SelectedIndex = num2;
                            }
                        }
                        else

                        {
                            Binding binding2 = new Binding("Avalue");
                            binding2.Mode = BindingMode.TwoWay;
                            comboBox.SetBinding(ComboBox.TextProperty, binding2);
                            comboBox.IsEditable = true;
                            comboBox.IsTextSearchEnabled = false;
                            bool flag9 = att["name"].ToString() == "brand";
                            if (flag9)

                            {
                                TextBox textBox2 = new TextBox();
                                textBox2.Height = 22.0;
                                textBox2.Width = (double)(215 - num);
                                textBox2.KeyDown += this.auClNmcSBP;
                                comboBox.Items.Add(textBox2);
                                comboBox.GotFocus += this.akgl7QsrYW;
                                WaittingImg waittingImg = new WaittingImg("Enter后开搜索");
                                waittingImg.pauseWaitting();
                                textBox2.Tag = waittingImg;
                            }
                        }
                        canvas.Children.Add(comboBox);
                    }
                }
                else
                {
                    MutiAttrSelector mutiAttrSelector = new MutiAttrSelector();
                    mutiAttrSelector.Height = 22.0;
                    mutiAttrSelector.Width = (double)(170);
                    mutiAttrSelector.Margin = new Thickness((double)(170), 2.0, 0.0, 0.0);
                    mutiAttrSelector.Tag = od;
                    Binding binding3 = new Binding("Avalue");
                    binding3.Mode = BindingMode.TwoWay;
                    mutiAttrSelector.SetBinding(MutiAttrSelector.AttributValueProperty, binding3);
                    mutiAttrSelector.SetBinding(FrameworkElement.ToolTipProperty, binding3);
                    JArray jarray2 = (JArray)att["options"];
                    bool flag10 = jarray2.Count > 0;
                    if (flag10)
                    {
                        label.Tag = new FyLabel("", label, mutiAttrSelector, att);
                        bool flag11 = !string.IsNullOrEmpty(od.Avalue);
                        if (flag11)
                        {
                            List<string> list = new List<string>();
                            string[] array = od.Avalue.Split(new char[]
                                                        {
                                ','
                                                        }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string text2 in array)
                            {
                                bool flag12 = !list.Contains(text2.Trim());
                                if (flag12)
                                {
                                    list.Add(text2.Trim());
                                }
                            }
                            mutiAttrSelector.oldvalues = list;
                        }
                        List<OptionItem> list2 = new List<OptionItem>();
                        for (int k = 0; k < jarray2.Count; k++)
                        {
                            string text3 = ((JObject)jarray2[k])["name"].ToString().Trim();
                            string chName2 = text3;
                            bool flag13 = ((JObject)jarray2[k])["CHname"] != null;
                            if (flag13)
                            {
                                bool flag14 = !string.IsNullOrEmpty(((JObject)jarray2[k])["CHname"].ToString());
                                if (flag14)
                                {
                                    chName2 = ((JObject)jarray2[k])["CHname"].ToString();
                                }
                            }
                            OptionItem item2 = new OptionItem
                            {
                                EnName = text3,
                                ChName = chName2
                            };
                            list2.Add(item2);
                        }
                        mutiAttrSelector.AddOpints(list2);
                    }
                    canvas.Children.Add(mutiAttrSelector);
                }
            }
            else
            {
                TextBox textBox3 = new TextBox();
                textBox3.Height = 22.0;
                textBox3.Width = (double)(170);
                textBox3.Margin = new Thickness((double)(170), 2.0, 0.0, 0.0);
                //textBox3.LostFocus += this.NFAl5Wf0JS;

                Binding binding4 = new Binding("Avalue");

                binding4.Mode = BindingMode.TwoWay;

                binding4.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;

                textBox3.SetBinding(TextBox.TextProperty, binding4);
                canvas.Children.Add(textBox3);
            }
            wp.Children.Add(canvas);
        }

        private void akgl7QsrYW(object sender, RoutedEventArgs e)
        {
            //throw new NotImplementedException();
        }

        private void auClNmcSBP(object d, KeyEventArgs e)
        {
            bool flag = e.KeyboardDevice.IsKeyDown(Key.Return);
            if (flag)
            {
                e.Handled = true;
                TextBox textBox = (TextBox)d;
                bool flag2 = string.IsNullOrEmpty(textBox.Text.Trim());
                if (!flag2)
                {
                    WaittingImg waittingImg = (WaittingImg)textBox.Tag;
                    waittingImg.setTips("搜索中......");
                    waittingImg.startWaitting();
                    if (oldSreachContect == textBox.Text || textBox.Text.Trim() == string.Empty)
                        return;
                    oldSreachContect = textBox.Text;
                    ComboBox comboBox = (ComboBox)textBox.Parent;
                    comboBox.Items.Clear();
                    comboBox.Items.Add(textBox);
                    comboBox.Items.Add(textBox.Tag);
                    textBox.Focus();
                    Task.Run(() =>
                    {
                        var jsondata = new LazadaCore().GetBrands();
                        if (jsondata == null)
                        {
                            this.Dispatcher.BeginInvoke(new Action<TextBox>(delegate (TextBox b)
                            {
                                ((WaittingImg)b.Tag).setTips("查无结果");
                                ((WaittingImg)b.Tag).pauseWaitting();
                            }), new object[] { d });
                        }
                        else
                        {
                            base.Dispatcher.BeginInvoke(new Action<TextBox, JObject>(delegate (TextBox b, JObject c)
                            {
                                ((WaittingImg)b.Tag).setTips("继续请按Enter");
                                ((WaittingImg)b.Tag).pauseWaitting();
                                try
                                {
                                    string value = b.Text.Trim().ToLower();
                                    JArray jarray = (JArray)c["data"];
                                    foreach (JToken jtoken in jarray)
                                    {
                                        if (jtoken["name"].ToString().ToLower().StartsWith(value))
                                        {
                                            comboBox.Items.Insert(2, jtoken["name"].ToString());
                                        }
                                    }
                                }
                                catch
                                {
                                }
                            }), new object[] { d, jsondata });
                        }
                    });

                }
            }
        }

        private void i36lhTIgPS(object w, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)w;
            try
            {
                ((Aattribute)comboBox.Tag).Avalue = comboBox.SelectedValue.ToString();
            }
            catch
            {
            }
        }

        private void aaQlO13fOX(object sender, MouseEventArgs e)
        {

        }

        private void LArlUJbNoF(object sender, MouseEventArgs e)
        {

        }

        #region 属性双击翻译
        private void AttributeDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Label label = (Label)sender;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(label.Content.ToString() + "\r\n");
            bool flag = label.Tag != null;
            if (flag)
            {
                FyLabel fyLabel = (FyLabel)label.Tag;
                JArray jarray = (JArray)fyLabel.FYary["options"];
                foreach (JToken jtoken in jarray)
                {
                    stringBuilder.Append(jtoken["name"].ToString() + "\r\n");
                }
                fyLabel.FYstr = stringBuilder.ToString();
                new Thread(new ParameterizedThreadStart(this.AttributeTranslation)).Start(fyLabel);
            }
            else
            {
                var labelContent = new ALiCore().ChangeEnToZh(label.Content.ToString());
                this.Dispatcher.BeginInvoke(new Action(() => label.Content = labelContent));
            }
        }

        public void AttributeTranslation(object d)
        {
            string text = new ALiCore().ChangeEnToZh(((FyLabel)d).FYstr);
            base.Dispatcher.BeginInvoke(new Action<FyLabel, string>(delegate (FyLabel b, string c)
            {
                try
                {
                    bool flag = string.IsNullOrEmpty(c);
                    if (!flag)
                    {
                        Dictionary<string, string> dictionary = new Dictionary<string, string>();
                        string[] strZH = c.Replace("\n", "●").Split('●');
                        string[] strEN = ((FyLabel)b).FYstr.Replace("\n", "●").Split('●');
                        for (int i = 0; i < strEN.Length; i++)
                        {
                            string key = strEN[i].ToString().Trim();
                            string value = strZH.Length > i ? strZH[i].ToString().Trim() : null;
                            bool flag3 = !dictionary.ContainsKey(key);
                            if (flag3)
                            {
                                dictionary.Add(key, value);
                            }
                        }
                        Label fylb = b.FYlb;
                        bool flag4 = dictionary.ContainsKey(fylb.Content.ToString());
                        if (flag4)
                        {
                            fylb.ToolTip = fylb.Content.ToString();
                            fylb.Content = dictionary[fylb.Content.ToString()];
                        }
                        string key2 = b.FYary["label"].ToString();
                        bool flag5 = dictionary.ContainsKey(key2);
                        if (flag5)
                        {
                            b.FYary["CHlabel"] = dictionary[key2];
                        }
                        JArray jarray = (JArray)b.FYary["options"];
                        foreach (JToken jtoken in jarray)
                        {
                            bool flag6 = dictionary.ContainsKey(jtoken["name"].ToString());
                            if (flag6)
                            {
                                jtoken["CHname"] = jtoken["name"].ToString() + "(" + dictionary[jtoken["name"].ToString()] + ")";
                            }
                        }
                        bool flag7 = b.FYcbx != null;
                        if (flag7)
                        {
                            bool flag8 = b.FYcbx is ComboBox;
                            if (flag8)
                            {
                                ComboBox comboBox = (ComboBox)b.FYcbx;
                                foreach (object obj in ((IEnumerable)comboBox.Items))
                                {
                                    OptionItem optionItem = (OptionItem)obj;
                                    bool flag9 = dictionary.ContainsKey(optionItem.EnName);
                                    if (flag9)
                                    {
                                        optionItem.ChName = optionItem.EnName + "(" + dictionary[optionItem.EnName] + ")";
                                    }
                                }
                                comboBox.Items.Refresh();
                                bool flag10 = comboBox.SelectedIndex > 0;
                                if (flag10)
                                {
                                    int selectedIndex = comboBox.SelectedIndex;
                                    comboBox.SelectedIndex = 0;
                                    comboBox.SelectedIndex = selectedIndex;
                                }
                            }
                            else
                            {
                                bool flag11 = b.FYcbx is MutiAttrSelector;
                                if (flag11)
                                {
                                    ((MutiAttrSelector)b.FYcbx).RefreshOpints(dictionary);
                                }
                            }
                        }
                    }
                }
                catch
                {
                }
            }), new object[]
            {
                (FyLabel)d,
                text
            });
        }
        #endregion

        private void ruNlSIpe3Q(object sender, EventArgs e)
        {

        }

        private void KxGl3D9EJU(object sender, SelectionChangedEventArgs e)
        {

        }

        private void viblM1hkeC(object sender, RoutedEventArgs e)
        {
            if (WhatInBoxTXB.Text != string.Empty)
            {
                Product product = (Product)this.DataContext;
                product.Lazadapackageincluding = new ALiCore().ChangeZhToSiteDefaultLangauge(WhatInBoxTXB.Text,"offer");
            }

        }

        private void UdklvHhQRn(object sender, RoutedEventArgs e)
        {
            if (WhatInBoxTXB.Text == string.Empty) return;
            var strArr = WhatInBoxTXB.Text.Split(new char[] { '\n' });
            string rs = "";
            foreach (var item in strArr)
            {
                if (item.Trim() == string.Empty) continue;
                if (!item.StartsWith("1 * "))
                {
                    rs += "1 * " + item + "\n";
                }
                else
                {
                    rs += item + "\n";
                }
            }
            Product product = (Product)this.DataContext;
            product.Lazadapackageincluding = rs;
            //WhatInBoxTXB.Text = rs;
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }


        /// <summary>
        /// 获取计价模板下拉框
        /// </summary>
        private void GetPriceTemplates()
        {
            var list = new PriceTemplateCore().GetPriceTemplateList();
            cmbValuateMde.ItemsSource = list;
            cmbValuateMde.DisplayMemberPath = "Jname";
            cmbValuateMde.SelectedValuePath = "Jname";

            cboPT.ItemsSource = list;
            cboPT.DisplayMemberPath = "Jname";
            cboPT.SelectedValuePath = "Jname";
            cboPT.SelectedIndex = 0;
        }

        private void StartTimePicker_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime now = DateTime.Now;
                DateTime dateTime = DateTime.Parse(this.startTimePicker.PickedDateTime);
                DateTime dateTime2 = dateTime.AddMonths(1);
                bool flag = string.IsNullOrEmpty(this.endTimePicker.PickedDateTime);
                if (flag)
                {
                    this.endTimePicker.PickedDateTime = dateTime2.ToString("yyyy-MM-dd HH:00:00");
                }
                dateTime2 = DateTime.Parse(this.endTimePicker.PickedDateTime);
                this.CalcDays(dateTime, dateTime2);
                bool flag2 = now.CompareTo(dateTime) > 0;
                if (flag2)
                {
                    this.startTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.startTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
                bool flag3 = dateTime.CompareTo(dateTime2) > 0;
                if (flag3)
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
            }
            catch
            {
            }
        }

        private void EndTimePicker_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime now = DateTime.Now;
                DateTime u = now.AddHours(1.0);
                DateTime dateTime = DateTime.Parse(this.endTimePicker.PickedDateTime);
                bool flag = string.IsNullOrEmpty(this.startTimePicker.PickedDateTime);
                if (flag)
                {
                    this.startTimePicker.PickedDateTime = u.ToString("yyyy-MM-dd HH:00:00");
                }
                u = DateTime.Parse(this.startTimePicker.PickedDateTime);
                this.CalcDays(u, dateTime);
                bool flag2 = u.CompareTo(dateTime) > 0 || now.CompareTo(dateTime) > 0;
                if (flag2)
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 0, 0));
                }
                else
                {
                    this.endTimePicker.BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100));
                }
            }
            catch
            {
            }
        }

        #region 未了解方法
        public static string IDfWwoYj3X(string a, char b)
        {
            bool flag = a.Trim() == "";
            string result;
            if (flag)
            {
                result = "";
            }
            else
            {
                a = a.Trim();
                string[] array = a.Split(new char[]
                {
                    b
                }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < array.Length; i++)
                {
                    array[i] = tQiWgS80yU(array[i]);
                }
                result = string.Join(" " + b.ToString() + " ", array.Distinct<string>().ToArray<string>());
            }
            return result;
        }

        public static string tQiWgS80yU(string a)
        {
            bool flag = a.Trim() == "";
            string result;
            if (flag)
            {
                result = " ";
            }
            else
            {
                string[] array = a.Split(new char[]
                {
                    ' '
                }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < array.Length; i++)
                {
                    bool flag2 = array[i].Length > 1;
                    if (flag2)
                    {
                        array[i] = array[i].Substring(0, 1).ToUpper() + array[i].Substring(1).ToLower();
                    }
                    else
                    {
                        array[i] = array[i].ToUpper();
                    }
                }
                result = string.Join(" ", array);
            }
            return result;
        }
        #endregion


        /// <summary>
        /// 计算日期差值并显示
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        private void CalcDays(DateTime start, DateTime end)
        {
            int hours = (end - start).Hours;
            int days = (end - start).Days;
            this.timeTips.Content = string.Format("{0}D{1}H", days, hours);
        }

        private void PqQlBmCSW4(object sender, RoutedEventArgs e)
        {
            this.colorModel = null;
            Fkflmvunvs(null, null);
        }

        private void ocblJb3IMX(object sender, RoutedEventArgs e)
        {
            if (colorModel != null)
            {
                bool flag2 = this.colorModel.checkRepeadColor();
                if (!flag2)
                {
                    string[] useColors = this.colorModel.getUseColors();
                    this.textBox11.Text = string.Join(" , ", useColors);
                    Product product = (Product)this.DataContext;
                    product.Pcolors = this.textBox11.Text;

                    new ProductCore().SaveNewColorSizeToDBprolist(product);
                    this.Pop_xiangji.IsOpen = false;
                    this.colorModel = null;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //foreach (UIElement item in mainWin.myContain.Children)
            //{
            //    var name = ((UserControl)item).Name;
            //}
            //mainWin.myContain.Children.Clear();
            //DetailsEditor userControl = new DetailsEditor((Product)this.DataContext, mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);
            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "Detail");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //mainWin.myContain.Children.Clear();
            //ChooseImg userControl = new ChooseImg((Product)this.DataContext, mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);
            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "Img");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (!SaveProduct())
            {
                CMessageBox.Show("保存失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            //mainWin.myContain.Children.Clear();
            //Tasks userControl = new Tasks(mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);
            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "MT");
        }

        private DataTable CreateDataTable(List<string> addCols)
        {
            DataTable dt = new DataTable();
            DataColumn dc_0 = new DataColumn("SellerSku");
            DataColumn dc_10 = new DataColumn("IsSelected");
            DataColumn dc_11 = new DataColumn("package_weight");
            DataColumn dc_12 = new DataColumn("CostPrice");
            DataColumn dc_1 = new DataColumn("price");
            DataColumn dc_2 = new DataColumn("special_price");
            DataColumn dc_3 = new DataColumn("quantity");
            DataColumn dc_4 = new DataColumn("Pjijiamuban");
            dt.Columns.Add(dc_10);
            dt.Columns.Add(dc_0);
            foreach (var item in addCols)
            {
                DataColumn dc = new DataColumn(item);
                dt.Columns.Add(dc);
            }
            dt.Columns.Add(dc_11);
            dt.Columns.Add(dc_12);
            dt.Columns.Add(dc_1);
            dt.Columns.Add(dc_2);
            dt.Columns.Add(dc_3);
            dt.Columns.Add(dc_4);
            return dt;
        }

        private void BtnRefrush_Click(object sender, RoutedEventArgs e)
        {
            CreateDataGridForCategory();
            //DataGridRow dr=

        }

        private void CreateDataGridForCategory()
        {
            List<DataGridTextColumn> del = new List<DataGridTextColumn>();
            foreach (var item in dgShow.Columns)
            {
                if (item is DataGridTextColumn)
                    if (!dgColunms.Contains(item.Header.ToString()))
                    {
                        del.Add((DataGridTextColumn)item);
                    }
            }
            del.ForEach(p => dgShow.Columns.Remove(p));

            int rows = 1;
            List<string> addCols = new List<string>();
            Queue<Aattribute> items = new Queue<Aattribute>();
            Product product = (Product)this.DataContext;
            int index = 2;
            if (categoryAttrs.Count > 0)
            {
                foreach (var item in categoryAttrs)
                {
                    DataGridTextColumn column = new DataGridTextColumn();
                    column.Header = item.Aname;
                    Binding binding = new Binding();
                    binding.Path = new PropertyPath(item.Aname);
                    column.Binding = binding;
                    column.Width = 80;
                    dgShow.Columns.Insert(index, column);
                    var length = item.Avalue.Replace(" ", "").Replace(" ", "").Replace("，", ",").Split(',').Length;
                    rows = rows * length;
                    if (item.Avalue.Trim() != string.Empty)
                    {
                        addCols.Add(item.Aname);
                        items.Enqueue(item);
                        index++;
                    }
                }
                //CreateDataGridComboBox(index);
                dtSource = CreateDataTable(addCols);
            }
            if (items.Count > 0)
            {
                while (items.Count > 0)
                {
                    var firstItem = items.Dequeue();
                    var loopRows = firstItem.Avalue.Replace(" ", "").Replace(" ", "").Replace("，", ",").Split(',').Length;
                    var values = firstItem.Avalue.Replace("，", ",").Split(',');
                    int kLimit = dtSource.Rows.Count;
                    string name = "";
                    if (dtSource.Rows.Count > 0)
                    {
                        for (int k = 0; k < kLimit; k++)
                        {
                            for (int i = 0; i < loopRows; i++)
                            {
                                DataRow dr = null;
                                if (i == 0)
                                {
                                    dr = dtSource.Rows[k];
                                    name = dr["SellerSku"].ToString();
                                    dr[firstItem.Aname] = values[i].Trim();
                                    dr["SellerSku"] = Convert.ToString(dr["SellerSku"]) + "-" + Convert.ToString(dr[firstItem.Aname]);
                                    dr["SellerSku"] = dr["SellerSku"].ToString().Replace(" ", "").Replace(":", "");
                                }
                                else
                                {
                                    var r = dtSource.Rows.Count;
                                    dr = dtSource.NewRow();
                                    for (int l = 0; l < dtSource.Columns.Count; l++)
                                    {
                                        dr[l] = dtSource.Rows[k][l];
                                    }
                                    dr[firstItem.Aname] = values[i].Trim();
                                    dr["SellerSku"] = name + "-" + Convert.ToString(dr[firstItem.Aname]);
                                    dr["SellerSku"] = dr["SellerSku"].ToString().Replace(" ", "").Replace(":", "");
                                    dtSource.Rows.Add(dr);
                                }

                            }
                        }
                    }
                    else
                    {
                        for (int i = 0; i < loopRows; i++)
                        {
                            DataRow dr = dtSource.NewRow();
                            dr["IsSelected"] = false;
                            dr["package_weight"] = product.Lazadapackageweight;
                            dr["CostPrice"] = product.Porigprice;
                            dr["price"] = product.Lazadaprice;
                            dr["special_price"] = product.Lazadapromprice;
                            dr["quantity"] = product.Pkuchen;
                            dr["Pjijiamuban"] = product.Pjisangongshi;
                            dr["SellerSku"] = product.Pidprefix + product.SKUNumber;
                            dr[firstItem.Aname] = values[i].Trim();
                            dr["SellerSku"] = Convert.ToString(dr["SellerSku"]) + "-" + Convert.ToString(dr[firstItem.Aname]);
                            dr["SellerSku"] = dr["SellerSku"].ToString().Replace(" ", "").Replace(":", "");
                            dtSource.Rows.Add(dr);
                        }
                    }

                }
            }
            else
            {
                dtSource = CreateDataTable(addCols);

                DataRow dr = dtSource.NewRow();
                dr["IsSelected"] = false;
                dr["package_weight"] = product.Lazadapackageweight;
                dr["CostPrice"] = product.Porigprice;
                dr["price"] = product.Lazadaprice;
                dr["special_price"] = product.Lazadapromprice;
                dr["quantity"] = product.Pkuchen;
                dr["Pjijiamuban"] = product.Pjisangongshi;
                dr["SellerSku"] = product.Pidprefix + product.SKUNumber;
                dr["SellerSku"] = Convert.ToString(dr["SellerSku"]) + "-" + "OnlyOne";
                dr["SellerSku"] = dr["SellerSku"].ToString().Replace(" ", "").Replace(":", "");
                dtSource.Rows.Add(dr);


            }
            if (addCols.Count > 0)
            {
                dtSource.DefaultView.Sort = addCols[0];
                dtSource = dtSource.DefaultView.ToTable();
            }
            //}
            //else
            //{
            //    DataGridTextColumn column = new DataGridTextColumn();
            //    column.Header = "Only";
            //}
            dgShow.ItemsSource = dtSource.DefaultView;

        }

        private void BtnReturn_Click(object sender, RoutedEventArgs e)
        {
            CreateDataGridFromSku();
        }

        private void CreateDataGridFromSku()
        {
            Product product = (Product)this.DataContext;
            if (product.SKUDetail != string.Empty && product.SKUDetail != null)
            {
                List<DataGridTextColumn> del = new List<DataGridTextColumn>();
                foreach (var item in dgShow.Columns)
                {
                    if (item is DataGridTextColumn)
                        if (!dgColunms.Contains(item.Header.ToString()))
                        {
                            del.Add((DataGridTextColumn)item);
                        }
                }
                del.ForEach(pp => dgShow.Columns.Remove(pp));

                int index = 2;
                foreach (var item in categoryAttrs)
                {
                    DataGridTextColumn column = new DataGridTextColumn();
                    column.Header = item.Aname;
                    Binding binding = new Binding();
                    binding.Path = new PropertyPath(item.Aname);
                    column.Binding = binding;
                    column.Width = 80;
                    dgShow.Columns.Insert(index, column);
                    var length = item.Avalue.Replace(" ", "").Replace(" ", "").Replace("，", ",").Split(',').Length;
                    index++;
                }

                JArray array = JsonConvert.DeserializeObject<JArray>(product.SKUDetail);
                if (array.Count > 0)
                {
                    dtSource = null;
                    dtSource = new DataTable();
                    var obj = JsonConvert.DeserializeObject<JObject>(array[0].ToString());
                    var p = obj.Properties();
                    DataColumn dc_0 = new DataColumn("IsSelected");
                    dtSource.Columns.Add(dc_0);
                    foreach (var item in p)
                    {
                        DataColumn dc = new DataColumn(item.Name);
                        dtSource.Columns.Add(dc);
                    }
                    //CreateDataGridComboBox(index);
                    for (int i = 0; i < array.Count; i++)
                    {
                        var json = JsonConvert.DeserializeObject<JObject>(array[i].ToString());
                        var ps = json.Properties();
                        DataRow dr = dtSource.NewRow();
                        dr["IsSelected"] = false;
                        foreach (var item in ps)
                        {
                            dr[item.Name] = item.Value;
                        }
                        dtSource.Rows.Add(dr);
                    }
                    dgShow.ItemsSource = dtSource.DefaultView;
                }
            }
        }

        private void CreateDataGridComboBox(int index)
        {
            var list = new PriceTemplateCore().GetPriceTemplateList();
            var cbo = ((DataGridComboBoxColumn)dgShow.Columns[6 + index - 1]);
            cbo.ItemsSource = list;
            cbo.DisplayMemberPath = "Jname";
            cbo.SelectedValuePath = "Jname";
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var pt = (PriceTemplateEntity)((ComboBox)sender).SelectedItem;
            if (pt == null) return;
            var ptc = new PriceTemplateCore();

            for (int i = 0; i < dtSource.Rows.Count; i++)
            {
                if (Convert.ToString(dtSource.Rows[i]["Pjijiamuban"]) == pt.Jname)
                {
                    var strs = ptc.CalcProductCost(pt, dtSource.Rows[i]["package_weight"].ToString(), dtSource.Rows[i]["CostPrice"].ToString(), Convert.ToDouble(dtSource.Rows[i]["CostPrice"]));
                    dtSource.Rows[i]["price"] = strs[2];
                    dtSource.Rows[i]["special_price"] = strs[0];
                }
            }
        }

        private void ComboBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var pt = (PriceTemplateEntity)((ComboBox)sender).SelectedItem;
            if (pt == null) return;
            var ptc = new PriceTemplateCore();

            for (int i = 0; i < dtSource.Rows.Count; i++)
            {
                if (Convert.ToString(dtSource.Rows[i]["Pjijiamuban"]) == pt.Jname)
                {
                    var strs = ptc.CalcProductCost(pt, dtSource.Rows[i]["package_weight"].ToString(), dtSource.Rows[i]["CostPrice"].ToString(), Convert.ToDouble(dtSource.Rows[i]["CostPrice"]));
                    dtSource.Rows[i]["price"] = strs[2];
                    dtSource.Rows[i]["special_price"] = strs[0];
                }
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            ChangeCheckBoxState(true);
        }

        private void ChangeCheckBoxState(bool isChecked)
        {
            if (dtSource != null)
            {
                for (int i = 0; i < dtSource.Rows.Count; i++)
                {
                    dtSource.Rows[i]["IsSelected"] = isChecked;
                }
            }
        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            ChangeCheckBoxState(false);
        }

        private void BtnCalc_Click(object sender, RoutedEventArgs e)
        {
            if (dtSource == null) return;
            var pt = (PriceTemplateEntity)cboPT.SelectedItem;
            if (pt == null) return;
            var ptc = new PriceTemplateCore();
            var strs = ptc.CalcProductCost(pt, numpackage_weight.Value.ToString(), numCostPrice.Value.ToString(), Convert.ToDouble(numCostPrice.Value));
            for (int i = 0; i < dtSource.Rows.Count; i++)
            {
                if (Convert.ToBoolean(dtSource.Rows[i]["IsSelected"]))
                {
                    dtSource.Rows[i]["price"] = strs[2];
                    dtSource.Rows[i]["special_price"] = strs[0];
                    dtSource.Rows[i]["package_weight"] = numpackage_weight.Value;
                    dtSource.Rows[i]["CostPrice"] = numCostPrice.Value;
                    dtSource.Rows[i]["quantity"] = numquantity.Value;
                    dtSource.Rows[i]["Pjijiamuban"] = pt.Jname;
                }
            }
        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            CheckBox check = (CheckBox)sender;
            var tt = e;
            var dt = (DataTable)check.DataContext;
        }

        private void CheckBox_Unchecked_1(object sender, RoutedEventArgs e)
        {

        }
        //反译颜色
        private void button12_Click(object sender, RoutedEventArgs e)
        {
            if (textBox11.Text.Trim() == "")
            {
                CMessageBox.Show("请填写颜色后再进行操作！");
                return;
            }
            textBox11.Text = new ALiCore().ChangeEnToZh(textBox11.Text);

        }
        //匹配颜色尺码
        private void button23_Click(object sender, RoutedEventArgs e)
        {
            if(textBox11.Text.Trim()==""&& textBox12.Text.Trim() == "")
            {
                CMessageBox.Show("请填写尺码或颜色后再生成变体！");
                return;
            }
            var product = (Product)this.DataContext;
            if(product.Lazadacategoryid==null|| product.Lazadacategoryid=="")
            {
                CMessageBox.Show("请先选择类目！");
                return;
            }
            JObject jsondata = new LazadaCore().GetCategoryAttr(product.Lazadacategoryid);
            if (jsondata["data"] == null) return;
            var list = ((JArray)jsondata["data"]).ToList();
            categoryOtherAttrs.Clear();
            categoryAttrs.Clear();
            categoryAttrDic = InitDictionary(product.Lazadaskux, product.Lazadaattributs);
            skulistpanel.Children.Clear();
            list.ForEach(item =>
            {
                var name = item["name"].ToString();
                ///去除系统自带属性
                if (attrlist.Contains(name))
                    return;
                ///是否是销售属性,(用于判断是否是上方的辩题属性)
                bool isSaleProp = Convert.ToBoolean(item["is_sale_prop"]);
                if ((isSaleProp && item["name"].ToString() != "brand") || item["name"].ToString() == "color_hb")//|| item["name"].ToString() == "Type_of_Material")
                {
                    Aattribute aattribute = new Aattribute();
                    aattribute.Aname = item["name"].ToString();
                    if (categoryAttrDic.ContainsKey(aattribute.Aname))
                    {
                        aattribute.Avalue = categoryAttrDic[aattribute.Aname];
                    }
                    categoryAttrs.Add(aattribute);
                    SkuValueSelector skuValueSelector = new SkuValueSelector((JObject)item, item["label"].ToString());
                    product.Pcolors = textBox11.Text;
                    product.Psizes = textBox12.Text;
                    if (aattribute.Aname == "size" && (product.Psizes == null || product.Psizes.Length > 0))
                    {
                        string text2 = product.Psizes == null ? "" : Regex.Replace(product.Psizes, "[^0-9a-zA-Z\\s\\.-:,]", "");
                        if (text2.Length > 0)
                        {
                            aattribute.Avalue = PublicFunctions.upFirstCharWithSpaceWithSplitor(("," + text2).Replace("，", ",").Replace(",3XL", ",Int:3XL").Replace(",XXXL", ",Int:3XL").Replace(",2XS", ",Int:XXS").Replace(",2XL", ",Int:XXL").Replace(",XL", ",Int:XL")
                                .Replace(",S", ",Int:S").Replace(",M", ",Int:M").Replace(",L", ",Int:L").Replace(",32", ",EU:32").Replace(",32.5", ",EU:32.5").Replace(",33", ",EU:33").Replace(",34", ",EU:34").Replace(",33.5", ",EU:33.5").Replace(",34.5", ",EU:34.5")
                                .Replace(",35", ",EU:35").Replace(",35.5", ",EU:35.5").Replace(",36", ",EU:36").Replace(",36.5", ",EU:36.5").Replace(",37", ",EU:37").Replace(",37.5", ",EU:37.5").Replace(",38", ",EU:38").Replace(",38.5", ",EU:38.5").Replace(",39", ",EU:39")
                                .Replace(",39.5", ",EU:39.5").Replace(",40", ",EU:40").Replace(",40.5", ",EU:40.5").Replace(",41", ",EU:41").Replace(",41.5", ",EU:41.5").Replace(",42", ",EU:42").Replace(",42.5", ",EU:42.5").Replace(",43", ",EU:43").Replace(",43.5", ",EU:43.5")
                                .Replace(",44", ",EU:44").Replace(",44.5", ",EU:44.5").Replace(",45", ",EU:45").Replace(",45.5", ",EU:45.5").Replace(",46", ",EU:46").Replace(",47", ",EU:47").Replace(",46.5", ",EU:46.5").Replace(",47.5", ",EU:47.5").Replace(",48", ",EU:48")
                                .Replace(",48.5", ",EU:48.5").Replace(",49", ",EU:49").Replace(",49.5", ",EU:49.5").Replace(",50", ",EU:50").Remove(0, 1), ',', false);
                            skuValueSelector.zhongwencolor = text2;
                        }
                    }
                    else if (aattribute.Aname == "color_family" && (product.Pcolors == null || product.Pcolors.Length > 0))
                    {
                        string text2 = product.Pcolors == null ? "" : Regex.Replace(product.Pcolors, "[^0-9a-zA-Z\\s\\.-:,]", "");
                        if (text2.Length > 0)
                        {
                            aattribute.Avalue = PublicFunctions.upFirstCharWithSpaceWithSplitor(text2.Replace("，", ","), ',');
                            skuValueSelector.zhongwencolor = text2;
                        }
                    }
                    if (item["input_type"].ToString().IndexOf("Input") != -1 || !item["options"].HasValues)
                    {
                        skuValueSelector.CanEdit = true;
                        skuValueSelector.CanCustomEdit = true;
                    }
                    if (item["input_type"].ToString() == "numeric")
                    {
                        skuValueSelector.IsNumeric = true;
                    }
                    skuValueSelector.DataContext = aattribute;
                    Binding binding = new Binding("Avalue");
                    binding.Mode = BindingMode.TwoWay;
                    binding.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                    skuValueSelector.SetBinding(SkuValueSelector.SelectSkuValueProperty, binding);

                    this.skulistpanel.Children.Add(skuValueSelector);
                    skuValueSelector.Margin = new Thickness(0.0, 3.0, 0.0, 5.0);
                }
            });
        }
        //翻译
        private void button11_Click(object sender, RoutedEventArgs e)
        {
            if (textBox11.Text.Trim() == "")
            {
                CMessageBox.Show("请填写颜色后再进行操作！");
                return;
            }
            textBox11.Text = PublicFunctions.upFirstCharWithSpaceWithSplitor(new ALiCore().ChangeZhToEn(textBox11.Text).Replace("，", ","), ',');
        }
    }

    public class OptionItem
    {
        public string EnName { get; set; }
        public string ChName { get; set; }

    }

    public class FyLabel
    {
        public string FYstr { get; set; }

        public Label FYlb { get; set; }

        public JObject FYary { get; set; }

        public FrameworkElement FYcbx { get; set; }

        public FyLabel(string _str, Label _label, FrameworkElement _cbxy, JObject _ary)
        {
            FYstr = _str;
            FYlb = _label;
            FYcbx = _cbxy;
            FYary = _ary;
        }
    }

    public class Aattribute : INotifyPropertyChanged
    {
        //1、该接口就只有一个事件PropertyChanged定义
        public event PropertyChangedEventHandler PropertyChanged;
        //4、Notify方法
        protected void Notify(string propName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));


        }
        private string _name;
        private string _value;
        private string _label;
        private bool isSku;


        public string Alabel
        {
            get { return _label; }
            set
            {
                if (_label == value) return;
                _label = value;
                // Notify("Aname");
            }
        }

        public string Aname
        {
            get
            {

                return _name;

            }
            set
            {
                if (_name == value) return;
                _name = value;
                // Notify("Aname");
            }
        }

        public string Avalue
        {
            get { return _value; }
            set
            {
                if (_value == value) return;
                _value = value;
                Notify("Avalue");
            }
        }

        public bool IsSku { get => isSku; set => isSku = value; }

        public Aattribute(string _an, string _av)
        {
            Aname = _an;
            Avalue = _av;
            Alabel = "";
        }

        public Aattribute(string _an, string _av, string _al)
        {
            Aname = _an;
            Avalue = _av;
            Alabel = _al;
        }

        public Aattribute()
        {

            Aname = "";
            Avalue = "";
            Alabel = "";

        }


    }
}
