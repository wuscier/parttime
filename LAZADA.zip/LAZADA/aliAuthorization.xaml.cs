﻿using LAZADA.HaiWang;
using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using PublicFunction;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// aliAuthorization.xaml 的交互逻辑
    /// </summary>
    public partial class aliAuthorization : UserControl
    {
        public aliAuthorization()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if (checkBox.IsChecked == false || checkBox_Copy.IsChecked == false)
            {
                MessageBox.Show("请详细阅读以下协议！", "提示", MessageBoxButton.OK);
                return;
            }
            Task.Run(() =>
            {
                List<Store> lStore = new SqlAuthorization().GetStoreList(" and IsDefault=1 and account<>'' and user='" + GlobalUserClass.uname + "' and region=" + GlobalUserClass.SiteId);
                foreach (var item in lStore)
                {
                    new HaiWangRequestClient().Authmachine(item.account);
                    Thread.Sleep(100);
                }
            });

            new SqlAuthorization().Edit("UPDATE SystemConfiguration SET VALUE='0' where Name='AliAuthorization" + GlobalUserClass.GetHaiWangModel().UserID + "'");
            this.Dispatcher.BeginInvoke(new Action(() =>
            {
                string url = GlobalUserClass.GetHaiWangModel().CreateURL(Constants.HAIWANG_FUN_AUTHORIZED_URL);
                WinMyWebBrowser win = new WinMyWebBrowser("阿里翻译授权", url);
                button.Visibility = Visibility.Collapsed;
                btnGetAuthorize.Visibility = Visibility.Visible;
                win.ShowDialog();
            }));
        }

        private void textBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://terms.alicdn.com/legal-agreement/terms/suit_bu1_b2b/suit_bu1_b2b201908281743_89754.html");

            }
            catch
            {

            }
        }

        private void textBlock1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://terms.alicdn.com/legal-agreement/terms/suit_bu1_b2b/suit_bu1_b2b201908281742_93135.html");

            }
            catch
            {

            }
        }

        private void textBlock2_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://terms.alicdn.com/legal-agreement/terms/suit_bu1_b2b/suit_bu1_b2b201908282211_89314.html");

            }
            catch
            {

            }
        }

        private void BtnGetAuthorize_Click(object sender, RoutedEventArgs e)
        {
            new HaiWangCore().GetUserAuthorized();
            if (new SystemConfigCore().SetAliAuthorization() == 0 && GlobalUserClass.GetHaiWangModel().IsAuthorized)
            {
                CMessageBox.Show("授权成功");
                Window window = Window.GetWindow(this);
                window.Close();
            }
            else
            {
                CMessageBox.Show("授权失败,请联系客服");
            }
        }
    }
}
