﻿using LAZADA.HaiWang;
using LAZADA.TasksBtns;
using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Link;
using Logic.Platform;
using Logic.SystemSole;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.Entity;
using PublicFunction.Entity.BaseEntity;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// Tasks.xaml 的交互逻辑
    /// </summary>
    public partial class Tasks : UserControl
    {
        public PagingViewModel vm = new PagingViewModel();
        private GlobalUserClass global = new GlobalUserClass();
        MainWindow myWin = null;
        public Tasks(MainWindow window)
        {
            SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.ShowSKU);
            myWin = window;
            vm.CurrentPage = 1;
            InitializeComponent();
            SystemSoleEntity.SelectedProductNumberList.Clear();
            Paging pageinfo = new Paging(vm, new Action(() => SystemSoleEntity.LoadProductList(vm)));
            gridpage.Children.Add(pageinfo);

            //SystemSoleEntity.LoadProductList(" and  (pstatetype='0' or pstatetype='10') ");
        }

        //新增任务
        private void NewTasksBtn_Click(object sender, RoutedEventArgs e)
        {
            string token = Constants.Ali1688_ACCESSTOKEN + "";
            if (new SystemConfigCore().SetAliAuthorization() == 1 || !GlobalUserClass.GetHaiWangModel().IsAuthorized)
            {
                WinNoAuthorize win = new WinNoAuthorize();
                win.ShowDialog();
                //return;
            }
            if (token == string.Empty)
            {
                CMessageBox.Show("未进行1688授权,请先在设置中授权后进行操作");
                return;
            }
            if (SystemSoleEntity.GetMainWinModel().IsRunTask)
            {
                CMessageBox.Show("当前在执行任务，请稍后");
                return;
            }
            NewTask task = new NewTask();
            task.ShowDialog();
            //NewTasks newTasks = new NewTasks();
            //newTasks.ShowDialog();
        }
        //产品编辑按钮
        private void ProductEditBtn_Click(object sender, RoutedEventArgs e)
        {
            //SPUEditor sPUEditor = new SPUEditor();
            //this.Content = sPUEditor.Content;


        }

        //重新采集
        private void AgainCollectBtn_MouseDown(object sender, MouseButtonEventArgs e)
        {
            AgainCollect againCollect = new AgainCollect();
            againCollect.ShowDialog();
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            string imgpath = Convert.ToString(((TextBlock)sender).ToolTip);
            if (Directory.Exists(imgpath))
            {
                System.Diagnostics.Process.Start("explorer.exe", imgpath);
            }
            else
            {
                //  MessageBox.Show(((TextBlock)sender).InputBindings).GetType().ToString());  
                // ((TextBlock)sender).Text = "无效路径";
            }
        }

        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            string olink = Convert.ToString(((TextBlock)sender).ToolTip);
            if (olink != "")
            {
                try
                {
                    System.Diagnostics.Process.Start(olink);
                }
                catch
                {

                }
            }
        }

        private void TextBlock_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void LvData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void MnuPitchon_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MunUncheck_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ChkAllCheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void ChkAllCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {

        }
        //上传图片
        private void UploadImgBtn_Click(object sender, RoutedEventArgs e)
        {
            global.GETLAZADATOKEN(GlobalUserClass.SiteId);
            new LogOutput.LogTo().WriteLine(Constants.LAZADA_ACCESSTOKEN);
            var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            if (Constants.LAZADA_ACCESSTOKEN == string.Empty)
            {
                CMessageBox.Show("未进行LAZADA授权,请在设置中授权后进行操作。");
                return;
            }
            if (list.Count == 0)
            {
                CMessageBox.Show("没有选中,请勾选左侧勾选框");
                return;
            }
            if (SystemSoleEntity.GetMainWinModel().IsRunTask)
            {
                CMessageBox.Show("当前在执行任务，请稍后");
                return;
            }
            SystemSoleEntity.GetMainWinModel().InitModel("上传图片", list.Count);
            Task.Run(() =>
            {
                foreach (var product in list)
                {
                    try
                    {
                        if (product.Pnewimgsurl != null && product.Pnewimgsurl != string.Empty)
                            new UpLoadImageCore().UpLoadImagesNew(product);
                    }
                    catch
                    {
                        SystemSoleEntity.GetMainWinModel().IbulkErrowCount++;
                    }
                    SystemSoleEntity.GetMainWinModel().TaskRunCount++;
                    SystemSoleEntity.GetMainWinModel().Ipbvalue += SystemSoleEntity.GetMainWinModel().TaskAdd;
                }
            });
        }

        /// <summary>
        /// 重新采集
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CollectBtn_Click(object sender, RoutedEventArgs e)
        {
            var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            if (list.Count == 0)
            {
                CMessageBox.Show("没有选中,请勾选左侧勾选框");
                //CMessageBox.Show("没有选中,请勾选左侧勾选框");
                return;
            }
            if (SystemSoleEntity.GetMainWinModel().IsRunTask)
            {
                CMessageBox.Show("当前在执行任务，请稍后");
                return;
            }
            if (CMessageBoxResult.OK == CMessageBox.Show($"确定要重新采集{SystemSoleEntity.SelectedProductNumberList.Count}行数据吗", CMessageBoxButton.OKCancel))
            {
                SystemSoleEntity.GetMainWinModel().InitModel("重新采集", list.Count);
                GlobalUserClass globalUser = new GlobalUserClass();
                globalUser.RefreshAli1688Token();
                Task.Run(() =>
                {
                    Parallel.ForEach(list, new Action<Product>((product) => {
                        try
                        {
                            new GetLinkCore().DownProductInfo(product, true);
                        }
                        catch (Exception ex)
                        {
                            SystemSoleEntity.GetMainWinModel().IbulkErrowCount++;
                            product.Pstate = "采集失败";
                            new LogOutput.LogTo().WriteErrorLine("采集出错：" + product.Porigimgsurl + "///" + ex.Message);
                        }
                        SystemSoleEntity.GetMainWinModel().Ipbvalue += SystemSoleEntity.GetMainWinModel().TaskAdd;
                        SystemSoleEntity.GetMainWinModel().TaskRunCount++;
                    }));
                    //foreach (var product in list)
                    //{
                        
                    //}
                });
            }
        }

        private void DeleteTasksBtn_Click(object sender, RoutedEventArgs e)
        {
            var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            if (list.Count == 0)
            {
                CMessageBox.Show("没有可以删除的任务.需要删除请勾选左边勾选框");
                return;
            }
            if (CMessageBoxResult.OK == CMessageBox.Show($"确定要删除{SystemSoleEntity.SelectedProductNumberList.Count}行数据吗", CMessageBoxButton.OKCancel))
            {
                foreach (var item in list)
                {
                    new ProductCore().DeleteProduct(item);
                    //SystemSoleEntity.GetProductList().Remove(item);
                }
                Search();
            }
        }

        internal void Search()
        {
            var text = ((ComboBoxItem)comboBox1.SelectedItem).Content;
            switch (text)
            {
                case "待编辑的":
                    SystemSoleEntity.queryWhere = " and  (pstatetype='0' or pstatetype='10') ";
                    SystemSoleEntity.LoadProductList(vm);
                    break;
                case "发布成功":
                    SystemSoleEntity.queryWhere = " and  pstatetype='1' ";
                    SystemSoleEntity.LoadProductList(vm);
                    break;
                case "发布失败":
                    SystemSoleEntity.queryWhere = " and  pstatetype='2' ";
                    SystemSoleEntity.LoadProductList(vm);
                    break;
                case "已删除":
                    SystemSoleEntity.queryWhere = " and  pstatetype='-3' ";
                    SystemSoleEntity.LoadProductList(vm);
                    break;
                case "所有的":
                    SystemSoleEntity.queryWhere = "";
                    SystemSoleEntity.LoadProductList(vm);
                    break;
                default: break;
            }
            if (lvShowProduct != null)
            {
                AllCheckBox.IsChecked = false;
                //lvShowProduct.ItemsSource = SystemSoleEntity.GetProductList();
                var list = SystemSoleEntity.GetProductList();
                //vm.CurrentPage = 1;
                //vm.CountNumber = SystemSoleEntity.GetProductList().Count();
                //var showList = list.Skip((vm.PageSize * (vm.CurrentPage - 1))).Take(vm.PageSize).ToList();
                //lvShowProduct.ItemsSource = showList;
            }

        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            this.lvShowProduct.ItemsSource = SystemSoleEntity.GetProductList();
        }

        private void TextBlockMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuItem menuItem = (MenuItem)sender;
            if (menuItem.Tag == null) return;
            if (menuItem.Tag.ToString().Trim() == "") return;
            Clipboard.SetDataObject(menuItem.Tag.ToString().Trim()); //到剪贴板
        }

        private void TextBlock_DataContextChanged_1(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void LvShowProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Product product = ((ListView)sender).SelectedItem as Product;
            if (product != null)
                SystemSoleEntity.SetCurrentProduct(product.SiteID, product.Number);

        }

        private void CheckAndPush(Product product)
        {
            //if (product.Pstatetype == "1")
            //{
            //    product.Pcancsv = "已经发布";
            //    return;
            //}
            if ((product.SPUEditError != null && product.SPUEditError != string.Empty) ||
            (product.DetailsEditError != null && product.DetailsEditError != string.Empty) ||
            (product.UploadImgError != null && product.UploadImgError != string.Empty))
            {
                product.Pcancsv = "存在异常";
                return;
            }
            if (Convert.ToDateTime(product.Lazadapromstart) <= DateTime.Now)
            {
                product.Pcancsv = "促销开始时间错误";
                return;
            }
            if (Convert.ToDateTime(product.Lazadapromend) <= Convert.ToDateTime(product.Lazadapromstart))
            {
                product.Pcancsv = "促销结束时间错误";
                return;
            }
            var imgs = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var img in imgs)
            {
                if (!img.StartsWith("http"))
                {
                    product.Pcancsv = "有描述图片没上传";
                    return;
                }
            }
            if (product.SKUDetail == string.Empty || product.SKUDetail == null)
            {
                product.Pcancsv = "SKU属性缺失,请去SPU界面重新保存";
                return;
            }
            product.Pcancsv = "准备发布...";
            new LazadaCore().PushProduct(product);
        }

        /// <summary>
        /// 发布
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReleaseProductBtn_Click(object sender, RoutedEventArgs e)
        {
            global.GETLAZADATOKEN(GlobalUserClass.SiteId);
            //CMessageBox.Show(Constants.LAZADA_ACCESSTOKEN);
            if (Constants.LAZADA_ACCESSTOKEN == string.Empty)
            {
                CMessageBox.Show("未进行LAZADA授权,请在设置中授权后进行操作。");
                return;
            }
            if (SystemSoleEntity.SelectedProductNumberList.Count == 0)
            {
                CMessageBox.Show("没有选中,请勾选左侧勾选框");
                return;
            }
            if (SystemSoleEntity.GetMainWinModel().IsRunTask)
            {
                CMessageBox.Show("当前在执行任务，请稍后");
                return;
            }
            var json = new HummingbirdCore().GetPoints();
            if (json == null)
            {
                CMessageBox.Show("服务器链接失败，请稍后重试");
                return;
            }
            if (!Convert.ToBoolean(json["success"]))
            {
                CMessageBox.Show("账号异常，请联系客服");
                return;
            }
            var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            if (Convert.ToInt32(json["result"]) < list.Count)
            {
                CMessageBox.Show("发布积分不足，请联系客服");
                return;
            }

            Constants.ReleaseStore = null;
            if (Constants.iChooseStore == 1)
            {
                ChooseStore set = new ChooseStore();
                BaseWindow baseWindow = new BaseWindow();
                baseWindow.Show(myWin, 425, 312, set, "选择发布店铺");
            }
            else
            {
                List<Store> lStore = new SqlAuthorization().GetStoreList(" and IsDefault=1 and account<>'' and user='" + GlobalUserClass.uname + "' and expirationTime>'" + GlobalUserClass.GetTime(GlobalUserClass.Access_Token).Replace("\"", "").Replace("T", " ") + "' and region=" + GlobalUserClass.SiteId);
                foreach (var item in lStore)
                {
                    Constants.ReleaseStore.Add(item.Name == "" ? item.account : item.Name, item.id.ToString() + "," + item.accessToken);
                }
            }
            if(Constants.ReleaseStore.Count==0)
            {
                MessageBox.Show("未选择发布店铺，取消发布！", "提示", MessageBoxButton.OK);
                return;
            }
            //List<Product> doList = new List<Product>();
            //foreach (var item in SystemSoleEntity.SelectedProductNumberList)
            //{
            //    var product = SystemSoleEntity.GetProductList().Where(p => p.Number == item).First();
            //    doList.Add()

            //    ///发布成功的不能再重新采集了
            //    
            //}
            //var list = SystemSoleEntity.GetProductList().Where(p => p.IsChecked).ToList();
            SystemSoleEntity.GetMainWinModel().InitModel("发布产品", list.Count);
            if (GlobalUserClass.SiteId == 9)
            {


                CrbPublishProWin crbPublish = new CrbPublishProWin();
                crbPublish.ShowDialog();
                //BaseWindow baseWindow = new BaseWindow();
                //baseWindow.Show(myWin, 400, 475, crbPublish, "六合一发布站点选择");
            }
            else
            {

                Task.Run(() =>
                {
                    foreach (var product in list)
                    {
                        try
                        {
                            product.Pcancsv = "开始检查数据...";
                            Thread.Sleep(100);
                            CheckAndPush(product);
                        }
                        catch (Exception ex)
                        {
                            SystemSoleEntity.GetMainWinModel().IbulkErrowCount++;
                            new LogOutput.LogTo().WriteErrorLine("发布产品出错：" + product.Porigimgsurl + "///" + ex.Message);
                        }
                        SystemSoleEntity.GetMainWinModel().Ipbvalue += SystemSoleEntity.GetMainWinModel().TaskAdd;
                        SystemSoleEntity.GetMainWinModel().TaskRunCount++;
                    }
                });
            }

        }

        /// <summary>
        /// 将选中项加入到列表里
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            CheckBox chk = (CheckBox)sender;
            Product product = (Product)chk.DataContext;
            if (!SystemSoleEntity.SelectedProductNumberList.Contains(product.Number))
                SystemSoleEntity.SelectedProductNumberList.Add(product.Number);
        }

        /// <summary>
        /// 将选中项从列表里减掉
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckBox_Unchecked_1(object sender, RoutedEventArgs e)
        {
            CheckBox chk = (CheckBox)sender;
            Product product = (Product)chk.DataContext;
            if (SystemSoleEntity.SelectedProductNumberList.Contains(product.Number))
                SystemSoleEntity.SelectedProductNumberList.Remove(product.Number);
        }

        private void comboBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Search();
        }

        /// <summary>
        /// 选择类目
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ChoiceCategoryBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SystemSoleEntity.SelectedProductNumberList.Count == 0)
            {
                CMessageBox.Show("没有选中,请勾选左侧勾选框");
                return;
            }
            ChoiceCategory choiceCategory = new ChoiceCategory();
            choiceCategory.ShowDialog();
        }

        /// <summary>
        /// 批量编辑
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BatchEditBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SystemSoleEntity.SelectedProductNumberList.Count == 0)
            {
                CMessageBox.Show("没有选中,请勾选左侧勾选框");
                return;
            }
            if (SystemSoleEntity.GetMainWinModel().IsRunTask)
            {
                CMessageBox.Show("当前在执行任务，请稍后");
                return;
            }
            //BatchWindow batchEdit = new BatchWindow();
            //batchEdit.ShowDialog();
            BatchEditNew batchEdit = new BatchEditNew();
            //BaicWindow baic = new BaicWindow(950, 500, batchEdit, "批量编辑");
            ////batchEdit.parent = baic;
            //baic.ShowDialog();
            BaseWindow baseWindow = new BaseWindow();
            batchEdit.parent = baseWindow;
            baseWindow.Show(myWin, 950, 500, batchEdit, "批量编辑");
        }

        /// <summary>
        /// 计价模板
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ValuationTemplateBtn_Click(object sender, RoutedEventArgs e)
        {
            //ValuationTemplate valuationTemplate = new ValuationTemplate();
            //valuationTemplate.ShowDialog();
            NewValuationTemplate valuationTemplate = new NewValuationTemplate();
            //BaicWindow baic = new BaicWindow(927, 474, valuationTemplate, "计价模板");
            //baic.ShowDialog();
            BaseWindow baseWindow = new BaseWindow();
            baseWindow.Show(myWin, 927, 474, valuationTemplate, "计价模板");
        }

        private void CopyRowBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SystemSoleEntity.SelectedProductNumberList.Count == 0)
            {
                CMessageBox.Show("没有选中,请勾选左侧勾选框");
                return;
            }
            if (CMessageBoxResult.OK == CMessageBox.Show($"确定要复制{SystemSoleEntity.SelectedProductNumberList.Count}行数据吗", CMessageBoxButton.OKCancel))
            {
                foreach (var item in SystemSoleEntity.SelectedProductNumberList)
                {
                    var product = SystemSoleEntity.GetProductList().Where(p => p.Number == item).First();
                    Product product_new = new ProductCore().CopyProduct(product);
                    //if (product_new != null)
                    //    SystemSoleEntity.GetProductList().Insert(0, product_new);
                }
                //SystemSoleEntity.LoadProductList();
                Search();
            }
        }

        private void UpdateSKUBtn_Click(object sender, RoutedEventArgs e)
        {
            if (SystemSoleEntity.SelectedProductNumberList.Count == 0)
            {
                CMessageBox.Show("没有选中,请勾选左侧勾选框");
                return;
            }
            UpdateSKU update = new UpdateSKU();
            update.ShowDialog();
        }

        private void CopyOtherSite_Click(object sender, RoutedEventArgs e)
        {
            //DownOtherSite win = new DownOtherSite();
            //win.ShowDialog();
            NewDownOtherSite downOtherSite = new NewDownOtherSite();
            //BaicWindow baic = new BaicWindow(927, 476, downOtherSite, "同步产品");
            //baic.ShowDialog();
            BaseWindow baseWindow = new BaseWindow();
            baseWindow.Show(myWin, 927, 476, downOtherSite, "同步产品");

        }

        private void AllCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            foreach (var item in SystemSoleEntity.GetProductList())
            {
                item.IsChecked = true;
                if (!SystemSoleEntity.SelectedProductNumberList.Contains(item.Number))
                {
                    SystemSoleEntity.SelectedProductNumberList.Add(item.Number);
                }
            }
        }

        private void AllCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (var item in SystemSoleEntity.GetProductList())
            {
                item.IsChecked = false;
                if (SystemSoleEntity.SelectedProductNumberList.Contains(item.Number))
                {
                    SystemSoleEntity.SelectedProductNumberList.Remove(item.Number);
                }
            }
        }

        private void CreateNewBtn_Click(object sender, RoutedEventArgs e)
        {
            //myWin.myContain.Children.Clear();
            //Product product = new Product();
            //var pc = new ProductCore();
            //var po = typeof(Product).GetProperties();
            //foreach (var p in po)
            //{
            //    try
            //    {
            //        var value = p.GetType().IsValueType ? Activator.CreateInstance(p.GetType()) : "";
            //        p.SetValue(product, value);
            //    }
            //    catch { }
            //}
            //product.Pidprefix = pc.GetNewPorductPidprefix();
            //product.Number = pc.GetNextProductNumber();
            //product.SKUNumber = pc.GetNextSKUNumberByIdprefix(product.Pidprefix);
            //product.SiteID = GlobalUserClass.SiteId;
            //product.Pusername = GlobalUserClass.uname;
            //product.Padddate = DateTime.Now.ToString();
            //if (pc.CreateProduct(product))
            //{
            //    SPUEditor spu = new SPUEditor(product, myWin, vm.CurrentPage);
            //    myWin.myContain.Children.Add(spu);
            //}
            //else
            //{
            //    CMessageBox.Show("创建失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
            //    Tasks task = new Tasks(myWin, 1);
            //    myWin.myContain.Children.Add(task);
            //}
            CMessageBox.Show("该功能还未对所有卖家开放,敬请期待...");
        }

        private void Menu_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;

            //MessageBox.Show("");
        }

        private void Mygrid_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void ComboBoxItem_Selected(object sender, RoutedEventArgs e)
        {
        }

        private void Menu_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox combo = (ComboBox)sender;
            if (combo.SelectedIndex == 0) return;
            long number = Convert.ToInt64(combo.Tag);
            Product product = SystemSoleEntity.GetProductList().Where(p => p.Number == number).First();
            switch (combo.SelectedIndex)
            {
                case 1:
                    //myWin.myContain.Children.Clear();
                    //SPUEditor spu = new SPUEditor(product, myWin, vm.CurrentPage);
                    //myWin.myContain.Children.Add(spu);
                    myWin.ChangeChildControl(product, myWin, "SPU");
                    break;
                case 2:
                    //myWin.myContain.Children.Clear();
                    //DetailsEditor editor = new DetailsEditor(product, myWin, vm.CurrentPage);
                    //myWin.myContain.Children.Add(editor);
                    myWin.ChangeChildControl(product, myWin, "Detail");
                    break;
                case 3:
                    //myWin.myContain.Children.Clear();
                    //ChooseImg img = new ChooseImg(product, myWin, vm.CurrentPage);
                    //myWin.myContain.Children.Add(img);
                    myWin.ChangeChildControl(product, myWin, "Img");
                    break;
                case 4:
                    myWin.myContain.Children.Clear();
                    AdditionalSKU add = new AdditionalSKU(product, myWin, vm.CurrentPage);
                    myWin.myContain.Children.Add(add);
                    break;
                case 5:
                    break;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            long number = Convert.ToInt64(btn.Tag);
            Product product = SystemSoleEntity.GetProductList().Where(p => p.Number == number).First();
            //if (product.Pcancsv=="发布OK..."&&product.Pstatetype == "1")
            //{
            //    new ProductCore().UpdatePulishResult(product);
            //}
            //myWin.myContain.Children.Clear();
            //SPUEditor spu = new SPUEditor(product, myWin, vm.CurrentPage);
            //myWin.myContain.Children.Add(spu);
            myWin.ChangeChildControl(product, myWin, "SPU");
        }

        private void Image_MouseEnter(object sender, MouseEventArgs e)
        {
            Image img = (Image)sender;
            if (popShowPic.Tag != null)
                if ((long)popShowPic.Tag == (long)img.Tag)
                    return;
            popShowPic.Tag = img.Tag;
            popShowPic.IsOpen = false;
            popShowPic.PlacementTarget = img;
            popShowPic.IsOpen = true;
            imgBigPic.Source = img.Source;
            // new BitmapImage(new Uri(img.Source, UriKind.Absolute));
        }

        private void Image_MouseLeave(object sender, MouseEventArgs e)
        {
            popShowPic.IsOpen = false;
            popShowPic.Tag = null;
        }

        private void PopShowPic_MouseEnter(object sender, MouseEventArgs e)
        {
            popShowPic.IsOpen = true;
        }

        /// <summary>
        /// 查货源
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnSelectSource_Click(object sender, RoutedEventArgs e)
        {
            var num = (long)popShowPic.Tag;
            var product = SystemSoleEntity.GetProductList().Where(p => p.Number == num).First();
            if (product.Pimgurl.StartsWith("http"))
                Process.Start("http://kj.1688.com/pdt_tongkuan.html?imgUrl=" + product.Pimgurl);
            else
                Process.Start("http://kj.1688.com/pdt_tongkuan.html?productUrl=" + product.Poriglink);
        }
        /// <summary>
        /// 添加来源
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAddUrl_Click(object sender, RoutedEventArgs e)
        {
            long num = (long)popShowPic.Tag;
            AddSourceUrlWin sourceUrl = new AddSourceUrlWin(num);
            sourceUrl.ShowDialog();
            //BaseWindow window = new BaseWindow();
            //window.Show(myWin, 700, 350, sourceUrl, "添加来源URL");
        }

        private void RefershBtn_Click(object sender, RoutedEventArgs e)
        {
            Search();
        }

        private void BtnGoToVedio_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://15592546.s21v.faiusr.com/58/ABUIABA6GAAgt_rx6AUotIarwAM.mp4");
            }
            catch
            {

            }
        }
    }
}
