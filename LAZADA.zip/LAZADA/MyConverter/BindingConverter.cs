﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace LAZADA.MyConverter
{
    public class Boroffset4Converter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return ((double)value) - 4;

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }
    public class Boroffset8Converter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return ((double)value) - 8;

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    public class BoolBlueBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((bool)value)
            {
                return Brushes.Blue;
            }
            else
            {
                return Brushes.Transparent;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    public class BoolRedBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((bool)value)
            {
                return Brushes.Red;
            }
            else
            {
                return Brushes.Transparent;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }


    public class BoolOrangeBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null) return Brushes.LightGray;

            if ((bool)value)
            {
                return Brushes.Orange;
            }
            else
            {
                return Brushes.LightGray;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }


    [ValueConversion(typeof(double), typeof(Thickness))]
    public class PaddingLeftConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            Double width = (Double)value;
            return new Thickness(width, 0, 0, 0);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }



    //有无附加SKU
    public class lazadaskucountConvertor : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            // if (targetType != typeof(Visibility)) { return null; }
            // return ((bool)value ? Visibility.Visible : Visibility.Hidden);
            if (value == null) return Visibility.Hidden;
            try
            {
                int a = 0;
                if (int.TryParse(value.ToString(), out a)) return Visibility.Hidden;
                if (a > 0) return Visibility.Visible;
            }
            catch
            {


            }
            return Visibility.Hidden;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }
    // 是否编辑过 EditedConverter
    public class EditedConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            // if (targetType != typeof(Visibility)) { return null; }
            // return ((bool)value ? Visibility.Visible : Visibility.Hidden);
            if (value == null) return Brushes.Transparent;
            try
            {
                if (((string)value).Trim() == "10" || ((string)value).Trim() == "7" || ((string)value).Trim() == "13")
                    return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ABDAFF"));
            }
            catch
            {


            }
            return Brushes.Transparent;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    //有无PUID
    public class PUIDConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            // if (targetType != typeof(Visibility)) { return null; }
            // return ((bool)value ? Visibility.Visible : Visibility.Hidden);
            if (value == null) return null;
            try
            {
                if (!String.IsNullOrEmpty((string)value))
                    return new SolidColorBrush(System.Windows.Media.Color.FromRgb(142, 212, 147));
            }
            catch
            {


            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    public class ErrorBGConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (((string)value).Replace("\n", "") != string.Empty)
                return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FB5154"));
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }


    public class ExistsBGConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((bool)value)
                return new SolidColorBrush(System.Windows.Media.Color.FromRgb(230, 190, 190));
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }



    public class ExistsMSGConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((bool)value)
                return "重复";
            return "";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    public class GlobalErrorConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (((string)value).Replace("\n", "").Trim() != string.Empty)
                return "不能发布";
            return "";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }


    public class ItemBGConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            var local = (DateTime)values[0];
            var update = (DateTime)values[1];
            if (local != update)
                return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ABDAFF"));
            return Brushes.Transparent;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class DateTimeConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return ((DateTime)value).ToString("yyyy-MM-dd HH:mm:ss");
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    public class IsUpdateConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((bool)value)
                return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#ABDAFF"));
            return Brushes.Transparent;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    //图片上传进度
    public class upImgcontConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            // if (targetType != typeof(Visibility)) { return null; }
            // return ((bool)value ? Visibility.Visible : Visibility.Hidden);
            if (value == null) return 0;
            try
            {
                string[] str1 = ((string)value).Replace("[", "").Replace("]", "").Replace(" ", "").Split('/');
                if (str1[1].Trim() == "0") return 0;

                // return 0.5;
                Double xd = System.Convert.ToDouble(str1[0]) / System.Convert.ToDouble(str1[1]);
                if (xd < 0) xd = 0;
                return xd;
            }
            catch
            {
                return 0;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }


    //图片上传进度文字
    public class TBForegroundConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            // if (targetType != typeof(Visibility)) { return null; }
            // return ((bool)value ? Visibility.Visible : Visibility.Hidden);
            if (value == null)
                return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            try
            {
                string[] str1 = ((string)value).Replace("[", "").Replace("]", "").Replace(" ", "").Split('/');
                if (str1[0].Trim() != str1[1].Trim())
                    return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));

                // return 0.5;
                Double xd = System.Convert.ToDouble(str1[0]) / System.Convert.ToDouble(str1[1]);
                if (xd < 0) xd = 0;
                return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFF"));
            }
            catch
            {
                return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#000000"));
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    //有问题的重量
    public class WeightConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            // if (targetType != typeof(Visibility)) { return null; }
            // return ((bool)value ? Visibility.Visible : Visibility.Hidden);
            if (value == null) return null;
            if (value.ToString().Trim() == "590")
                return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FB5154"));

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    //右下角显示/隐藏 与 绑定源的转换
    public class dispalyConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            if (targetType != typeof(Visibility)) { return null; }
            return ((bool)value ? Visibility.Visible : Visibility.Hidden);

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }

    //数据库连接状态
    public class DBLINKConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            // if (targetType != typeof(Visibility)) { return null; }
            // return ((bool)value ? Visibility.Visible : Visibility.Hidden);
            if ((bool)value)
            {
                System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(33, 180, 44));
                return brsA;
            }
            else
            {

                System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
                return brsA;

            }

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }


    class WidthConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (Double)value - 136;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (Double)value + 136;
        }
    }

    class HeightConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (Double)value - 130;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (Double)value + 130;
        }
    }
}
