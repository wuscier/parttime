﻿using LAZADA.ChangeSite;
using LAZADA.TasksBtns;
using LAZADA.TasksBtns.ChangeSite;
using Logic.SystemSole;
using PublicFunction.ConfigHelp;
using PublicFunction.SiteImgRequestHelp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// UserInforStateClassify.xaml 的交互逻辑
    /// </summary>
    public partial class UserInforStateClassify : UserControl
    {
        MainWindow myMainWin = null;
        public UserInforStateClassify()
        {
            InitializeComponent();

        }

        public UserInforStateClassify(string siteName, MainWindow main)
        {
            InitializeComponent();
            //设置站点名称
            SiteName.Text = siteName;
            myMainWin = main;
        }

        private void State1_MouseEnter(object sender, MouseEventArgs e)
        {
            ((Label)sender).Background = new SolidColorBrush(Colors.Coral);
            ((Label)sender).FontWeight = FontWeights.Bold;
        }

        private void State1_MouseLeave(object sender, MouseEventArgs e)
        {
            ((Label)sender).Background = new SolidColorBrush(Colors.Beige);
            ((Label)sender).FontWeight = FontWeights.Normal;

        }

        private void State1_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void State2_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void State3_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void State4_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void State5_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void StateCBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Exhibit_MouseEnter(object sender, MouseEventArgs e)
        {
            ((Label)sender).Background = new SolidColorBrush(Colors.Brown);
            ((Label)sender).FontWeight = FontWeights.Bold;
        }

        private void Exhibit_MouseLeave(object sender, MouseEventArgs e)
        {
            ((Label)sender).Background = new SolidColorBrush();
            ((Label)sender).FontWeight = FontWeights.Normal;
        }

        private void UserInforICON_MouseDown(object sender, MouseButtonEventArgs e)
        {
            NewChioceSites changeSta = new NewChioceSites();
            BaicWindow chioceSites = new BaicWindow(710, 260, changeSta, "LAZADA站点选择");
            chioceSites.ShowDialog();

            Smith.WPF.HtmlEditor.HtmlEditor.toLanguage = new SiteChangeHelp().GetToLanguage();
            #region 切换站点图片与文字
            SiteName.Text = GlobalUserClass.SiteName;
            switch (GlobalUserClass.SiteName)
            {
                case "马来西亚":
                    SiteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.MYImg);
                    break;
                case "越南":
                    SiteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.VNImg);
                    break;
                case "新加坡":
                    SiteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.SgImg);
                    break;
                case "印度尼西亚":
                    SiteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.IDImg);
                    break;
                case "泰国":
                    SiteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.THImg);
                    break;
                case "菲律宾":
                    SiteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.PHImg);
                    break;
                case "六合一":
                    SiteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.CrbImg);
                    break;
                default:
                    SiteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.DefaultImg);
                    break;
            }
            ChangeSiteInit();

            #endregion

        }

        /// <summary>
        /// 切换站点以后需要重置的数据
        /// </summary>
        private void ChangeSiteInit()
        {
            myMainWin.ReadSystemBasic();
        }


        private void Setlb_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SetWindow set = new SetWindow();
            set.ShowDialog();
        }
    }
}
