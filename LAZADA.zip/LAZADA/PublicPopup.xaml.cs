﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// PublicPopup.xaml 的交互逻辑
    /// </summary>
    public partial class PublicPopup : UserControl
    {
        private PublicPopup()
        {
            InitializeComponent();
        }
        public PublicPopup(int Width,int Height)
        {
            InitializeComponent();
            this.Width = Width;
            this.Height = Height;
            this.top.Width = Width - 2;

        }

        private void CloseWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            
        }
    }
}
