using LAZADA.ChangeSite;
using Logic.Author;
using Logic.BasicInfo;
using Logic.Login;
using LogOutput;
using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.Author;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.RequestModel;
using PublicFunction.Entity.ResponseModel;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using static LAZADA.GlobalUserClass;

namespace LAZADA
{
    /// <summary>
    /// UserLogin.xaml 的交互逻辑
    /// </summary>
    public partial class UserLogin : UserControl
    {
        System.Windows.Forms.Timer myLoginTimer = null;//登录计时
        ObservableCollection<UserInfo> listUserInfo;
        private My1688Collect My1688Author = new My1688Collect();
        private GlobalUserClass GlobalUser = new GlobalUserClass();
        int tryloginTimes = 0;//尝试登录次数
        int loginErrowTimes = 0;//登录错误次数
        public UserLogin()
        {
            InitializeComponent();
            //lbl_version.Content = Constants.VERSIONNUMBER;
            #region 初始化账号密码
            //初始化账号密码
            //try
            //{
            //    Constants.HARD_DISKID = PublicFunctions.GetHardDiskID();
            //    if (Constants.HARD_DISKID.Length > 200) Constants.HARD_DISKID = Constants.HARD_DISKID.Substring(0, 160);
            //    if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "\\userinfo.act"))
            //    {
            //        FileStream opfile = new FileStream(AppDomain.CurrentDomain.BaseDirectory + "\\userinfo.act", FileMode.Open);
            //        StreamReader reader = new StreamReader(opfile, System.Text.Encoding.Default);
            //        string logindata = reader.ReadToEnd().Trim();
            //        reader.Close();
            //        opfile.Close();

            //        string loginresult = EncryptionWay.Decrypt(logindata, Constants.GETLINK_LOGIN_ENCRYPT);
            //        JObject jb = (JObject)JsonConvert.DeserializeObject(loginresult);

            //        txtLoginName.Text = jb["uname"].ToString();
            //        usepwdtb.Password = jb["uepwd"].ToString();
            //        //usepwdtb.Password = "123456abcdef";
            //        usepwdtb.Tag = jb["uepwd"].ToString();
            //    }
            //}
            //catch (Exception ex)
            //{

            //    new LogOutput.LogTo().WriteLine(ex.Message);
            //}
            #endregion
            try
            {
                listUserInfo = new LoginInfoXmlHelper().GetLoginInfo();
                this.DataContext = listUserInfo;
                usepwdtb.Password = listUserInfo.FirstOrDefault().UserPwd;
            }
            catch (Exception ex)
            {

                new LogOutput.LogTo().WriteLine(ex.Message);
            }
        }

        #region 按钮
        //密码改变
        private void usepwdtb_PasswordChanged(object sender, RoutedEventArgs e)
        {

        }
        #endregion
        //登录
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            Login();
        }
        //阅读服务条款
        private void lblServiceAgreement_MouseDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            try
            {
                System.Diagnostics.Process.Start(Constants.SERVERTERMS_URL + "contract.aspx");
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.InnerException.Message);
            }
        }
        #region//退出
        private void txtExit_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Environment.Exit(0);
        }
        #endregion


        #region //登录
        private void Login()
        {
            //if (chbAgreed.IsChecked != true)
            //{
            //    return;
            //}
            //if (myLoginTimer != null)
            //{
            //    return;
            //}

            myLoginWay();


        }

        public void myLoginWay()
        {
            if (String.IsNullOrEmpty(GlobalUserClass.LoginName))
            {
                startLogin();
            }
            else
            {
                tryloginTimes++;
                if (tryloginTimes > 10)
                {
                    txtUserTag.Text = "网络错误，请手动登陆";

                }
            }

        }
        private void startLogin()
        {

            #region 非空验证
            if (txtLoginName.Text.Trim() == "" || usepwdtb.Password.Trim() == "")
            {
                bool ischeck = new UserLoginCore().CheckTextBox(txtLoginName, usepwdtb);
                if (ischeck)
                {
                    txtUserTag.Text = "账号或密码不能为空，请重新输入.....";
                    return;
                }
            }
            #endregion
            #region 长度验证
            if ((txtLoginName.Text.Length < 4 || txtLoginName.Text.Length > 20) || usepwdtb.Password.Trim().Length < 6 || usepwdtb.Password.Trim().Length > 20)
            {
                bool txblength = new UserLoginCore().CheckTextBoxLength(txtLoginName, 4, 20);
                bool pwdlength = new UserLoginCore().CheckPasswordLength(usepwdtb, 6, 20);
                if (txblength || pwdlength)
                {
                    txtUserTag.Text = "账号或密码无效，请重新输入.....";
                    return;
                }
            }
            #endregion

            #region 登录
            //获取登录accesstoken
            string r = new UserLoginCore().Token_Req(txtLoginName.Text, usepwdtb.Password).ToString();
            Constants.LoginAccount = txtLoginName.Text;
            Constants.LoginPwd = usepwdtb.Password;
            new LogOutput.LogTo().WriteLine(r);
            if (r == "网络异常，请检查网络")
            {
                txtUserTag.Text = "网络异常，请检查网络";
            }
            else
            {

                try
                {
                    JObject loginresult = new JObject();
                    loginresult = (JObject)JsonConvert.DeserializeObject(r);
                    listUserInfo = new ObservableCollection<UserInfo>();
                    //if (GlobalUserClass.Error_Description != null)
                    //{
                    txtUserTag.Text = GlobalUserClass.Error_Description;
                    listUserInfo = new LoginInfoXmlHelper().GetLoginInfo();
                    foreach (var item in listUserInfo)
                    {
                        if (txtLoginName.Text == item.UserName)
                        {
                            loginErrowTimes = item.LoginCount;
                            break;
                        }
                        else
                        {
                            loginErrowTimes = 0;
                        }
                    }
                    loginErrowTimes++;
                    if (txtUserTag.Text.ToString() == "账号或密码错误")
                    {
                        txtUserTag.Text = "已输错账号或密码" + loginErrowTimes.ToString() + "次，您还能输入" + (11 - loginErrowTimes).ToString() + "次";
                        if (loginErrowTimes < 11)
                        {
                            var user = new UserInfo
                            {
                                UserName = txtLoginName.Text,
                                UserPwd = usepwdtb.Password,
                                LoginCount = loginErrowTimes
                            };
                            //listUserInfo.Remove(listUserInfo.FirstOrDefault(u => u.UserName == user.UserName));

                            listUserInfo.Insert(0, user);
                            new LoginInfoXmlHelper().CreateXml(listUserInfo.ToList());
                            usepwdtb.Password = "";
                            return;
                        }
                    }
                    if (txtUserTag.Text.ToString() == "账号已被锁定，请稍后再试")
                    {
                        txtUserTag.Text = "账号已被锁定，请10分钟后再试";
                        return;
                    }
                    //}
                    //else
                    //{
                    GlobalUserClass.Access_Token = Convert.ToString(loginresult["access_token"]);
                    GlobalUserClass.GetHaiWangModel().Token = new UserLoginCore().Token_HW(txtLoginName.Text, usepwdtb.Password).ToString();
                    //通过Access_Token获取个人信息
                    string msg = new UserLoginCore().GetProfile(Access_Token);
                    GlobalUserClass.Msg = msg;
                    //获取登录请求结果
                    JObject result = new JObject();
                    result = (JObject)JsonConvert.DeserializeObject(GlobalUserClass.Msg);
                    bool success = Convert.ToBoolean(result == null ? "false" : result["success"]);

                    #region 登录成功
                    if (success)
                    {
                        GlobalUserClass.uname = txtLoginName.Text;
                        GlobalUserClass.uepwd = usepwdtb.Password;
                        try
                        {
                            Constants.iChooseStore = new SystemConfigCore().SetOpenChooseStore();
                            //同步登录信息
                            GlobalUser.SetMsg(GlobalUserClass.Msg);
                            Task.Run(() =>
                            {
                                new SystemConfigCore().sqlCheck();
                            });
                            ////同步用户所有授权信息
                            //new Logic.Author.GetUserAuthorMSG();

                            Constants.GETLAZADA_APPSECRET();
                            Constants.GETALIBABA_KEY();
                            Constants.ACCESSKEYID = Constants.GetAppIdOrSecret(Constants.ALIAPPID_BASE64Str);
                            Constants.ACCESSKEYSECRET = Constants.GetAppIdOrSecret(Constants.ALIAPPSECRET_BASE64Str);
                            #region 获取1688accesstoken
                            GlobalUser.RefreshAli1688Token();
                            #endregion

                            txtUserTag.Text = "已登陆";

                            if (chkRemberAccount.IsChecked == true)
                            {
                                //记住账号密码
                                //UserLoginCore.LoginData(txtLoginName.Text, usepwdtb.Password);
                                var users = new UserInfo()
                                {
                                    UserName = uname,
                                    UserPwd = uepwd,
                                    LoginCount = 0
                                };
                                if (listUserInfo != null)
                                {
                                    listUserInfo.Remove(listUserInfo.FirstOrDefault(u => u.UserName == users.UserName));
                                    listUserInfo.Insert(0, users);
                                    new LoginInfoXmlHelper().CreateXml(listUserInfo.ToList());
                                }
                                else
                                {
                                    listUserInfo = new ObservableCollection<UserInfo>();
                                    listUserInfo.Insert(0, users);
                                    new LoginInfoXmlHelper().CreateXml(listUserInfo.ToList());
                                }
                            }


                            //关闭当前窗体并跳转
                            Window targetWindow = Window.GetWindow(this);
                            targetWindow.DialogResult = true;
                            targetWindow.Close();


                        }
                        catch (Exception ex)
                        {
                            GlobalUserClass.LoginName = "";
                            txtUserTag.Text = ex.Message;//"登录异常，请尝试重新登陆";
                            new LogOutput.LogTo().WriteErrorLine(ex.Message);

                        }
                        loginErrowTimes = 0;
                    }
                    else
                    {
                        //if (txtUserTag.Text.ToString() == "所有站点均已过期，请续费")
                        //{
                        //    txtUserTag.Text = "所有站点均已过期，请续费";
                        //}
                        //else
                        //{

                        txtUserTag.Text = txtUserTag.Text;
                        return;

                        //}
                    }
                    #endregion

                    try
                    {


                        #region 登录token失效
                        DateTime time = DateTime.Now.AddMinutes(-72000);
                        string dt = GlobalUserClass.GetTime(Access_Token);
                        DateTime now = Convert.ToDateTime(dt.Replace("\"", string.Empty));
                        int code = GlobalUserClass.StatusCode;
                        if (code == 401 || now < time)
                        {
                            #region 刷新accesstoken
                            GlobalUserClass.Refresh_token = loginresult["refresh_token"].ToString();
                            string token = new UserLoginCore().Refreshtoken(Refresh_token);
                            GlobalUserClass.Access_Token = token;
                            #endregion
                        }
                        #endregion
                        #region 登录错误
                        if (code == 400)
                        {
                            txtUserTag.Text = Error_Description;
                            #region 所有站点过期
                            if (txtUserTag.Text.ToString() == "所有站点均已过期，请续费")
                            {
                                //跳到续费界面
                                Process.Start("http://91lazada.com/" + "download1");
                            }
                            #endregion
                            #region 新用户试用找客服
                            if (txtUserTag.Text.ToString() == "新注册用户不能登录系统，请联系客服开通试用功能")
                            {
                                //跳到官网联系客服
                                Process.Start("http://91lazada.com/" + "download1");
                            }
                            #endregion
                            loginErrowTimes++;
                            if (loginErrowTimes > 20)
                            {
                                btnLogin.IsEnabled = false;
                                txtUserTag.Text = Error_Description + ",自动退出";

                                Thread.Sleep(2000);
                                Window targetWindow = Window.GetWindow(this);
                                targetWindow.DialogResult = false;
                                targetWindow.Close();
                                Application.Current.Shutdown();
                            }
                            return;
                        }
                        #endregion
                        #region 系统维护
                        if (code == 502 || code == 500)
                        {
                            txtUserTag.Text = "系统正在维护，请稍后再试";
                            Thread.Sleep(2000);
                            Environment.Exit(0);
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {

                        new LogOutput.LogTo().WriteErrorLine(ex.Message);
                    }


                }
                catch (Exception ex)
                {
                    new LogOutput.LogTo().WriteLine(ex.Message);
                    txtUserTag.Text = r;
                }

                //}
            }
            #endregion
        }
        #endregion
        private void timer1_Tick(object sender, EventArgs e)
        {
            //GlobalUser.Ref_Sav_AliToken();
        }
        private void UserControl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                Login();
        }
        /// <summary>
        /// 联系客服
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TxtUserTag_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://91lazada.com/" + "download1");
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.InnerException.Message);
            }
        }

        private void TxtSmall_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Application.Current.Windows[0].WindowState = WindowState.Minimized;
        }

        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnRegistered_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("http://join.fengniaobox.com/#/register"); //Constants.REGISTER_URL + "loginUp.aspx"

            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
            }
        }
        /// <summary>
        /// 登陆
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnLogin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Login();
        }

        private void BdLoginName_MouseDown(object sender, MouseButtonEventArgs e)
        {
            popLoginname.IsOpen = true;
        }
        /// <summary>
        /// 找回密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblFindAccoount_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start("http://join.fengniaobox.com/#/register");
        }

        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.Handled = false;
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            e.Handled = false;
        }
    }
}