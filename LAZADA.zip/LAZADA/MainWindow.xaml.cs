﻿using LAZADA.ChangeSite;
using LAZADA.OnlineProductControls;
using LAZADA.HaiWang;
using LAZADA.TasksBtns;
using LAZADA.TasksBtns.ChangeSite;
using LAZADA.TasksBtns.CustomerControl;
using LAZADA.TasksBtns.SystemConfigControl;
using Logic.BasicInfo;
using Logic.Platform;
using Logic.SystemSole;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.DBEntity;
using PublicFunction.Entity.ViewModel;
using PublicFunction.SiteImgRequestHelp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using static LAZADA.GlobalUserClass;

namespace LAZADA
{
    /// <summary>
    /// 鼠标方向
    /// </summary>
    public enum ResizeDirection
    {
        /// <summary>
        /// 左
        /// </summary>
        Left = 1,
        /// <summary>
        /// 右
        /// </summary>
        Right = 2,
        /// <summary>
        /// 上
        /// </summary>
        Top = 3,
        /// <summary>
        /// 左上
        /// </summary>
        TopLeft = 4,
        /// <summary>
        /// 右上
        /// </summary>
        TopRight = 5,
        /// <summary>
        /// 下
        /// </summary>
        Bottom = 6,
        /// <summary>
        /// 左下
        /// </summary>
        BottomLeft = 7,
        /// <summary>
        /// 右下
        /// </summary>
        BottomRight = 8,
    }

    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        #region 用来调整窗体大小的变量的事件
        private HwndSource _HwndSource;
        private const int WM_SYSCOMMAND = 0x112;
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        private Dictionary<ResizeDirection, Cursor> cursors = new Dictionary<ResizeDirection, Cursor>
        {
            {ResizeDirection.Top, Cursors.SizeNS},
            {ResizeDirection.Bottom, Cursors.SizeNS},
            {ResizeDirection.Left, Cursors.SizeWE},
            {ResizeDirection.Right, Cursors.SizeWE},
            {ResizeDirection.TopLeft, Cursors.SizeNWSE},
            {ResizeDirection.BottomRight, Cursors.SizeNWSE},
            {ResizeDirection.TopRight, Cursors.SizeNESW},
            {ResizeDirection.BottomLeft, Cursors.SizeNESW}
        };

        #endregion


        Rect rcnormal;
        private bool isMax = false;
        public Tasks Tasks = null;
        public ChioceSites chioceSites = null;
        private GlobalUserClass GlobalUser = new GlobalUserClass();
        public LoginWindow login = new LoginWindow();

        /// <summary>
        /// 设置所有的按钮未被选中
        /// </summary>
        private void SetRadioBtnCheckedFalse()
        {
            //rdoTasks.IsChecked = false;
            //rdoSPUEdit.IsChecked = false;
            //rdoDetails.IsChecked = false;
            //rdoChioseImg.IsChecked = false;
            //rdoSku.IsChecked = false;
            //switch (SystemSoleEntity.GetSelectedTab())
            //{
            //    case CurrentSelectedTab.ShowSKU:
            //        rdoTasks.IsChecked = true;
            //        break;
            //    case CurrentSelectedTab.EditSpu:
            //        rdoSPUEdit.IsChecked = true;
            //        break;
            //    case CurrentSelectedTab.EditDetail:
            //        rdoDetails.IsChecked = true;
            //        break;
            //    case CurrentSelectedTab.EditImages:
            //        rdoChioseImg.IsChecked = true;
            //        break;
            //    case CurrentSelectedTab.AttachSKU:
            //        rdoSku.IsChecked = true;
            //        break;
            //}
        }

        void Window_MouseMove(object sender, MouseEventArgs e)
        {
            if (Mouse.LeftButton != MouseButtonState.Pressed)
            {
                FrameworkElement element = e.OriginalSource as FrameworkElement;
                if (element != null && !element.Name.Contains("Resize")) this.Cursor = Cursors.Arrow;
            }
        }

        public MainWindow()
        {
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            InitializeComponent();
            this.txtUserName.Text = uname;
            this.SourceInitialized += delegate (object sender, EventArgs e)
            {
                this._HwndSource = PresentationSource.FromVisual((Visual)sender) as HwndSource;
            };

            this.MouseMove += new MouseEventHandler(Window_MouseMove);

            this.DataContext = SystemSoleEntity.GetMainWinModel();
            Constants.MainWindowIsOpening = true;


            #region 显示选择站点窗体
            NewChioceSites sites = new NewChioceSites();
            BaicWindow chioceSites = new BaicWindow(710, 260, sites, "LAZADA站点选择");
            chioceSites.ShowDialog();
            Smith.WPF.HtmlEditor.HtmlEditor.UserID = GlobalUserClass.GetHaiWangModel().UserID;
            Smith.WPF.HtmlEditor.HtmlEditor.toLanguage = new SiteChangeHelp().GetToLanguage();
            /// 刷新TOKEN
            ///  DispatcherTimer timer = new DispatcherTimer();
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval
            = TimeSpan.FromMilliseconds(36000000);

            timer.Tick += timer1_Tick;

            timer.Start();
            new LogOutput.LogTo().WriteLine(Constants.Ali1688_ACCESSTOKEN);
            //GlobalUser.RefreshAli1688Token();
            GlobalUser.GETLAZADATOKEN(SiteId);

            #endregion
            #region 选择站点
            if (GlobalUserClass.SiteName != null)
            {

                try
                {
                    UserSite site = new UserSite(GlobalUserClass.SiteName, this);
                    userMenu.Content = site;

                    #region 初始站点头像
                    switch (GlobalUserClass.SiteName)
                    {
                        case "马来西亚":
                            site.siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.MYImg);
                            break;
                        case "越南":
                            site.siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.VNImg);
                            break;
                        case "新加坡":
                            site.siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.SgImg);
                            break;
                        case "印度尼西亚":
                            site.siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.IDImg);
                            break;
                        case "泰国":
                            site.siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.THImg);
                            break;
                        case "菲律宾":
                            site.siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.PHImg);
                            break;
                        case "六合一":
                            site.siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.CrbImg);
                            break;
                        default:
                            site.siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.DefaultImg);
                            break;
                    }
                    #endregion

                }
                catch (Exception ex)
                {

                    new LogOutput.LogTo().WriteErrorLine(ex.InnerException.Message);
                }
            }
            else
            {
                Application.Current.Shutdown();
            }
            #endregion
            //任务栏
            if (Tasks == null)
            {
                Tasks = new Tasks(this);
            }
            myContain.Children.Clear();
            myContain.Children.Add(Tasks);
            //Task.Run(() =>
            ReadSystemBasic();
            new HaiWangCore().GetUserAuthorized();
            Task.Run(() => ShowHaiWangInfo());
            //Task.Run(() => ShowVedio());
            //ShowHaiWangActivity();
            //);
        }

        private void ShowVedio()
        {
            if (new SystemConfigCore().IsShowVedio())
            {
                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    WinVedio win = new WinVedio();
                    win.ShowDialog();
                }));
            }
        }

        private void ShowHaiWangInfo()
        {
            Thread.Sleep(1000);
            if ((new SystemConfigCore().SetAliAuthorization() == 1 || !GlobalUserClass.GetHaiWangModel().IsAuthorized) && new SqlAuthorization().GetStoreList(" and account<>'' and user='" + GlobalUserClass.uname + "'").Count > 0)
                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    aliAuthorization set = new aliAuthorization();
                    //BaicWindow baic = new BaicWindow(400, 604, set, "账号授权设置");
                    //baic.ShowDialog();d:DesignWidth="800" Height="568"
                    BaicWindow baseWindow = new BaicWindow(804, 610, set, "账号阿里授权");
                    baseWindow.ShowDialog();
                    //WinInfo win = new WinInfo();
                    //win.ShowDialog();
                }));
        }


        private void ShowHaiWangActivity()
        {
            Task.Run(() =>
            {
                Thread.Sleep(500);
                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    UC_HaiWangActivity uc = new UC_HaiWangActivity();
                    uc.ShowDialog();
                }));
            });
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //GlobalUser.Ref_Sav_AliToken();
        }
        public void ReadSystemBasic()
        {
            ///刷新任务列表
            RdoTasks_Click(null, null);
            ///清空当前已选择产品
            SystemSoleEntity.SetCurrentProduct(-1, -1);
            ///清空复选框里的产品
            SystemSoleEntity.SelectedProductNumberList.Clear();
            Task.Run(() =>
            {
                ///清空类目树，然后重新加载
                SystemSoleEntity.CategoryObject = null;
                new LazadaCore().GetCategoryTree();
            });
            //SystemSoleEntity.LoadProductList(Tasks.vm);
        }

        /// <summary>
        /// SPU编辑
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RdoSPUEdit_Click(object sender, RoutedEventArgs e)
        {
            Product product = SystemSoleEntity.GetCurrentProduct();
            if (product == null)
            {
                CMessageBox.Show("当前没有选中的产品，无法编辑，请鼠标左键单击选择一个产品");
                SetRadioBtnCheckedFalse();
                return;
            }
            if (product.Pimgurl == null || product.Pimgurl == string.Empty)
            {
                CMessageBox.Show("当前产品还未采集，请先采集后再编辑");
                SetRadioBtnCheckedFalse();
                return;
            }
            TaskControlSaveProduct();
            SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.EditSpu);
            SetRadioBtnCheckedFalse();
            //SPUEditor sPUEdits = new SPUEditor(product, this,vm);
            //TasksControl.Children.Clear();
            //TasksControl.Children.Add(sPUEdits);
        }

        /// <summary>
        /// 详情编辑
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        internal void RdoDetails_Click(object sender, RoutedEventArgs e)
        {
            Product product = SystemSoleEntity.GetCurrentProduct();
            if (product == null)
            {
                CMessageBox.Show("当前没有选中的产品，无法编辑，请鼠标左键单击选择一个产品");
                SetRadioBtnCheckedFalse();
                return;
            }
            if (product.Pimgurl == null || product.Pimgurl == string.Empty)
            {
                CMessageBox.Show("当前产品还未采集，请先采集后再编辑");
                SetRadioBtnCheckedFalse();
                return;
            }
            //rdoDetails.IsChecked = true;
            //TaskControlSaveProduct();
            //SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.EditDetail);
            //SetRadioBtnCheckedFalse();
            //DetailsEditor detailsEditor = new DetailsEditor(this)
            //{
            //    DataContext = product
            //};
            //TasksControl.Children.Clear();
            //TasksControl.Children.Add(detailsEditor);
        }

        /// <summary>
        /// 选择图片
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        internal void RdoChioseImg_Click(object sender, RoutedEventArgs e)
        {
            Product product = SystemSoleEntity.GetCurrentProduct();
            if (product == null)
            {
                CMessageBox.Show("当前没有选中的产品，无法编辑，请鼠标左键单击选择一个产品");
                SetRadioBtnCheckedFalse();
                return;
            }
            if (product.Pimgurl == null || product.Pimgurl == string.Empty)
            {
                CMessageBox.Show("当前产品还未采集，请先采集后再编辑");
                SetRadioBtnCheckedFalse();
                return;
            }
            //rdoChioseImg.IsChecked = true;
            //TaskControlSaveProduct();
            //SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.EditImages);
            //SetRadioBtnCheckedFalse();
            //ChooseImg chooseImg = new ChooseImg(product, this);
            //TasksControl.Children.Clear();
            //TasksControl.Children.Add(chooseImg);
        }

        /// <summary>
        /// 附加SKU
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RdoSku_Click(object sender, RoutedEventArgs e)
        {
            Product product = SystemSoleEntity.GetCurrentProduct();
            if (product == null)
            {
                CMessageBox.Show("当前没有选中的产品，无法编辑，请鼠标左键单击选择一个产品");
                SetRadioBtnCheckedFalse();
                return;
            }
            if (product.Pimgurl == null || product.Pimgurl == string.Empty)
            {
                CMessageBox.Show("当前产品还未采集，请先采集后再附加");
                SetRadioBtnCheckedFalse();
                return;
            }
            //rdoSku.IsChecked = true;
            //TaskControlSaveProduct();
            //SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.AttachSKU);
            //SetRadioBtnCheckedFalse();
            //AdditionalSKU additionalSKU = new AdditionalSKU(product);
            //TasksControl.Children.Clear();
            //TasksControl.Children.Add(additionalSKU);
        }

        /// <summary>
        /// 任务列表
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        internal void RdoTasks_Click(object sender, RoutedEventArgs e)
        {
            Product product = SystemSoleEntity.GetCurrentProduct();
            if (product != null)
            {
                TaskControlSaveProduct();
            }
            //TasksControl.Children.Clear();
            //SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.ShowSKU);
            //SetRadioBtnCheckedFalse();
            //TasksControl.Children.Add(new Tasks());
        }

        /// <summary>
        /// 设置当前的UI保存当前SKU
        /// </summary>
        private void TaskControlSaveProduct()
        {
            //switch (SystemSoleEntity.GetSelectedTab())
            //{
            //    case CurrentSelectedTab.EditSpu:
            //        var spu = (SPUEditor)TasksControl.Children[0];
            //        spu.SaveProduct(true);
            //        break;
            //    case CurrentSelectedTab.EditDetail:
            //        var details = (DetailsEditor)TasksControl.Children[0];
            //        details.SaveProduct(true);
            //        break;
            //    case CurrentSelectedTab.EditImages:
            //        var ChooseImg = (ChooseImg)TasksControl.Children[0];
            //        ChooseImg.SaveProduct(true);
            //        break;
            //}
        }

        private void ChioseImglb_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //ChooseImg chooseImg = new ChooseImg();
            //TasksControl.Children.Clear();
            //TasksControl.Children.Add(chooseImg);
        }
        //添加代理
        private void TxtAddproxy_MouseDown(object sender, MouseButtonEventArgs e)
        {
            AddProxy addProxy = new AddProxy
            {
                WindowStartupLocation = WindowStartupLocation.Manual,
                Left = -((TextBlock)sender).PointFromScreen(new Point(0, 0)).X - 20
            };
            addProxy.Top = -((TextBlock)sender).PointFromScreen(new Point(0, 0)).Y - addProxy.Height - 10;
            //addProxy.Owner = Application.Current.MainWindow;
            addProxy.ShowDialog();
        }

        private void PrgbulkprogressBar_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void StkbulkTip_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //if (stkbulkTip.Margin.Left > 0)
            //{
            //    bulkTip.Margin = new Thickness(0, 0, 0, 0);
            //    文字平移，Margin属性是Thickness类型，选择ThicknessAnimation
            //    ThicknessAnimation ta = new ThicknessAnimation();
            //    ta.From = new Thickness(15, 0, 0, 0);             //起始值
            //    ta.To = new Thickness(0, 0, 0, 0);        //结束值
            //    ta.Duration = TimeSpan.FromSeconds(0.6);         //动画持续时间
            //    this.stkbulkTip.BeginAnimation(StackPanel.MarginProperty, ta);//开始动画
            //}
            //else
            //{
            //    文字平移，Margin属性是Thickness类型，选择ThicknessAnimation
            //    ThicknessAnimation ta = new ThicknessAnimation();
            //    ta.From = new Thickness(0, 0, 0, 0);             //起始值
            //    ta.To = new Thickness(stkbulkTip.Width - bulkType.ActualWidth, 0, 0, 0);        //结束值
            //    ta.Duration = TimeSpan.FromSeconds(1.5);         //动画持续时间
            //    this.stkbulkTip.BeginAnimation(StackPanel.MarginProperty, ta);//开始动画

            //}
        }
        //共享组同步
        private void TxttongbuTB_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            SharedGroup sharedGroup = new SharedGroup
            {
                WindowStartupLocation = WindowStartupLocation.Manual,
                Left = -((TextBlock)sender).PointFromScreen(new Point(0, 0)).X - 20
            };
            sharedGroup.Top = -((TextBlock)sender).PointFromScreen(new Point(0, 0)).Y - sharedGroup.Height - 10;
            //sharedGroup.Owner = Application.Current.MainWindow;
            sharedGroup.ShowDialog();
        }

        private void TxtDownCookir_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void TxtDownData_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void TxtOpenUrl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Product product = SystemSoleEntity.GetCurrentProduct();
            if (product == null) return;
            if (product.Poriglink != null && product.Poriglink != string.Empty)
            {
                try
                {
                    System.Diagnostics.Process.Start(product.Poriglink);
                }
                catch
                {

                }
            }
        }

        private void StkbulkTip_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            ThicknessAnimation ta = new ThicknessAnimation();
            ta.From = new Thickness(15, 0, 0, 0);             //起始值
            ta.To = new Thickness(0, 0, 0, 0);        //结束值
            ta.Duration = TimeSpan.FromSeconds(0.6);         //动画持续时间
            //this.stkbulkTip.BeginAnimation(StackPanel.MarginProperty, ta);//开始动画
        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                //新增任务
                if (Keyboard.IsKeyDown(Key.LeftCtrl) && Keyboard.IsKeyDown(Key.N))
                {
                    NewTasks newTasks = new NewTasks();
                    newTasks.ShowDialog();
                }
                //刷新
                if (Keyboard.IsKeyDown(Key.F5))
                {

                }
                //复制行
                if (Keyboard.IsKeyDown(Key.LeftCtrl) && Keyboard.IsKeyDown(Key.C))
                {

                }
                //保存
                if (Keyboard.IsKeyDown(Key.LeftCtrl) && Keyboard.IsKeyDown(Key.S))
                {

                }

            }
            catch (Exception)
            {


            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Grid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (CMessageBoxResult.OK == CMessageBox.Show("确定要关闭系统吗？", CMessageBoxButton.OKCancel))
            {
                System.Diagnostics.Process.GetCurrentProcess().Kill();
                //System.Environment.Exit(0);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (!isMax)
            {
                ResizeTop.MouseDown -= Grid_MouseMove;
                ResizeBottom.MouseDown -= Grid_MouseMove;
                ResizeLeft.MouseDown -= Grid_MouseMove;
                ResizeRight.MouseDown -= Grid_MouseMove;
                ResizeTopLeft.MouseDown -= Grid_MouseMove;
                ResizeTopRight.MouseDown -= Grid_MouseMove;
                ResizeBottomLeft.MouseDown -= Grid_MouseMove;
                ResizeBottomRight.MouseDown -= Grid_MouseMove;

                ResizeTop.MouseMove -= Grid_MouseMove;
                ResizeBottom.MouseMove -= Grid_MouseMove;
                ResizeLeft.MouseMove -= Grid_MouseMove;
                ResizeRight.MouseMove -= Grid_MouseMove;
                ResizeTopLeft.MouseMove -= Grid_MouseMove;
                ResizeTopRight.MouseMove -= Grid_MouseMove;
                ResizeBottomLeft.MouseMove -= Grid_MouseMove;
                ResizeBottomRight.MouseMove -= Grid_MouseMove;

                ResizeTop.Cursor = Cursors.None;
                ResizeBottom.Cursor = Cursors.None;
                ResizeLeft.Cursor = Cursors.None;
                ResizeRight.Cursor = Cursors.None;
                ResizeTopLeft.Cursor = Cursors.None;
                ResizeTopRight.Cursor = Cursors.None;
                ResizeBottomLeft.Cursor = Cursors.None;
                ResizeBottomRight.Cursor = Cursors.None;

                isMax = true;
                rcnormal = new Rect(this.Left, this.Top, this.Width, this.Height);//保存下当前位置与大小
                this.Left = 0;//设置位置
                this.Top = 0;
                Rect rc = SystemParameters.WorkArea;//获取工作区大小
                this.Width = rc.Width;
                this.Height = rc.Height;
                //this.WindowState = WindowState.Maximized;
            }
            else
            {
                ResizeTop.MouseDown += Grid_MouseMove;
                ResizeBottom.MouseDown += Grid_MouseMove;
                ResizeLeft.MouseDown += Grid_MouseMove;
                ResizeRight.MouseDown += Grid_MouseMove;
                ResizeTopLeft.MouseDown += Grid_MouseMove;
                ResizeTopRight.MouseDown += Grid_MouseMove;
                ResizeBottomLeft.MouseDown += Grid_MouseMove;
                ResizeBottomRight.MouseDown += Grid_MouseMove;

                ResizeTop.MouseMove += Grid_MouseMove;
                ResizeBottom.MouseMove += Grid_MouseMove;
                ResizeLeft.MouseMove += Grid_MouseMove;
                ResizeRight.MouseMove += Grid_MouseMove;
                ResizeTopLeft.MouseMove += Grid_MouseMove;
                ResizeTopRight.MouseMove += Grid_MouseMove;
                ResizeBottomLeft.MouseMove += Grid_MouseMove;
                ResizeBottomRight.MouseMove += Grid_MouseMove;

                ResizeTop.Cursor = Cursors.ScrollNS;
                ResizeBottom.Cursor = Cursors.ScrollNS;
                ResizeLeft.Cursor = Cursors.ScrollWE;
                ResizeRight.Cursor = Cursors.ScrollWE;
                ResizeTopLeft.Cursor = Cursors.ScrollNW;
                ResizeTopRight.Cursor = Cursors.ScrollNE;
                ResizeBottomLeft.Cursor = Cursors.ScrollSW;
                ResizeBottomRight.Cursor = Cursors.ScrollSE;

                isMax = false;
                this.Left = rcnormal.Left;
                this.Top = rcnormal.Top;
                this.Width = rcnormal.Width;
                this.Height = rcnormal.Height;
                //this.WindowState = WindowState.Normal;
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            myContain.Children.Clear();
            myContain.Children.Add(new Tasks(this));

            //ChangeChildControl(null, this, "Tasks", 1);
        }

        private void ResizeWindow(ResizeDirection direction)
        {
            SendMessage(_HwndSource.Handle, WM_SYSCOMMAND, (IntPtr)(61440 + direction), IntPtr.Zero);
        }

        private void Grid_MouseMove(object sender, MouseEventArgs e)
        {
            FrameworkElement element = sender as FrameworkElement;
            ResizeDirection direction = (ResizeDirection)Enum.Parse(typeof(ResizeDirection), element.Name.Replace("Resize", ""));

            this.Cursor = cursors[direction];
            if (e.LeftButton == MouseButtonState.Pressed) ResizeWindow(direction);
        }

        private void BtnSet_Click(object sender, RoutedEventArgs e)
        {
            //SetWindow set = new SetWindow();
            //set.ShowDialog();
            NewSetWindow set = new NewSetWindow();
            //BaicWindow baic = new BaicWindow(400, 604, set, "账号授权设置");
            //baic.ShowDialog();d:DesignWidth="800" Height="568"
            BaseWindow baseWindow = new BaseWindow();
            baseWindow.Show(MainWin, 842, 705, set, "账号授权设置");
        }//242.121" Width="611.442  4,38Height="384.27" Width="401.223"Height="658.27" Width="838.832

        private void BtnChangeUser_Click(object sender, RoutedEventArgs e)
        {
            this.user.IsOpen = true;
            //this.Shade.Visibility = Visibility.Visible;

        }
        /// <summary>
        /// 注销登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginOut_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Forms.Application.Restart();
            Application.Current.Shutdown();
        }
        /// <summary>
        /// 联系客服
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LblContact_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start("http://91lazada.com/" + "download1");
        }

        public void ChangeChildControl_OnlineProduct(ShowOnLineProduct product, MainWindow main, string name)
        {
            OnlinePro uc = null;
            if (name == "OnLine")
            {
                foreach (UserControl element in myContain.Children)
                {
                    if (element.Name == name)
                    {
                        element.Visibility = Visibility.Visible;

                        uc = (OnlinePro)element;
                        uc.LoadLocalOnlineProduct();
                    }
                }
                myContain.Children.Clear();
                myContain.Children.Add(uc);
            }
            else
            {
                foreach (UserControl element in myContain.Children)
                {
                    if (element.Name == "OnLine")
                    {
                        element.Visibility = Visibility.Hidden;
                        uc = (OnlinePro)element;
                    }
                }
                OnlineProductDetail detail = new OnlineProductDetail(product, main);
                myContain.Children.Clear();
                myContain.Children.Add(detail);
                myContain.Children.Add(uc);
            }

        }

        public void ChangeChildControl(Product product, MainWindow main, string name)
        {

            bool ishas = false;
            if (name == "MT")///任务列表
            {
                UserControl uc = null;
                foreach (UserControl element in myContain.Children)
                {
                    if (element.Name == name)
                    {
                        element.Visibility = Visibility.Visible;
                        uc = element;
                        ishas = true;
                        break;
                    }
                }
                if (!ishas)
                    uc = new Tasks(main);
                myContain.Children.Clear();
                myContain.Children.Add(uc);

            }
            else///非任务列表
            {
                UserControl task = null;
                UserControl uc = null;
                foreach (UserControl element in myContain.Children)
                {
                    if (element.Name == "MT")
                    {
                        element.Visibility = Visibility.Collapsed;
                        task = element;
                        break;
                    }
                }
                switch (name)
                {
                    case "SPU":
                        uc = new SPUEditor(product, main);
                        break;
                    case "Detail":
                        uc = new DetailsEditor(product, main);
                        break;
                    case "Img":
                        uc = new ChooseImg(product, main);
                        break;
                    default:
                        break;
                }
                myContain.Children.Clear();
                myContain.Children.Add(task);
                myContain.Children.Add(uc);
            }
        }

        /// <summary>
        /// 产品管理
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (GlobalUserClass.SiteId == 9) return;
            if (new SystemConfigCore().SetAliAuthorization() == 1 || !GlobalUserClass.GetHaiWangModel().IsAuthorized)
            {
                WinNoAuthorize win = new WinNoAuthorize();
                win.ShowDialog();
                //return;
            }
            if (new OnlineProductFunctionUpadteCore().CreateTableOnlineProduct())
            {
                myContain.Children.Clear();
                myContain.Children.Add(new OnlinePro(this));
            }
            else
            {
                CMessageBox.Show("新功能存在异常,请联系客服");
            }
        }

        private void MainWin_Loaded(object sender, RoutedEventArgs e)
        {
            if (!new HaiWangUpdateCore().CheckNeedToUpdate())
            {
                CMessageBox.Show("海王更新失败,请联系管理员");
                System.Diagnostics.Process.GetCurrentProcess().Kill();
                return;
            }
            if (new SystemConfigCore().CheckNeedToUpdate())
            {
                FreightUpdate set = new FreightUpdate();
                set.ShowDialog();
            }

        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            var url = GlobalUserClass.GetHaiWangModel().CreateURL(Constants.HAIWANG_DELETEROLE_URL);
            WinMyWebBrowser win = new WinMyWebBrowser("取消授权", url);
            win.ShowDialog();
            new HaiWangCore().GetUserAuthorized();

            Task.Run(() =>
            {
                if (new SystemConfigCore().CheckNeedToUpdate())
                {
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        FreightUpdate set = new FreightUpdate();
                        set.ShowDialog();
                    }));
                }
            });
        }
    }
}
