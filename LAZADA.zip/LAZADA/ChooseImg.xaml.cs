﻿using LAZADA.HaiWang;
using LAZADA.TasksBtns;
using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Link;
using Logic.Platform;
using Logic.SystemSole;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.Entity.DBEntity;
using PublicFunction.WebRequestHelper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LAZADA
{
    /// <summary>
    /// ChooseImg.xaml 的交互逻辑
    /// </summary>
    public partial class ChooseImg : UserControl
    {
        JArray allskuzh = new JArray();
        List<JToken> oldskuimglist;
        MainWindow mainWin = null;
        //DateTime openTime;
        int parentCurrentPage = 1;
        private delegate void UpdataValue(double _str);//定义进度条委托 
        private static DispatcherOperationCallback exitFrameCallback = new DispatcherOperationCallback(ExitFrame);
        public void updataValue(double _str)
        {
            progressBar.Value = _str;

        }

        public ChooseImg(Product product, MainWindow _mainWin)
        {
            SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.EditImages);
            InitializeComponent();
            //openTime = DateTime.Now;
            mainWin = _mainWin;
            this.DataContext = product;
            AddColorText(product);
            AddOrigImg(product, true);
            myImgEditor.EditImgOk += MyImgEditor_EditImgOk;
            //if (GlobalUserClass.SiteId != 1 && GlobalUserClass.SiteId != 2 && GlobalUserClass.SiteId != 3 && GlobalUserClass.SiteId != 5)
            //    btnTransPic.Visibility = Visibility.Collapsed;
        }

        private void MyImgEditor_EditImgOk(object Sender, ImageEditorEx.ImgEditorControl.EditImgOkEventArgs e)
        {

            if (e.MyRenderTargetBitmap == null) return;

            string filePath = e.ImgPath.Trim();

            string newFilePath = filePath;

            PngBitmapEncoder encode = new PngBitmapEncoder();
            encode.Frames.Add(BitmapFrame.Create(e.MyRenderTargetBitmap));
            MemoryStream ms = new MemoryStream();
            encode.Save(ms);

            Bitmap TsaveBmp = new Bitmap(ms);

            ms.Dispose();

            if (TsaveBmp == null) return;

            Bitmap TTsaveBmp = ConvertImage.HeapWhiteBitMap(TsaveBmp);

            TsaveBmp.Dispose();

            //ConsoleManager.Write(string.Format("95  内存中格式转化:原W:{0},原H:{1},输出W:{0},输出H:{1},\n", e.MyRenderTargetBitmap.Width, e.MyRenderTargetBitmap.Height , TTsaveBmp.Width , TTsaveBmp.Height));

            if (System.IO.File.Exists(filePath))
            {
                string path2 = System.IO.Path.GetDirectoryName(filePath);
                //MessageBox.Show(path2);
                if (!System.IO.Directory.Exists(path2 + "\\Trash"))
                {
                    Directory.CreateDirectory(path2 + "\\Trash");
                }
                try
                {
                    File.Delete(path2 + "\\Trash\\" + System.IO.Path.GetFileName(filePath));
                    File.Move(filePath, path2 + "\\Trash\\" + System.IO.Path.GetFileName(filePath));
                }
                catch
                {
                    newFilePath = path2 + "\\" + System.IO.Path.GetFileNameWithoutExtension(filePath) + DateTime.Now.ToString("hhmmss") + ".jpg";
                }

            }
            else
            {

                if (chkMerge.IsChecked == true && spFree.Children.Count > 1)
                {
                    int npb = (int)(nudRow.Value) * (int)(nudColumn.Value);
                    if (npb > spFree.Children.Count) npb = spFree.Children.Count;
                    ArrayList pblist = new ArrayList();
                    for (int i = 0; i < npb; i++)
                    {
                        pblist.Add(spFree.Children[i]);

                    }
                    foreach (BorderImageX itm in pblist)
                    {
                        itm.SourceBitmapImage100 = null;
                        spFree.Children.Remove(itm);
                    }

                    TTsaveBmp.Save(newFilePath, System.Drawing.Imaging.ImageFormat.Jpeg);

                    TTsaveBmp.Dispose();

                    RightAddOne(newFilePath, true, false);

                    if (spFree.Children.Count > 1)
                    {
                        ShowMegeredImg();
                    }
                    return;

                }

            }
            TTsaveBmp.Save(newFilePath, System.Drawing.Imaging.ImageFormat.Jpeg);

            TTsaveBmp.Dispose();


            //记录下左边要更新的图片， 在切换回颜色分组界面时执行更新
            //   if (needFreshSkuImg.ContainsKey(filePath))
            //   {
            //    needFreshSkuImg[filePath] = newFilePath;
            //   }
            //   else
            //    {
            //     needFreshSkuImg.Add(filePath, newFilePath);
            //    }

            //改用分发事件的方式实现

            // onChangSkuimg?.Invoke(filePath, newFilePath);


            if (listUseImg.Items.Count > 0)
            {
                foreach (SkuImgListBox sbx in listUseImg.Items)
                {
                    sbx.changeImg(filePath, filePath);

                }
            }


            //刷新右边
            if (wpLocalImg.Children.Count > 0)
            {
                for (int i = 0; i < wpLocalImg.Children.Count; i++)
                {
                    if (wpLocalImg.Children[i] is BorderImageX)
                    {

                        if (((BorderImageX)(wpLocalImg.Children[i])).SourcePath.Trim() == filePath)
                        {
                            ((BorderImageX)(wpLocalImg.Children[i])).Refresh();

                        }


                    }
                }
            }


            //刷新下边
            if (spFree.Children.Count > 0)
            {
                for (int i = 0; i < spFree.Children.Count; i++)
                {
                    if (spFree.Children[i] is BorderImageX)
                    {

                        if (((BorderImageX)(spFree.Children[i])).SourcePath.Trim() == filePath)
                        {
                            ((BorderImageX)(spFree.Children[i])).Refresh();

                        }


                    }
                }

            }


            //刷新上边要用的图  WrapPanel0是上边   ，WrapPanel3是下右边
            if (wpUseImg.Children.Count > 0)
            {

                for (int i = 0; i < wpUseImg.Children.Count; i++)
                {
                    if (wpUseImg.Children[i] is BorderImageX)
                    {

                        if (((BorderImageX)(wpUseImg.Children[i])).SourcePath.Trim() == filePath)
                        {
                            ((BorderImageX)(wpUseImg.Children[i])).Refresh();

                        }


                    }
                }


            }


        }

        private void AddOrigImg(Product product, bool _isAsyn)
        {
            Task.Run(() =>
            {
                try
                {
                    if (listUseImg.Items.Count == 0)
                    {
                        if (product.Lazadaskux != null && product.Lazadaskux != string.Empty)
                        {
                            if (product.Lazadaskuimages != null && product.Lazadaskuimages != string.Empty)
                            {
                                try
                                {
                                    oldskuimglist = ((JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages)).ToList();
                                }
                                catch { }
                            }
                            var sukzh = (JArray)JsonConvert.DeserializeObject(product.Lazadaskux);
                            if (sukzh.Count > 0)
                            {
                                if (sukzh.Count == 2)
                                {
                                    JToken _J1 = sukzh[0];
                                    JToken _J2 = sukzh[1];

                                    if ((_J1["name"].ToString() == "color_family" && _J2["name"].ToString() == "size") || (_J2["name"].ToString() == "color_family" && _J1["name"].ToString() == "size"))
                                    {
                                        if (_J1["name"].ToString() == "color_family" && _J2["name"].ToString() == "size")
                                        {
                                            DeepOne2(_J1, _J2);
                                        }
                                        else if (_J2["name"].ToString() == "color_family" && _J1["name"].ToString() == "size")
                                        {
                                            DeepOne2(_J2, _J1);
                                        }
                                    }
                                    else
                                    {
                                        JObject AF = new JObject
                                    {
                                        { "sku", new JArray() },

                                        { "leftimages", new JArray() },

                                        { "rightimages", new JArray() }
                                    };

                                        DeepOne(AF, 0, sukzh);
                                    }
                                }
                                else
                                {
                                    JObject AF = new JObject
                                {
                                    { "sku", new JArray() },

                                    { "leftimages", new JArray() },

                                    { "rightimages", new JArray() }
                                };

                                    DeepOne(AF, 0, sukzh);
                                }
                            }
                            if (allskuzh.Count > 0)
                            {
                                Task.Run(() => YsAsynReloadDo(allskuzh));
                            }
                        }
                    }
                    else
                    {
                        Task.Run(() =>
                        {
                            for (int i = 0; i < listUseImg.Items.Count; i++)
                            {
                                this.Dispatcher.BeginInvoke(new Action<int>((b) =>
                                {
                                    if (b < listUseImg.Items.Count)
                                    {
                                        ((SkuImgListBox)listUseImg.Items[b]).refeshLocalImg();
                                    }
                                }), i);

                            }
                        });
                    }
                }
                catch { }
                try
                {
                    if (product.Pnewimgsurl != null && product.Pnewimgsurl.Length > 10)
                    {
                        this.Dispatcher.BeginInvoke(new Action(() =>
                        wpUseImg.Children.Clear()));
                        Task.Run(() =>
                        {
                            Thread.Sleep(400);
                            string[] useimgs = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            Parallel.ForEach(useimgs, new Action<string>((item) =>
                            {
                                this.Dispatcher.BeginInvoke(new Action(() => { TopRightAddOne(item); }));
                            }));

                            //for (int i = 0; i < useimgs.Length; i++)
                            //{
                            //    //  if (!File.Exists(useimgs[i])) continue;
                            //    Thread.Sleep(100);
                            //    this.Dispatcher.BeginInvoke(new Action<string>((b) =>  // b= x
                            //    {//UI线程中做的事

                            //        TopRightAddOne(b);

                            //    }
                            //    ), useimgs[i]); //此处x传给代理处理函数的参数 ， 可以是多个
                            //}
                        });
                    }
                }
                catch { }
                try
                {
                    if (product.Plocalimgpath != null && product.Plocalimgpath != string.Empty)
                    {
                        if (!Directory.Exists(product.Plocalimgpath)) return;
                        this.Dispatcher.BeginInvoke(new Action(() =>
                        wpLocalImg.Children.Clear()));

                        Task.Run(() =>
                                {
                                    string oldimgs = "";
                                    if (product.Pnewimgsurl != null && product.Pnewimgsurl != "")
                                    {
                                        oldimgs = product.Pnewimgsurl;
                                    }
                                    Thread.Sleep(600);
                                    this.Dispatcher.BeginInvoke(new Action(() =>  // b= x
                                    {//UI线程中做的事

                                        BottomRefresh();
                                    }
                                    )); //此处x传给代理处理函数的参数 ， 可以是多个
                                    string[] Imgs = Directory.GetFiles(product.Plocalimgpath, "*.jpg");

                                    Thread.Sleep(200);

                                    Parallel.ForEach(Imgs, new Action<string>((item) =>
                                    {
                                        bool isused = (oldimgs.Length > 10 && oldimgs.IndexOf(item.Trim()) >= 0) ? true : false;
                                        this.Dispatcher.BeginInvoke(new Action(() => { RightAddOne(item.Trim(), false, isused); }));
                                    }));

                                    //foreach (string img in Imgs)
                                    //{
                                    //    Thread.Sleep(100);
                                    //    bool isused = (oldimgs.Length > 10 && oldimgs.IndexOf(img.Trim()) >= 0) ? true : false;
                                    //    this.Dispatcher.BeginInvoke(new Action<bool>((b) =>  // b= x
                                    //    {//UI线程中做的事

                                    //        RightAddOne(img.Trim(), false, b);
                                    //    }
                                    //    ), isused); //此处x传给代理处理函数的参数 ， 可以是多个
                                    //}
                                });
                    }
                }
                catch { }
            });
        }

        //底下刷新
        private void BottomRefresh()
        {
            if (spFree.Children.Count > 0)
            {
                int npb = spFree.Children.Count;

                ArrayList pblist = new ArrayList();
                for (int i = 0; i < npb; i++)
                {
                    if (File.Exists(((BorderImageX)(spFree.Children[i])).SourcePath))
                    {
                        ((BorderImageX)(spFree.Children[i])).Refresh();
                    }
                    else
                    {
                        pblist.Add(spFree.Children[i]);
                    }

                }
                foreach (BorderImageX itm in pblist)
                {
                    itm.SourceBitmapImage100 = null;
                    spFree.Children.Remove(itm);
                }

                if (chkMerge.IsChecked == true && spFree.Children.Count > 1)
                {
                    ShowMegeredImg();
                }

            }
        }

        private void BottomMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            myImgEditor.LoadImage(((BorderImageX)sender).SourcePath);
        }

        private void Bottomimg_MouseDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;

            BorderImageX t = (BorderImageX)sender;

            if (t.IsSelected)
            {
                t.IsSelected = false;
                spFree.Tag = null;
                return;
            }

            if (spFree.Tag != null)
            {
                if (spFree.Tag is BorderImageX t2)
                {
                    t2.IsSelected = false;
                    int idx0 = spFree.Children.IndexOf(t2);
                    spFree.Children.Remove(t2);

                    int idx = spFree.Children.IndexOf(t);


                    spFree.Children.Insert(idx, t2);

                    NewMegeredImg((idx0 < idx) ? idx0 : idx);
                }

                spFree.Tag = null;

            }
            else
            {
                t.IsSelected = true;
                spFree.Tag = t;
            }


        }

        private void ShowMegeredImg()
        {

            if (spFree.Children.Count > 1)
            {
                string filePath = string.Empty;

                int npb = (int)(nudRow.Value) * (int)(nudColumn.Value);
                //System.Drawing.Image[] curzhupb = null;
                ArrayList pblist = new ArrayList();
                //pblist.Clear();
                for (int i = 0; i < spFree.Children.Count; i++)
                {
                    if (i < npb)
                    {
                        ((BorderImageX)(spFree.Children[i])).Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0xee, 0xee, 0xee));

                        string mpath = ((BorderImageX)(spFree.Children[i])).SourcePath;

                        if (System.IO.File.Exists(mpath))
                        {
                            System.Drawing.Image amImg = ConvertImage.loadCloneBitmap(mpath);
                            pblist.Add(amImg);

                            if (string.IsNullOrEmpty(filePath)) filePath = mpath;
                        }
                    }
                    else
                    {
                        ((BorderImageX)(spFree.Children[i])).Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0xd5, 0xff, 0xd5));
                    }

                }

                Bitmap mergeredImg = ConvertImage.AutoMergerImg(800, (int)(nudRow.Value), (int)(nudColumn.Value), pblist);
                if (mergeredImg != null)
                {
                    string path2 = System.IO.Path.GetDirectoryName(filePath);

                    string newImgname = path2 + "\\B" + DateTime.Now.ToString("hhmmss") + ConvertImage.CreateRandomCode() + "hebin.jpg";

                    myImgEditor.LoadMemoryImage(newImgname, mergeredImg);
                }

            }


        }

        private void NewMegeredImg(int idx)
        {
            if (chkMerge.IsChecked != true) return;
            if (spFree.Children.Count < 2) return;

            int npb = (int)(nudRow.Value) * (int)(nudColumn.Value);
            if (idx < npb)
            {
                ShowMegeredImg();
            }

        }

        private void BottomDeleted1(object Sender, RoutedEventArgs e)
        {
            e.Handled = true;

            if (((BorderImageX)Sender).IsSelected) spFree.Tag = null;

            ((BorderImageX)Sender).SourceBitmapImage100 = null;
            int idx = spFree.Children.IndexOf((BorderImageX)Sender);
            spFree.Children.Remove((BorderImageX)Sender);

            NewMegeredImg(idx);


        }

        //下边添加一个要合并的图片
        private void HebinImgAddOne(string _imgpathstr)
        {
            if (!File.Exists(_imgpathstr)) return;

            BorderImageX bdimg = new BorderImageX
            {
                //  bdimg.SetResourceReference(Button.StyleProperty, "BorderImageXstyle96");
                Width = 76,
                Height = 76,

                SourcePath = _imgpathstr,
                ToolTip = null
            };
            spFree.Children.Add(bdimg);
            bdimg.MouseDoubleClick += BottomMouseDoubleClick;
            bdimg.MouseRightButtonDown += BottomMouseDoubleClick;
            bdimg.MouseLeftButtonDown += Bottomimg_MouseDown;
            bdimg.Deleted += BottomDeleted1;


            NewMegeredImg(spFree.Children.Count - 1);

        }

        private void Bdimg_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // if(((BorderImageX)sender).IsSelected == true) return;
            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
            {
                HebinImgAddOne(((BorderImageX)sender).SourcePath);
            }
            else
            {

                myImgEditor.LoadImage(((BorderImageX)sender).SourcePath);
                if (wpLocalImg.Tag != null)
                {
                    if (wpLocalImg.Tag is BorderImageX)
                    {
                        ((BorderImageX)(wpLocalImg.Tag)).IsSelected = false;
                    }
                }
                ((BorderImageX)sender).IsSelected = true;
                wpLocalImg.Tag = sender;

            }
        }

        //右边删一个
        private void DelBt_Click(object sender, RoutedEventArgs e)
        {
            e.Handled = true;
            //Button delBt = (Button)sender;
            BorderImageX tbx = (BorderImageX)sender;
            string filePath = tbx.SourcePath.Trim();

            // ()(((Canvas)(delBt.Parent)).Parent)
            tbx.SourceBitmapImage100 = null;
            wpLocalImg.Children.Remove(tbx);

            if (System.IO.File.Exists(filePath))
            {
                FileInfo fileInfo = new FileInfo(filePath);
                if (fileInfo.Length < 1024 * 2) //1字节单位
                {
                    try
                    {
                        File.Delete(filePath);
                    }
                    catch
                    {
                        // continue;
                    }
                    return;
                }
                string path2 = System.IO.Path.GetDirectoryName(filePath);
                //MessageBox.Show(path2);
                if (!System.IO.Directory.Exists(path2 + "\\Trash"))
                {
                    Directory.CreateDirectory(path2 + "\\Trash");
                }
                File.Delete(path2 + "\\Trash\\" + System.IO.Path.GetFileName(filePath));
                File.Move(filePath, path2 + "\\Trash\\" + System.IO.Path.GetFileName(filePath));

            }

            if (listUseImg.Items.Count > 0)
            {
                foreach (SkuImgListBox sbx in listUseImg.Items)
                {
                    sbx.changeImg(filePath, "");

                }
            }



            //清理上边要用的图
            if (wpUseImg.Children.Count > 0)
            {
                ArrayList cavanlist = new ArrayList();
                for (int i = 0; i < wpUseImg.Children.Count; i++)
                {
                    if (wpUseImg.Children[i] is BorderImageX)
                    {

                        if (((BorderImageX)(wpUseImg.Children[i])).SourcePath.Trim() == filePath)
                        {
                            cavanlist.Add(wpUseImg.Children[i]);
                        }
                    }

                }

                for (int j = 0; j < cavanlist.Count; j++)
                {
                    wpUseImg.Children.Remove((Canvas)cavanlist[j]);
                }

                cavanlist.Clear();
                cavanlist = null;
            }

            //清理下边
            if (spFree.Children.Count > 0)
            {
                /*
                ArrayList cavanlist = new ArrayList();
                for (int i = 0; i < StackPanel1.Children.Count; i++)
                {
                    System.Windows.Controls.Image aimgblock = ConvertImage.GetChildObject<System.Windows.Controls.Image>((Canvas)(StackPanel1.Children[i]), null);
                    if (aimgblock != null)
                    {

                        if (aimgblock.Tag != null && aimgblock.Tag.ToString() != "")
                        {
                            if (aimgblock.Tag.ToString() == filePath)
                            {
                                aimgblock.Source = null;
                                cavanlist.Add(StackPanel1.Children[i]);

                            }
                        }

                    }
                }

                for (int j = 0; j < cavanlist.Count; j++)
                {
                    StackPanel1.Children.Remove((Canvas)cavanlist[j]);
                }

                cavanlist.Clear();
                cavanlist = null;

                */
            }





        }

        private void Bdimg_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            BorderImageX t = (BorderImageX)(sender);
            if (t.IsErrowSize) return;


            if (listUseImg.SelectedItem != null)
            {
                if (((SkuImgListBox)(listUseImg.SelectedItem)).getImgCount() < 1)
                {
                    if (t.SizeWidth < 800 || t.SizeHeight < 800)
                    {
                        // new TipPopup(t, "主图应大于800x800，此图为" + t.SizeInfo).Show();
                        t.ShowTipPopup("主图应大于800x800，此图为" + t.SizeInfo);
                        return;
                    }
                }
                ((SkuImgListBox)(listUseImg.SelectedItem)).addImgX(t.SourcePath.Trim());
            }
        }

        private void Bdimg_Used(object Sender, RoutedEventArgs e)
        {
            BorderImageX t = (BorderImageX)(Sender);

            if (t.IsErrowSize) return;
            TopRightAddOne(t.SourcePath);

        }

        private void Bdimg_UnUsed(object Sender, RoutedEventArgs e)
        {
            e.Handled = true;
            if (wpUseImg.Children.Count > 0)
            {
                string tpath = ((BorderImageX)(Sender)).SourcePath.Trim();
                List<BorderImageX> cavanlist = new List<BorderImageX>();
                for (int i = 0; i < wpUseImg.Children.Count; i++)
                {
                    if (wpUseImg.Children[i] is BorderImageX t)
                    {
                        if (t.SourcePath.Trim() == tpath)
                        {
                            t.SourceBitmapImage100 = null;
                            cavanlist.Add(t);
                        }
                    }
                }

                for (int j = 0; j < cavanlist.Count; j++)
                {
                    wpUseImg.Children.Remove(cavanlist[j]);
                }

                cavanlist.Clear();
                cavanlist = null;

            }
        }

        //下右边添加一个
        private void RightAddOne(string _imgpathstr, bool at0, bool _isused)
        {
            //  Canvas acanvas = geneOneCavans(_imgpathstr);

            if (!File.Exists(_imgpathstr)) return;
            BorderImageX bdimg = new BorderImageX
            {
                ShowCheck = true,
                IsUsed = _isused,
                SourcePath = _imgpathstr
            };

            bdimg.MouseLeftButtonDown += Bdimg_MouseLeftButtonDown;
            bdimg.MouseRightButtonUp += Bdimg_MouseRightButtonDown;

            bdimg.Deleted += DelBt_Click; //(object sender, RoutedEventArgs e) // Bdimg_Deleted;
            bdimg.Used += Bdimg_Used;
            bdimg.UnUsed += Bdimg_UnUsed;


            if (at0)
            {
                wpLocalImg.Children.Insert(0, bdimg);
            }
            else
            {
                wpLocalImg.Children.Add(bdimg);
            }

        }

        private void TopBdimg_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            BorderImageX t = (BorderImageX)sender;

            if (t.IsSelected)
            {
                t.IsSelected = false;
                wpUseImg.Tag = null;
                return;
            }

            if (wpUseImg.Tag != null)
            {
                if (wpUseImg.Tag is BorderImageX t2)
                {
                    t2.IsSelected = false;
                    wpUseImg.Children.Remove(t2);
                    wpUseImg.Children.Insert(wpUseImg.Children.IndexOf(t), t2);

                }

                wpUseImg.Tag = null;

            }
            else
            {
                t.IsSelected = true;
                wpUseImg.Tag = t;
            }


        }

        private void Bdimg_Deleted1(object Sender, RoutedEventArgs e)
        {
            e.Handled = true;

            if (((BorderImageX)Sender).IsSelected) wpUseImg.Tag = null;

            ((BorderImageX)Sender).SourceBitmapImage100 = null;

            wpUseImg.Children.Remove((BorderImageX)Sender);
        }

        //上右添加一个
        private void TopRightAddOne(string _imgpathstr)
        {
            //  Canvas acanvas = geneOneCavans(_imgpathstr);
            if (_imgpathstr.Trim().StartsWith("http"))
            {
                BorderImageX bdimg = new BorderImageX
                {
                    SourcePath = _imgpathstr
                };

                bdimg.MouseLeftButtonDown += TopBdimg_MouseLeftButtonDown;
                bdimg.Deleted += Bdimg_Deleted1;

                wpUseImg.Children.Add(bdimg);
            }
            else
            {
                if (File.Exists(_imgpathstr))
                {
                    BorderImageX bdimg = new BorderImageX
                    {
                        SourcePath = _imgpathstr
                    };

                    bdimg.MouseLeftButtonDown += TopBdimg_MouseLeftButtonDown;
                    bdimg.Deleted += Bdimg_Deleted1;

                    wpUseImg.Children.Add(bdimg);

                }

            }
        }

        //加载SKU组合
        private void YsAsynReloadDo(object data)
        {
            Thread.Sleep(100);
            JArray Jskuboxs = (JArray)data;

            if (Jskuboxs.Count > 0)
            {
                //for (int i = 0; i < Jskuboxs.Count; i++)
                //{
                //    this.Dispatcher.BeginInvoke(new Action(() => AddNewSkuImgBox((JObject)Jskuboxs[i])));

                //    Thread.Sleep(200);

                //}

                Parallel.ForEach(Jskuboxs, new Action<JToken>((item) => this.Dispatcher.BeginInvoke(new Action(() => AddNewSkuImgBox((JObject)item)))));
                //foreach (var item in Jskuboxs)
                //{
                //    this.Dispatcher.BeginInvoke(new Action(() => AddNewSkuImgBox((JObject)item)));
                //    Thread.Sleep(200);
                //}

                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (listUseImg.Items.Count > 0)
                    {
                        listUseImg.SelectedIndex = 0;
                    }
                }));
            }

        }

        //新建颜色分组
        private void AddNewSkuImgBox(JObject _jdata) //string[] _imgs, string _lazadaColor, string _chColor
        {
            try
            {
                SkuImgListBox skulsb = new SkuImgListBox(_jdata);

                if (String.IsNullOrEmpty(skulsb.LazadaSkuZuohe)) return;

                skulsb.DeleteAllImgSkuImgListBox += Skulsb_DeleteAllImgSkuImgListBox;

                skulsb.CopyOneSkuImgListBox += Skulsb_CopyOneSkuImgListBox;

                skulsb.CopyAllSkuImgListBox += Skulsb_CopyAllSkuImgListBox;

                listUseImg.Items.Add(skulsb);
            }
            catch (Exception ex)
            {
                new LogOutput.LogTo().WriteErrorLine(ex.Message);
            }

        }

        private void Skulsb_CopyAllSkuImgListBox(object sender, RoutedEventArgs e)
        {
            SkuImgListBox _self = (SkuImgListBox)sender;
            if (listUseImg.Items.Contains(_self))
            {
                //  _self
                //  int ix = skuimgboxList.IndexOf();
                int ix = listUseImg.Items.IndexOf(_self);
                if (ix >= (listUseImg.Items.Count - 1)) return;

                if (_self.skuimginfo == null) return;

                List<string> limg = _self.GetLeftImgPaths();
                if (limg == null) return;
                //getImgCount

                string[] limgArray = limg.ToArray();
                /*
                                new Thread(() => {
                                    this.Dispatcher.BeginInvoke(new Action(() =>
                                    {

                                    }));
                                }).Start();
                */
                for (int iy = (ix + 1); iy < listUseImg.Items.Count; iy++)
                {
                    ((SkuImgListBox)listUseImg.Items[iy]).clearAndAddimgLeft(limgArray);
                }



            }
        }

        //复制上一行的图片
        private void Skulsb_CopyOneSkuImgListBox(object sender, RoutedEventArgs e)
        {
            SkuImgListBox _self = (SkuImgListBox)sender;
            if (listUseImg.Items.Contains(_self))
            {
                //  _self
                //  int ix = skuimgboxList.IndexOf();
                int ix = listUseImg.Items.IndexOf(_self);
                if (ix < 1) return;

                if (_self.skuimginfo == null) return;
                // if (_self.getImgCount() > 0) return;

                List<string> limg = ((SkuImgListBox)(listUseImg.Items[ix - 1])).GetLeftImgPaths();

                if (limg == null) return;

                _self.clearAndAddimgLeft(limg.ToArray());
            }
        }

        //清本行以下行的图片
        private void Skulsb_DeleteAllImgSkuImgListBox(object sender, RoutedEventArgs e) //Skulsb_DeleteAllImgSkuImgListBox
        {
            SkuImgListBox _self = (SkuImgListBox)sender;
            if (listUseImg.Items.Contains(_self))
            {
                int ix = listUseImg.Items.IndexOf(_self);
                if (ix >= (listUseImg.Items.Count - 1)) return;

                if (_self.skuimginfo == null) return;
                for (int iy = (ix + 1); iy < listUseImg.Items.Count; iy++)
                {
                    ((SkuImgListBox)listUseImg.Items[iy]).clearImg();
                }
            }
        }

        //异步加载完
        //右边刷新一次
        private void DeepOne(JObject AJ, int _rk, JArray sukzh)
        {
            int rank = _rk;
            JToken _Jo = sukzh[_rk];
            string tname = _Jo["name"].ToString();
            string[] tvalues = _Jo["value"].ToString().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string st in tvalues)  //遍历第几个SKU值
            {
                // AJ["name"] = tname;
                //  AJ["value"] = st;
                JObject wobj = new JObject
                {
                    { "name", tname },
                    { "value", st.Trim() }
                };
                JObject AJX = (JObject)AJ.DeepClone(); //
                if (AJX["sku"] == null)
                {
                    JArray jasku = new JArray
                    {
                        wobj
                    };
                    AJX["sku"] = jasku;
                }
                else
                {
                    ((JArray)AJX["sku"]).Add(wobj);
                }
                if (rank < (sukzh.Count - 1))
                {
                    DeepOne(AJX, rank + 1, sukzh);
                }
                else
                {
                    allskuzh.Add(AJX);  // 收集
                    if (oldskuimglist != null && oldskuimglist.Count > 0)
                    {
                        try
                        {
                            List<JToken> listA = new List<JToken>();
                            listA = AJX["sku"].ToList();
                            IEnumerable<JToken> query = listA.OrderBy(JToken => JToken["name"]);
                            listA = query.ToList();
                            JToken sametoken = null;
                            foreach (JToken jt in oldskuimglist) //不同sku组合
                            {
                                if (((JArray)jt["sku"]).Count == listA.Count)  //子SKU个数相等
                                {
                                    List<JToken> listB = new List<JToken>();
                                    listB = jt["sku"].ToList();
                                    IEnumerable<JToken> queryB = listB.OrderBy(JToken => JToken["name"]);
                                    listB = queryB.ToList();
                                    int px = 0;
                                    for (px = 0; px < listA.Count; px++)  //同一组合下的 不同子SKU
                                    {
                                        if (listA[px]["name"].ToString().Trim() != listB[px]["name"].ToString().Trim() || listA[px]["value"].ToString().Trim() != listB[px]["value"].ToString().Trim())
                                        {
                                            sametoken = null;
                                            break;
                                        }
                                    }
                                    if (px >= listA.Count)
                                    {
                                        sametoken = jt;
                                        AJX["leftimages"] = jt["leftimages"];
                                        AJX["rightimages"] = jt["rightimages"];
                                        break;
                                    }
                                }
                            }

                            if (sametoken != null && oldskuimglist.Contains(sametoken))
                            {
                                oldskuimglist.Remove(sametoken);
                            }
                        }
                        catch //(Exception es)
                        {

                        }
                    }
                }
            }
        }


        //异步加载完
        //右边刷新一次
        private void DeepOne2(JToken Jcolor, JToken Jsize)
        {
            string[] tcolors = Jcolor["value"].ToString().Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string st in tcolors)
            {
                JObject cobj = new JObject
                {
                    { "name", Jcolor["name"].ToString() },
                    { "value", st.Trim() }
                };

                JObject sobj = new JObject
                {
                    { "name", Jsize["name"].ToString() },
                    { "value", Jsize["value"].ToString() }
                };


                JArray jasku = new JArray
                {
                    cobj,
                    sobj
                };

                JObject AFX = new JObject
                {
                    { "sku", jasku },
                    { "leftimages", new JArray() },
                    { "rightimages", new JArray() }
                };

                allskuzh.Add(AFX);  // 收集

                if (oldskuimglist != null && oldskuimglist.Count > 0)
                {
                    try
                    {
                        foreach (JToken jt in oldskuimglist) //不同sku组合
                        {
                            JArray Jod = (JArray)jt["sku"];
                            if (Jod.Count == 2)  //子SKU个数相等
                            {
                                JToken _J1 = (JToken)Jod[0];
                                JToken _J2 = (JToken)Jod[1];

                                if (_J1["name"].ToString() == "color_family" && _J2["name"].ToString() == "size")
                                {
                                    if (_J1["value"].ToString() == st.Trim())
                                    {
                                        AFX["leftimages"] = jt["leftimages"];
                                    }
                                }
                                else
                                if (_J2["name"].ToString() == "color_family" && _J1["name"].ToString() == "size")
                                {
                                    if (_J2["value"].ToString() == st.Trim())
                                    {
                                        AFX["leftimages"] = jt["leftimages"];
                                    }
                                }
                            }
                        }
                    }
                    catch // (Exception es)
                    {

                    }
                }
            }
        }

        /// <summary>
        /// 加载左侧颜色列表
        /// </summary>
        private void AddColorText(Product product)
        {
            if (product.Pcolors == null || product.Pcolors == string.Empty)
            {
                //CMessageBox.Show("请先选择类目");
                return;
            }
            listWord.Items.Clear();
            var colorArr = product.Pcolors.Split(',');
            foreach (var item in colorArr)
            {
                if (item.Trim() != string.Empty)
                {
                    var tips = ColorMatch.GetCHcolor(item, product.Pcolormatch);
                    if (tips == "")
                    {
                        tips = item;
                    }
                    AddOneColorText(item.Trim(), tips);

                }
            }

        }

        /// <summary>
        /// 左边颜色值选项卡中添加颜色
        /// </summary>
        /// <param name="_color"></param>
        /// <param name="_tips"></param>
        public void AddOneColorText(string _color, string _tips)
        {
            // ListBoxItem oneItem = new
            _color = (_color.Replace(",", " ").Replace("\'", " ").Replace("=", " ").Replace("|", "").Replace("(", "").Replace(")", "")).Trim();
            if (_color == "") return;
            ListBoxItem oneItem = new ListBoxItem();
            // oneItem.Click +=new RoutedEventHandler(oneItem_Click);
            // oneItem.Checked +=new RoutedEventHandler(oneItem_Checked);
            oneItem.MouseEnter += new MouseEventHandler(OneItem_MouseEnter);
            oneItem.MouseLeave += new MouseEventHandler(OneItem_MouseLeave);
            oneItem.MouseDoubleClick += OneItem_MouseDoubleClick;
            oneItem.Content = _color;
            if (_tips != "") oneItem.ToolTip = _tips;
            if (ColorMatch.wishcolors != null)
            {
                if (!ColorMatch.IsWishColor(_color))
                {
                    oneItem.Foreground = System.Windows.Media.Brushes.Red; ;
                    oneItem.ToolTip = "要手动匹配";
                }
            }
            listWord.Items.Add(oneItem);


        }

        //鼠标双击事件
        private void OneItem_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            myImgEditor.inputText(((ListBoxItem)sender).Content.ToString());
        }


        //左边选项鼠标离开时
        private void OneItem_MouseLeave(object sender, RoutedEventArgs e)
        {
            ((ListBoxItem)sender).FontWeight = FontWeights.Normal;
        }

        //左边选项鼠标划过时
        private void OneItem_MouseEnter(object sender, RoutedEventArgs e)
        {
            ((ListBoxItem)sender).FontWeight = FontWeights.Bold;
        }


        private void BtnSaveNext_Click(object sender, RoutedEventArgs e)
        {
            //SaveProduct();
            //mainWin.RdoTasks_Click(null, null);
            if (!SaveProduct())
            {
                CMessageBox.Show("保存失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            //mainWin.myContain.Children.Clear();
            //Tasks userControl = new Tasks(mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);

            mainWin.ChangeChildControl(null, mainWin, "MT");
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (SaveProduct())
            {
                CMessageBox.Show("已保存");
            }
        }

        public void ReleaseSkuImg()
        {
            if (listUseImg.Items.Count > 0)
            {
                foreach (SkuImgListBox sib in listUseImg.Items)
                {
                    sib.clearImg();
                }
            }
            listUseImg.Items.Clear();
        }


        public void ReleaseCommonImg()
        {
            if (wpUseImg.Children.Count > 0)
            {
                for (int i = 0; i < wpUseImg.Children.Count; i++)
                {
                    if (wpUseImg.Children[i] is BorderImageX)
                    {
                        ((BorderImageX)(wpUseImg.Children[i])).SourceBitmapImage100 = null;
                    }
                }
            }

            wpUseImg.Children.Clear();

        }

        public void ReleaseLocalImg()
        {
            if (wpLocalImg.Children.Count > 0)
            {
                for (int i = 0; i < wpLocalImg.Children.Count; i++)
                {
                    if (wpLocalImg.Children[i] is BorderImageX)
                    {
                        ((BorderImageX)(wpLocalImg.Children[i])).SourceBitmapImage100 = null;
                    }
                }
            }
            wpLocalImg.Children.Clear();
        }


        public void ReleaseImg()
        {
            ReleaseSkuImg();
            ReleaseCommonImg();
            ReleaseLocalImg();

        }


        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            allskuzh.Clear();

            ReleaseImg();
            var product = (Product)this.DataContext;
            AddOrigImg(product, true);
        }

        private void BtnPaste_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ListUseImg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ExpSourceImg_Expanded(object sender, RoutedEventArgs e)
        {
            if (wpSourceImg.Children.Count > 0) return;
            Product product = (Product)this.DataContext;

            if (product.Porigimgsurl.Length < 5) return;

            Thread thNetLoadimg = new Thread(new ParameterizedThreadStart(NetAsynReloadDo))
            {
                IsBackground = true
            };
            thNetLoadimg.Start(product.Porigimgsurl);
        }

        private void NetAsynReloadDo(object data)
        {
            Thread.Sleep(100);
            string[] urls = ((string)data).Split(',');
            foreach (var item in urls)
            {
                Thread.Sleep(50);

                this.Dispatcher.BeginInvoke(new Action(() => UrlImgAddOne(item)));
            }
            //for (int i = 0; i < urls.Length; i++)
            //{
            //    Thread.Sleep(50);

            //    this.Dispatcher.BeginInvoke(new Action(() => UrlImgAddOne(urls[i])));

            //}
            Thread.Sleep(50);
            this.Dispatcher.BeginInvoke(new Action(() => CheckSeleced2()));
        }

        //收集详情描述要用的图片地址
        public string CollectUseimg()
        {

            if (wpUseImg.Children.Count > 0)
            {
                List<string> pathList = new List<string>();
                for (int i = 0; i < wpUseImg.Children.Count; i++)
                {
                    if (wpUseImg.Children[i] is BorderImageX)
                    {
                        if (!pathList.Contains(((BorderImageX)wpUseImg.Children[i]).SourcePath.Trim()))
                            pathList.Add(((BorderImageX)wpUseImg.Children[i]).SourcePath.Trim());

                    }
                }
                if (pathList.Count > 0)
                {
                    return string.Join(",", pathList.ToArray());
                }
                else
                {
                    return "";
                }
            }
            else
            {
                return "";

            }


        }

        private void CheckSeleced2()
        {
            string _useimgs = CollectUseimg();
            if (_useimgs.Length < 3) return;
            string[] useimgs = _useimgs.Split(',');

            if (wpSourceImg.Children.Count > 0)
            {
                for (int i = 0; i < wpSourceImg.Children.Count; i++)
                {
                    System.Windows.Controls.Image aimgblock = ConvertImage.GetChildObject<System.Windows.Controls.Image>((Canvas)(wpSourceImg.Children[i]), null);
                    if (aimgblock != null)
                    {
                        if (aimgblock.Tag != null && aimgblock.Tag.ToString() != "")
                        {
                            if (useimgs.Contains(aimgblock.Tag.ToString().Trim()))
                            {
                                CheckBox ccb = ConvertImage.GetChildObject<CheckBox>((Canvas)(wpSourceImg.Children[i]), null);
                                if (ccb != null) ccb.IsChecked = true;
                                //System.Windows.Shapes.Rectangle rect = ConvertImage.GetChildObject<System.Windows.Shapes.Rectangle>((Canvas)(WrapPanel2.Children[i]), null);
                                //System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(200, 85, 45));
                                //rect.Stroke = brs;
                                //rect.StrokeThickness = 2;

                            }
                        }

                    }
                }
            }


        }

        public void Acanvas_MouseEnter(object sender, MouseEventArgs e)
        {
            Button delBt = ConvertImage.GetChildObject<Button>(((Canvas)sender), null);
            delBt.Visibility = Visibility.Visible;
        }
        public void Acanvas_MouseLeave(object sender, MouseEventArgs e)
        {
            Button delBt = ConvertImage.GetChildObject<Button>(((Canvas)sender), null);
            delBt.Visibility = Visibility.Hidden;
        }

        //浏览器中查看
        private void NetImgMenuItem2_Click(object sender, RoutedEventArgs e)
        {

            MenuItem menuItem = (MenuItem)sender;
            if (menuItem.Tag == null) return;
            if (menuItem.Tag.ToString().Trim() == "") return;
            // Clipboard.SetDataObject(menuItem.Tag.ToString().Trim()); //到剪贴板
            try
            {
                System.Diagnostics.Process.Start(menuItem.Tag.ToString());
            }
            catch
            {

            }
        }

        //网络图片异步加载完成时
        private void Abtimg_DownloadCompletedX(object sender, EventArgs e)
        {
            // MessageBox.Show(((BitmapImage)sender).UriSource.ToString());

            foreach (Canvas acanvas in wpSourceImg.Children)
            {
                System.Windows.Controls.Image aimgblock = ConvertImage.GetChildObject<System.Windows.Controls.Image>(acanvas, null);
                if (aimgblock != null && aimgblock.Tag != null)
                {
                    if (aimgblock.Tag.ToString() == ((BitmapImage)sender).UriSource.ToString())
                    {
                        if (((BitmapImage)sender).Width < 20 || ((BitmapImage)sender).Height < 20)
                        {
                            wpSourceImg.Children.Remove(acanvas);
                            return;
                        }
                        /*
                        // aimgblock.ToolTip = ((BitmapImage)sender).Width.ToString("#") + "X" + ((BitmapImage)sender).Height.ToString("#");
                        System.Windows.Controls.Image aimgTip = new System.Windows.Controls.Image();
                        aimgTip.Width = 400;
                        aimgTip.Height = 400 * ((BitmapImage)sender).Height / ((BitmapImage)sender).Width;
                        aimgTip.Source = aimgblock.Source;
                        acanvas.ToolTip = aimgTip;

                        acanvas.SetValue(ToolTipService.InitialShowDelayProperty, 1000);
                        acanvas.SetValue(ToolTipService.BetweenShowDelayProperty, 1000);
                        acanvas.SetValue(ToolTipService.HasDropShadowProperty, true);
                        */
                        return;

                    }
                }

            }

        }

        private void Aimgblock_MouseEnter(object sender, MouseEventArgs e)
        {
            System.Windows.Controls.Image aimgblock = (System.Windows.Controls.Image)sender;
            if (aimgblock != null && aimgblock.Tag != null && aimgblock.ToolTip == null)
            {

                // aimgblock.ToolTip = ((BitmapImage)sender).Width.ToString("#") + "X" + ((BitmapImage)sender).Height.ToString("#");
                System.Windows.Controls.Image aimgTip = new System.Windows.Controls.Image
                {
                    Width = 400,
                    // aimgTip.Height = 400 * ((BitmapImage)sender).Height / ((BitmapImage)sender).Width;
                    Source = new BitmapImage(new Uri(aimgblock.Tag.ToString(), UriKind.Absolute))
                };
                aimgblock.ToolTip = aimgTip;

                aimgblock.SetValue(ToolTipService.InitialShowDelayProperty, 600);
                aimgblock.SetValue(ToolTipService.BetweenShowDelayProperty, 1000);
                aimgblock.SetValue(ToolTipService.ShowDurationProperty, 30000);
                aimgblock.SetValue(ToolTipService.HasDropShadowProperty, true);

                return;


            }
        }


        //加载网络图片
        private void UrlImgAddOne(string _imgpathstr, bool isFirst = false)
        {
            Canvas acanvas = new Canvas
            {
                Height = 96,
                Width = 96
            };
            System.Windows.Media.Brush brsA = new SolidColorBrush(System.Windows.Media.Color.FromRgb(210, 225, 210));
            acanvas.Background = brsA;
            acanvas.Margin = new Thickness(2);
            //   acanvas.MouseLeftButtonDown += Acanvas_MouseLeftButtonDown;
            // acanvas.MouseRightButtonDown += new MouseButtonEventHandler(aimgblock_MouseRightButtonDown);
            // acanvas.MouseEnter += Acanvas_MouseEnter; 
            acanvas.MouseEnter += new MouseEventHandler(Acanvas_MouseEnter);
            acanvas.MouseLeave += new MouseEventHandler(Acanvas_MouseLeave);
            //acanvas.MouseLeftButtonDown += new MouseButtonEventHandler(aimgblock0_MouseLeftButtonDown);
            if (_imgpathstr.StartsWith("http"))
            {
                //右键，复制图片网络地址
                ContextMenu Menu1 = new ContextMenu();
                MenuItem menuItem2 = new MenuItem
                {
                    Header = "浏览器中查看"
                };
                menuItem2.Click += new RoutedEventHandler(NetImgMenuItem2_Click);
                menuItem2.Tag = _imgpathstr.Trim();
                Menu1.Items.Add(menuItem2);
                acanvas.ContextMenu = Menu1;
            }

            System.Windows.Controls.Image aimgblock = new System.Windows.Controls.Image
            {
                Width = 90,
                Height = 90,
                Margin = new Thickness(3),
                Tag = _imgpathstr
            };
            //aimgblock.Source = new BitmapImage(new Uri(_imgpathstr, UriKind.Absolute));
            //Uri uri = null;
            //if (_imgpathstr.IndexOf(".jpg") > -1)
            //{
            //    uri = new Uri(_imgpathstr.Replace(".jpg", ".100x100.jpg"), UriKind.Absolute);
            //}
            //else
            //{
            //    uri = new Uri(_imgpathstr, UriKind.Absolute);

            //}
            BitmapImage abtimg = new BitmapImage(new Uri(_imgpathstr, UriKind.Absolute));//.Replace(".jpg", ".100x100.jpg")
            //BitmapImage abtimg = new BitmapImage(uri);
            abtimg.DownloadCompleted += new EventHandler(Abtimg_DownloadCompletedX);
            aimgblock.Source = abtimg;
            aimgblock.MouseEnter += Aimgblock_MouseEnter;




            //aimgblock.Source = ConvertImage.FileToBitmapImage(_imgpathstr);
            //  aimgblock.MouseLeftButtonDown += new MouseButtonEventHandler(aimgblock2_MouseLeftButtonDown);
            // aimgblock.MouseRightButtonDown += new MouseButtonEventHandler(aimgblock_MouseRightButtonDown);
            acanvas.Children.Add(aimgblock);
            // acanvas.ToolTip =new 




            System.Windows.Shapes.Rectangle rect = new System.Windows.Shapes.Rectangle
            {
                Width = 92,
                Height = 92
            };
            System.Windows.Media.Brush brs = null;
            if (_imgpathstr.IndexOf("ae01.alicdn.com") == -1)
                brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(170, 170, 140));
            else
                brs = new SolidColorBrush(System.Windows.Media.Colors.Red);
            rect.Stroke = brs;
            rect.StrokeThickness = 1;
            rect.Margin = new Thickness(2);
            //rect.MouseLeave +=new MouseEventHandler(rect_MouseLeave);
            acanvas.Children.Add(rect);

            /*

            CheckBox usecb = new CheckBox();
            usecb.Cursor = Cursors.Hand;
            usecb.Margin = new Thickness(70, 6, 0, 2);
            usecb.SetResourceReference(CheckBox.StyleProperty, "style7");
            usecb.Checked += new RoutedEventHandler(usecb_Checked);
            usecb.Unchecked += new RoutedEventHandler(usecb_Unchecked);
            acanvas.Children.Add(usecb);
            */
            Button delBt = new Button
            {
                Tag = _imgpathstr,
                Width = 24,
                Height = 24,
                Margin = new Thickness(7, 5, 0, 0)
            };
            delBt.SetResourceReference(Button.StyleProperty, "btnStyleDown");
            delBt.Visibility = Visibility.Hidden;

            //  delBt.Visibility = Visibility.Visible;
            delBt.Click += new RoutedEventHandler(DownOneImg_Click);
            acanvas.Children.Add(delBt);

            CheckBox chk = new CheckBox()
            {
                Width = 20,
                Height = 20,
                Margin = new Thickness(80, 2, 0, 0),
                Tag = _imgpathstr
            };
            acanvas.Children.Add(chk);

            if (isFirst)
                wpSourceImg.Children.Insert(0, acanvas);
            else
                wpSourceImg.Children.Add(acanvas);

        }
        private void DownOneImg_Click(object sender, RoutedEventArgs e)
        {
            string timgpath = ((Button)sender).Tag.ToString();
            Product product = (Product)this.DataContext;

            string imgPath = product.Plocalimgpath;
            if (!System.IO.Directory.Exists(imgPath)) { Directory.CreateDirectory(imgPath); }

            string loackImgPath = imgPath + "\\C" + DateTime.Now.ToFileTime().ToString() + ".jpg";

            aimg currimg = new aimg(timgpath, loackImgPath, 0);

            Thread thd = new Thread((a) =>
            {  //a是传进来的object
               //这里是新线程做的事
                aimg ax = (aimg)a;
                WebClientWithOutTime wc1 = new WebClientWithOutTime();
                wc1.Headers.Add("User-Agent", "Chrome");
                try
                {
                    wc1.DownloadFile(ax.imgUrl, ax.imgName);//第二个参数是保存到本地的文件名和路径，不要随时改动文件动，重新下载时要用L477
                }
                catch
                {
                    Thread.Sleep(1000);
                    try
                    {
                        wc1.DownloadFile(ax.imgUrl, ax.imgName);//第二个参数是保存到本地的文件名和路径

                    }
                    catch
                    {
                        Thread.Sleep(1000);
                        try
                        {

                            wc1.DownloadFile(ax.imgUrl, ax.imgName);//第二个参数是保存到本地的文件名和路径

                        }
                        catch
                        {
                            return;
                        }

                    }

                }

                this.Dispatcher.BeginInvoke(new Action<string>((b) =>  // b= x
                {
                    //UI线程中做的事
                    RightAddOne(b, true, false);

                }

            ), loackImgPath); //此处x传给代理处理函数的参数 ， 可以是多个


            })
            {
                IsBackground = true
            };

            thd.Start(currimg);  //object传给新线程的参数，要封装成object


        }

        private void GridLocalImg_Drop(object sender, DragEventArgs e)
        {

        }

        private void GridLocalImg_DragEnter(object sender, DragEventArgs e)
        {

        }

        private void BtnOpenFile_Click(object sender, RoutedEventArgs e)
        {
            Product product = (Product)this.DataContext;
            if (product.Plocalimgpath != null && product.Plocalimgpath != "")
            {
                string imgPath = product.Plocalimgpath;
                if (!System.IO.Directory.Exists(imgPath)) return;

                System.Diagnostics.Process.Start("explorer.exe", imgPath);

            }
            else
            {
                System.Windows.Forms.FolderBrowserDialog fbd = new System.Windows.Forms.FolderBrowserDialog();
                if (System.Windows.Forms.DialogResult.OK == fbd.ShowDialog())
                {
                    product.Plocalimgpath = fbd.SelectedPath;
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        new GetLinkCore().UpdateImageSavePath(fbd.SelectedPath);
                        new ProductCore().UpdatePlocalimgpath(product);
                    }));
                    System.Diagnostics.Process.Start("explorer.exe", product.Plocalimgpath);
                }
            }


        }

        private void BtnShrinkage_Click(object sender, RoutedEventArgs e)
        {
            //ImgEditorCanvas.IsVisible = true;
            if (cvsImgEditor.Visibility == System.Windows.Visibility.Visible)
            {
                cvsImgEditor.Visibility = System.Windows.Visibility.Collapsed;

                //  SkuImgCanvas.Visibility = System.Windows.Visibility.Visible;

                //  isEditImg = false;

            }
            else
            {
                cvsImgEditor.Visibility = System.Windows.Visibility.Visible;
                // SkuImgCanvas.Visibility = System.Windows.Visibility.Collapsed;

                //  isEditImg = true;
            }
        }

        private void BtnToWhite_Click(object sender, RoutedEventArgs e)
        {
            Product product = (Product)this.DataContext;
            if (product.Plocalimgpath != null && product.Plocalimgpath != "")
            {
                btnToWhite.IsEnabled = false;
                // MessageBox.Show("B" + _cDRW["pnewimgsurl"].ToString());
                string _currFolder = product.Plocalimgpath;
                if (!System.IO.Directory.Exists(_currFolder)) return;
                //ConvertImage.cutImg(_currFolder, true, false);
                //ConvertImage.cutImg(_currFolder, true, true);
                //ConvertImage.cutImg(_currFolder, true, false);

                //rightReload(cDRW, false);

                //   MessageBox.Show(cDRW["plocalimgpath"].ToString());

                Thread thLoadimg = new Thread(new ParameterizedThreadStart(Cuttingimg))
                {
                    IsBackground = true
                };
                thLoadimg.Start(_currFolder);
            }
        }

        public void Cuttingimg(object _path)
        {
            string _currFolder2 = (string)_path;
            ConvertImage.cutImg(_currFolder2, true, false);
            ConvertImage.cutImg(_currFolder2, true, true);
            ConvertImage.cutImg(_currFolder2, true, false);

            this.Dispatcher.BeginInvoke(new Action(() => { btnToWhite.IsEnabled = true; })); //此处x传给代理处理函数的参数 ， 可以是多个
            this.Dispatcher.BeginInvoke(new Action(() => AddOrigImg((Product)this.DataContext, false)));

        }

        private void BtnRefreshImg_Click(object sender, RoutedEventArgs e)
        {
            AddOrigImg((Product)this.DataContext, false);
        }

        private void BtnPasteImg_Click(object sender, RoutedEventArgs e)
        {
            Product product = (Product)this.DataContext;
            try
            {
                IDataObject data = Clipboard.GetDataObject();

                if (data == null) return;

                if (data.GetDataPresent(typeof(Bitmap)))
                {
                    System.Drawing.Image photo = (System.Drawing.Image)data.GetData(typeof(Bitmap));

                    // if (cDRW["pnewimgsurl"] != null && cDRW["pnewimgsurl"].ToString() != "")
                    // {
                    string imgPath = product.Plocalimgpath;

                    if (!Directory.Exists(imgPath))
                    {
                        Directory.CreateDirectory(imgPath);
                    }

                    imgPath = product.Plocalimgpath + "\\Bx" + DateTime.Now.ToString("MMddhhmmss") + ".jpg"; ;

                    photo.Save(imgPath, System.Drawing.Imaging.ImageFormat.Jpeg);

                    RightAddOne(imgPath, true, false);
                    //  }



                }

            }
            catch
            {
            }
        }

        private void CvsImgEditor_DragOver(object sender, DragEventArgs e)
        {

        }

        private void CvsImgEditor_DragLeave(object sender, DragEventArgs e)
        {

        }

        private void CvsImgEditor_DragEnter(object sender, DragEventArgs e)
        {

        }

        private void CvsImgEditor_Drop(object sender, DragEventArgs e)
        {

        }

        private void NudImgWide_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void NudImgHigh_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void BtnClearWatermark_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnClearWatermark_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void BtnSaveImg_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAllClear_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnCheckProduct_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Syrangc_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void ImgEdit_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void ImgEdit_MouseDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void TxtAddWord_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyboardDevice.IsKeyDown(Key.Enter))
            {
                e.Handled = true;

                TextBox tbx = (TextBox)sender;
                if (string.IsNullOrEmpty(tbx.Text)) return;

                myImgEditor.inputText(tbx.Text.Trim());

            }
        }

        private void BtnMatching_Click(object sender, RoutedEventArgs e)
        {
            //Pop_xiangji.IsOpen = true;
            //if (cclmd == null)
            //{
            //    cclmd = new colormodel();

            //    if (cDRW != null && cDRW["pcolors"] != null && cDRW["pcolors"].ToString().Trim().Length > 0)
            //    {
            //        string tcolorsText = ColorMatch.colorsUpFirstchar2(cDRW["pcolors"].ToString().Trim().Replace("，", ","));
            //        string[] leftColors = tcolorsText.Split(',');
            //        for (int i = 0; i < leftColors.Length; i++)
            //        {
            //            if (leftColors[i].Trim() != "")
            //            {
            //                //MessageBox.Show(leftColors[i].Trim());
            //                string tips = getColorTips(leftColors[i].Trim());
            //                //  if (tips == "") tips = "要手动匹配（选一个Wish系统的颜色与之对应吧）";
            //                cclmd.leftAddOne(leftColors[i].Trim(), tips);
            //            }
            //        }
            //    }
            //}

            //contentControl1.Content = cclmd;
        }

        private void BtnRefreshWord_Click(object sender, RoutedEventArgs e)
        {
            //AddColorText((Product)this.DataContext);
        }

        private void ListWord_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void ListWord_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ChkMerge_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void ChkMerge_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void ChkMerge_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void NudRow_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void NudColumn_ValueChanged(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void BtnDown_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnUp_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnRight_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnLeft_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

        }

        private void PopImgDispose_Opened(object sender, EventArgs e)
        {

        }

        private void BtnRefreshColor_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnSureColor_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnEditDetail_Click(object sender, RoutedEventArgs e)
        {
            ImgEditor imgEditor = new ImgEditor();
            imgEditor.ShowDialog();
        }

        public bool SaveProduct(bool isAuto = false)
        {
            //if ((DateTime.Now - openTime).Seconds < 3) return false;
            Product product = (Product)this.DataContext;
            //if (isAuto && (product.Pstatetype != "1" || product.Pstatetype != "2"))
            //    return false;
            if (product.Pstatetype != "1")
                product.Pstatetype = "10";
            product.UploadImgError = "";
            //lazada sku and  images
            product.Lazadaskuimages = Collectlazadacolors();

            product.Pnewimgsurl = CollectUseimg();
            if (product.Pnewimgsurl.Length == 0)
            {
                product.UploadImgError += "未选择详情图片 \n";
            }
            string[] cuc = CollectUseimgConut();
            var imagecount = Convert.ToInt32(cuc[1]);
            if (imagecount <= 0)
            {
                product.UploadImgError += "未选择图片 \n";
            }
            else
            {
                var urls = product.Pnewimgsurl.Split(',');
                if (imagecount - urls.Length == 0)
                {
                    product.UploadImgError += "未选择产品主图图片 \n";
                }
            }

            product.Pstate = String.Format($"图片状态[{cuc[0]}/{cuc[1]}]");
            product.Pupedimg = String.Format($"[{cuc[0]}/{cuc[1]}]");
            return new ProductCore().UpdateImagesEditor(product);
        }


        //收集颜色分组图片地址
        public string Collectlazadacolors()
        {
            if (listUseImg.Items.Count < 1) return "";

            JArray jary = new JArray();
            foreach (SkuImgListBox silb in listUseImg.Items)
            {
                JObject askuinfo = silb.getJsonInfo();
                // if (askuinfo["sku"].HasValues && (askuinfo["leftimages"].HasValues || askuinfo["rightimages"].HasValues))
                jary.Add(askuinfo);
            }
            if (jary.Count > 0)
            {
                return JsonConvert.SerializeObject(jary);
            }
            else
            {
                return "";
            }


        }


        //收集要用的图片地址,网络图数/本地图数
        public string[] CollectUseimgConut()
        {
            Product product = (Product)this.DataContext;
            int cot = 0;
            int cal = 0;

            if (product.Pnewimgsurl.Length > 8)
            {
                string[] newconimg2 = product.Pnewimgsurl.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                if (newconimg2.Length > 0)
                {

                    for (int lx = 0; lx < newconimg2.Length; lx++)
                    {
                        cal++;

                        if (newconimg2[lx].ToString().Trim().StartsWith("http"))
                        {
                            cot++;
                        }

                    }

                }

            }



            if (product.Lazadaskuimages != null && product.Lazadaskuimages != "")
            {
                try
                {
                    string newzhuimg = "";

                    JArray msku = (JArray)JsonConvert.DeserializeObject(product.Lazadaskuimages);

                    foreach (JToken jtn in msku) //不同sku组合
                    {
                        if (jtn["leftimages"] != null && jtn["leftimages"].HasValues)
                        {
                            JArray jaz = (JArray)jtn["leftimages"];
                            foreach (string jtx in jaz)
                            {
                                cal++;
                                if (jtx.Trim().StartsWith("http"))
                                {
                                    cot++;

                                }
                            }

                            if (newzhuimg.Length < 5 && jaz.Count > 0) newzhuimg = jaz[0].ToString();


                        }



                        /*
                        if (jtn["rightimages"] != null && jtn["rightimages"].HasValues)
                        {
                            foreach (string jtx in (JArray)jtn["rightimages"])
                            {
                                cal++;
                                if (jtx.Trim().StartsWith("http"))
                                {
                                    cot++;
                                }
                            }
                        }
                        */
                    }

                    //if (newzhuimg.Length > 5) product.Pimgurl = newzhuimg;

                    //  return new string[] { cot.ToString(), cal.ToString() };

                }
                catch
                {

                }

            }

            return new string[] { cot.ToString(), cal.ToString() };

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //mainWin.myContain.Children.Clear();
            //DetailsEditor userControl = new DetailsEditor((Product)this.DataContext, mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);

            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "Detail");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //mainWin.myContain.Children.Clear();
            //SPUEditor userControl = new SPUEditor((Product)this.DataContext, mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);

            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "SPU");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (!SaveProduct())
            {
                CMessageBox.Show("保存失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            //mainWin.myContain.Children.Clear();
            //Tasks userControl = new Tasks(mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);

            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "MT");
        }


        private void BtnTransPic_Click(object sender, RoutedEventArgs e)
        {

            List<string> list = new List<string>();
            foreach (UIElement item in wpSourceImg.Children)
            {
                Canvas canvas = (Canvas)item;
                foreach (UIElement child in canvas.Children)
                {
                    if (child is CheckBox)
                    {
                        var chk = (CheckBox)child;
                        if (chk.IsChecked ?? false)
                        {
                            var imgurl = Convert.ToString(chk.Tag);
                            list.Add(imgurl);
                        }
                    }
                }
            }
            if (list.Count == 0)
            {
                CMessageBox.Show("没有选择需要翻译的图片");
                return;
            }
            else
            {
                CMessageBoxResult mesResult = CMessageBox.Show("所选图片源语言是否为中文？", "提示", CMessageBoxButton.YesNO, CMessageBoxImage.Question);

                System.Windows.Forms.Control control = new System.Windows.Forms.Control();
                progressBar.Maximum = list.Count;
                label3.Content =  "0/" + list.Count;
                progressBar.Visibility = Visibility.Visible;
                label2.Visibility = Visibility.Visible;
                label3.Visibility = Visibility.Visible;
                Product product = (Product)this.DataContext;
                int i = 0;
                foreach (var item in list)
                {
                    i++;
                    string items =new HaiWangCore().PostSeakingImagetranslate(item, mesResult == CMessageBoxResult.Yes ? "zh" : "en");
                    if (item == items || items == null)
                    {
                        this.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            progressBar.Value = i;
                        }));
                        label3.Content = i + "/" + list.Count;
                        continue;
                    }
                    var imageurl = items.Contains("http") ? items : ("http:" + items);
                    product.Porigimgsurl = imageurl + "," + product.Porigimgsurl;
                    //Thread.Sleep(50);
                    UrlImgAddOne(imageurl, true);
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        progressBar.Value = i;
                    }));
                    //if (control.IsHandleCreated)
                    //{
                    //    control.BeginInvoke(new UpdataValue(updataValue), i);
                    //}
                    label3.Content = i + "/" + list.Count;
                    DoEvents();
                    //this.Dispatcher.BeginInvoke(new Action(() => UrlImgAddOne(imageurl, true)));
                }
                progressBar.Visibility = Visibility.Hidden;
                label2.Visibility = Visibility.Hidden;
                label3.Visibility = Visibility.Hidden;
                this.Dispatcher.BeginInvoke(new Action(() =>
                {
                    progressBar.Value = 0;
                }));
                new ProductCore().UpdatePorigimgsurl(product);
            }
        }
        public static void DoEvents()
        {
            DispatcherFrame nestedFrame = new DispatcherFrame();
            DispatcherOperation exitOperation = Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background, exitFrameCallback, nestedFrame);
            Dispatcher.PushFrame(nestedFrame);
            if (exitOperation.Status !=
            DispatcherOperationStatus.Completed)
            {
                exitOperation.Abort();
            }
        }

        private static Object ExitFrame(Object state)
        {
            DispatcherFrame frame = state as
            DispatcherFrame;
            frame.Continue = false;
            return null;
        }
        private void BtnTransPic1_Click(object sender, RoutedEventArgs e)
        {

            List<string> list = new List<string>();
            foreach (UIElement item in wpSourceImg.Children)
            {
                Canvas canvas = (Canvas)item;
                foreach (UIElement child in canvas.Children)
                {
                    if (child is CheckBox)
                    {
                        var chk = (CheckBox)child;
                        if (chk.IsChecked ?? false)
                        {
                            var imgurl = Convert.ToString(chk.Tag);
                            list.Add(imgurl);
                        }
                    }
                }
            }
            if (list.Count == 0)
            {
                CMessageBox.Show("没有选择需要翻译的图片");
                return;
            }
            else
            {
                Product product = (Product)this.DataContext;
                WinChooseLang win = new WinChooseLang(0, list);
                win.ShowDialog();
                List<string> transImagesList = new HaiWangCore().GetTranslateImages(win.ReturnTaskID);
                foreach (var item in transImagesList)
                {
                    var imageurl = item.Contains("http") ? item: ("http:" + item);
                    product.Porigimgsurl = imageurl + "," + product.Porigimgsurl;

                    this.Dispatcher.BeginInvoke(new Action(() => UrlImgAddOne(imageurl, true)));
                }
                if (transImagesList.Count > 0)
                {
                    product.PicTaskId = win.ReturnTaskID;
                }
                new ProductCore().UpdatePorigimgsurl(product);
            }
        }
    }
}
