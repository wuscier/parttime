﻿using Logic.BasicInfo;
using Logic.SystemSole;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// AdditionalSKU.xaml 的交互逻辑
    /// </summary>
    public partial class AdditionalSKU : UserControl
    {
        MainWindow mainWin = null;
        int parentCurrentPage = 1;
        public AdditionalSKU(Product product, MainWindow main, int currentPage)
        {
            parentCurrentPage = currentPage;
            mainWin = main;
            InitializeComponent();
            this.DataContext = product;
        }

        private void BtnSure_Click(object sender, RoutedEventArgs e)
        {
            if (rbnCustom.IsChecked == true)
            {
                if (txtCustom.Text.Trim().Length < 1) return;

                CreatNewRecord(txtCustom.Text);

            }

            if (rbnColor.IsChecked == true)
            {

                if (txtSourceColor.Text.Trim().Length < 1) return;

                CreatNewRecord(txtSourceColor.Text);

            }

            if (rbnSize.IsChecked == true)
            {
                if (txtSourceSize.Text.Trim().Length < 1) return;

                CreatNewRecord(txtSourceSize.Text);
            }
        }

        private void CreatNewRecord(string _str)
        {
            Product product = (Product)this.DataContext;
            ProductCore pc = new ProductCore();

            StringBuilder sb = new StringBuilder();

            string[] strs = _str.Replace("'", "").Split(new char[] { ',', '，' }, StringSplitOptions.RemoveEmptyEntries);

            if (strs.Length < 2) return;

            string title = product.Pnewtitle;

            string selfcolor = "";

            foreach (string sst in strs)
            {
                Regex regexSw = new Regex(@"\b" + Regex.Replace(sst.Trim(), "[^0-9a-zA-Z]", ".?") + @"\b", RegexOptions.IgnoreCase);
                Match matchSw = regexSw.Match(title);
                if (matchSw.Success)
                {
                    selfcolor = sst.Trim();
                    title = regexSw.Replace(title, " ");
                    title = title.Replace("( )", " ");
                }

            }

            for (int i = (strs.Length - 1); i >= 0; i--)
            {
                strs[i] = strs[i].Trim();
                if (string.IsNullOrEmpty(strs[i])) continue;

                if (selfcolor == strs[i] || (selfcolor.Length < 1 && i == 0))
                {
                    product.Pnewtitle = title + " (" + strs[i].ToUpper() + ")";
                    product.PnewtitleX = title + " (" + strs[i].ToUpper() + ")";
                    product.Lazadaskuy = strs[i].ToUpper();
                    product.Lazadafujiaskucount = strs.Length.ToString();

                    pc.SaveParentSku(product);

                    //   DBoprations.saveSkuyToDBprolist(_dr);

                    sb.Insert(0, strs[i] + ": 为本行\r\n");
                    continue;
                }

                Product product_new = product;
                product_new.Lazadaisparent = "0";
                product_new.Lazadaparentid = product.Number.ToString();
                product_new.Lazadafujiaskucount = "0";

                product_new.Pnewtitle = title + " (" + strs[i].ToUpper() + ")";
                product_new.PnewtitleX = title + " (" + strs[i].ToUpper() + ")";


                product_new.Lazadaskuy = strs[i].ToUpper();

                Product p = pc.CopyProduct(product_new);

                if (p != null)
                {
                    SystemSoleEntity.GetProductList().Insert(0, p);
                    sb.Insert(0, strs[i] + ": OK\r\n");
                }
                else
                {
                    sb.Insert(0, strs[i] + ": 生成失败\r\n");
                }
            }
            txtResult.Text = sb.ToString();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            mainWin.myContain.Children.Clear();
            Tasks userControl = new Tasks(mainWin);
            mainWin.myContain.Children.Add(userControl);
        }
    }
}
