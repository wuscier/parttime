﻿using Logic.PriceTemplate;
using Logic.SystemSole;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// OnlineProSPUEdit.xaml 的交互逻辑
    /// </summary>
    public partial class OnlineProSPUEdit : UserControl
    {
        private int parentCurrentPage = 1;
        public OnlineProSPUEdit(OnlineProduct product, MainWindow _mainWin, int currentPage)
        {
            parentCurrentPage = currentPage;
            SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.EditSpu);
            InitializeComponent();


            var currency = new SiteChangeHelp().GetCurrency();
            lbl_price.Content = "价格" + currency;
            lbl_discountPrice.Content = "促销价" + currency;

            GetPriceTemplates();
            this.DataContext = product;
            
        }
        /// <summary>
        /// 获取计价模板下拉框
        /// </summary>
        private void GetPriceTemplates()
        {
            var list = new PriceTemplateCore().GetPriceTemplateList();
            cmbValuateMde.ItemsSource = list;
            cmbValuateMde.DisplayMemberPath = "Jname";
            cmbValuateMde.SelectedValuePath = "Jname";

            cboPT.ItemsSource = list;
            cboPT.DisplayMemberPath = "Jname";
            cboPT.SelectedValuePath = "Jname";
            cboPT.SelectedIndex = 0;
        }
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void btnSaveNext_Click(object sender, RoutedEventArgs e)
        {

        }

        private void F75lxpxTmO(object sender, SelectionChangedEventArgs e)
        {

        }

        private void lHwllOTpUY(object sender, RoutedEventArgs e)
        {

        }

        private void lbLlIuK5s2(object sender, RoutedPropertyChangedEventArgs<decimal> e)
        {

        }

        private void StartTimePicker_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {

        }

        private void EndTimePicker_PickedDateTimeChanged(object sender, RoutedEventArgs e)
        {

        }

        private void tSblrcsZRe(object sender, MouseButtonEventArgs e)
        {

        }

        private void a2gljhwPPO(object sender, RoutedEventArgs e)
        {

        }

        private void PIil6fSQDn(object sender, TextChangedEventArgs e)
        {

        }

        private void Fkflmvunvs(object sender, RoutedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        private void BtnRefrush_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnReturn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnCalc_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ruNlSIpe3Q(object sender, EventArgs e)
        {

        }

        private void KxGl3D9EJU(object sender, SelectionChangedEventArgs e)
        {

        }

        private void viblM1hkeC(object sender, RoutedEventArgs e)
        {

        }

        private void UdklvHhQRn(object sender, RoutedEventArgs e)
        {

        }

        private void PqQlBmCSW4(object sender, RoutedEventArgs e)
        {

        }

        private void ocblJb3IMX(object sender, RoutedEventArgs e)
        {

        }

        private void dj0xntc6bF(object sender, RoutedEventArgs e)
        {

        }
    }
}
