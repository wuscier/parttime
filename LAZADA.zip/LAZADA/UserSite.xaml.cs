﻿using LAZADA.ChangeSite;
using LAZADA.TasksBtns;
using LAZADA.TasksBtns.ChangeSite;
using LAZADA.TasksBtns.CustomerControl;
using Logic.SystemSole;
using PublicFunction.ConfigHelp;
using PublicFunction.SiteImgRequestHelp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// UserSite.xaml 的交互逻辑
    /// </summary>
    public partial class UserSite : UserControl
    {
        public UserSite()
        {
            InitializeComponent();
        }
        public UserSite(string siteName, MainWindow main)
        {
            InitializeComponent();
            SiteName.Text = siteName;
            myMainWin = main;
        }
        MainWindow myMainWin = null;
        private void BdChangeSite_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ChangeSite();
            //Task.Run(() =>
            //{
                myMainWin.myContain.Children.Clear();
                myMainWin.myContain.Children.Add(new Tasks(myMainWin));
                Smith.WPF.HtmlEditor.HtmlEditor.toLanguage = new SiteChangeHelp().GetToLanguage();
            //});
        }
        private void ChangeSite()
        {

            NewChioceSites changeSta = new NewChioceSites();
            BaseWindow chioceSites = new BaseWindow();
            chioceSites.Show(myMainWin, 710, 260, changeSta, "LAZADA站点选择");
            #region 切换站点图片与文字
            Application.Current.Dispatcher.Invoke(new Action(() =>
            {
                SiteName.Text = GlobalUserClass.SiteName;
                switch (GlobalUserClass.SiteName)
                {
                    case "马来西亚":
                        siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.MYImg);
                        break;
                    case "越南":
                        siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.VNImg);
                        break;
                    case "新加坡":
                        siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.SgImg);
                        break;
                    case "印度尼西亚":
                        siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.IDImg);
                        break;
                    case "泰国":
                        siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.THImg);
                        break;
                    case "菲律宾":
                        siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.PHImg);
                        break;
                    case "六合一":
                        siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.CrbImg);
                        break;
                    default:
                        siteImg.ImageSource = SiteImgModeConvert.SetSiteImg(SiteImgModeConvert.SiteImgMode.DefaultImg);
                        break;
                }
                ChangeSiteInit();
            }));
            #endregion

        }
        /// <summary>
        /// 切换站点以后需要重置的数据
        /// </summary>
        private void ChangeSiteInit()
        {
            myMainWin.ReadSystemBasic();

            //PageingViewModel vm = new PageingViewModel();
            myMainWin.Tasks.vm.CurrentPage = 1;
            SystemSoleEntity.LoadProductList(myMainWin.Tasks.vm);
            //new Paging(vm);
        }

        private void Site_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ChangeSite();
        }
    }
}
