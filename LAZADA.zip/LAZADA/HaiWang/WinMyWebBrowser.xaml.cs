﻿
using CefSharp;
using CefSharp.WinForms;
using LAZADA.TasksBtns.CustomerControl;
using PublicFunction;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Forms.Integration;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.HaiWang
{
    /// <summary>
    /// WinMyWebBrowser.xaml 的交互逻辑
    /// </summary>
    public partial class WinMyWebBrowser : Window
    {

        Rect rcnormal;
        private bool isMax = false;
        ChromiumWebBrowser webbrowser = null;
        public WinMyWebBrowser(string winTitle, string url)
        {
            InitializeComponent();
            //this.Height = Screen.PrimaryScreen.WorkingArea.Height;
            //this.Title = winTitle;
            this.tbtitle.Text = winTitle;
            var settings = new CefSettings();
            settings.CefCommandLineArgs.Add("disable-gpu", "1");
            //settings.CefCommandLineArgs.Add("force-device-scale-factor", "1");
            ////Cef.Initialize(settings);
            //if (!Cef.Initialize(settings, shutdownOnProcessExit: false, performDependencyCheck: true))
            //{
            //    //throw new Exception("Unable to Initialize Cef");
            //}
            webbrowser = new ChromiumWebBrowser(url);
            var winform = new WindowsFormsHost()
            {
                Child = webbrowser
            };
            try
            {
                CefSharpSettings.LegacyJavascriptBindingEnabled = true;
                webbrowser.RegisterJsObject("SeaKing", new JsEvent(this));
            }
            catch { }
            //webbrowser.FrameLoadEnd += Webbrowser_FrameLoadEnd;
            myBrowser.Children.Add(winform);
        }

        private void Webbrowser_FrameLoadEnd(object sender, FrameLoadEndEventArgs e)
        {
            webbrowser.ShowDevTools();
        }

        private void CloseWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //Cef.Shutdown();
            webbrowser.Dispose();
            webbrowser = null;
            this.Close();
        }

        private void Grid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        class JsEvent
        {
            private WinMyWebBrowser winMyWebBrowser;

            public JsEvent(WinMyWebBrowser winMyWebBrowser)
            {
                this.winMyWebBrowser = winMyWebBrowser;
            }

            public void seakingComplete()
            {
                winMyWebBrowser.Dispatcher.BeginInvoke(new Action(() => winMyWebBrowser.Close()));
            }

            public void downloadExcel()
            {
                winMyWebBrowser.Dispatcher.BeginInvoke(new Action(() =>
                {
                    SaveFileDialog sfd = new SaveFileDialog();
                    sfd.InitialDirectory = "C:\\";
                    sfd.Filter = "Excel files(*.xlsx)|*.xlsx|Excel files(*.xls)|*.xls|All files(*.*)|*.*";
                    if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        if (sfd.FileName != string.Empty)
                        {
                            // 设置参数
                            HttpWebRequest request = WebRequest.Create(Constants.HAIWANG_EXCEL_DOWNLOAD_URL) as HttpWebRequest;
                            //发送请求并获取相应回应数据
                            HttpWebResponse response = request.GetResponse() as HttpWebResponse;
                            //直到request.GetResponse()程序才开始向目标网页发送Post请求
                            Stream responseStream = response.GetResponseStream();
                            //创建本地文件写入流
                            Stream stream = new FileStream(sfd.FileName, FileMode.Create);
                            byte[] bArr = new byte[1024];
                            int size = responseStream.Read(bArr, 0, (int)bArr.Length);
                            while (size > 0)
                            {
                                stream.Write(bArr, 0, size);
                                size = responseStream.Read(bArr, 0, (int)bArr.Length);
                            }
                            stream.Close();
                            responseStream.Close();
                        }
                    }
                }));
            }
        }

        private void ToMax_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!isMax)
            {
                isMax = true;
                rcnormal = new Rect(this.Left, this.Top, this.Width, this.Height);//保存下当前位置与大小
                Rect rc = SystemParameters.WorkArea;//获取工作区大小
                this.Width = rc.Width;
                this.Height = rc.Height;
                this.Left = 0;//设置位置
                this.Top = 0;
            }
            else
            {
                isMax = false;
                this.Left = rcnormal.Left;
                this.Top = rcnormal.Top;
                this.Width = rcnormal.Width;
                this.Height = rcnormal.Height;
            }
        }
    }

}
