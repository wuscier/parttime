﻿using Logic.Platform;
using PublicFunction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.HaiWang
{
    /// <summary>
    /// WinChooseLang.xaml 的交互逻辑
    /// </summary>
    public partial class WinChooseLang : Window
    {
        public long ReturnTaskID;
        private List<string> images;
        long productId;
        int iState = 0;//0.图片翻译  1.图片批量翻译
        public WinChooseLang(long pid, List<string> imgs,int state=0)
        {
            InitializeComponent();
            images = imgs;
            productId = pid;
            iState = state;
        }

        private void CloseWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void BtnGetAuthorize_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var sourceLang = zh.IsChecked == true ? "zh" : "en";
            ReturnTaskID = new HaiWangCore().PostImagesToTranslate(productId, images, sourceLang);
            new LogOutput.LogTo().WriteErrorLine("任务ID：" + ReturnTaskID.ToString());
            string url = GlobalUserClass.GetHaiWangModel().CreateURLByTaskID(Constants.HAIWANG_FUN_PIC_URL, ReturnTaskID);
            new LogOutput.LogTo().WriteErrorLine("图片翻译跳转的链接：" + url);
            WinMyWebBrowser win = new WinMyWebBrowser("图片翻译", url);
            win.ShowDialog();
            this.Close();
        }
    }
}
