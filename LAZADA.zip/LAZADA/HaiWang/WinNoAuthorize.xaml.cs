﻿using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using PublicFunction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LAZADA.HaiWang
{
    /// <summary>
    /// WinNoAuthorize.xaml 的交互逻辑
    /// </summary>
    public partial class WinNoAuthorize : Window
    {
        public WinNoAuthorize()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Dispatcher.BeginInvoke(new Action(() =>
            {
                string url = GlobalUserClass.GetHaiWangModel().CreateURL(Constants.HAIWANG_FUN_AUTHORIZED_URL);
                WinMyWebBrowser win = new WinMyWebBrowser("阿里翻译授权", GlobalUserClass.GetHaiWangModel().CreateURL(Constants.HAIWANG_FUN_AUTHORIZED_URL));
                btnToAuthorize.Visibility = Visibility.Collapsed;
                btnGetAuthorize.Visibility = Visibility.Visible;
                win.ShowDialog();
            }));
        }

        private void BtnGetAuthorize_Click(object sender, RoutedEventArgs e)
        {
            new HaiWangCore().GetUserAuthorized();
            if (new SystemConfigCore().SetAliAuthorization() == 0 && GlobalUserClass.GetHaiWangModel().IsAuthorized)
            {
                CMessageBox.Show("授权成功");
                this.Close();
            }
            else
            {
                CMessageBox.Show("授权失败,请联系客服");
            }
        }

        private void CloseWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }
    }
}
