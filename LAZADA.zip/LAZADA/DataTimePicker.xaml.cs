﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LAZADA
{
    /// <summary>
    /// DataTimePicker.xaml 的交互逻辑
    /// </summary>
    public partial class DataTimePicker : UserControl
    {

        //事件触发机制(必须和事件在同一个类中) 外界无法直接用EventSelecedme()来触发事件
        public static readonly RoutedEvent PickedDateTimeChangedEvent = EventManager.RegisterRoutedEvent("PickedDateTimeChanged", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(DataTimePicker));

        //register 最后一个参数（可选的回调函数 ）可做属性值验证，倒数第2个参数（一个类）的其中一个属性可以做属性值改变时的处理函数
        //DependencyProperty.Register("SelectedValue", typeof(string), typeof(CbxTreeRole), new PropertyMetadata("TextBox", new PropertyChangedCallback(OnTextChanged)));
        public static readonly DependencyProperty PickedDateTimeProperty = DependencyProperty.Register("PickedDateTime", typeof(string), typeof(DataTimePicker), new PropertyMetadata(onPickedDateTimeChanged));

        public string PickedDateTime  //不在此作验证
        {
            get { return (string)GetValue(PickedDateTimeProperty); }
            set { SetValue(PickedDateTimeProperty, value); }
        }

        public event RoutedEventHandler PickedDateTimeChanged
        {
            add { AddHandler(PickedDateTimeChangedEvent, value); }
            remove { RemoveHandler(PickedDateTimeChangedEvent, value); }
        }

        public static void onPickedDateTimeChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            if (e.NewValue == null) return;
            if (string.IsNullOrEmpty(e.NewValue.ToString())) return;

            RoutedEventArgs arg = new RoutedEventArgs(PickedDateTimeChangedEvent, sender);
            ((DataTimePicker)sender).RaiseEvent(arg);


            //  if(e.OldValue != null) MessageBox.Show( ((DataTimePicker)sender).Name +" : "+ e.OldValue.ToString() + "------>" + e.OldValue.ToString());


        }

        /*
        public  enum  ChangeItems   //("yyyy-MM-dd hh:mm:ss");
        {
            Year= 0,
            Month = 1,
            Day = 2,
            Hour = 3,
            Minuter = 4,
            Second = 5
        }
        */



        // private DateTime _mypickeddate ;        
        private int _myyear = 2015;
        private int _mymouth = 1;
        private int _myday = 1;

        private int _myhour = 0;
        private int _myminute = 0;
        private int _mysecond = 0;

        public DateTime selectedDateTime
        {
            get
            {
                return new DateTime(pickedyear, pickedmouth, pickedmyday, pickedhour, pickedminute, pickedsecond);

            }

            set
            {
                pickedyear = value.Year;
                pickedmouth = value.Month;
                pickedmyday = value.Day;

                pickedhour = value.Hour;
                pickedminute = value.Minute;
                pickedsecond = value.Second;
            }

        }




        public int pickedyear
        {
            get
            {
                return _myyear;
            }
            set
            {
                _myyear = value;
                DateTextBox.Text = string.Format("{0:0000}-{1:00}-{2:00}", _myyear, _mymouth, _myday);
            }

        }

        public int pickedmouth
        {
            get
            {
                return _mymouth;
            }
            set
            {
                _mymouth = value;
                DateTextBox.Text = string.Format("{0:0000}-{1:00}-{2:00}", _myyear, _mymouth, _myday);

                listBoxDD.Items.Clear();
                DateTime _dt = new DateTime(pickedyear, _mymouth, 1, pickedhour, pickedminute, pickedsecond);
                int days = DateTime.DaysInMonth(_dt.Year, _dt.Month);
                if (pickedmyday > days) pickedmyday = days;
                setDD(pickedmyday.ToString("0#"), _dt);
            }

        }


        public int pickedmyday
        {
            get
            {
                return _myday;
            }
            set
            {
                _myday = value;
                DateTextBox.Text = string.Format("{0:0000}-{1:00}-{2:00}", _myyear, _mymouth, _myday);
            }

        }

        public int pickedhour
        {
            get
            {
                return _myhour;
            }
            set
            {
                _myhour = value;
                if (_myhour < 0) _myhour = 0;
                if (_myhour > 23) _myhour = 23;

                TimeTextBox.Text = string.Format("{0:00}:{1:00}:{2:00}", _myhour, pickedminute, pickedsecond);
            }

        }

        public int pickedminute
        {
            get
            {
                return _myminute;
            }
            set
            {
                _myminute = value;
                if (_myminute < 0) _myminute = 0;
                if (_myminute > 59) _myminute = 59;

                TimeTextBox.Text = string.Format("{0:00}:{1:00}:{2:00}", pickedhour, _myminute, pickedsecond);
            }


        }

        public int pickedsecond
        {
            get
            {
                return _mysecond;
            }
            set
            {
                _mysecond = value;
                if (_mysecond < 0) _mysecond = 0;
                if (_mysecond > 59) _mysecond = 59;

                TimeTextBox.Text = string.Format("{0:00}:{1:00}:{2:00}", pickedhour, pickedminute, _mysecond);
            }

        }


        private int _changeItem = 2;

        public int changeItem
        {
            get { return _changeItem; }
            set
            {
                _changeItem = value;
            }
        }



        public DataTimePicker()
        {
            InitializeComponent();


            // addHMS();

            // setDataTime(DateTime.Now);
            DateTime nowdt = DateTime.Now;

            if (string.IsNullOrEmpty(PickedDateTime))
            {
                selectedDateTime = nowdt;
                InitDatePanl(selectedDateTime);
            }
            else
            {
                DateTime tm;
                if (DateTime.TryParse(PickedDateTime, out tm))
                {
                    selectedDateTime = tm;
                    InitDatePanl(selectedDateTime);
                }
                else
                {
                    selectedDateTime = nowdt;
                    InitDatePanl(selectedDateTime);
                }
            }





        }


        private void setYY(string _y)
        {
            if (!listBoxYY.HasItems)
            {
                for (int i = 2015; i < 2050; i++)
                {
                    ListBoxItem oneItem = new ListBoxItem();
                    oneItem.Content = i.ToString();
                    listBoxYY.Items.Add(oneItem);

                }
            }

            foreach (ListBoxItem oneItem in listBoxYY.Items)
            {
                if (oneItem.Content.ToString() == _y)
                {
                    listBoxYY.SelectedItem = oneItem;
                    return;
                }

            }

        }


        private void setMM(string _m)
        {


            if (!listBoxMM.HasItems)
            {
                for (int i = 1; i < 13; i++)
                {
                    ListBoxItem oneItem = new ListBoxItem();
                    oneItem.Content = i.ToString("0#");
                    listBoxMM.Items.Add(oneItem);

                }
            }

            foreach (ListBoxItem oneItem in listBoxMM.Items)
            {
                if (oneItem.Content.ToString() == _m)
                {
                    listBoxMM.SelectedItem = oneItem;
                    return;
                }

            }

        }


        private void setDD(string _d, DateTime _dt)
        {
            int days = DateTime.DaysInMonth(_dt.Year, _dt.Month);

            if (!listBoxDD.HasItems)
            {
                for (int i = 1; i <= days; i++)
                {
                    ListBoxItem oneItem = new ListBoxItem();
                    oneItem.Content = i.ToString("0#");
                    listBoxDD.Items.Add(oneItem);

                }
            }

            foreach (ListBoxItem oneItem in listBoxDD.Items)
            {
                if (oneItem.Content.ToString() == _d)
                {
                    listBoxDD.SelectedItem = oneItem;
                    return;
                }

            }

        }


        private void setH(string _h)
        {
            if (!listBoxH.HasItems)
            {
                for (int i = 0; i < 24; i++)
                {
                    ListBoxItem oneItem = new ListBoxItem();
                    oneItem.Content = i.ToString("0#");
                    listBoxH.Items.Add(oneItem);

                }
            }

            foreach (ListBoxItem oneItem in listBoxH.Items)
            {
                if (oneItem.Content.ToString() == _h)
                {
                    listBoxH.SelectedItem = oneItem;
                    return;
                }

            }

        }

        private void setM(string _m)
        {
            if (!listBoxM.HasItems)
            {
                for (int i = 0; i < 60; i++)
                {
                    ListBoxItem oneItem = new ListBoxItem();
                    oneItem.Content = i.ToString("0#");
                    listBoxM.Items.Add(oneItem);

                }
            }

            foreach (ListBoxItem oneItem in listBoxM.Items)
            {
                if (oneItem.Content.ToString() == _m)
                {
                    listBoxM.SelectedItem = oneItem;
                    return;
                }

            }

        }


        private void setS(string _s)
        {
            if (!listBoxS.HasItems)
            {
                for (int i = 0; i < 60; i++)
                {
                    ListBoxItem oneItem = new ListBoxItem();
                    oneItem.Content = i.ToString("0#");
                    listBoxS.Items.Add(oneItem);

                }
            }

            foreach (ListBoxItem oneItem in listBoxS.Items)
            {
                if (oneItem.Content.ToString() == _s)
                {
                    listBoxS.SelectedItem = oneItem;
                    return;
                }

            }

        }






        private void InitDatePanl(DateTime _dt)
        {
            setYY(_dt.Year.ToString());
            setMM(_dt.Month.ToString("0#"));
            setDD(_dt.Day.ToString("0#"), _dt);
            setH(_dt.Hour.ToString("0#"));
            setM(_dt.Minute.ToString("0#"));
            setS(_dt.Second.ToString("0#"));

        }






        private void addHMS()
        {
            listBoxH.Items.Clear();

            for (int i = 0; i < 24; i++)
            {
                ListBoxItem oneItem = new ListBoxItem();
                oneItem.Content = i.ToString("0#");

                listBoxH.Items.Add(oneItem);

            }

            for (int i = 0; i < 60; i++)
            {
                ListBoxItem oneItem = new ListBoxItem();
                oneItem.Content = i.ToString("0#");

                listBoxM.Items.Add(oneItem);
            }

            for (int i = 0; i < 60; i++)
            {
                ListBoxItem oneItem = new ListBoxItem();
                oneItem.Content = i.ToString("0#");

                listBoxS.Items.Add(oneItem);
            }


        }

        //左边选项鼠标划过时
        private void oneItem_MouseEnter(object sender, MouseEventArgs e)
        {
            ((TextBlock)sender).FontWeight = FontWeights.Bold;
        }
        //左边选项鼠标离开时
        private void oneItem_MouseLeave(object sender, MouseEventArgs e)
        {
            ((TextBlock)sender).FontWeight = FontWeights.Normal;
        }

        //复位选中时间
        private void textBlock0_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DateTime dt = DateTime.Now;
            if (!string.IsNullOrEmpty(PickedDateTime))
            {
                try
                {
                    selectedDateTime = DateTime.Parse(PickedDateTime);
                }
                catch
                {
                    selectedDateTime = DateTime.Now;
                }
            }
            else
            {
                selectedDateTime = dt;
            }

            InitDatePanl(selectedDateTime);
        }

        //now
        private void textBlock1_MouseDown(object sender, MouseButtonEventArgs e)
        {
            selectedDateTime = DateTime.Now;
            InitDatePanl(selectedDateTime);
        }




        //选择了新的日期


        //选择了新的日期


        //选择时间
        private void listBoxH_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                pickedhour = (int.Parse)(((ListBoxItem)(listBoxH.SelectedItem)).Content.ToString());


            }
            catch
            {

            }
        }
        private void listBoxM_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 
            try
            {
                pickedminute = (int.Parse)(((ListBoxItem)(listBoxM.SelectedItem)).Content.ToString());
            }
            catch
            {

            }
        }

        private void listBoxS_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 
            // 
            try
            {
                pickedsecond = (int.Parse)(((ListBoxItem)(listBoxS.SelectedItem)).Content.ToString());
            }
            catch
            {

            }
        }
        private void listBoxDD_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 
            // 
            try
            {
                if (listBoxDD.SelectedItem != null)
                    pickedmyday = (int.Parse)(((ListBoxItem)(listBoxDD.SelectedItem)).Content.ToString());
            }
            catch
            {

            }
        }

        private void listBoxMM_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 
            // 
            try
            {
                pickedmouth = (int.Parse)(((ListBoxItem)(listBoxMM.SelectedItem)).Content.ToString());
            }
            catch
            {

            }
        }

        private void listBoxYY_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 
            // 
            try
            {
                pickedyear = (int.Parse)(((ListBoxItem)(listBoxYY.SelectedItem)).Content.ToString());
            }
            catch
            {

            }
        }

        //日期格式检查
        private bool checkTime()
        {
            string tm = TimeTextBox.Text.Trim();
            if (tm.Length < 5) return false;
            return Regex.IsMatch(tm, @"^((20|21|22|23|[0-1]?\d):[0-5]?\d:[0-5]?\d)$");
        }

        private bool checkDate()
        {
            string dt = DateTextBox.Text.Trim();
            if (dt.Length < 8) return false;
            return Regex.IsMatch(dt, @"^(((((1[6-9]|[2-9]\d)\d{2})-(0?[13578]|1[02])-(0?[1-9]|[12]\d|3[01]))|(((1[6-9]|[2-9]\d)\d{2})-(0?[13456789]|1[012])-(0?[1-9]|[12]\d|30))|(((1[6-9]|[2-9]\d)\d{2})-0?2-(0?[1-9]|1\d|2[0-8]))|(((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))-0?2-29)))$");
        }

        private void TimeTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (checkTime())
            {
                System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 0, 0));
                TimeTextBox.Foreground = brs;
            }
            else
            {
                System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
                TimeTextBox.Foreground = brs;
            }


        }

        private void DateTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (checkDate())
            {
                System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0, 0, 0));
                DateTextBox.Foreground = brs;
            }
            else
            {
                System.Windows.Media.Brush brs = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 0, 0));
                DateTextBox.Foreground = brs;
            }
        }




        //展开时间选择面板

        //取消
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            datepopup.IsOpen = false;
        }

        //确定
        private void button_Click(object sender, RoutedEventArgs e)
        {
            PickedDateTime = selectedDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            datepopup.IsOpen = false;
        }



        private void DateTimeTextBox_MouseUp(object sender, MouseButtonEventArgs e)
        {
            // PickedDateTime = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
            datepopup.IsOpen = true;

            DateTime tm = DateTime.Now;
            if (DateTime.TryParse(PickedDateTime, out tm))
            {
                selectedDateTime = tm;
                InitDatePanl(selectedDateTime);
            }


        }

        private void DateTimeTextBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //  datepopup.IsOpen = true;
        }

        private void CalendarPicker_MouseLeave(object sender, MouseEventArgs e)
        {

        }

        private void RepeatButton_Click(object sender, RoutedEventArgs e)
        {

            timeForwardOrBack(1);
        }
        private void RepeatButton_Click_1(object sender, RoutedEventArgs e)
        {
            timeForwardOrBack(-1);
        }



        private void timeForwardOrBack(int _steep)
        {

            DateTime dt = DateTime.Now;
            if (!string.IsNullOrEmpty(PickedDateTime))
            {
                try
                {
                    dt = DateTime.Parse(PickedDateTime);
                }
                catch
                {
                    dt = DateTime.Now;
                }
            }
            else
            {
                PickedDateTime = dt.AddHours(1).ToString("yyyy-MM-dd HH:00:00");

                return;
            }

            //    DateTime.Parse(DateTime.Now.ToString("yyyy-MM-01")).AddMonths(-1).ToShortDateString();

            switch (changeItem)
            {
                case 0:
                    PickedDateTime = dt.AddYears(_steep).ToString("yyyy-MM-dd HH:mm:ss");
                    break;
                case 1:
                    PickedDateTime = dt.AddMonths(_steep).ToString("yyyy-MM-dd HH:mm:ss");

                    break;
                case 2:
                    PickedDateTime = dt.AddDays(_steep).ToString("yyyy-MM-dd HH:mm:ss");

                    break;
                case 3:
                    PickedDateTime = dt.AddHours(_steep).ToString("yyyy-MM-dd HH:mm:ss");

                    break;
                case 4:
                    PickedDateTime = dt.AddMinutes(_steep).ToString("yyyy-MM-dd HH:mm:ss");

                    break;
                case 5:
                    PickedDateTime = dt.AddSeconds(_steep).ToString("yyyy-MM-dd HH:mm:ss");

                    break;
                default:

                    break;

            }

        }

    }
}
