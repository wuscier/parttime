﻿using LAZADA.HaiWang;
using LAZADA.TasksBtns.CustomerControl;
using Logic.BasicInfo;
using Logic.Platform;
using Logic.SystemSole;
using Logic.Translation;
using PublicFunction;
using PublicFunction.AlertHelp;
using PublicFunction.ConfigHelp;
using PublicFunction.Entity.DBEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Top.Api.Response;

namespace LAZADA
{
    /// <summary>
    /// DetailsEditor.xaml 的交互逻辑
    /// </summary>
    public partial class DetailsEditor : UserControl
    {
        MainWindow mainWin = null;
        int parentCurrentPage = 1;
        string strOldTitle = "";
        public DetailsEditor(Product product, MainWindow _mainWin)
        {
            SystemSoleEntity.UpdateSelectedTab(CurrentSelectedTab.EditDetail);
            InitializeComponent();
            mainWin = _mainWin;
            this.DataContext = product;
            this.HtmlEditorDescribe.BindingContent = product.Lazadadescription;
            this.HtmlEditorSellingPoint.BindingContent = product.Lazadahighlight;

            switch (GlobalUserClass.SiteId)
            {
                case 1:
                    lblTitleMY.Content = "标题Sg";
                    break;
                case 2:
                    lblTitleMY.Content = "标题Th";
                    break;
                case 3:
                    lblTitleMY.Content = "标题My";
                    break;
                case 4:
                    lblTitleMY.Content = "标题Vn";
                    break;
                case 5:
                    lblTitleMY.Content = "标题Ph";
                    break;
                case 6:
                    lblTitleMY.Content = "标题Id";
                    break;
                case 9:
                    lblTitleMY.Content = "标题Cb";
                    break;
                default:
                    break;
            }
            if (new SystemConfigCore().SetAliAuthorization() == 0 && GlobalUserClass.GetHaiWangModel().IsAuthorized)
            {
                button.Visibility = Visibility.Visible;
            }
            else
            {
                button.Visibility = Visibility.Hidden;
            }
            AlibabaSeakingDiagnosistitleResponse rep = new HaiWangCore().Diagnosistitle(product, product.PnewtitleX, "en");
            if (rep.IsError)
            {
                label2.Content = "诊断出错！";
                ScoreDetail.Visibility = Visibility.Collapsed;
            }
            else
            {
                label2.Content = rep.TotalScore.ToString();
                ScoreDetail.ToolTip = "";
                string str = "所有大写字母词:";
                for (int a = 0; a < rep.AllUppercaseWords.Count; a++)
                {
                    str += str == "所有大写字母词:" ? rep.AllUppercaseWords[a] : ("," + rep.AllUppercaseWords[a]);
                }
                if (str != "所有大写字母词:")
                    ScoreDetail.ToolTip += str + "\n";
                if (rep.ContainCoreClasses)
                    ScoreDetail.ToolTip += "包含核心类\n";
                str = "禁用单词列表:";
                for (int a = 0; a < rep.DisableWordList.Count; a++)
                {
                    str += str == "禁用单词列表:" ? rep.DisableWordList[a] : ("," + rep.DisableWordList[a]);
                }
                if (str != "禁用单词列表:")
                    ScoreDetail.ToolTip += str + "\n";
                str = "重复的单词列表:";
                for (int a = 0; a < rep.DuplicateWordList.Count; a++)
                {
                    str += str == "重复的单词列表:" ? rep.DuplicateWordList[a] : ("," + rep.DuplicateWordList[a]);
                }
                if (str != "重复的单词列表:")
                    ScoreDetail.ToolTip += str + "\n";
                if (rep.LanguageQualityScore != "")
                    ScoreDetail.ToolTip += "语言质量分:" + rep.LanguageQualityScore + "\n";
                str = "首字母未大写单词列表:";
                for (int a = 0; a < rep.NoFirstUppercaseWordList.Count; a++)
                {
                    str += str == "首字母未大写单词列表:" ? rep.NoFirstUppercaseWordList[a] : ("," + rep.NoFirstUppercaseWordList[a]);
                }
                if (str != "首字母未大写单词列表:")
                    ScoreDetail.ToolTip += str + "\n";
                if (rep.OverLengthLimit)
                    ScoreDetail.ToolTip += "标题长度超出限制\n";
                str = "拼写错误单词列表:";
                for (int a = 0; a < rep.SpellErrorWordList.Count; a++)
                {
                    str += str == "拼写错误单词列表:" ? rep.SpellErrorWordList[a] : ("," + rep.SpellErrorWordList[a]);
                }
                if (str != "拼写错误单词列表:")
                    ScoreDetail.ToolTip += str + "\n";
            }
        }

        private void expSellingPoint_Expanded(object sender, RoutedEventArgs e)
        {

        }

        private void expSellingPoint_Collapsed(object sender, RoutedEventArgs e)
        {

        }

        private void txtKeywords_MouseLeave(object sender, MouseEventArgs e)
        {

        }

        private void txtKeywords_LostFocus(object sender, RoutedEventArgs e)
        {

        }

        private void txtKeywords_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void rTagMenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void sTagMenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void gTagMenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void txtKW_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void cmbTags_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void cmbTags_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {

        }

        private void txtTitleEn_LostFocus(object sender, RoutedEventArgs e)
        {
            var baidu = new BaiDuCore();
            if (txtTitleEn.Text == null)
                txtTitleEn.Text = "";
            Product product = (Product)DataContext;
            product.Pnewtitle = baidu.upFirstCharWithSpaceX(txtTitleEn.Text);
            product.PnewtitleX = baidu.upFirstCharWithSpaceX(new ALiCore().ChangeZhToSiteDefaultLangauge(txtTitleEn.Text));
            DataContext = product;
        }

        private void TitleSMenuItemCH_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TitleAMenuItemCH_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TitleGMenuItemCH_Click(object sender, RoutedEventArgs e)
        {

        }

        private void txtDelTitle_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            txtTitleEn.Text = "";
        }

        private void cmbTemplate_DropDownOpened(object sender, EventArgs e)
        {

        }

        private void cmbTemplate_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnRelated_Click(object sender, RoutedEventArgs e)
        {

        }

        private void popSearchTitle_Opened(object sender, EventArgs e)
        {

        }

        private void btnSaveNext_Click(object sender, RoutedEventArgs e)
        {
            if (!SaveProduct())
            {
                CMessageBox.Show("保存失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            //mainWin.myContain.Children.Clear();
            //ChooseImg userControl = new ChooseImg((Product)this.DataContext, mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);

            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "Img");
            //mainWin.RdoChioseImg_Click(null, null);
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if (SaveProduct())
            {
                CMessageBox.Show("已保存");
            }
        }

        public bool SaveProduct(bool isAuto = false)
        {
            Product product = (Product)this.DataContext;
            //if (isAuto && (product.Pstatetype != "1" || product.Pstatetype != "2"))
            //    return false;
            if (product.Pstatetype != "1")
                product.Pstatetype = "10";
            product.DetailsEditError = "";
            product.Lazadadescription = this.HtmlEditorDescribe.BindingContent;
            product.Lazadahighlight = this.HtmlEditorSellingPoint.BindingContent;
            if (product.Pnewtitle.Trim() == string.Empty)
            {
                product.DetailsEditError += "翻译前标题为空 \n";
            }
            if (product.PnewtitleX.Trim() == string.Empty)
            {
                product.DetailsEditError += "翻译后标题为空 \n";
            }
            var enTitle = (product.Pbrand ?? "") + product.PnewtitleX;
            if (enTitle.Length > 500)
            {
                product.DetailsEditError += "标题限制长度500 \n";
            }
            if (product.Lazadahighlight == string.Empty)
            {
                product.DetailsEditError += "卖点为空 \n";
            }
            if (product.Lazadadescription == string.Empty)
            {
                product.DetailsEditError += "描述头为空 \n";
            }
            return new ProductCore().UpdateDetailsEditor(product);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //mainWin.myContain.Children.Clear();
            //ChooseImg userControl = new ChooseImg((Product)this.DataContext, mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);

            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "Img");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //mainWin.myContain.Children.Clear();
            //SPUEditor userControl = new SPUEditor((Product)this.DataContext, mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);

            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "SPU");
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            if (!SaveProduct())
            {
                CMessageBox.Show("保存失败", "系统错误", CMessageBoxButton.OK, CMessageBoxImage.Error);
                return;
            }
            //mainWin.myContain.Children.Clear();
            //Tasks userControl = new Tasks(mainWin, parentCurrentPage);
            //mainWin.myContain.Children.Add(userControl);

            mainWin.ChangeChildControl((Product)this.DataContext, mainWin, "MT");
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Product product = (Product)this.DataContext;
            var baidu = new BaiDuCore();
            if (txtTitleEn.Text == null)
                txtTitleEn.Text = "";
            txtTitleEn.Text = baidu.upFirstCharWithSpaceX(txtTitleEn.Text);
            Regex reg = new Regex("[\u4e00-\u9fa5]+");
            var sourceLang = "zh";
            if (!reg.IsMatch(txtTitleEn.Text))
            {
                sourceLang = "en";
            }
            List<string> titles = new List<string>() { txtTitleEn.Text };
            List<long> categoryids = new List<long>() { Convert.ToInt64(product.Lazadacategoryid) };
            List<string> categorynames = new List<string>() { product.LazadaCategoryTreePath };
            var productPic = "";
            if (product.Pimgurl.StartsWith("http"))
            {
                productPic = product.Pimgurl;
            }
            else
            {
                try
                {
                    productPic = product.Porigimgsurl.Split(',')[0];
                }
                catch { productPic = ""; }
            }
            List<string> images = new List<string>() { productPic };
            var taskID = new HaiWangCore().PostTitleToTranslate(0, titles, categoryids, categorynames, images, sourceLang);

            string url = GlobalUserClass.GetHaiWangModel().CreateURLByTaskID(Constants.HAIWANG_FUN_TITLE_URL, taskID);
            WinMyWebBrowser win = new WinMyWebBrowser("标题翻译", url);
            win.ShowDialog();
            List<string> transtitleList = new HaiWangCore().GetTranslateTitle(taskID);
            //txtTitleMY.Text = transtitleList.FirstOrDefault();
            string title = transtitleList.FirstOrDefault();
            if (title != null && title.Length > 0)
            {
                product.PnewtitleX = title;
                product.TitleTaskId = taskID;
                new ProductCore().UpdateTitleTaskID(product);
            }
            //product.PnewtitleX= transtitleList.FirstOrDefault();
            //txtTitleMY.Text = baidu.upFirstCharWithSpaceX(new HaiWangCore().TranslateZhToSiteDefaultResponse(txtTitleEn.Text));
        }
        //一键智能优化
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Product product = (Product)this.DataContext;
            strOldTitle = txtTitleMY.Text;
            txtTitleMY.Text = new HaiWangCore().Aititlegenerate(product, txtTitleMY.Text, "en");
            //product.PnewtitleX = new HaiWangCore().Aititlegenerate(product, txtTitleMY.Text, !reg.IsMatch(txtTitleMY.Text, 0) ? "en" : "zn");

        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            if (strOldTitle != "")
            {
                Product product = (Product)this.DataContext;
                product.PnewtitleX = strOldTitle;
                strOldTitle = "";
            }
        }
    }
}
